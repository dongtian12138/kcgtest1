# 已退役 B 阶段抓取路线索引

本目录保存 2026-08-20 被 `CARTS-GRASP-CROSS-OBJECT-V1` 明确覆盖的旧路线。2026-08-21 工程清理只移动了内容，没有删除或改写旧代码、配置、测试和说明。

## 归档原因

- `B_GOAL_MODE` 使用对象专用圆柱近似、固定候选和经验门限；当前只允许作为 baseline。
- `B_FAST_PICK_V1`、`B_MINIMAL_V2` 和 PAD SDF/胶囊兼容性链用于旧 B 阶段诊断，不属于当前跨对象 CARTS-Grasp 候选生成或控制路径。
- 当前 `grasp/robust`、`isaac/robust_grasp`、CARTS 配置和 `test/robust_grasp` 的引用审计未发现对这些模块的依赖。

## 路径映射

- `root_backups/`：原根目录的 4 组 `.b_minimal_v2*_backup_*`。
- `root_entrypoints/`：原根目录的直接接管说明、GUI 说明、B 启动和验证脚本。
- `src/kcg_connector/config/`：旧 B_GOAL_MODE、fast-pick 和 minimal-v2 配置。
- `src/kcg_connector/isaac/`：旧 B runner、PAD 构建器和兼容性 smoke。
- `src/kcg_connector/kcg_connector/grasp/`：旧候选、控制器和 PAD 角色模块。
- `src/kcg_connector/test/`：只验证上述退役路线的测试。

## 使用边界

1. 不参加当前默认测试、Isaac 运行或正式验收。
2. 历史控制文件中的原路径用于证据追溯；若要复现旧路线，应从本目录复制到独立临时工作树，不能直接混回当前源码。
3. 归档不改变旧运行的证据等级：旧数值或 GUI 结果仍不是 `B_FORMAL_DYNAMIC_PASS`。
4. 当前主线、冻结模型、TE/J599 对象、质量/质心、安全门和真值防火墙均未因归档改变。
