#!/usr/bin/env python3
"""Isolated, mesh-free D38999 three-pad table-pick baseline (B_MINIMAL_V2).

The runner deliberately avoids the historical H1--H25 control stack and all
mesh collision cooking.  It imports the real hand joint topology and inertias,
uses exactly one conservative analytic capsule at the centre of each
user-confirmed blue pad, initializes every active and mimic joint before the
first explicit physics step, then executes a statically swept approach and a
minimum-jerk vertical lift.

This is a diagnostic B-stage baseline, not a formal full-iiwa B pass.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np
import yaml

from kcg_connector.grasp.d38999_b_minimal_v2 import (
    ACTIVE_CONTROL_JOINTS,
    ACTIVE_TERMINAL_LINKS,
    FOLLOWER_JOINTS,
    HAND_JOINT_ORDER,
    ROOT_TORQUE_JOINTS,
    SCHEMA as CANDIDATE_SCHEMA,
    selected_central_capsules,
    sha256,
)


REPOSITORY = Path(__file__).resolve().parents[3]
DEFAULT_CONFIG = REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2.yaml"
DEFAULT_CANDIDATES = (
    REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json"
)
DEFAULT_PROXY = (
    REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
)
DEFAULT_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
RESULT_SCHEMA = "D38999_B_MINIMAL_V2_RESULT"
HAND_LINKS = (
    "handbase_link",
    "f1Link1",
    "f1Link2",
    "f1Link3",
    "f2Link1",
    "f2Link2",
    "f3Link1",
    "f3Link2",
    "f3Link3",
)
ALL_HAND_DOFS = HAND_JOINT_ORDER


class RuntimeStateError(RuntimeError):
    """Raised after a machine-readable runtime diagnostic has been persisted."""

    def __init__(self, message: str, diagnostic: Mapping[str, Any]):
        super().__init__(message)
        self.diagnostic = dict(diagnostic)


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--scenario",
        choices=("hand_stability", "offtable_grasp", "table_pick"),
        default="table_pick",
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--candidates", default=str(DEFAULT_CANDIDATES))
    parser.add_argument("--proxy-manifest", default=str(DEFAULT_PROXY))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--candidate-id", default="PAD_CORE_Z12")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--gui", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args(argv)


def _rpy_matrix(rpy: Sequence[float]) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.asarray(
        (
            (cp * cy, sr * sp * cy - cr * sy, cr * sp * cy + sr * sy),
            (cp * sy, sr * sp * sy + cr * cy, cr * sp * sy - sr * cy),
            (-sp, sr * cp, cr * cp),
        ),
        dtype=np.float64,
    )


def _matrix_to_rpy(matrix: np.ndarray) -> tuple[float, float, float]:
    # XYZ fixed-axis convention, matching URDF rpy.
    pitch = math.asin(float(np.clip(-matrix[2, 0], -1.0, 1.0)))
    if abs(math.cos(pitch)) > 1.0e-9:
        roll = math.atan2(matrix[2, 1], matrix[2, 2])
        yaw = math.atan2(matrix[1, 0], matrix[0, 0])
    else:
        roll = math.atan2(-matrix[1, 2], matrix[1, 1])
        yaw = 0.0
    return float(roll), float(pitch), float(yaw)


def _quat_wxyz_to_matrix(quaternion: Sequence[float]) -> np.ndarray:
    values = np.asarray(quaternion, dtype=np.float64)
    if values.shape != (4,) or not np.all(np.isfinite(values)):
        raise ValueError("quaternion must contain four finite values")
    norm = float(np.linalg.norm(values))
    if norm <= 1.0e-15:
        raise ValueError("quaternion norm must be positive")
    w, x, y, z = values / norm
    return np.asarray(
        (
            (1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)),
            (2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)),
            (2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)),
        ),
        dtype=np.float64,
    )


def _tilt_angle_rad(initial: Sequence[float], final: Sequence[float]) -> float:
    first_axis = _quat_wxyz_to_matrix(initial)[:, 2]
    final_axis = _quat_wxyz_to_matrix(final)[:, 2]
    return float(math.acos(float(np.clip(first_axis @ final_axis, -1.0, 1.0))))


def _load_inputs(arguments: argparse.Namespace) -> tuple[
    dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]
]:
    config = yaml.safe_load(Path(arguments.config).read_text(encoding="utf-8"))
    candidates = json.loads(Path(arguments.candidates).read_text(encoding="utf-8"))
    proxy = json.loads(Path(arguments.proxy_manifest).read_text(encoding="utf-8"))
    if config.get("schema_version") != "d38999_b_minimal_v2":
        raise ValueError("unexpected B_MINIMAL_V2 config schema")
    if candidates.get("schema") != CANDIDATE_SCHEMA:
        raise ValueError("unexpected B_MINIMAL_V2 candidate schema")
    if candidates.get("status") != "STATIC_SWEEP_PASS_AWAITING_ISAAC":
        raise ValueError("candidate manifest has not passed static sweep")
    if proxy.get("collision_route") != "B_MINIMAL_V2_PAD_CORE_ANALYTIC_CAPSULES":
        raise ValueError("unexpected PAD-core route")
    if proxy.get("diagnostic_dynamic_use_allowed") is not True:
        raise ValueError("PAD-core diagnostic use is not authorized")
    if proxy.get("formal_b_use_allowed") is not False:
        raise ValueError("PAD-core snapshot must remain diagnostic-only")
    if proxy.get("whole_terminal_convex_hull_count") != 0:
        raise ValueError("old whole-terminal convex hull is forbidden")
    if sha256(arguments.source_urdf) != candidates.get("source_urdf_sha256"):
        raise ValueError("source URDF changed after candidate generation")
    if sha256(arguments.proxy_manifest) != candidates.get("source_proxy_manifest_sha256"):
        raise ValueError("PAD proxy manifest changed after candidate generation")
    matching = [
        row
        for row in candidates.get("candidates", [])
        if row.get("candidate_id") == arguments.candidate_id
    ]
    if len(matching) != 1:
        raise ValueError(f"candidate missing or duplicated: {arguments.candidate_id}")
    candidate = matching[0]
    checks = candidate.get("sweep_metrics")
    if not checks:
        raise ValueError("candidate has no sweep metrics")
    numeric_tolerance = 1.0e-12
    if float(checks["minimum_table_clearance_m"]) + numeric_tolerance < float(
        config["static_preflight"]["minimum_table_clearance_m"]
    ):
        raise ValueError("candidate table clearance is below config gate")
    if float(checks["maximum_final_object_penetration_m"]) > float(
        config["static_preflight"]["maximum_final_object_penetration_m"]
    ) + numeric_tolerance:
        raise ValueError("candidate final preload is above config gate")
    return config, candidates, proxy, candidate


def _inertial_link(name: str) -> ET.Element:
    link = ET.Element("link", {"name": name})
    inertial = ET.SubElement(link, "inertial")
    ET.SubElement(inertial, "origin", {"xyz": "0 0 0", "rpy": "0 0 0"})
    ET.SubElement(inertial, "mass", {"value": "1.0"})
    ET.SubElement(
        inertial,
        "inertia",
        {
            "ixx": "0.01",
            "ixy": "0",
            "ixz": "0",
            "iyy": "0.01",
            "iyz": "0",
            "izz": "0.01",
        },
    )
    return link


def _element_digest(element: ET.Element) -> str:
    normalized = copy.deepcopy(element)
    for node in normalized.iter():
        node.tail = None
    return hashlib.sha256(ET.tostring(normalized, encoding="utf-8")).hexdigest()


def _candidate_world_geometry(
    config: Mapping[str, Any],
    candidate: Mapping[str, Any],
    *,
    scenario: str = "table_pick",
) -> dict[str, Any]:
    rotation = _rpy_matrix(config["hand_mount"]["rpy_rad"])
    object_center_key = (
        "offtable_world_center_m" if scenario == "offtable_grasp" else "world_center_m"
    )
    object_world = np.asarray(config["object"][object_center_key], dtype=np.float64)
    object_hand = np.asarray(
        (
            candidate["object_axis_center_xy_hand_m"][0],
            candidate["object_axis_center_xy_hand_m"][1],
            candidate["object_center_z_hand_m"],
        ),
        dtype=np.float64,
    )
    handbase_final = object_world - rotation @ object_hand
    world_up_in_joint = rotation.T @ np.array((0.0, 0.0, 1.0), dtype=np.float64)
    world_up_in_joint /= np.linalg.norm(world_up_in_joint)
    return {
        "rotation_world_from_hand": rotation.tolist(),
        "hand_mount_rpy_rad": [float(value) for value in config["hand_mount"]["rpy_rad"]],
        "handbase_final_world_m": handbase_final.tolist(),
        "lift_axis_in_joint_frame": world_up_in_joint.tolist(),
        "object_world_center_m": object_world.tolist(),
        "object_center_hand_m": object_hand.tolist(),
    }


def _build_minimal_urdf(
    *,
    source_urdf: Path,
    destination: Path,
    geometry: Mapping[str, Any],
) -> dict[str, Any]:
    source_root = ET.parse(source_urdf).getroot()
    source_links = {str(link.get("name")): link for link in source_root.findall("link")}
    source_joints = {str(joint.get("name")): joint for joint in source_root.findall("joint")}
    output = ET.Element("robot", {"name": "d38999_b_minimal_v2"})
    output.append(_inertial_link("rig_base_link"))
    inertial_hashes: dict[str, str] = {}
    removed_visuals = 0
    removed_collisions = 0
    for name in HAND_LINKS:
        source = source_links.get(name)
        if source is None:
            raise ValueError(f"source URDF missing link: {name}")
        copied = copy.deepcopy(source)
        inertial = copied.find("inertial")
        if inertial is None:
            raise ValueError(f"source URDF missing inertial: {name}")
        inertial_hashes[name] = _element_digest(inertial)
        for visual in list(copied.findall("visual")):
            copied.remove(visual)
            removed_visuals += 1
        for collision in list(copied.findall("collision")):
            copied.remove(collision)
            removed_collisions += 1
        output.append(copied)

    lift = ET.SubElement(output, "joint", {"name": "lift_z", "type": "prismatic"})
    ET.SubElement(lift, "parent", {"link": "rig_base_link"})
    ET.SubElement(lift, "child", {"link": "handbase_link"})
    ET.SubElement(
        lift,
        "origin",
        {
            "xyz": " ".join(
                f"{float(value):.12g}" for value in geometry["handbase_final_world_m"]
            ),
            "rpy": " ".join(
                f"{float(value):.12g}" for value in geometry["hand_mount_rpy_rad"]
            ),
        },
    )
    ET.SubElement(
        lift,
        "axis",
        {
            "xyz": " ".join(
                f"{float(value):.12g}"
                for value in geometry["lift_axis_in_joint_frame"]
            )
        },
    )
    ET.SubElement(
        lift,
        "limit",
        {"lower": "0", "upper": "0.060", "effort": "500", "velocity": "0.10"},
    )
    ET.SubElement(lift, "dynamics", {"damping": "20", "friction": "0"})

    for name in HAND_JOINT_ORDER:
        source = source_joints.get(name)
        if source is None:
            raise ValueError(f"source URDF missing joint: {name}")
        output.append(copy.deepcopy(source))

    tree = ET.ElementTree(output)
    ET.indent(tree, space="  ")
    tree.write(destination, encoding="utf-8", xml_declaration=True)

    check = ET.parse(destination).getroot()
    parented = {joint.find("child").get("link") for joint in check.findall("joint")}
    roots = [link.get("name") for link in check.findall("link") if link.get("name") not in parented]
    if roots != ["rig_base_link"]:
        raise AssertionError(f"minimal URDF must have one root, got {roots}")
    for name in HAND_LINKS:
        link = check.find(f"link[@name='{name}']")
        if link is None or link.findall("visual") or link.findall("collision"):
            raise AssertionError(f"minimal URDF retained mesh geometry on {name}")
        if _element_digest(link.find("inertial")) != inertial_hashes[name]:
            raise AssertionError(f"minimal URDF changed inertial on {name}")
    return {
        "source_urdf": str(source_urdf),
        "source_urdf_sha256": sha256(source_urdf),
        "temporary_urdf": str(destination),
        "root_links": roots,
        "removed_visual_count": removed_visuals,
        "removed_collision_count": removed_collisions,
        "mesh_collision_count": 0,
        "real_hand_inertials_preserved": True,
        "lift_joint_count": 1,
        "extra_fixed_mount_joint_count": 0,
    }


def _dry_run(arguments: argparse.Namespace) -> dict[str, Any]:
    config, candidates, proxy, candidate = _load_inputs(arguments)
    geometry = _candidate_world_geometry(config, candidate, scenario=arguments.scenario)
    output = Path(arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    urdf_path = output / "d38999_b_minimal_v2.urdf"
    evidence = _build_minimal_urdf(
        source_urdf=Path(arguments.source_urdf).resolve(),
        destination=urdf_path,
        geometry=geometry,
    )
    selected = selected_central_capsules(proxy)
    report = {
        "schema": RESULT_SCHEMA,
        "status": "DRY_RUN_PASS",
        "scenario": arguments.scenario,
        "candidate": candidate,
        "geometry": geometry,
        "rig_urdf": evidence,
        "selected_pad_capsules": {
            link: selected[link]["capsule"] for link in ACTIVE_TERMINAL_LINKS
        },
        "pad_primitive_count": 3,
        "whole_terminal_convex_hull_count": 0,
        "source_proxy_dynamic_use_allowed": bool(
            proxy.get("source_proxy_dynamic_use_allowed", False)
        ),
        "diagnostic_pad_core_dynamic_use_allowed": bool(
            proxy.get("diagnostic_dynamic_use_allowed", False)
        ),
        "minimal_v2_override_scope": "DIAGNOSTIC_ONE_CENTRAL_PAD_CAPSULE_PER_FINGER",
        "formal_b_passed": False,
    }
    _write_json(output / "B_MINIMAL_V2_DRY_RUN_RESULT.json", report)
    return report


def _runtime_error_diagnostic(
    *,
    output: Path,
    phase: str,
    phase_step: int,
    global_step: int,
    dof_names: Sequence[str],
    positions: np.ndarray,
    velocities: np.ndarray,
    efforts: np.ndarray,
    targets: Mapping[str, float],
    recent_trace: Sequence[Mapping[str, Any]],
    reason: str,
) -> dict[str, Any]:
    channels: dict[str, Any] = {}
    for name, values in (
        ("joint_positions", positions),
        ("joint_velocities", velocities),
        ("joint_efforts", efforts),
    ):
        bad = np.flatnonzero(~np.isfinite(values))
        channels[name] = {
            "nonfinite_indices": bad.astype(int).tolist(),
            "nonfinite_dof_names": [
                str(dof_names[index]) if index < len(dof_names) else f"index_{index}"
                for index in bad
            ],
            "values": [
                None if not math.isfinite(float(value)) else float(value)
                for value in values
            ],
        }
    diagnostic = {
        "schema": "D38999_B_MINIMAL_V2_RUNTIME_DIAGNOSTIC",
        "reason": reason,
        "phase": phase,
        "phase_step": int(phase_step),
        "global_step": int(global_step),
        "targets": {name: float(value) for name, value in targets.items()},
        "channels": channels,
        "recent_trace": list(recent_trace)[-20:],
    }
    _write_json(output / "B_MINIMAL_V2_RUNTIME_DIAGNOSTIC.json", diagnostic)
    return diagnostic


def _run_isaac(arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation, SingleRigidPrim
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    import omni.usd
    from pxr import Gf, PhysicsSchemaTools, PhysxSchema, Sdf, Usd, UsdGeom, UsdPhysics, UsdShade

    config, candidates, proxy, candidate = _load_inputs(arguments)
    selected = selected_central_capsules(proxy)
    output = Path(arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    geometry = _candidate_world_geometry(config, candidate, scenario=arguments.scenario)
    rig_urdf = output / "d38999_b_minimal_v2.urdf"
    urdf_evidence = _build_minimal_urdf(
        source_urdf=Path(arguments.source_urdf).resolve(),
        destination=rig_urdf,
        geometry=geometry,
    )

    import_dir = output / "rig_usd"
    import_dir.mkdir()
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=str(rig_urdf),
            usd_path=str(import_dir),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    if not imported_path.exists():
        raise RuntimeError(f"URDF import failed: {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(config["simulation"]["physics_rate_hz"]),
        rendering_dt=1.0 / float(config["simulation"]["rendering_rate_hz"]),
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/MinimalRig")

    articulation_roots = [
        prim for prim in stage.Traverse() if prim.HasAPI(UsdPhysics.ArticulationRootAPI)
    ]
    if len(articulation_roots) != 1:
        raise RuntimeError(
            f"B_MINIMAL_V2 requires exactly one articulation root, got "
            f"{[str(prim.GetPath()) for prim in articulation_roots]}"
        )
    articulation_root = articulation_roots[0]
    imported_collisions = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(articulation_root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if imported_collisions:
        raise RuntimeError(f"mesh-free minimal rig imported collisions: {imported_collisions}")

    physics_scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(physics_scenes) != 1:
        raise RuntimeError("expected exactly one physics scene")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(-9.81)

    material_scope = "/World/PhysicsMaterials"
    UsdGeom.Scope.Define(stage, material_scope)

    def material(path: str, static: float, dynamic: float) -> Any:
        result = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(result.GetPrim())
        api.CreateStaticFrictionAttr(float(static))
        api.CreateDynamicFrictionAttr(float(dynamic))
        api.CreateRestitutionAttr(0.0)
        return result

    pad_material = material(
        material_scope + "/PAD",
        config["friction"]["pad_object"],
        config["friction"]["pad_object"],
    )
    object_material = material(
        material_scope + "/OBJECT",
        config["friction"]["pad_object"],
        config["friction"]["pad_object"],
    )
    table_material = material(
        material_scope + "/TABLE",
        config["friction"]["table_static"],
        config["friction"]["table_dynamic"],
    )

    terminal_prims: dict[str, Any] = {}
    pad_paths_by_finger: dict[str, set[str]] = {}
    pad_collision_apis: list[Any] = []
    for link_name in ACTIVE_TERMINAL_LINKS:
        matches = [
            prim
            for prim in stage.Traverse()
            if prim.GetName() == link_name and prim.HasAPI(UsdPhysics.RigidBodyAPI)
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one rigid prim for {link_name}, got {len(matches)}")
        terminal = matches[0]
        if terminal.IsInstanceProxy():
            raise RuntimeError(f"terminal is an instance proxy: {terminal.GetPath()}")
        if terminal.IsInstance():
            terminal.SetInstanceable(False)
            terminal = stage.GetPrimAtPath(terminal.GetPath())
        terminal_prims[link_name] = terminal
        PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
        capsule = selected[link_name]["capsule"]
        path = str(terminal.GetPath()) + "/PAD_CORE_CAPSULE"
        geometry_prim = UsdGeom.Capsule.Define(stage, path)
        geometry_prim.CreateAxisAttr(UsdGeom.Tokens.z)
        geometry_prim.CreateRadiusAttr(float(capsule["radius_m"]))
        geometry_prim.CreateHeightAttr(float(capsule["cylinder_height_m"]))
        xform = UsdGeom.Xformable(geometry_prim)
        xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
        rotation = Gf.Rotation(
            Gf.Vec3d(0.0, 0.0, 1.0), Gf.Vec3d(*capsule["axis_unit_local"])
        )
        xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
        collision_api = UsdPhysics.CollisionAPI.Apply(geometry_prim.GetPrim())
        collision_api.CreateCollisionEnabledAttr(False)
        pad_collision_apis.append(collision_api)
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(geometry_prim.GetPrim())
        physx_collision.CreateContactOffsetAttr(float(config["collision"]["contact_offset_m"]))
        physx_collision.CreateRestOffsetAttr(float(config["collision"]["rest_offset_m"]))
        UsdShade.MaterialBindingAPI(geometry_prim.GetPrim()).Bind(
            pad_material, materialPurpose="physics"
        )
        geometry_prim.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set("PAD_CORE_PROXY")
        geometry_prim.GetPrim().CreateAttribute("kcg:finger", Sdf.ValueTypeNames.Token).Set(
            link_name
        )
        pad_paths_by_finger[link_name] = {path}

    table = UsdGeom.Cube.Define(stage, "/World/Table")
    table.CreateSizeAttr(1.0)
    table_xform = UsdGeom.Xformable(table)
    half_xy = float(config["table"]["half_extent_xy_m"])
    thickness = float(config["table"]["thickness_m"])
    top_z = float(config["table"]["top_z_m"])
    table_xform.AddTranslateOp().Set(Gf.Vec3d(0.0, 0.0, top_z - 0.5 * thickness))
    table_xform.AddScaleOp().Set(Gf.Vec3f(2.0 * half_xy, 2.0 * half_xy, thickness))
    table_collision_api = UsdPhysics.CollisionAPI.Apply(table.GetPrim())
    table_collision_api.CreateCollisionEnabledAttr(arguments.scenario == "table_pick")
    UsdShade.MaterialBindingAPI(table.GetPrim()).Bind(table_material, materialPurpose="physics")

    object_path = "/World/FastConnector"
    obj = UsdGeom.Cylinder.Define(stage, object_path)
    obj.CreateAxisAttr(UsdGeom.Tokens.z)
    obj.CreateRadiusAttr(float(config["object"]["radius_m"]))
    obj.CreateHeightAttr(float(config["object"]["height_m"]))
    obj_xform = UsdGeom.Xformable(obj)
    obj_xform.AddTranslateOp().Set(Gf.Vec3d(*geometry["object_world_center_m"]))
    object_collision_api = UsdPhysics.CollisionAPI.Apply(obj.GetPrim())
    object_collision_api.CreateCollisionEnabledAttr(False)
    object_rigid = UsdPhysics.RigidBodyAPI.Apply(obj.GetPrim())
    object_rigid.CreateRigidBodyEnabledAttr(True)
    object_rigid.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(obj.GetPrim()).CreateMassAttr(float(config["object"]["mass_kg"]))
    object_contact = PhysxSchema.PhysxCollisionAPI.Apply(obj.GetPrim())
    object_contact.CreateContactOffsetAttr(float(config["collision"]["contact_offset_m"]))
    object_contact.CreateRestOffsetAttr(float(config["collision"]["rest_offset_m"]))
    UsdShade.MaterialBindingAPI(obj.GetPrim()).Bind(object_material, materialPurpose="physics")
    PhysxSchema.PhysxContactReportAPI.Apply(obj.GetPrim()).CreateThresholdAttr().Set(0.0)

    robot = world.scene.add(
        SingleArticulation(prim_path=str(articulation_root.GetPath()), name="b_minimal_v2")
    )
    object_view = world.scene.add(SingleRigidPrim(prim_path=object_path, name="fast_connector"))

    stage_path = output / "B_MINIMAL_V2_STAGE.usda"
    trace_path = output / "B_MINIMAL_V2_TRACE.csv"
    result_path = output / "B_MINIMAL_V2_RESULT.json"
    world.reset()

    dof_names = list(robot.dof_names)
    required = ("lift_z",) + ALL_HAND_DOFS
    missing = [name for name in required if name not in dof_names]
    if missing:
        raise RuntimeError(f"minimal articulation missing DOFs: {missing}; got {dof_names}")
    indices = {name: dof_names.index(name) for name in required}
    if len(set(indices.values())) != len(indices):
        raise RuntimeError(f"duplicate DOF indices: {indices}")

    controller = robot.get_articulation_controller()
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[indices["lift_z"]] = float(config["joint_control"]["lift_kp"])
    kds[indices["lift_z"]] = float(config["joint_control"]["lift_kd"])
    for name in ACTIVE_CONTROL_JOINTS:
        kps[indices[name]] = float(config["joint_control"]["finger_kp"])
        kds[indices[name]] = float(config["joint_control"]["finger_kd"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

    initial_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initial_positions[indices["lift_z"]] = float(candidate["approach_lift_m"])
    initial_positions[indices["f1j1"]] = float(candidate["open_preshape_rad"])
    initial_positions[indices["f3j1"]] = float(candidate["open_preshape_rad"])
    for name in ("f1j2", "f1j3", "f2j1", "f2j2", "f3j2", "f3j3"):
        initial_positions[indices[name]] = float(candidate["open_flexion_rad"])
    robot.set_joint_positions(initial_positions.astype(np.float32))
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))

    initialized_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initialized_velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
    if not np.all(np.isfinite(initialized_positions)) or not np.all(
        np.isfinite(initialized_velocities)
    ):
        raise RuntimeError("non-finite articulation immediately after explicit initialization")
    maximum_initial_error = float(np.max(np.abs(initialized_positions - initial_positions)))
    if maximum_initial_error > float(config["initialization"]["maximum_position_error_rad"]):
        raise RuntimeError(
            f"explicit initial joint state did not latch; max error={maximum_initial_error}"
        )

    current_targets = {
        "lift_z": float(candidate["approach_lift_m"]),
        "f1j1": float(candidate["open_preshape_rad"]),
        "f1j2": float(candidate["open_flexion_rad"]),
        "f2j1": float(candidate["open_flexion_rad"]),
        "f3j2": float(candidate["open_flexion_rad"]),
    }

    # Enable all contact only after the complete articulation state has been
    # explicitly initialized. No explicit physics step has occurred yet.
    if arguments.scenario in ("offtable_grasp", "table_pick"):
        for api in pad_collision_apis:
            api.GetCollisionEnabledAttr().Set(True)
        object_collision_api.GetCollisionEnabledAttr().Set(True)
        # In the off-table capacity diagnostic the object remains kinematic only
        # while the three pads establish preload.  It is released exactly once
        # after GRIP_SETTLE and is never pose-written afterwards.
        object_rigid.GetKinematicEnabledAttr().Set(
            arguments.scenario == "offtable_grasp"
        )
    else:
        # Hand-stability scenario intentionally executes with zero collisions.
        object_collision_api.GetCollisionEnabledAttr().Set(False)
        object_rigid.GetKinematicEnabledAttr().Set(True)

    stage.Export(str(stage_path))

    interface = get_physx_simulation_interface()
    rate = float(config["simulation"]["physics_rate_hz"])
    trace_rows: list[dict[str, Any]] = []
    recent_rows: list[dict[str, Any]] = []
    pad_impulse_by_finger = {name: 0.0 for name in ACTIVE_TERMINAL_LINKS}
    table_impulse_total = 0.0
    first_step_wall_s: float | None = None
    maximum_joint_speed = 0.0
    initial_object_position_raw, initial_object_orientation_raw = object_view.get_world_pose()
    initial_object_position = np.asarray(initial_object_position_raw, dtype=np.float64)
    initial_object_orientation = np.asarray(initial_object_orientation_raw, dtype=np.float64)
    trace_fields = [
        "step",
        "phase",
        "phase_step",
        "lift_target_m",
        "lift_position_m",
        "f1j1_target_rad",
        "f1j2_target_rad",
        "f2j1_target_rad",
        "f3j2_target_rad",
        *[f"{name}_position_rad" for name in required],
        *[f"{name}_velocity_rad_s" for name in required],
        *[f"{name}_effort_nm" for name in ROOT_TORQUE_JOINTS],
        "f1_pad_force_n",
        "f2_pad_force_n",
        "f3_pad_force_n",
        "table_force_n",
        "step_wall_s",
    ]
    trace_stream = trace_path.open("w", newline="", encoding="utf-8")
    trace_writer = csv.DictWriter(trace_stream, fieldnames=trace_fields)
    trace_writer.writeheader()
    trace_stream.flush()

    def apply_targets() -> None:
        names = tuple(current_targets)
        robot.apply_action(
            ArticulationAction(
                joint_positions=np.asarray(
                    [current_targets[name] for name in names], dtype=np.float32
                ),
                joint_indices=np.asarray([indices[name] for name in names], dtype=np.int32),
            )
        )

    def sample_contacts() -> tuple[dict[str, float], float]:
        per_finger = {name: 0.0 for name in ACTIVE_TERMINAL_LINKS}
        table_impulse = 0.0
        headers, contacts, _friction = interface.get_full_contact_report()
        for header in headers:
            collider0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
            collider1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
            pair = {collider0, collider1}
            start = int(header.contact_data_offset)
            stop = start + int(header.num_contact_data)
            impulse = sum(
                float(np.linalg.norm(np.asarray(contact.impulse, dtype=np.float64)))
                for contact in contacts[start:stop]
            )
            if object_path in pair and "/World/Table" in pair:
                table_impulse += impulse
            if object_path in pair:
                for finger, paths in pad_paths_by_finger.items():
                    if any(path in pair for path in paths):
                        per_finger[finger] += impulse
        return per_finger, table_impulse

    def step(phase: str, phase_step: int) -> np.ndarray:
        nonlocal first_step_wall_s, maximum_joint_speed, table_impulse_total
        apply_targets()
        started = time.perf_counter()
        world.step(render=bool(arguments.gui))
        wall = time.perf_counter() - started
        if first_step_wall_s is None:
            first_step_wall_s = wall
            if wall > float(config["simulation"]["first_physics_step_deadline_s"]):
                diagnostic = {
                    "schema": "D38999_B_MINIMAL_V2_RUNTIME_DIAGNOSTIC",
                    "reason": "FIRST_PHYSICS_STEP_DEADLINE_EXCEEDED",
                    "first_step_wall_s": wall,
                    "deadline_s": float(
                        config["simulation"]["first_physics_step_deadline_s"]
                    ),
                }
                _write_json(output / "B_MINIMAL_V2_RUNTIME_DIAGNOSTIC.json", diagnostic)
                raise RuntimeStateError("first physics step deadline exceeded", diagnostic)
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts_full = np.asarray(
            robot.get_measured_joint_efforts(
                joint_indices=np.arange(robot.num_dof, dtype=np.int32)
            ),
            dtype=np.float64,
        )
        root_efforts = efforts_full[
            np.asarray([indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32)
        ]
        if not (
            np.all(np.isfinite(positions))
            and np.all(np.isfinite(velocities))
            and np.all(np.isfinite(efforts_full))
        ):
            diagnostic = _runtime_error_diagnostic(
                output=output,
                phase=phase,
                phase_step=phase_step,
                global_step=len(trace_rows) + 1,
                dof_names=dof_names,
                positions=positions,
                velocities=velocities,
                efforts=efforts_full,
                targets=current_targets,
                recent_trace=recent_rows,
                reason="NONFINITE_ARTICULATION_STATE",
            )
            stage.Export(str(output / "B_MINIMAL_V2_FAILURE_STAGE.usda"))
            raise RuntimeStateError("non-finite articulation state", diagnostic)
        speed = float(np.max(np.abs(velocities)))
        maximum_joint_speed = max(maximum_joint_speed, speed)
        if speed > float(config["runtime_guards"]["maximum_joint_speed_rad_s"]):
            diagnostic = _runtime_error_diagnostic(
                output=output,
                phase=phase,
                phase_step=phase_step,
                global_step=len(trace_rows) + 1,
                dof_names=dof_names,
                positions=positions,
                velocities=velocities,
                efforts=efforts_full,
                targets=current_targets,
                recent_trace=recent_rows,
                reason="JOINT_SPEED_GUARD",
            )
            diagnostic["maximum_joint_speed_rad_s"] = speed
            _write_json(output / "B_MINIMAL_V2_RUNTIME_DIAGNOSTIC.json", diagnostic)
            stage.Export(str(output / "B_MINIMAL_V2_FAILURE_STAGE.usda"))
            raise RuntimeStateError("joint speed guard", diagnostic)
        per_finger, table_impulse = sample_contacts()
        for finger, impulse in per_finger.items():
            pad_impulse_by_finger[finger] += impulse
        table_impulse_total += table_impulse
        row: dict[str, Any] = {
            "step": len(trace_rows) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "lift_target_m": current_targets["lift_z"],
            "lift_position_m": float(positions[indices["lift_z"]]),
            "f1j1_target_rad": current_targets["f1j1"],
            "f1j2_target_rad": current_targets["f1j2"],
            "f2j1_target_rad": current_targets["f2j1"],
            "f3j2_target_rad": current_targets["f3j2"],
            "f1_pad_force_n": per_finger["f1Link3"] * rate,
            "f2_pad_force_n": per_finger["f2Link2"] * rate,
            "f3_pad_force_n": per_finger["f3Link3"] * rate,
            "table_force_n": table_impulse * rate,
            "step_wall_s": wall,
        }
        for name in required:
            row[f"{name}_position_rad"] = float(positions[indices[name]])
            row[f"{name}_velocity_rad_s"] = float(velocities[indices[name]])
        for name, value in zip(ROOT_TORQUE_JOINTS, root_efforts):
            row[f"{name}_effort_nm"] = float(value)
        trace_writer.writerow(row)
        trace_stream.flush()
        trace_rows.append(row)
        recent_rows.append(row)
        if len(recent_rows) > 20:
            del recent_rows[0]
        return root_efforts

    try:
        # Always validate the initialized articulation before contact is enabled.
        # In table_pick contact was enabled above, but the static sweep guarantees
        # a 3 mm gap at the raised/open state.
        stability_steps = int(config["trajectory"]["initial_stability_steps"])
        tare_samples: list[np.ndarray] = []
        for index in range(stability_steps):
            efforts = step("INITIAL_STABILITY", index)
            tare_samples.append(efforts)
        tare = np.mean(np.stack(tare_samples), axis=0)

        if arguments.scenario == "hand_stability":
            final_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
            final_velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
            pass_state = bool(
                np.all(np.isfinite(final_positions))
                and np.all(np.isfinite(final_velocities))
                and maximum_joint_speed
                <= float(config["acceptance"]["hand_stability_max_speed_rad_s"])
            )
            return {
                "schema": RESULT_SCHEMA,
                "status": "PASS" if pass_state else "FAIL",
                "classification": "HAND_STABILITY_PASS" if pass_state else "HAND_STABILITY_FAIL",
                "scenario": arguments.scenario,
                "candidate": candidate,
                "rig_urdf": urdf_evidence,
                "dof_names": dof_names,
                "articulation_root": str(articulation_root.GetPath()),
                "articulation_root_count": len(articulation_roots),
                "physics_steps": len(trace_rows),
                "maximum_joint_speed_rad_s": maximum_joint_speed,
                "first_physics_step_wall_s": first_step_wall_s,
                "trace_csv": str(trace_path),
                "stage_usda": str(stage_path),
                "fast_baseline_passed": False,
                "formal_b_passed": False,
            }

        preclose_steps = int(config["trajectory"]["raised_preclose_steps"])
        for index in range(preclose_steps):
            fraction = (index + 1) / float(preclose_steps)
            blend = 10.0 * fraction**3 - 15.0 * fraction**4 + 6.0 * fraction**5
            current_targets["f1j1"] = float(candidate["open_preshape_rad"]) + blend * (
                float(candidate["preclose_preshape_rad"])
                - float(candidate["open_preshape_rad"])
            )
            for name, target in zip(ROOT_TORQUE_JOINTS, candidate["preclose_flexion_rad"]):
                current_targets[name] = float(candidate["open_flexion_rad"]) + blend * (
                    float(target) - float(candidate["open_flexion_rad"])
                )
            step("RAISED_PRECLOSE", index)

        descend_steps = int(config["trajectory"]["descend_steps"])
        approach_lift = float(candidate["approach_lift_m"])
        for index in range(descend_steps):
            fraction = (index + 1) / float(descend_steps)
            blend = 10.0 * fraction**3 - 15.0 * fraction**4 + 6.0 * fraction**5
            current_targets["lift_z"] = approach_lift * (1.0 - blend)
            step("DESCEND_TO_GRASP", index)

        close_steps = int(config["trajectory"]["final_close_steps"])
        for index in range(close_steps):
            fraction = (index + 1) / float(close_steps)
            blend = 10.0 * fraction**3 - 15.0 * fraction**4 + 6.0 * fraction**5
            current_targets["f1j1"] = float(candidate["preclose_preshape_rad"]) + blend * (
                float(candidate["preshape_rad"])
                - float(candidate["preclose_preshape_rad"])
            )
            for name, start, target in zip(
                ROOT_TORQUE_JOINTS,
                candidate["preclose_flexion_rad"],
                candidate["finger_flexion_targets_rad"],
            ):
                current_targets[name] = float(start) + blend * (float(target) - float(start))
            step("FINAL_CLOSE", index)

        target_torque = float(config["finger_control"]["target_root_torque_delta_nm"])
        maximum_extra = float(config["finger_control"]["maximum_extra_closure_rad"])
        build_start = np.asarray(
            [current_targets[name] for name in ROOT_TORQUE_JOINTS], dtype=np.float64
        )
        force_build_steps = int(config["trajectory"]["force_build_steps"])
        force_target_reached = False
        last_force_delta = np.zeros(3, dtype=np.float64)
        for index in range(force_build_steps):
            efforts = step("FORCE_BUILD", index)
            last_force_delta = np.abs(efforts - tare)
            if np.all(last_force_delta >= target_torque):
                force_target_reached = True
                break
            for finger_index, name in enumerate(ROOT_TORQUE_JOINTS):
                if last_force_delta[finger_index] < target_torque:
                    current_targets[name] = min(
                        build_start[finger_index] + maximum_extra,
                        current_targets[name]
                        + float(config["finger_control"]["closure_increment_rad"]),
                    )
        if not force_target_reached:
            diagnostic = {
                "schema": "D38999_B_MINIMAL_V2_RUNTIME_DIAGNOSTIC",
                "reason": "ROOT_TORQUE_PRELOAD_NOT_REACHED",
                "target_root_torque_delta_nm": target_torque,
                "actual_root_torque_delta_nm": last_force_delta.tolist(),
                "phase": "FORCE_BUILD",
                "physics_steps": len(trace_rows),
            }
            _write_json(output / "B_MINIMAL_V2_RUNTIME_DIAGNOSTIC.json", diagnostic)
            raise RuntimeStateError("root torque preload was not reached", diagnostic)

        grip_settle_steps = int(config["trajectory"]["grip_settle_steps"])
        for index in range(grip_settle_steps):
            step("GRIP_SETTLE", index)

        if arguments.scenario == "offtable_grasp":
            object_view.set_linear_velocity((0.0, 0.0, 0.0))
            object_view.set_angular_velocity((0.0, 0.0, 0.0))
            object_rigid.GetKinematicEnabledAttr().Set(False)
            for index in range(int(config["trajectory"]["support_release_steps"])):
                step("SUPPORT_RELEASE_HOLD", index)
            lift_targets = [float(config["offtable_lift_control"]["target_m"])]
            lift_steps = [int(config["offtable_lift_control"]["steps"])]
        else:
            lift_targets = [
                float(value) for value in config["lift_control"]["stage_targets_m"]
            ]
            lift_steps = [int(value) for value in config["lift_control"]["stage_steps"]]
        previous = 0.0
        retained = float(config["finger_control"]["retained_torque_fraction"])
        adaptive_limit = np.asarray(
            [current_targets[name] for name in ROOT_TORQUE_JOINTS], dtype=np.float64
        ) + maximum_extra
        for target, steps in zip(lift_targets, lift_steps):
            for index in range(steps):
                fraction = (index + 1) / float(steps)
                blend = 10.0 * fraction**3 - 15.0 * fraction**4 + 6.0 * fraction**5
                current_targets["lift_z"] = previous + blend * (target - previous)
                efforts = step(f"LIFT_{target * 1000.0:.1f}MM", index)
                delta = np.abs(efforts - tare)
                for finger_index, name in enumerate(ROOT_TORQUE_JOINTS):
                    if delta[finger_index] < retained * target_torque:
                        current_targets[name] = min(
                            adaptive_limit[finger_index],
                            current_targets[name]
                            + float(config["finger_control"]["adaptive_closure_increment_rad"]),
                        )
            previous = target

        final_hold_steps = int(config["trajectory"]["final_hold_steps"])
        for index in range(final_hold_steps):
            step("FINAL_HOLD", index)

        final_position_raw, final_orientation_raw = object_view.get_world_pose()
        final_position = np.asarray(final_position_raw, dtype=np.float64)
        final_orientation = np.asarray(final_orientation_raw, dtype=np.float64)
        object_lift = float(final_position[2] - initial_object_position[2])
        object_xy_drift = float(np.linalg.norm(final_position[:2] - initial_object_position[:2]))
        object_tilt = _tilt_angle_rad(initial_object_orientation, final_orientation)
        final_rows = trace_rows[-max(1, final_hold_steps) :]
        final_pad_force = {
            "f1Link3": float(np.mean([row["f1_pad_force_n"] for row in final_rows])),
            "f2Link2": float(np.mean([row["f2_pad_force_n"] for row in final_rows])),
            "f3Link3": float(np.mean([row["f3_pad_force_n"] for row in final_rows])),
        }
        final_table_force = float(np.mean([row["table_force_n"] for row in final_rows]))
        required_lift = float(
            config["acceptance"][
                "offtable_minimum_lift_m"
                if arguments.scenario == "offtable_grasp"
                else "minimum_lift_m"
            ]
        )
        passed = bool(
            all(
                force >= float(config["acceptance"]["minimum_final_pad_force_n"])
                for force in final_pad_force.values()
            )
            and final_table_force
            <= float(config["acceptance"]["maximum_final_table_force_n"])
            and object_lift >= required_lift
            and object_xy_drift
            <= float(config["acceptance"]["maximum_object_xy_drift_m"])
            and object_tilt
            <= float(config["acceptance"]["maximum_object_tilt_rad"])
        )
        classification_prefix = (
            "OFFTABLE_GRASP"
            if arguments.scenario == "offtable_grasp"
            else "TABLE_PICK"
        )
        return {
            "schema": RESULT_SCHEMA,
            "status": "PASS" if passed else "FAIL",
            "classification": (
                classification_prefix + "_PASS"
                if passed
                else classification_prefix + "_PHYSICAL_FAIL"
            ),
            "scenario": arguments.scenario,
            "candidate": candidate,
            "rig_urdf": urdf_evidence,
            "dof_names": dof_names,
            "articulation_root": str(articulation_root.GetPath()),
            "articulation_root_count": len(articulation_roots),
            "physics_steps": len(trace_rows),
            "first_physics_step_wall_s": first_step_wall_s,
            "maximum_joint_speed_rad_s": maximum_joint_speed,
            "pad_primitive_count": 3,
            "whole_terminal_convex_hull_count": 0,
            "pad_impulse_by_finger_ns": pad_impulse_by_finger,
            "table_impulse_total_ns": table_impulse_total,
            "initial_object_position_m": initial_object_position.tolist(),
            "final_object_position_m": final_position.tolist(),
            "object_lift_m": object_lift,
            "object_xy_drift_m": object_xy_drift,
            "object_tilt_rad": object_tilt,
            "final_hold_pad_force_n": final_pad_force,
            "final_hold_table_force_n": final_table_force,
            "trace_csv": str(trace_path),
            "stage_usda": str(stage_path),
            "truth_boundary": {
                "online_object_pose_used": False,
                "online_contact_truth_used": False,
                "posthoc_object_pose_used": True,
                "posthoc_contact_report_used": True,
                "object_pose_write_after_first_explicit_step_count": 0,
            },
            "fast_baseline_passed": passed,
            "formal_b_passed": False,
        }
    finally:
        trace_stream.flush()
        trace_stream.close()


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    if arguments.dry_run:
        report = _dry_run(arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0

    portable = Path(arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    exit_code = 1
    output = Path(arguments.output_dir).resolve()
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": not bool(arguments.gui),
                "hide_ui": not bool(arguments.gui),
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = _run_isaac(arguments)
        exit_code = 0 if report.get("status") == "PASS" else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        diagnostic = error.diagnostic if isinstance(error, RuntimeStateError) else None
        runtime_reason = (
            str(diagnostic.get("reason"))
            if isinstance(diagnostic, Mapping) and diagnostic.get("reason")
            else type(error).__name__
        )
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"B_MINIMAL_V2_{runtime_reason}",
            "scenario": arguments.scenario,
            "candidate_id": arguments.candidate_id,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "runtime_diagnostic": diagnostic,
            "fast_baseline_passed": False,
            "formal_b_passed": False,
        }
        exit_code = 2
    _write_json(output / "B_MINIMAL_V2_RESULT.json", report)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
