#!/usr/bin/env python3
"""Dependency-light static validator for the isolated B_MINIMAL_V2 patch.

It intentionally avoids pytest and all Isaac imports.  The selected interpreter
only needs NumPy, SciPy and PyYAML, which are already required by the candidate
generator itself.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

import numpy as np
import yaml


def _args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", default=str(Path(__file__).resolve().parents[3]))
    return parser.parse_args()


def _load_runner(path: Path):
    spec = importlib.util.spec_from_file_location("d38999_b_minimal_v2_runner", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load runner: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    arguments = _args()
    root = Path(arguments.repository).resolve()
    package_root = root / "src/kcg_connector"
    sys.path.insert(0, str(package_root))
    from kcg_connector.grasp.d38999_b_minimal_v2 import (  # noqa: PLC0415
        ACTIVE_TERMINAL_LINKS,
        SCHEMA,
        build_candidates,
        selected_central_capsules,
    )

    urdf = root / "artifacts/kcg_connector/urdf/handarm.urdf"
    pad_core_path = root / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
    candidates_path = root / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json"
    config_path = root / "src/kcg_connector/config/d38999_b_minimal_v2.yaml"
    runner_path = root / "src/kcg_connector/isaac/d38999_b_minimal_v2_runner.py"
    required = (urdf, pad_core_path, candidates_path, config_path, runner_path)
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"missing B_MINIMAL_V2 inputs: {missing}")

    pad_core = json.loads(pad_core_path.read_text(encoding="utf-8"))
    assert pad_core["schema"] == "D38999_B_MINIMAL_V2_PAD_CORE_V1"
    assert pad_core["collision_route"] == "B_MINIMAL_V2_PAD_CORE_ANALYTIC_CAPSULES"
    assert pad_core["diagnostic_dynamic_use_allowed"] is True
    assert pad_core["formal_b_use_allowed"] is False
    assert pad_core["whole_terminal_convex_hull_count"] == 0
    assert pad_core["pad_primitive_count_total"] == 3
    assert all(len(row["capsules"]) == 1 for row in pad_core["links"])

    expected = json.loads(candidates_path.read_text(encoding="utf-8"))
    actual = build_candidates(urdf_path=urdf, proxy_manifest_path=pad_core_path)
    assert actual == expected
    assert expected["schema"] == SCHEMA
    assert expected["status"] == "STATIC_SWEEP_PASS_AWAITING_ISAAC"
    assert expected["diagnostic_pad_core_dynamic_use_allowed"] is True
    rows = expected["candidates"]
    assert [row["candidate_id"] for row in rows] == [
        "PAD_CORE_Z12",
        "PAD_CORE_Z14",
        "PAD_CORE_Z18",
    ]
    for row in rows:
        metrics = row["sweep_metrics"]
        assert metrics["sample_count"] == 303
        assert metrics["minimum_table_clearance_m"] >= 0.003 - 1.0e-12
        assert metrics["minimum_precontact_object_clearance_m"] >= 0.003 - 1.0e-12
        assert metrics["maximum_final_object_penetration_m"] <= 0.0002 + 1.0e-12
        assert metrics["minimum_interfinger_clearance_m"] >= 0.010
        assert all(-0.0002 <= gap <= 0.0002 for gap in metrics["closed_object_gaps_m"])

    selected = selected_central_capsules(pad_core)
    assert list(selected) == list(ACTIVE_TERMINAL_LINKS)
    assert [selected[name]["capsule_index"] for name in ACTIVE_TERMINAL_LINKS] == [2, 2, 2]

    runner = _load_runner(runner_path)
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    candidate = rows[0]
    table_geometry = runner._candidate_world_geometry(
        config, candidate, scenario="table_pick"
    )
    off_geometry = runner._candidate_world_geometry(
        config, candidate, scenario="offtable_grasp"
    )
    object_shift = np.asarray(off_geometry["object_world_center_m"]) - np.asarray(
        table_geometry["object_world_center_m"]
    )
    hand_shift = np.asarray(off_geometry["handbase_final_world_m"]) - np.asarray(
        table_geometry["handbase_final_world_m"]
    )
    assert np.allclose(object_shift, [0.0, 0.0, 0.070])
    assert np.allclose(hand_shift, object_shift)

    with tempfile.TemporaryDirectory(prefix="b-minimal-v2-static-") as temporary:
        generated = Path(temporary) / "minimal.urdf"
        evidence = runner._build_minimal_urdf(
            source_urdf=urdf,
            destination=generated,
            geometry=table_geometry,
        )
        assert evidence["root_links"] == ["rig_base_link"]
        assert evidence["mesh_collision_count"] == 0
        assert evidence["extra_fixed_mount_joint_count"] == 0
        tree = ET.parse(generated).getroot()
        assert len(tree.findall("joint[@name='lift_z']")) == 1
        assert tree.find("joint[@name='hand_mount']") is None
        for link in tree.findall("link"):
            assert not link.findall("visual")
            assert not link.findall("collision")

    text = runner_path.read_text(encoding="utf-8")
    for follower in ("f1j3", "f2j2", "f3j1", "f3j3"):
        assert follower in text
    assert 'for name in ("f1j2", "f1j3", "f2j1", "f2j2", "f3j2", "f3j3")' in text
    assert text.index("robot.set_joint_positions") < text.index(
        "api.GetCollisionEnabledAttr().Set(True)"
    )
    for marker in (
        "NONFINITE_ARTICULATION_STATE",
        "nonfinite_dof_names",
        "ROOT_TORQUE_PRELOAD_NOT_REACHED",
        "SUPPORT_RELEASE_HOLD",
        "trace_stream.flush()",
    ):
        assert marker in text

    result = {
        "schema": "D38999_B_MINIMAL_V2_STATIC_VALIDATION",
        "status": "PASS",
        "candidate_ids": [row["candidate_id"] for row in rows],
        "candidate_sweep_samples_each": 303,
        "pad_primitive_count": 3,
        "whole_terminal_convex_hull_count": 0,
        "minimal_urdf_root_count": 1,
        "scenarios": ["hand_stability", "offtable_grasp", "table_pick"],
        "isaac_dynamic_claimed": False,
        "formal_b_passed": False,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
