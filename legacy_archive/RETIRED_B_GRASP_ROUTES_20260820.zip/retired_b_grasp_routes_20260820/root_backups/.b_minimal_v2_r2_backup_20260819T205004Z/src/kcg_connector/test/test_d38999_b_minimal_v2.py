from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from kcg_connector.grasp.d38999_b_minimal_v2 import (
    ACTIVE_TERMINAL_LINKS,
    SCHEMA,
    build_candidates,
    compare_candidate_manifests,
    selected_central_capsules,
)


REPOSITORY = Path(__file__).resolve().parents[3]
URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
PROXY = REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
CANDIDATES = REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json"
RUNNER = REPOSITORY / "src/kcg_connector/isaac/d38999_b_minimal_v2_runner.py"


def _runner_module():
    spec = importlib.util.spec_from_file_location("d38999_b_minimal_v2_runner", RUNNER)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_precomputed_manifest_reproduces() -> None:
    expected = json.loads(CANDIDATES.read_text(encoding="utf-8"))
    actual = build_candidates(urdf_path=URDF, proxy_manifest_path=PROXY)
    comparison = compare_candidate_manifests(actual, expected)
    assert comparison["equivalent"], comparison
    assert actual["schema"] == expected["schema"] == SCHEMA
    assert expected["status"] == "STATIC_SWEEP_PASS_AWAITING_ISAAC"


def test_three_candidates_pass_full_sweep_and_are_real_axial_positions() -> None:
    manifest = json.loads(CANDIDATES.read_text(encoding="utf-8"))
    rows = manifest["candidates"]
    assert [row["candidate_id"] for row in rows] == [
        "PAD_CORE_Z12",
        "PAD_CORE_Z14",
        "PAD_CORE_Z18",
    ]
    assert len({row["object_center_z_hand_m"] for row in rows}) == 3
    assert len({row["approach_lift_m"] for row in rows}) == 3
    for row in rows:
        metrics = row["sweep_metrics"]
        assert metrics["sample_count"] == 303
        assert metrics["minimum_table_clearance_m"] >= 0.003 - 1e-12
        assert metrics["minimum_precontact_object_clearance_m"] >= 0.003 - 1e-12
        assert metrics["maximum_final_object_penetration_m"] <= 0.0002
        assert metrics["minimum_interfinger_clearance_m"] >= 0.010
        assert all(-0.0002 <= gap <= 0.0002 for gap in metrics["closed_object_gaps_m"])


def test_only_one_central_pad_capsule_per_finger_is_selected() -> None:
    proxy = json.loads(PROXY.read_text(encoding="utf-8"))
    selected = selected_central_capsules(proxy)
    assert list(selected) == list(ACTIVE_TERMINAL_LINKS)
    assert [selected[name]["capsule_index"] for name in ACTIVE_TERMINAL_LINKS] == [2, 2, 2]
    manifest = json.loads(CANDIDATES.read_text(encoding="utf-8"))
    assert manifest["minimal_v2_collision_subset"]["pad_primitive_count_total"] == 3
    assert manifest["minimal_v2_collision_subset"]["whole_terminal_convex_hull_count"] == 0


def test_minimal_urdf_has_one_root_and_no_mesh_geometry(tmp_path: Path) -> None:
    module = _runner_module()
    config = module.yaml.safe_load(
        (REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2.yaml").read_text()
    )
    candidate = json.loads(CANDIDATES.read_text())["candidates"][0]
    geometry = module._candidate_world_geometry(config, candidate)
    output = tmp_path / "minimal.urdf"
    evidence = module._build_minimal_urdf(
        source_urdf=URDF,
        destination=output,
        geometry=geometry,
    )
    assert evidence["root_links"] == ["rig_base_link"]
    assert evidence["mesh_collision_count"] == 0
    assert evidence["extra_fixed_mount_joint_count"] == 0
    root = ET.parse(output).getroot()
    assert len(root.findall("joint[@name='lift_z']")) == 1
    assert root.find("joint[@name='hand_mount']") is None
    for link in root.findall("link"):
        assert not link.findall("visual")
        assert not link.findall("collision")


def test_runner_initializes_all_active_and_mimic_joints_before_contact() -> None:
    text = RUNNER.read_text(encoding="utf-8")
    for follower in ("f1j3", "f2j2", "f3j1", "f3j3"):
        assert follower in text
    assert 'for name in ("f1j2", "f1j3", "f2j1", "f2j2", "f3j2", "f3j3")' in text
    assert 'initial_positions[indices["f3j1"]]' in text
    assert text.index("robot.set_joint_positions") < text.index(
        "api.GetCollisionEnabledAttr().Set(True)"
    )
    assert "NONFINITE_ARTICULATION_STATE" in text
    assert "nonfinite_dof_names" in text
    assert "trace_stream.flush()" in text


def test_runner_has_two_stage_integration_gate() -> None:
    module = _runner_module()
    parsed = module._arguments(
        [
            "--scenario",
            "hand_stability",
            "--candidate-id",
            "PAD_CORE_Z12",
            "--output-dir",
            "/tmp/not-created-b-minimal-v2-output",
            "--kit-portable-root",
            "/tmp/not-created-b-minimal-v2-portable",
        ]
    )
    assert parsed.scenario == "hand_stability"
    assert parsed.candidate_id == "PAD_CORE_Z12"


def test_pad_core_snapshot_is_clean_and_diagnostic_only() -> None:
    pad_core = json.loads(PROXY.read_text(encoding="utf-8"))
    assert pad_core["schema"] == "D38999_B_MINIMAL_V2_PAD_CORE_V1"
    assert pad_core["collision_route"] == "B_MINIMAL_V2_PAD_CORE_ANALYTIC_CAPSULES"
    assert pad_core["diagnostic_dynamic_use_allowed"] is True
    assert pad_core["formal_b_use_allowed"] is False
    assert pad_core["whole_terminal_convex_hull_count"] == 0
    assert pad_core["pad_primitive_count_total"] == 3
    assert all(len(row["capsules"]) == 1 for row in pad_core["links"])


def test_offtable_geometry_translates_hand_and_object_together() -> None:
    module = _runner_module()
    config = module.yaml.safe_load(
        (REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2.yaml").read_text()
    )
    candidate = json.loads(CANDIDATES.read_text())["candidates"][0]
    table = module._candidate_world_geometry(config, candidate, scenario="table_pick")
    off = module._candidate_world_geometry(config, candidate, scenario="offtable_grasp")
    object_shift = np.asarray(off["object_world_center_m"]) - np.asarray(
        table["object_world_center_m"]
    )
    hand_shift = np.asarray(off["handbase_final_world_m"]) - np.asarray(
        table["handbase_final_world_m"]
    )
    assert np.allclose(object_shift, [0.0, 0.0, 0.070])
    assert np.allclose(hand_shift, object_shift)


def test_runner_has_preload_fail_closed_and_support_release_stage() -> None:
    text = RUNNER.read_text(encoding="utf-8")
    assert "ROOT_TORQUE_PRELOAD_NOT_REACHED" in text
    assert "SUPPORT_RELEASE_HOLD" in text
    assert 'choices=("hand_stability", "offtable_grasp", "table_pick")' in text
    assert "object_rigid.GetKinematicEnabledAttr().Set(False)" in text
    assert "diagnostic_pad_core_dynamic_use_allowed" in text


def test_candidate_manifest_comparison_accepts_only_numerical_noise() -> None:
    expected = json.loads(CANDIDATES.read_text(encoding="utf-8"))
    noisy = json.loads(json.dumps(expected))
    noisy["candidates"][0]["geometry_score"] += 8.5e-9
    report = compare_candidate_manifests(noisy, expected)
    assert report["equivalent"], report
    assert report["exact_numeric_difference_count"] == 1

    materially_changed = json.loads(json.dumps(expected))
    materially_changed["candidates"][0]["sweep_metrics"][
        "minimum_table_clearance_m"
    ] -= 1.0e-5
    report = compare_candidate_manifests(materially_changed, expected)
    assert not report["equivalent"]
    assert report["out_of_tolerance_count"] == 1


def test_candidate_manifest_comparison_rejects_structure_change() -> None:
    expected = json.loads(CANDIDATES.read_text(encoding="utf-8"))
    changed = json.loads(json.dumps(expected))
    changed["candidates"][0]["candidate_id"] = "WRONG_CANDIDATE"
    report = compare_candidate_manifests(changed, expected)
    assert not report["equivalent"]
    assert report["structural_difference_count"] == 1
