# D38999 B阶段极速接管补丁

## 这次直接改了什么

本补丁不再沿用H1～H25控制链，也不再等待SDF、末端网格凸包或复杂Isaac碰撞烹饪。

新增一条独立的 `B_FAST_PICK_V1` 快速基线：

1. 保留真实三指手关节拓扑、模仿关节、质量和惯量；
2. 临时URDF中删除全部视觉网格和原始碰撞网格；
3. 只挂载已经审计过的15个蓝色指腹解析胶囊；
4. 红色指尖、侧面和旧整个末节大凸包不参与快速基线碰撞；
5. 使用真实三指运动学离线求解抓取姿态，而不是固定H25位置；
6. 默认测试螺母抓持带 `z=19、14、24 mm` 三个位置；
7. 单指保守所需法向力为6.758 N，控制目标为约7 N/指；
8. 通过三路指根关节力矩增量调节共同抓紧量；
9. 通过一个物理棱柱关节执行0.5/2/10/40 mm竖直抬升，不写物体位姿；
10. 物体位姿与接触报告只用于固定时刻的运行后评分，不参与在线控制。

## 重要定位

这条快速基线用于尽快回答：

> 三根真实蓝色指腹、合理抓取位置和约7 N/指条件下，能否稳定夹住0.31 kg活动端并完成40 mm抬升？

它通过后，证明抓取几何和三指承载没有问题，并输出应接入完整iiwa B阶段的候选姿态。

它不是完整iiwa桌面抓取的正式 `B_FORMAL_DYNAMIC_PASS`，因为快速基线用物理升降测试架隔离了机械臂碰撞、规划和腕部结构。这样做是为了先在几十分钟内结束“手到底能不能抓住”的争论，再把已验证候选接入完整机器人。

## 新增文件

- `src/kcg_connector/kcg_connector/grasp/d38999_b_fast_pick.py`
- `src/kcg_connector/isaac/build_d38999_b_fast_pick_candidates.py`
- `src/kcg_connector/isaac/d38999_b_fast_pick_rig.py`
- `src/kcg_connector/config/d38999_b_fast_pick_v1.yaml`
- `src/kcg_connector/config/d38999_b_fast_pick_candidates_v1.json`
- `src/kcg_connector/test/test_d38999_b_fast_pick.py`
- `src/kcg_connector/test/test_d38999_b_fast_pick_rig.py`
- `run_d38999_b_fast_pick.sh`

## 执行前

停止Codex继续修改仓库，并确认没有Isaac进程：

```bash
pkill -TERM -f 'd38999_.*smoke.py' || true
sleep 3
pgrep -af 'isaac-sim|isaacsim|d38999_.*smoke.py' || true
```

不要删除原仓库；先备份：

```bash
cd /home/noob/WorkPlace
cp -a kcgtest1 "kcgtest1_backup_$(date +%Y%m%d_%H%M%S)"
```

## 静态验证

在仓库根目录运行：

```bash
cd /home/noob/WorkPlace/kcgtest1
export PYTHONPATH=src/kcg_connector

python3 -m py_compile \
  src/kcg_connector/kcg_connector/grasp/d38999_b_fast_pick.py \
  src/kcg_connector/isaac/build_d38999_b_fast_pick_candidates.py \
  src/kcg_connector/isaac/d38999_b_fast_pick_rig.py

PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
PYTHONPATH=src/kcg_connector \
python3 -m pytest -q \
  src/kcg_connector/test/test_d38999_b_fast_pick.py \
  src/kcg_connector/test/test_d38999_b_fast_pick_rig.py
```

预期：`8 passed`。

## 一键运行

冻结候选已经随补丁提供，默认不要求SciPy。直接运行：

```bash
cd /home/noob/WorkPlace/kcgtest1
bash run_d38999_b_fast_pick.sh /home/noob/WorkPlace/kcgtest1
```

需要重新离线优化候选时再执行：

```bash
REGENERATE_CANDIDATES=1 \
  bash run_d38999_b_fast_pick.sh /home/noob/WorkPlace/kcgtest1
```

脚本顺序：

```text
读取补丁内冻结候选（可选重新生成）
→ 静态dry-run
→ PAD_Z19
→ 若失败则PAD_Z14
→ 若失败则PAD_Z24
```

首个通过的候选会写入：

```text
artifacts/direct_takeover/B_FAST_PICK_V1_<时间>/SELECTED_CANDIDATE.txt
```

每次运行的结果：

```text
B_FAST_PICK_RESULT.json
B_FAST_PICK_TRACE.csv
B_FAST_PICK_STAGE.usda
```

## 通过标准

快速基线至少满足：

- 三根指腹均产生接触冲量；
- 三路指根力矩维持抓持；
- 最终2秒保持窗口内三根指腹仍有持续接触；
- 最终保持窗口内桌面接触力接近0；
- 活动端最终上升不少于39 mm；
- 横向漂移不超过5 mm；
- 物理开始后对象位姿写入为0；
- 在线控制不读取对象位姿、接触名称、法向或事件真值。

## 门限语义

- `0.30 N·m`：只保留为B抓取质量软目标；
- `0.60 N·m`：仿真持续恢复门；
- `1.00 N·m`：仿真临时急停门；
- 上述数值均不声称是实体硬件极限；
- 单指15 N是用户提供的能力上限，正常目标约7 N/指，自适应上限12 N/指。

## 已完成的本地校验与限制

我已对补丁执行：

- 新增模块语法编译；
- 候选确定性重建；
- 临时URDF网格清除与惯量保留检查；
- PAD-only、保守PAD代理、兼容性runner及快速抓取新增测试，共 `26 passed`；
- 快速抓取自身定向测试为 `8 passed`；
- `PAD_Z19` 静态dry-run通过。

当前环境没有你的Isaac Sim 6.0.1运行时，因此这里不能诚实声称已经完成动态抓取。补丁的目的，是把你本机下一次运行直接推进到“真实指腹闭合并抬升”，而不是再等待SDF或网格烹饪。

另外，配置中的 `7 N/指` 是按质量、摩擦下界和安全系数推导的**设计目标**。当前在线控制使用三路指根力矩增量作代理，尚无实体标定关系，因此结果报告会把接触冲量换算力作为运行后验证，不会把0.18 N·m直接冒充为已测得7 N。

## 快速基线通过后的唯一下一步

读取 `SELECTED_CANDIDATE.txt` 与对应结果JSON，把以下参数接入完整iiwa场景：

- `preshape_rad`
- 三指 `finger_flexion_targets_rad`
- `object_axis_center_xy_hand_m`
- `grasp_local_z_mm`

完整iiwa集成时继续使用：

- 蓝色指腹解析胶囊；
- 共同抓紧＋差分定心；
- minimum-jerk Z抬升；
- 0.30 N·m软目标，而非单帧硬失败。
