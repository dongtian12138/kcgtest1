# B阶段完整iiwa live GUI启动命令

以下命令均运行 `full_iiwa_table_pick.py` 的当前 live stage，物理层使用
`D38999_ASSEMBLY_CONTROL_V1`，渲染层使用无碰撞、无质量的
`D38999_VISUAL_COMPLETE_V1`。它们不使用 post-hoc replay。

## 总览

```bash
cd /home/noob/WorkPlace/kcgtest1
bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 overview
```

## 抓取近景

```bash
cd /home/noob/WorkPlace/kcgtest1
bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 grasp
```

## 侧视图

```bash
cd /home/noob/WorkPlace/kcgtest1
bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 side
```

## 同时录制live视频

```bash
cd /home/noob/WorkPlace/kcgtest1
B_GUI_RECORD=1 bash run_full_iiwa_b_gui.sh \
  /home/noob/WorkPlace/kcgtest1 overview
```

默认在最终姿态保留 GUI 120 秒；可用
`B_GUI_HOLD_SECONDS=300` 延长。用 `B_GUI_DRY_RUN=1` 可完成不启动 Isaac 的
接口预检。每次真实 GUI 运行均由 `run_b_goal_mode_supervisor.sh` 托管，且拒绝
并行启动另一个 B runner。

## 当前真实性边界

这些命令用于查看 live 动态诊断，不表示正式 PAD 接触通过。当前每指只保留原
5胶囊方案中的一个中央 `PAD_CORE_CAPSULE`；在该胶囊中心线和8 mm轴向段上，
作者蓝色指腹表面比代理表面向连接器方向超前约0.711–1.211 mm。TIP/SIDE又
没有完整碰撞表示，因此画面可出现手指外观进入连接器的现象。当前状态只能称为
`B_FULL_IIWA_DIAGNOSTIC_PROXY_TABLE_PICK_PASS`，不能称为
`B_FORMAL_DYNAMIC_PASS`。
