#!/usr/bin/env bash
# Single entry point for every B_GOAL_MODE Isaac child process.
set -euo pipefail

ROOT="${1:-/home/noob/WorkPlace/kcgtest1}"
shift || true
ROOT="$(readlink -f "$ROOT")"

if [[ ! -d "$ROOT/src/kcg_connector" ]]; then
  echo "Repository not found: $ROOT" >&2
  exit 2
fi

SUPERVISOR="$ROOT/src/kcg_connector/kcg_connector/grasp/b_goal_mode/session_supervisor.py"
if [[ ! -f "$SUPERVISOR" ]]; then
  echo "B_GOAL_MODE supervisor not found: $SUPERVISOR" >&2
  exit 2
fi

export PYTHONPATH="$ROOT/src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}"
exec python3 "$SUPERVISOR" --repo-root "$ROOT" "$@"
