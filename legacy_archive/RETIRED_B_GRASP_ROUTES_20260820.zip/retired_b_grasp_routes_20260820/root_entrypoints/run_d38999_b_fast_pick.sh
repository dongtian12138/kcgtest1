#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$PWD}"
cd "$ROOT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
TASK_ROOT="artifacts/direct_takeover/B_FAST_PICK_V1_${STAMP}"
mkdir -p "$TASK_ROOT"

PYTHON_BIN="${KCG_PYTHON:-python3}"
export PYTHONPATH="src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}"

# The patch ships a frozen, portable candidate manifest. Regeneration is
# optional so the fast physics run does not depend on SciPy being available in
# the shell environment.
if [[ "${REGENERATE_CANDIDATES:-0}" == "1" ]]; then
  "$PYTHON_BIN" src/kcg_connector/isaac/build_d38999_b_fast_pick_candidates.py
fi

# Static dry-run catches path/URDF/candidate errors without launching Isaac.
"$PYTHON_BIN" src/kcg_connector/isaac/d38999_b_fast_pick_rig.py \
  --candidate-id PAD_Z19 \
  --output-dir "$TASK_ROOT/DRY_RUN_PAD_Z19" \
  --kit-portable-root "/tmp/kcg-b-fast-dry-${STAMP}" \
  --dry-run

for candidate in PAD_Z19 PAD_Z14 PAD_Z24; do
  output="$TASK_ROOT/$candidate"
  portable="/tmp/kcg-b-fast-${candidate}-${STAMP}"
  echo "=== Running $candidate ==="
  set +e
  timeout --signal=TERM --kill-after=10s 420s \
    src/kcg_connector/isaac/run_isaac_python.sh \
    src/kcg_connector/isaac/d38999_b_fast_pick_rig.py \
    --candidate-id "$candidate" \
    --output-dir "$output" \
    --kit-portable-root "$portable"
  rc=$?
  set -e
  if [[ -f "$output/B_FAST_PICK_RESULT.json" ]]; then
    passed="$("$PYTHON_BIN" - "$output/B_FAST_PICK_RESULT.json" <<'PY'
import json,sys
print(str(bool(json.load(open(sys.argv[1]))['fast_baseline_passed'])).lower())
PY
)"
    if [[ "$passed" == "true" ]]; then
      echo "FAST PICK PASSED with $candidate"
      printf '%s\n' "$candidate" > "$TASK_ROOT/SELECTED_CANDIDATE.txt"
      "$PYTHON_BIN" - \
        "$output/B_FAST_PICK_RESULT.json" \
        "$TASK_ROOT/FULL_IIWA_B_SELECTED_GRASP_OVERRIDE.yaml" <<'PY'
import json, sys, yaml
from pathlib import Path
result = json.loads(Path(sys.argv[1]).read_text())
candidate = result["candidate"]
override = {
    "schema_version": "d38999_b_fast_pick_selected_candidate_v1",
    "status": "FAST_GRASP_SUBSYSTEM_DYNAMIC_PASS_PENDING_FULL_IIWA_INTEGRATION",
    "candidate_id": candidate["candidate_id"],
    "grasp_local_z_mm": candidate["grasp_local_z_mm"],
    "preshape_rad": candidate["preshape_rad"],
    "finger_flexion_targets_rad": candidate["finger_flexion_targets_rad"],
    "object_axis_center_xy_hand_m": candidate["object_axis_center_xy_hand_m"],
    "pad_collision_route": "CONSERVATIVE_CONVEX_PAD_PROXY",
    "old_whole_terminal_hull_allowed": False,
    "finger_force_design": {
        "conservative_friction": 0.30,
        "required_normal_force_per_finger_n": 6.758,
        "nominal_target_per_finger_n": 7.0,
        "adaptive_limit_per_finger_n": 12.0,
        "user_reported_capability_per_finger_n": 15.0,
        "normal_force_mapping_calibrated": False,
    },
    "full_iiwa_control": {
        "z_motion": "MINIMUM_JERK_POSITION_LIFT",
        "finger_common_mode": "ROOT_EFFORT_PROXY_WITH_ANTI_WINDUP",
        "finger_differential_mode": "DISABLED_IN_FAST_BASELINE_ENABLE_AFTER_FULL_IIWA_WRENCH_TEST",
        "legacy_0p30_nm_role": "B_QUALITY_SOFT_TARGET_NOT_HARDWARE_LIMIT",
    },
    "source_fast_result": str(Path(sys.argv[1])),
    "formal_b_pass_claimed": False,
}
Path(sys.argv[2]).write_text(yaml.safe_dump(override, sort_keys=False, allow_unicode=True))
PY
      echo "Selected full-iiwa override: $TASK_ROOT/FULL_IIWA_B_SELECTED_GRASP_OVERRIDE.yaml"
      exit 0
    fi
  fi
  echo "$candidate did not pass (exit=$rc); trying next ranked candidate"
done

echo "No candidate passed. Inspect $TASK_ROOT/*/B_FAST_PICK_RESULT.json" >&2
exit 3
