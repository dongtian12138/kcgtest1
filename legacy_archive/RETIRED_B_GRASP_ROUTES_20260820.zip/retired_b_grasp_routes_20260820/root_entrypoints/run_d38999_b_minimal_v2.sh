#!/usr/bin/env bash
# Run the isolated B_MINIMAL_V2 integration ladder:
#   static preflight -> hand stability -> off-table grasp -> table pick.
# The script never invokes H1-H25, SDF, CoACD, or agent_control state machines.
set -euo pipefail

ROOT="${1:-/home/noob/WorkPlace/kcgtest1}"
ROOT="$(readlink -f "$ROOT")"
if [[ ! -d "$ROOT/src/kcg_connector" ]]; then
  echo "Repository not found: $ROOT" >&2
  exit 2
fi

select_static_python() {
  local candidates=()
  [[ -n "${KCG_PYTHON:-}" ]] && candidates+=("$KCG_PYTHON")
  candidates+=(
    "python3"
    "$ROOT/.venv/bin/python"
    "/home/noob/WorkPlace/hamer/.conda-env/bin/python"
  )
  local candidate
  for candidate in "${candidates[@]}"; do
    [[ -x "$(command -v "$candidate" 2>/dev/null || true)" || -x "$candidate" ]] || continue
    if PYTHONPATH="$ROOT/src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}" \
      "$candidate" -c 'import numpy, scipy, yaml' >/dev/null 2>&1; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  echo "No Python interpreter with numpy/scipy/PyYAML was found." >&2
  return 1
}
STATIC_PYTHON="$(select_static_python)"
ISAAC_WRAPPER="$ROOT/src/kcg_connector/isaac/run_isaac_python.sh"
RUNNER="$ROOT/src/kcg_connector/isaac/d38999_b_minimal_v2_runner.py"
TEST_FILE="$ROOT/src/kcg_connector/test/test_d38999_b_minimal_v2.py"
VALIDATOR="$ROOT/src/kcg_connector/isaac/validate_d38999_b_minimal_v2.py"
CONFIG="$ROOT/src/kcg_connector/config/d38999_b_minimal_v2.yaml"
CANDIDATES="$ROOT/src/kcg_connector/config/d38999_b_minimal_v2_candidates.json"
PAD_CORE="$ROOT/src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
URDF="$ROOT/artifacts/kcg_connector/urdf/handarm.urdf"
TIMEOUT_SECONDS="${B_MINIMAL_V2_TIMEOUT_SECONDS:-600}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_ROOT="$ROOT/artifacts/direct_takeover/B_MINIMAL_V2_${STAMP}"
mkdir -p "$OUT_ROOT"

export PYTHONPATH="$ROOT/src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}"

for required in "$ISAAC_WRAPPER" "$RUNNER" "$TEST_FILE" "$VALIDATOR" "$CONFIG" "$CANDIDATES" "$PAD_CORE" "$URDF"; do
  if [[ ! -e "$required" ]]; then
    echo "Required file missing: $required" >&2
    exit 2
  fi
done
chmod +x "$ISAAC_WRAPPER" "$RUNNER"

summary_json="$OUT_ROOT/B_MINIMAL_V2_RUN_SUMMARY.json"
selected_file="$OUT_ROOT/SELECTED_CANDIDATE.txt"

echo "[B_MINIMAL_V2] output: $OUT_ROOT"
echo "[B_MINIMAL_V2] static validation using $STATIC_PYTHON"
"$STATIC_PYTHON" "$VALIDATOR" --repository "$ROOT" \
  | tee "$OUT_ROOT/STATIC_VALIDATION.json"

candidate_ids=(PAD_CORE_Z12 PAD_CORE_Z14 PAD_CORE_Z18)
for candidate in "${candidate_ids[@]}"; do
  dry="$OUT_ROOT/DRY_${candidate}"
  portable="$OUT_ROOT/.portable_dry_${candidate}"
  rm -rf "$dry" "$portable"
  "$STATIC_PYTHON" "$RUNNER" \
    --dry-run \
    --scenario table_pick \
    --candidate-id "$candidate" \
    --config "$CONFIG" \
    --candidates "$CANDIDATES" \
    --proxy-manifest "$PAD_CORE" \
    --source-urdf "$URDF" \
    --output-dir "$dry" \
    --kit-portable-root "$portable" \
    > "$OUT_ROOT/DRY_${candidate}.json"
done

echo "[B_MINIMAL_V2] static preflight passed"

run_one() {
  local scenario="$1"
  local candidate="$2"
  local run_dir="$OUT_ROOT/${scenario}_${candidate}"
  local portable="$OUT_ROOT/.portable_${scenario}_${candidate}"
  local log="$OUT_ROOT/${scenario}_${candidate}.log"
  rm -rf "$run_dir" "$portable"
  echo "[B_MINIMAL_V2] START scenario=$scenario candidate=$candidate"
  set +e
  timeout --signal=TERM --kill-after=10s "${TIMEOUT_SECONDS}s" \
    "$ISAAC_WRAPPER" "$RUNNER" \
      --scenario "$scenario" \
      --candidate-id "$candidate" \
      --config "$CONFIG" \
      --candidates "$CANDIDATES" \
      --proxy-manifest "$PAD_CORE" \
      --source-urdf "$URDF" \
      --output-dir "$run_dir" \
      --kit-portable-root "$portable" \
      2>&1 | tee "$log"
  local rc=${PIPESTATUS[0]}
  set -e
  echo "$rc" > "$run_dir.process_exit_code.txt"
  if [[ ! -f "$run_dir/B_MINIMAL_V2_RESULT.json" ]]; then
    "$STATIC_PYTHON" - "$scenario" "$candidate" "$rc" "$run_dir" <<'PY'
import json, sys
from pathlib import Path
scenario, candidate, rc, run_dir = sys.argv[1:]
out = {
    "schema": "D38999_B_MINIMAL_V2_RESULT",
    "status": "ERROR",
    "classification": "B_MINIMAL_V2_MISSING_RESULT_FILE",
    "scenario": scenario,
    "candidate_id": candidate,
    "process_exit_code": int(rc),
    "output_dir": run_dir,
    "fast_baseline_passed": False,
    "formal_b_passed": False,
}
Path(run_dir).mkdir(parents=True, exist_ok=True)
Path(run_dir, "B_MINIMAL_V2_RESULT.json").write_text(
    json.dumps(out, indent=2, sort_keys=True) + "\n"
)
PY
  fi
  "$STATIC_PYTHON" - "$run_dir/B_MINIMAL_V2_RESULT.json" <<'PY'
import json, sys
p=json.load(open(sys.argv[1]))
print("[B_MINIMAL_V2] RESULT", p.get("scenario"), p.get("candidate_id") or p.get("candidate",{}).get("candidate_id"), p.get("status"), p.get("classification"))
PY
}

result_field() {
  local result="$1"
  local field="$2"
  "$STATIC_PYTHON" - "$result" "$field" <<'PY'
import json, sys
p=json.load(open(sys.argv[1]))
value=p
for part in sys.argv[2].split('.'):
    if not isinstance(value, dict) or part not in value:
        print("")
        raise SystemExit(0)
    value=value[part]
if isinstance(value, bool):
    print("true" if value else "false")
elif value is None:
    print("")
else:
    print(value)
PY
}

package_and_stop() {
  local reason="$1"
  "$STATIC_PYTHON" - "$OUT_ROOT" "$reason" "$summary_json" <<'PY'
import json, sys
from pathlib import Path
root=Path(sys.argv[1]); reason=sys.argv[2]; target=Path(sys.argv[3])
results=[]
for p in sorted(root.glob("*/B_MINIMAL_V2_RESULT.json")):
    try:
        row=json.loads(p.read_text()); row["_path"]=str(p); results.append(row)
    except Exception as exc:
        results.append({"path":str(p),"parse_error":repr(exc)})
out={
  "schema":"D38999_B_MINIMAL_V2_RUN_SUMMARY",
  "status":"STOPPED",
  "reason":reason,
  "output_root":str(root),
  "results":results,
  "formal_b_passed":False,
}
target.write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+"\n")
PY
  local direct_root
  local run_name
  local package
  local temporary_package
  direct_root="$(dirname "$OUT_ROOT")"
  run_name="$(basename "$OUT_ROOT")"
  package="$direct_root/${run_name}_FAILURE_PACKAGE.tar.gz"
  temporary_package="/tmp/${run_name}_FAILURE_PACKAGE.$$.tar.gz"
  rm -f "$temporary_package"
  # Keep the diagnostic package uploadable. The portable Kit runtime, imported
  # rig USD and full stage can be regenerated and are not needed for control
  # root-cause analysis.
  tar \
    --exclude="$run_name/.portable_*" \
    --exclude="$run_name/*/rig_usd" \
    --exclude="$run_name/*/B_MINIMAL_V2_STAGE.usda" \
    -czf "$temporary_package" \
    -C "$direct_root" \
    "$run_name"
  mv -- "$temporary_package" "$package"
  echo "[B_MINIMAL_V2] STOPPED: $reason"
  echo "[B_MINIMAL_V2] failure package: $package"
  exit 4
}

# Integration gate 1: the articulation must remain finite and quiet with zero collision.
run_one hand_stability PAD_CORE_Z12
hand_result="$OUT_ROOT/hand_stability_PAD_CORE_Z12/B_MINIMAL_V2_RESULT.json"
if [[ "$(result_field "$hand_result" status)" != "PASS" ]]; then
  package_and_stop "HAND_STABILITY_GATE_FAILED"
fi

is_candidate_physical_error() {
  case "$1" in
    B_MINIMAL_V2_PAD_FORCE_PRELOAD_NOT_REACHED|\
    B_MINIMAL_V2_PRE_RELEASE_GRIP_NOT_STABLE|\
    B_MINIMAL_V2_THREE_PAD_CONTACT_LOSS|\
    B_MINIMAL_V2_ROOT_TORQUE_DIAGNOSTIC_CAP)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

selected=""
for candidate in "${candidate_ids[@]}"; do
  # Integration gate 2: support removal in free space.  This isolates grasp
  # capacity from the table release transient.
  run_one offtable_grasp "$candidate"
  off_result="$OUT_ROOT/offtable_grasp_${candidate}/B_MINIMAL_V2_RESULT.json"
  off_status="$(result_field "$off_result" status)"
  off_class="$(result_field "$off_result" classification)"
  if [[ "$off_status" == "ERROR" ]] && ! is_candidate_physical_error "$off_class"; then
    package_and_stop "OFFTABLE_INTEGRATION_ERROR_${candidate}_${off_class}"
  fi
  if [[ "$off_status" != "PASS" ]]; then
    echo "[B_MINIMAL_V2] candidate rejected by off-table gate: $candidate"
    continue
  fi

  # Integration gate 3: the same grasp must pick from the table and lift 40 mm.
  run_one table_pick "$candidate"
  table_result="$OUT_ROOT/table_pick_${candidate}/B_MINIMAL_V2_RESULT.json"
  table_status="$(result_field "$table_result" status)"
  table_class="$(result_field "$table_result" classification)"
  if [[ "$table_status" == "ERROR" ]] && ! is_candidate_physical_error "$table_class"; then
    package_and_stop "TABLE_PICK_INTEGRATION_ERROR_${candidate}_${table_class}"
  fi
  if [[ "$table_status" == "PASS" ]]; then
    selected="$candidate"
    printf '%s\n' "$candidate" > "$selected_file"
    break
  fi
  echo "[B_MINIMAL_V2] candidate rejected by table-pick gate: $candidate"
done

if [[ -z "$selected" ]]; then
  package_and_stop "NO_CANDIDATE_PASSED_OFFTABLE_AND_TABLE_GATES"
fi

"$STATIC_PYTHON" - "$OUT_ROOT" "$selected" "$CANDIDATES" "$summary_json" <<'PY'
import json, sys
from pathlib import Path
import yaml
root=Path(sys.argv[1]); selected=sys.argv[2]; manifest=Path(sys.argv[3]); summary=Path(sys.argv[4])
data=json.loads(manifest.read_text())
candidate=next(row for row in data["candidates"] if row["candidate_id"]==selected)
result=json.loads((root/f"table_pick_{selected}"/"B_MINIMAL_V2_RESULT.json").read_text())
override={
  "schema_version":"d38999_b_minimal_v2_selected_grasp_v1",
  "status":"DIAGNOSTIC_BASELINE_PASS_NOT_FORMAL_B",
  "selected_candidate":selected,
  "candidate":candidate,
  "runtime_result":{
    "object_lift_m":result.get("object_lift_m"),
    "object_xy_drift_m":result.get("object_xy_drift_m"),
    "object_tilt_rad":result.get("object_tilt_rad"),
    "final_hold_pad_force_n":result.get("final_hold_pad_force_n"),
    "final_hold_table_force_n":result.get("final_hold_table_force_n"),
  },
  "formal_b_passed":False,
  "next_task":"INTEGRATE_SELECTED_GRASP_INTO_FULL_IIWA_B_SCENE",
}
(root/"B_MINIMAL_V2_SELECTED_GRASP.yaml").write_text(yaml.safe_dump(override,sort_keys=False,allow_unicode=True))
all_results=[]
for p in sorted(root.glob("*/B_MINIMAL_V2_RESULT.json")):
    try:
        row=json.loads(p.read_text()); row["_path"]=str(p); all_results.append(row)
    except Exception:
        pass
out={
  "schema":"D38999_B_MINIMAL_V2_RUN_SUMMARY",
  "status":"PASS",
  "selected_candidate":selected,
  "output_root":str(root),
  "results":all_results,
  "diagnostic_baseline_passed":True,
  "formal_b_passed":False,
}
summary.write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+"\n")
PY

echo "[B_MINIMAL_V2] PASS selected=$selected"
echo "[B_MINIMAL_V2] output=$OUT_ROOT"
echo "[B_MINIMAL_V2] next=integrate selected grasp into the full iiwa B scene"
