#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
MODE="${1:-${B_ALL_GUI_MODE:-clean}}"
VIEW="${2:-${B_ALL_GUI_CAMERA_PRESET:-grasp}}"
HOLD_SECONDS="${B_ALL_GUI_HOLD_SECONDS:-120}"
DRY_RUN="${B_ALL_GUI_DRY_RUN:-0}"

case "$MODE" in
  clean) LIVE_MODE="clean" ;;
  debug|collision_debug) LIVE_MODE="collision_debug" ;;
  *)
    echo "Mode must be clean or debug: $MODE" >&2
    exit 2
    ;;
esac
case "$VIEW" in
  overview|grasp|side) ;;
  *)
    echo "Camera must be overview, grasp, or side: $VIEW" >&2
    exit 2
    ;;
esac
if ! [[ "$HOLD_SECONDS" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
  echo "B_ALL_GUI_HOLD_SECONDS must be a number of seconds: $HOLD_SECONDS" >&2
  exit 2
fi
if ! awk -v hold="$HOLD_SECONDS" 'BEGIN { exit !(hold >= 120.0) }'; then
  echo "B_ALL_GUI_HOLD_SECONDS must be at least 120 seconds." >&2
  exit 2
fi

CONTROL_FILES=(
  "$ROOT/artifacts/agent_control/PROJECT_CHARTER_CN.md"
  "$ROOT/artifacts/agent_control/WORK_QUEUE.yaml"
  "$ROOT/artifacts/agent_control/MASTER_STATE.json"
  "$ROOT/artifacts/agent_control/BLOCKER_LEDGER.jsonl"
  "$ROOT/artifacts/agent_control/GATE_LEDGER.csv"
  "$ROOT/artifacts/agent_control/AUTONOMOUS_RESUME_CN.md"
  "$ROOT/artifacts/agent_control/TASK_GRAPH.yaml"
  "$ROOT/artifacts/agent_control/CURRENT_TASK.md"
)
for control_file in "${CONTROL_FILES[@]}"; do
  if [[ ! -s "$control_file" ]]; then
    echo "Required control file is missing or empty: $control_file" >&2
    exit 2
  fi
  sed -n '1,$p' "$control_file" >/dev/null
done

RUNNER="$ROOT/src/kcg_connector/isaac/b_goal_mode/full_iiwa_table_pick.py"
VIEWER="$ROOT/src/kcg_connector/isaac/b_goal_mode/full_iiwa_trace_gui_viewer.py"
ISAAC_LAUNCHER="$ROOT/src/kcg_connector/isaac/run_isaac_python.sh"
SUPERVISOR="$ROOT/run_b_goal_mode_supervisor.sh"
CONFIG="$ROOT/src/kcg_connector/config/b_goal_mode/full_iiwa_b_goal_mode.yaml"
for required in "$RUNNER" "$VIEWER" "$ISAAC_LAUNCHER" "$SUPERVISOR" "$CONFIG"; do
  if [[ ! -f "$required" ]]; then
    echo "Required file is missing: $required" >&2
    exit 2
  fi
done
if [[ ! -x "$ISAAC_LAUNCHER" || ! -x "$SUPERVISOR" ]]; then
  echo "Isaac launcher or B supervisor is not executable." >&2
  exit 2
fi

ISAAC_ENV_PREFIX="${ISAAC_ENV_PREFIX:-/home/noob/WorkPlace/isaacsim/.conda-env}"
if [[ ! -x "$ISAAC_ENV_PREFIX/bin/python" ]]; then
  echo "Isaac Sim Python was not found: $ISAAC_ENV_PREFIX/bin/python" >&2
  exit 2
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)_$$"
RUN_ROOT="$ROOT/artifacts/b_goal_mode/B_ALL_COLLISION_GUI_DECOUPLED_${LIVE_MODE^^}_${VIEW^^}_$STAMP"
PHYSICS_OUT="$RUN_ROOT/PHYSICS"
VIEWER_OUT="$RUN_ROOT/GUI_VIEWER"
PHYSICS_PORTABLE="$ROOT/artifacts/b_goal_mode/.portable_B_ALL_COLLISION_GUI_PHYSICS_$STAMP"
VIEWER_PORTABLE="$ROOT/artifacts/b_goal_mode/.portable_B_ALL_COLLISION_GUI_VIEWER_$STAMP"
VIDEO="$PHYSICS_OUT/B_ALL_COLLISION_GUI_${LIVE_MODE^^}.mp4"

PHYSICS_ARGS=(
  --scenario integration
  --config "$CONFIG"
  --candidate-id CAD_P118_Q658_Q539
  --visual-overlay-complete
  --live-visual-mode "$LIVE_MODE"
  --record-live-video
  --video-output "$VIDEO"
  --output-dir "$PHYSICS_OUT"
  --kit-portable-root "$PHYSICS_PORTABLE"
)

echo "B_ALL_COLLISION_TRUTH_AUTONOMOUS one-click GUI"
echo "Mode:            $LIVE_MODE"
echo "Camera:          $VIEW"
echo "Final hold:      $HOLD_SECONDS seconds"
echo "Evidence root:   $RUN_ROOT"
echo "Stage 1: fresh headless Isaac physics; this is the dynamic acceptance source."
echo "Stage 2: independent interactive trace viewer; this is post-hoc visualization only."
echo "Viewer controls: Play/Pause/Restart/Final pose/Exit, plus viewport orbit/pan/zoom."
echo "Debug command:   bash run_full_iiwa_all_collision_truth_gui.sh debug"

if [[ "$DRY_RUN" == 1 ]]; then
  echo "Dry-run only; Isaac Sim and the interactive viewer will not start."
  export PYTHONPATH="$ROOT/src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}"
  python3 "$RUNNER" "${PHYSICS_ARGS[@]}" --dry-run
  echo "Planned viewer: $VIEWER_OUT (requires the fresh physics PASS above at real run time)."
  exit 0
fi

if pgrep -f '[f]ull_iiwa_table_pick.py|[f]ull_iiwa_trace_gui_viewer.py|[p]ublication_render_replay.py' >/dev/null; then
  echo "A D38999 B runner or viewer is already active; refusing a parallel Isaac launch." >&2
  pgrep -af '[f]ull_iiwa_table_pick.py|[f]ull_iiwa_trace_gui_viewer.py|[p]ublication_render_replay.py' >&2 || true
  exit 3
fi
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  echo "No DISPLAY or WAYLAND_DISPLAY is available for the Isaac GUI." >&2
  exit 3
fi

SESSION_POINTER="$ROOT/artifacts/b_goal_mode/ACTIVE_SESSION_PATH.txt"
if [[ ! -s "$SESSION_POINTER" ]]; then
  echo "B_GOAL_MODE active-session pointer is missing: $SESSION_POINTER" >&2
  exit 3
fi
SESSION="$(readlink -f "$(sed -n '1p' "$SESSION_POINTER")")"
if [[ ! -s "$SESSION/CURRENT_GOAL_STATE.json" ]]; then
  echo "B_GOAL_MODE session is invalid: $SESSION" >&2
  exit 3
fi

PHYSICS_GOAL_ID="B_ALL_COLLISION_GUI_PHYSICS_${LIVE_MODE^^}_$STAMP"
PHYSICS_COMMAND=(
  timeout --signal=TERM --kill-after=10s 1500s
  "$ISAAC_LAUNCHER" "$RUNNER" "${PHYSICS_ARGS[@]}"
)
"$SUPERVISOR" "$ROOT" \
  --session-dir "$SESSION" \
  --goal-id "$PHYSICS_GOAL_ID" \
  --unique-change "Fresh headless physical integration for the one-click GUI; final collision representation and frozen controller unchanged." \
  --expected-result "The physical run passes all four lift stages, PAD share and unauthorized-collision gates, and records the selected live view." \
  --failure-criterion "The fresh physical process exits nonzero or any integration, lift, PAD-share, unauthorized-contact, or live-capture gate fails." \
  --failure-branch "Preserve this physical evidence and stop before opening a viewer; do not mask a failed run with post-hoc replay." \
  -- "${PHYSICS_COMMAND[@]}"

PHYSICS_RESULT="$PHYSICS_OUT/FULL_IIWA_RESULT.json"
PHYSICS_TRACE="$PHYSICS_OUT/FULL_IIWA_TRACE.csv"
PHYSICS_STAGE="$PHYSICS_OUT/FULL_IIWA_STAGE.usda"
python3 - "$PHYSICS_RESULT" "$PHYSICS_TRACE" "$PHYSICS_STAGE" "$VIDEO" <<'PY'
import csv
import json
import pathlib
import sys

result_path, trace_path, stage_path, video_path = map(pathlib.Path, sys.argv[1:])
for path in (result_path, trace_path, stage_path, video_path):
    if not path.is_file() or path.stat().st_size <= 0:
        raise SystemExit(f"missing or empty physical evidence: {path}")
result = json.loads(result_path.read_text(encoding="utf-8"))
checks = {
    "status": result.get("status") == "PASS",
    "classification": result.get("classification") == "FULL_IIWA_INTEGRATION_QUIET_HOLD_PASS",
    "candidate": result.get("candidate_id") == "CAD_P118_Q658_Q539",
    "physics_steps": result.get("physics_steps") == 10737,
    "lift_stage_count": len(result.get("lift", {}).get("stage_results", [])) == 4,
    "lift_stages": all(stage.get("passed") is True for stage in result.get("lift", {}).get("stage_results", [])),
    "pad_share": set(result.get("pad_normal_impulse_share", {})) == {"f1Link3", "f2Link2", "f3Link3"} and all(float(value) >= 0.90 for value in result.get("pad_normal_impulse_share", {}).values()),
    "unauthorized_contacts": len(result.get("unauthorized_contact_pairs", {})) == 0,
    "tip_not_main_bearing": result.get("red_tip_main_bearing") is False,
    "live_capture": result.get("live_visualization", {}).get("passed") is True and result.get("live_visualization", {}).get("status") == "B_FULL_IIWA_LIVE_CAPTURE_PASS",
}
with trace_path.open(newline="", encoding="utf-8") as stream:
    checks["trace_rows"] = sum(1 for _ in csv.DictReader(stream)) == 10737
failed = [name for name, passed in checks.items() if not passed]
print(json.dumps({"physical_acceptance_checks": checks}, ensure_ascii=False, sort_keys=True))
if failed:
    raise SystemExit("physical acceptance gate failed: " + ", ".join(failed))
PY

echo "Fresh physical run PASS. Opening a separate post-hoc viewer; viewer motion is not dynamic evidence."
VIEWER_GOAL_ID="B_ALL_COLLISION_GUI_VIEWER_${LIVE_MODE^^}_$STAMP"
VIEWER_COMMAND=(
  timeout --signal=TERM --kill-after=10s 1500s
  "$ISAAC_LAUNCHER" "$VIEWER"
  --stage "$PHYSICS_STAGE"
  --trace "$PHYSICS_TRACE"
  --result "$PHYSICS_RESULT"
  --output-dir "$VIEWER_OUT"
  --kit-portable-root "$VIEWER_PORTABLE"
  --visual-mode "$LIVE_MODE"
  --camera-preset "$VIEW"
  --final-hold-seconds "$HOLD_SECONDS"
)
"$SUPERVISOR" "$ROOT" \
  --session-dir "$SESSION" \
  --goal-id "$VIEWER_GOAL_ID" \
  --unique-change "Interactive post-hoc viewer of the newly accepted physical trace; collisions and gravity disabled and no controller executed." \
  --expected-result "The viewer replays every sampled trace frame, offers pause/orbit/zoom, reaches the accepted final pose, and holds it for at least ${HOLD_SECONDS} seconds." \
  --failure-criterion "The GUI does not open, source validation fails, pose readback exceeds its viewer-only bound, or final hold is shorter than ${HOLD_SECONDS} seconds." \
  --failure-branch "Preserve the accepted physical evidence separately and fix only the viewer; never reinterpret a viewer failure as a physics failure." \
  -- "${VIEWER_COMMAND[@]}"

VIEWER_RESULT="$VIEWER_OUT/GUI_VIEWER_RESULT.json"
python3 - "$VIEWER_RESULT" "$HOLD_SECONDS" <<'PY'
import json
import math
import pathlib
import sys

result_path = pathlib.Path(sys.argv[1])
required_hold = float(sys.argv[2])
if not result_path.is_file() or result_path.stat().st_size <= 0:
    raise SystemExit(f"missing GUI viewer result: {result_path}")
result = json.loads(result_path.read_text(encoding="utf-8"))
checks = {
    "status": result.get("status") == "GUI_TRACE_VIEWER_PASS" and result.get("passed") is True,
    "scope": result.get("scope") == "POSTHOC_VIEW_ONLY_NOT_DYNAMIC_EVIDENCE",
    "gui_opened": result.get("gui_opened") is True,
    "controller_not_executed": result.get("controller_executed") is False,
    "viewer_physics_not_stepped": result.get("viewer_physics_stepped") is False,
    "collisions_disabled": int(result.get("disabled_collision_prim_count", 0)) > 0,
    "gravity_disabled": float(result.get("gravity_m_s2", math.inf)) == 0.0,
    "final_pose": result.get("final_pose_reached") is True,
    "final_hold": float(result.get("final_hold_seconds_observed", 0.0)) >= required_hold,
    "not_closed_early": result.get("closed_or_exited_early") is False,
}
failed = [name for name, passed in checks.items() if not passed]
print(json.dumps({"viewer_acceptance_checks": checks}, ensure_ascii=False, sort_keys=True))
if failed:
    raise SystemExit("GUI viewer gate failed: " + ", ".join(failed))
PY

echo "One-click GUI workflow PASS"
echo "Dynamic evidence: $PHYSICS_RESULT"
echo "Interactive viewer evidence: $VIEWER_RESULT"
echo "Recorded live physical video: $VIDEO"
