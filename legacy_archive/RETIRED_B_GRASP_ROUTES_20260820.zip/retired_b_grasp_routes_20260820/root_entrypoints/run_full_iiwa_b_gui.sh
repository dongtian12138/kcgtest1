#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/home/noob/WorkPlace/kcgtest1}"
ROOT="$(readlink -f "$ROOT")"
VIEW="${2:-${B_GUI_CAMERA_PRESET:-overview}}"
RECORD="${3:-${B_GUI_RECORD:-0}}"
HOLD_SECONDS="${B_GUI_HOLD_SECONDS:-120}"
DRY_RUN="${B_GUI_DRY_RUN:-0}"

case "$VIEW" in
  overview|grasp|side) ;;
  *)
    echo "Camera must be overview, grasp, or side: $VIEW" >&2
    exit 2
    ;;
esac
case "$RECORD" in
  0|false|no) RECORD=0 ;;
  1|true|yes|record) RECORD=1 ;;
  *)
    echo "Record mode must be 0/1 or false/true: $RECORD" >&2
    exit 2
    ;;
esac
if ! [[ "$HOLD_SECONDS" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
  echo "B_GUI_HOLD_SECONDS must be a non-negative number: $HOLD_SECONDS" >&2
  exit 2
fi

RUNNER="$ROOT/src/kcg_connector/isaac/b_goal_mode/full_iiwa_table_pick.py"
ISAAC_LAUNCHER="$ROOT/src/kcg_connector/isaac/run_isaac_python.sh"
SUPERVISOR="$ROOT/run_b_goal_mode_supervisor.sh"
CONFIG="$ROOT/src/kcg_connector/config/b_goal_mode/full_iiwa_b_goal_mode.yaml"
for required in "$RUNNER" "$ISAAC_LAUNCHER" "$SUPERVISOR" "$CONFIG"; do
  if [[ ! -f "$required" ]]; then
    echo "Required file is missing: $required" >&2
    exit 2
  fi
done
if [[ ! -x "$ISAAC_LAUNCHER" || ! -x "$SUPERVISOR" ]]; then
  echo "Isaac launcher or B supervisor is not executable." >&2
  exit 2
fi

ISAAC_ENV_PREFIX="${ISAAC_ENV_PREFIX:-/home/noob/WorkPlace/isaacsim/.conda-env}"
if [[ ! -x "$ISAAC_ENV_PREFIX/bin/python" ]]; then
  echo "Isaac Sim Python was not found: $ISAAC_ENV_PREFIX/bin/python" >&2
  exit 2
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$ROOT/artifacts/b_goal_mode/GUI_FULL_IIWA_B_${VIEW}_${STAMP}"
PORTABLE="$ROOT/artifacts/b_goal_mode/.portable_GUI_FULL_IIWA_B_${VIEW}_${STAMP}"
VIDEO="$OUT/B_FULL_IIWA_LIVE_RUN.mp4"

RUNNER_ARGS=(
  --scenario integration
  --config "$CONFIG"
  --gui
  --gui-renderer RayTracedLighting
  --gui-camera-preset "$VIEW"
  --gui-hold-seconds "$HOLD_SECONDS"
  --visual-overlay-complete
  --output-dir "$OUT"
  --kit-portable-root "$PORTABLE"
)
if [[ "$RECORD" == 1 ]]; then
  RUNNER_ARGS+=(--record-live-video --video-output "$VIDEO")
fi

echo "GUI camera:    $VIEW"
echo "GUI output:    $OUT"
echo "Portable root: $PORTABLE"
echo "Record video:  $RECORD"
echo "Hold seconds:  $HOLD_SECONDS"
echo "Scope: live diagnostic PAD proxy; not B_FORMAL_DYNAMIC_PASS."

if [[ "$DRY_RUN" == 1 ]]; then
  echo "Dry-run only; Isaac Sim will not start."
  export PYTHONPATH="$ROOT/src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}"
  exec python3 "$RUNNER" "${RUNNER_ARGS[@]}" --dry-run
fi

if pgrep -f '[f]ull_iiwa_table_pick.py|[p]ublication_render_replay.py' >/dev/null; then
  echo "A D38999 B runner is already active; refusing a parallel Isaac launch." >&2
  pgrep -af '[f]ull_iiwa_table_pick.py|[p]ublication_render_replay.py' >&2 || true
  exit 3
fi
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  echo "No DISPLAY or WAYLAND_DISPLAY is available for the Isaac GUI." >&2
  exit 3
fi

SESSION_POINTER="$ROOT/artifacts/b_goal_mode/ACTIVE_SESSION_PATH.txt"
if [[ ! -s "$SESSION_POINTER" ]]; then
  echo "B_GOAL_MODE active-session pointer is missing: $SESSION_POINTER" >&2
  exit 3
fi
SESSION="$(readlink -f "$(sed -n '1p' "$SESSION_POINTER")")"
if [[ ! -s "$SESSION/CURRENT_GOAL_STATE.json" ]]; then
  echo "B_GOAL_MODE session is invalid: $SESSION" >&2
  exit 3
fi

GOAL_ID="B_VISUAL_GUI_${VIEW^^}_${STAMP}"
COMMAND=(
  timeout --signal=TERM --kill-after=10s 1500s
  "$ISAAC_LAUNCHER" "$RUNNER" "${RUNNER_ARGS[@]}"
)

exec "$SUPERVISOR" "$ROOT" \
  --session-dir "$SESSION" \
  --goal-id "$GOAL_ID" \
  --unique-change "Live GUI view only: camera=${VIEW}, record=${RECORD}; frozen B physics and controller unchanged." \
  --expected-result "Isaac GUI shows the complete iiwa live stage and remains open for ${HOLD_SECONDS} seconds; diagnostic evidence is saved under ${OUT}." \
  --failure-criterion "GUI fails to open, the live physical run fails, or required visual output is missing." \
  --failure-branch "Stop this GUI run and preserve its supervised log; do not tune B or enter C/D/E." \
  -- "${COMMAND[@]}"
