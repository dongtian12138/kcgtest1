#!/usr/bin/env bash
set -euo pipefail
cd "${1:-$PWD}"

choose_python() {
  local candidates=()
  if [[ -n "${KCG_PYTHON:-}" ]]; then
    candidates+=("$KCG_PYTHON")
  fi
  candidates+=("python3" ".venv/bin/python")
  local candidate
  for candidate in "${candidates[@]}"; do
    if [[ "$candidate" == */* && ! -x "$candidate" ]]; then
      continue
    fi
    if command -v "$candidate" >/dev/null 2>&1 || [[ -x "$candidate" ]]; then
      if PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 "$candidate" - <<'PY' >/dev/null 2>&1
import numpy, scipy, yaml, pytest
PY
      then
        printf '%s\n' "$candidate"
        return 0
      fi
    fi
  done
  return 1
}

PYTHON_BIN="$(choose_python)" || {
  echo "No Python interpreter has numpy, scipy, PyYAML and pytest." >&2
  echo "Set KCG_PYTHON=/path/to/python and rerun." >&2
  exit 2
}

export PYTHONPATH="src/kcg_connector${PYTHONPATH:+:$PYTHONPATH}"
"$PYTHON_BIN" -m py_compile \
  src/kcg_connector/kcg_connector/grasp/d38999_b_fast_pick.py \
  src/kcg_connector/isaac/build_d38999_b_fast_pick_candidates.py \
  src/kcg_connector/isaac/d38999_b_fast_pick_rig.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 "$PYTHON_BIN" -m pytest -q \
  src/kcg_connector/test/test_d38999_b_fast_pick.py \
  src/kcg_connector/test/test_d38999_b_fast_pick_rig.py
"$PYTHON_BIN" src/kcg_connector/isaac/build_d38999_b_fast_pick_candidates.py
rm -rf /tmp/kcg-b-fast-dry-run /tmp/kcg-b-fast-dry-portable
"$PYTHON_BIN" src/kcg_connector/isaac/d38999_b_fast_pick_rig.py \
  --candidate-id PAD_Z19 \
  --output-dir /tmp/kcg-b-fast-dry-run \
  --kit-portable-root /tmp/kcg-b-fast-dry-portable \
  --dry-run
printf '%s\n' "B_FAST_PICK_STATIC_VALIDATION_PASS python=$PYTHON_BIN"
