#!/usr/bin/env python3
"""Full-iiwa tabletop pick with complete CAD-derived fingertip collision."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np
import yaml

from kcg_connector.d38999_tabletop_pick import (
    iiwa14_grasp_tcp_transform,
    interpolate_arm,
)
from kcg_connector.d38999_tabletop_scene import (
    author_d38999_tabletop_scene,
    load_d38999_tabletop_scene,
    verify_d38999_tabletop_asset,
)
from kcg_connector.grasp.b_goal_mode.bumpless_force_controller import (
    BumplessThreeFingerForceController,
    ForceControlOutput,
)
from kcg_connector.grasp.b_goal_mode.contact_wrench_audit import (
    aggregate_contact_wrench,
)
from kcg_connector.grasp.b_goal_mode.full_iiwa_integration import (
    CLAIM_SCOPE,
    DEFAULT_CONFIG,
    advance_closure_target,
    build_full_iiwa_plan,
    compute_proprioceptive_load_transfer_compensation,
    load_full_iiwa_config,
    map_force_controller_targets,
    write_plan,
)
from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    ACTIVE_PAD_LINKS,
    ROOT_TORQUE_JOINTS,
)
from kcg_connector.grasp.b_goal_mode.independent_contact_latch import (
    IndependentContactLatch,
    compute_tare_statistics,
)
from kcg_connector.grasp.b_goal_mode.lift_axis_controller import minimum_jerk
from kcg_connector.grasp.b_goal_mode.live_visualization import (
    FULL_ASSEMBLY_OVERVIEW_EYE_M,
    FULL_ASSEMBLY_OVERVIEW_TARGET_M,
    FullIiwaLiveVisualizer,
)
from kcg_connector.grasp.b_goal_mode.quiet_hold import assess_force_quiet_hold
from kcg_connector.grasp.b_goal_mode.root_torque_force_calibration import (
    RootTorqueForceFit,
    fit_g1_trace,
    serialize_fits,
)
from kcg_connector.grasp.b_goal_mode.slip_monitor import (
    ProprioceptiveSlipMonitor,
    ProprioceptiveSlipObservation,
)
from kcg_connector.grasp.d38999_pad_contact_roles import (
    FINGER_PAD_ROLE_SPECS,
    build_finger_pad_role,
)


REPOSITORY = Path(__file__).resolve().parents[4]
RESULT_SCHEMA = "D38999_FULL_IIWA_B_GOAL_MODE_RESULT_V2"
SCENARIO_GOALS = {
    "precheck": "FULL_IIWA_D0_ZERO_PRECONTACT",
    "integration": "FULL_IIWA_INTEGRATION_QUIET_HOLD",
    "validation": "FULL_IIWA_TABLE_PICK_VALIDATION",
}
FINGER_PREFIX = {"f1Link3": "f1", "f2Link2": "f2", "f3Link3": "f3"}
FINGER_LINKS = {
    "f1Link3": ("f1Link1", "f1Link2", "f1Link3"),
    "f2Link2": ("f2Link1", "f2Link2"),
    "f3Link3": ("f3Link1", "f3Link2", "f3Link3"),
}



GUI_CAMERA_PRESETS = {
    "overview": {
        "eye_m": FULL_ASSEMBLY_OVERVIEW_EYE_M,
        "target_m": FULL_ASSEMBLY_OVERVIEW_TARGET_M,
    },
    "grasp": {
        "eye_m": (0.20, -0.55, 0.34),
        "target_m": (0.520, -0.210, 0.245),
    },
    "side": {
        "eye_m": (0.18, 0.02, 0.32),
        "target_m": (0.520, -0.210, 0.245),
    },
}


def configure_gui_camera(*, stage: Any, preset: str, application: Any, UsdGeom: Any) -> None:
    if preset == "none":
        return
    from isaacsim.core.rendering_manager import ViewportManager

    values = GUI_CAMERA_PRESETS[preset]
    camera = UsdGeom.Camera.Define(stage, "/World/BFullIiwaInteractiveCamera")
    camera.CreateFocalLengthAttr(32.0)
    camera.CreateHorizontalApertureAttr(20.955)
    camera.CreateVerticalApertureAttr(20.955 * 720.0 / 1280.0)
    camera.CreateClippingRangeAttr((0.02, 12.0))
    ViewportManager.set_camera_view(
        camera=camera,
        eye=np.asarray(values["eye_m"], dtype=np.float64),
        target=np.asarray(values["target_m"], dtype=np.float64),
    )
    for _ in range(3):
        application.update()


class RuntimeGuardError(RuntimeError):
    def __init__(self, message: str, diagnostic: Mapping[str, Any]):
        super().__init__(message)
        self.diagnostic = dict(diagnostic)


class D0FirstCollisionReached(RuntimeGuardError):
    """Controlled D0 stop after the first robot-environment collision."""


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=tuple(SCENARIO_GOALS), required=True)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument(
        "--candidate-id",
        help="Select one configured candidate from the complete-CAD rescreen.",
    )
    parser.add_argument("--validation-index", type=int, default=0)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gui", action="store_true")
    parser.add_argument(
        "--gui-renderer",
        choices=("Minimal", "RayTracedLighting"),
        default="RayTracedLighting",
        help="Renderer used only when --gui is active.",
    )
    parser.add_argument(
        "--gui-camera-preset",
        choices=("overview", "grasp", "side", "none"),
        default="overview",
    )
    parser.add_argument(
        "--gui-hold-seconds",
        type=float,
        default=60.0,
        help="Keep the GUI open at the final pose for inspection.",
    )
    parser.add_argument(
        "--visual-overlay-complete",
        action="store_true",
        help="Render the frozen complete connector appearance as a nonphysical overlay.",
    )
    parser.add_argument(
        "--live-visual-mode",
        choices=("clean", "collision_debug"),
        default="clean",
        help="Clean live view or render-only collision diagnostics; physics is identical.",
    )
    parser.add_argument(
        "--record-live-video",
        action="store_true",
        help="Capture live milestones and an equal-time 20 fps MP4 from this run.",
    )
    parser.add_argument(
        "--video-output",
        help="MP4 path; relative paths are resolved below --output-dir.",
    )
    result = parser.parse_args(argv)
    if result.gui_hold_seconds < 0.0:
        parser.error("--gui-hold-seconds must be non-negative")
    if result.record_live_video and not result.visual_overlay_complete:
        parser.error("--record-live-video requires --visual-overlay-complete")
    if result.live_visual_mode == "collision_debug" and not result.visual_overlay_complete:
        parser.error("--live-visual-mode collision_debug requires --visual-overlay-complete")
    if result.video_output and not result.record_live_video:
        parser.error("--video-output requires --record-live-video")
    return result


def load_inputs(
    run_arguments: argparse.Namespace,
) -> tuple[
    dict[str, Any],
    dict[str, Path],
    dict[str, Any],
    dict[str, Any],
    dict[str, RootTorqueForceFit],
]:
    config, paths = load_full_iiwa_config(
        Path(run_arguments.config).resolve(), repository_root=REPOSITORY
    )
    if run_arguments.scenario == "validation" and run_arguments.validation_index not in (
        1,
        2,
        3,
    ):
        raise ValueError("validation-index must be 1, 2 or 3")
    if run_arguments.scenario != "validation" and run_arguments.validation_index != 0:
        raise ValueError("validation-index is only valid for validation")
    plan = build_full_iiwa_plan(
        Path(run_arguments.config).resolve(),
        repository_root=REPOSITORY,
        candidate_id=run_arguments.candidate_id,
    )
    selected = yaml.safe_load(
        paths["selected_goal_config"].read_text(encoding="utf-8")
    )
    fits = fit_g1_trace(paths["g1_trace"])
    return config, paths, plan, selected, fits


def dry_run(run_arguments: argparse.Namespace) -> dict[str, Any]:
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config, _paths, plan, selected, fits = load_inputs(run_arguments)
    write_plan(output / "FULL_IIWA_PLAN.json", plan)
    report = {
        "schema": RESULT_SCHEMA,
        "status": "DRY_RUN_PASS",
        "classification": f"{SCENARIO_GOALS[run_arguments.scenario]}_DRY_RUN_PASS",
        "goal_id": SCENARIO_GOALS[run_arguments.scenario],
        "scenario": run_arguments.scenario,
        "validation_index": run_arguments.validation_index,
        "candidate_id": plan["candidate_id"],
        "claim_scope": CLAIM_SCOPE,
        "pad_contract": plan["pad_contract"],
        "ik": plan["ik"],
        "root_torque_force_proxy": serialize_fits(fits),
        "first_force_target_n_per_finger": selected["g4_compliant_force_control"][
            "first_force_target_n_per_finger"
        ],
        "adaptive_force_ceiling_n_per_finger": selected["g5_unsupported_hold"][
            "adaptive_force_ceiling_n_per_finger"
        ],
        "absolute_force_ceiling_n_per_finger": config["frozen_boundaries"][
            "absolute_force_ceiling_n_per_finger"
        ],
        "old_terminal_hull_expected_to_be_disabled": 3,
        "object_pose_write_after_physics_count": 0,
        "online_object_pose_control": False,
        "online_contact_truth_control": False,
        "formal_b_passed": False,
        "visual_overlay_requested": bool(run_arguments.visual_overlay_complete),
        "live_video_requested": bool(run_arguments.record_live_video),
    }
    write_json(output / "FULL_IIWA_RESULT.json", report)
    return report


def quaternion_angle_rad(first: Sequence[float], second: Sequence[float]) -> float:
    q0 = np.asarray(first, dtype=np.float64)
    q1 = np.asarray(second, dtype=np.float64)
    q0 /= np.linalg.norm(q0)
    q1 /= np.linalg.norm(q1)
    return 2.0 * math.acos(float(np.clip(abs(q0 @ q1), 0.0, 1.0)))


def _semantic_finger(path: str) -> str | None:
    components = path.split("/")
    for terminal, links in FINGER_LINKS.items():
        if any(component in links for component in components):
            return terminal
    return None


def _normal_impulse(contact: Any) -> float:
    impulse = np.asarray(contact.impulse, dtype=np.float64)
    normal = np.asarray(contact.normal, dtype=np.float64)
    normal_norm = float(np.linalg.norm(normal))
    if normal_norm <= 1.0e-12:
        return 0.0
    return abs(float(impulse @ (normal / normal_norm)))


def _contact_record_is_active(contact: Any) -> bool:
    separation = float(contact.separation)
    impulse = np.asarray(contact.impulse, dtype=np.float64)
    if not math.isfinite(separation) or impulse.shape != (3,) or not np.all(
        np.isfinite(impulse)
    ):
        raise RuntimeError("non-finite PhysX contact record")
    return separation <= 0.0 or bool(np.any(impulse != 0.0))


def _triangle_component_arrays(component: Any) -> tuple[np.ndarray, np.ndarray]:
    """Return one finite triangle component in terminal-link local metres."""

    points = np.asarray(component.vertices, dtype=np.float64)
    faces = np.asarray(component.faces, dtype=np.int64)
    if (
        points.ndim != 2
        or points.shape[1] != 3
        or faces.ndim != 2
        or faces.shape[1] != 3
        or len(points) < 4
        or len(faces) < 4
        or not np.all(np.isfinite(points))
        or np.any(faces < 0)
        or np.any(faces >= len(points))
    ):
        raise RuntimeError("invalid CAD triangle component for fingertip collision")
    return points, faces


def _triangle_components_arrays(
    components: Sequence[Any],
) -> tuple[np.ndarray, np.ndarray]:
    """Return one triangle soup containing every supplied CAD component."""

    triangles = [
        np.asarray(component.triangles, dtype=np.float64)
        for component in components
    ]
    if not triangles or any(
        value.ndim != 3 or value.shape[1:] != (3, 3) or len(value) == 0
        for value in triangles
    ):
        raise RuntimeError("invalid CAD component inventory for fingertip collision")
    combined = np.concatenate(triangles, axis=0)
    points = combined.reshape((-1, 3))
    faces = np.arange(len(points), dtype=np.int64).reshape((-1, 3))
    if not np.all(np.isfinite(points)):
        raise RuntimeError("non-finite complete fingertip CAD collision geometry")
    return points, faces


def _ik_solution(plan: Mapping[str, Any], offset_m: float) -> np.ndarray:
    key = f"z_offset_{float(offset_m):.4f}_m"
    return np.asarray(plan["ik"]["solutions"][key]["arm_rad"], dtype=np.float64)


def run_isaac(run_arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation, SingleRigidPrim
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    from omni.physx.scripts import physicsUtils
    import omni.usd
    from pxr import (
        Gf,
        PhysicsSchemaTools,
        PhysxSchema,
        Sdf,
        Usd,
        UsdGeom,
        UsdLux,
        UsdPhysics,
        UsdShade,
    )

    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config, paths, plan, selected, fits = load_inputs(run_arguments)
    write_plan(output / "FULL_IIWA_PLAN.json", plan)
    tabletop = load_d38999_tabletop_scene(paths["tabletop_config"])
    connector_asset = verify_d38999_tabletop_asset(tabletop, REPOSITORY)
    scene_config = config["scene"]
    robot_config = config["robot"]
    motion = config["motion"]
    safety = config["safety"]
    quiet_hold_config = config["force_quiet_hold"]
    g2 = selected["g2_independent_contact"]
    g4 = selected["g4_compliant_force_control"]
    g5 = selected["g5_unsupported_hold"]
    g6 = selected["g6_real_lift"]
    candidate = plan["candidate"]
    closure_direction = np.asarray(
        candidate.get("closure_direction", (1.0, 1.0, 1.0)),
        dtype=np.float64,
    )
    if closure_direction.shape != (3,) or not np.all(
        np.isin(closure_direction, (-1.0, 1.0))
    ):
        raise RuntimeError("candidate closure direction is invalid")
    role_geometry = {
        spec.link_name: build_finger_pad_role(spec)
        for spec in FINGER_PAD_ROLE_SPECS
    }
    rate_hz = int(tabletop.physics.rate_hz)
    dt_s = 1.0 / float(rate_hz)
    mu = float(config["frozen_boundaries"]["pad_object_friction"])

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=dt_s,
        rendering_dt=1.0 / 60.0,
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    scene_authoring = author_d38999_tabletop_scene(
        stage,
        tabletop,
        connector_asset,
        add_reference_to_stage=add_reference_to_stage,
        Gf=Gf,
        Sdf=Sdf,
        UsdGeom=UsdGeom,
        UsdPhysics=UsdPhysics,
        UsdShade=UsdShade,
        physics_utils=physicsUtils,
    )
    add_reference_to_stage(
        str(paths["robot_asset"]), str(scene_config["robot_reference_prim_path"])
    )
    scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(scenes) != 1:
        raise RuntimeError(f"expected one physics scene, got {len(scenes)}")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")

    robot_root = str(scene_config["robot_reference_prim_path"])
    robot_prim = stage.GetPrimAtPath(robot_root)
    if not robot_prim.IsValid():
        raise RuntimeError("full robot reference root is missing")
    original_finger_colliders: dict[str, list[str]] = {
        name: [] for name in ACTIVE_PAD_LINKS
    }
    robot_collision_paths: set[str] = set()
    for prim in Usd.PrimRange(robot_prim):
        if not prim.HasAPI(UsdPhysics.CollisionAPI):
            continue
        path = str(prim.GetPath())
        robot_collision_paths.add(path)
        finger = _semantic_finger(path)
        if finger is not None:
            original_finger_colliders[finger].append(path)
    original_finger_count = sum(len(value) for value in original_finger_colliders.values())
    if original_finger_count != int(
        scene_config["expected_original_finger_collider_count"]
    ):
        raise RuntimeError(
            f"original finger collider count changed: {original_finger_count}"
        )

    material_root = "/World/FullIiwaBGoalModeMaterials"
    UsdGeom.Scope.Define(stage, material_root)
    pad_material = UsdShade.Material.Define(stage, material_root + "/PAD_MU_0P50")
    pad_material_api = UsdPhysics.MaterialAPI.Apply(pad_material.GetPrim())
    pad_material_api.CreateStaticFrictionAttr(mu)
    pad_material_api.CreateDynamicFrictionAttr(mu)
    pad_material_api.CreateRestitutionAttr(0.0)
    physx_pad_material = PhysxSchema.PhysxMaterialAPI.Apply(pad_material.GetPrim())
    physx_pad_material.CreateFrictionCombineModeAttr().Set("average")
    physx_pad_material.CreateRestitutionCombineModeAttr().Set("min")

    terminal_collision_config = scene_config["terminal_collision"]
    blocker_material = UsdShade.Material.Define(
        stage, material_root + "/FINGER_STRUCTURE_MU_0P35_0P25"
    )
    blocker_material_api = UsdPhysics.MaterialAPI.Apply(blocker_material.GetPrim())
    blocker_material_api.CreateStaticFrictionAttr(
        float(terminal_collision_config["blocker_static_friction"])
    )
    blocker_material_api.CreateDynamicFrictionAttr(
        float(terminal_collision_config["blocker_dynamic_friction"])
    )
    blocker_material_api.CreateRestitutionAttr(0.0)
    physx_blocker_material = PhysxSchema.PhysxMaterialAPI.Apply(
        blocker_material.GetPrim()
    )
    physx_blocker_material.CreateFrictionCombineModeAttr().Set("average")
    physx_blocker_material.CreateRestitutionCombineModeAttr().Set("min")

    disabled_terminal_hulls: list[str] = []
    retained_finger_colliders: dict[str, list[str]] = {
        name: [] for name in ACTIVE_PAD_LINKS
    }
    pad_paths: dict[str, str] = {}
    tip_paths: dict[str, str] = {}
    side_paths: dict[str, str] = {}
    convex_hull_cooking_readback: dict[str, dict[str, Any]] = {}
    terminal_mass_readback: dict[str, Any] = {}

    def author_collision_mesh(
        *,
        terminal: Any,
        prim_name: str,
        component: Any,
        role: str,
        material: Any,
        approximation: str,
        maximum_convex_hulls: int,
        link_name: str,
        component_inventory: Sequence[Any] | None = None,
    ) -> str:
        points, faces = (
            _triangle_component_arrays(component)
            if component_inventory is None
            else _triangle_components_arrays(component_inventory)
        )
        path = str(terminal.GetPath()) + "/" + prim_name
        mesh = UsdGeom.Mesh.Define(stage, path)
        mesh.CreatePointsAttr(
            [Gf.Vec3f(*[float(value) for value in point]) for point in points]
        )
        mesh.CreateFaceVertexCountsAttr([3] * len(faces))
        mesh.CreateFaceVertexIndicesAttr(
            [int(value) for value in faces.reshape(-1)]
        )
        mesh.CreateSubdivisionSchemeAttr(UsdGeom.Tokens.none)
        UsdPhysics.CollisionAPI.Apply(mesh.GetPrim()).CreateCollisionEnabledAttr(True)
        mesh_collision = UsdPhysics.MeshCollisionAPI.Apply(mesh.GetPrim())
        mesh_collision.CreateApproximationAttr().Set(approximation)
        if approximation == UsdPhysics.Tokens.convexDecomposition:
            decomposition = PhysxSchema.PhysxConvexDecompositionCollisionAPI.Apply(
                mesh.GetPrim()
            )
            decomposition.CreateMaxConvexHullsAttr().Set(maximum_convex_hulls)
            decomposition.CreateHullVertexLimitAttr().Set(
                int(terminal_collision_config["hull_vertex_limit"])
            )
            decomposition.CreateErrorPercentageAttr().Set(
                float(terminal_collision_config["error_percentage"])
            )
            decomposition.CreateMinThicknessAttr().Set(
                float(terminal_collision_config["minimum_thickness_m"])
            )
            decomposition.CreateShrinkWrapAttr().Set(
                bool(terminal_collision_config["shrink_wrap"])
            )
            decomposition.CreateVoxelResolutionAttr().Set(
                int(terminal_collision_config["voxel_resolution"])
            )
        elif approximation == UsdPhysics.Tokens.convexHull:
            convex_hull = PhysxSchema.PhysxConvexHullCollisionAPI.Apply(
                mesh.GetPrim()
            )
            expected_vertex_limit = int(
                terminal_collision_config["hull_vertex_limit"]
            )
            expected_minimum_thickness = float(
                terminal_collision_config["minimum_thickness_m"]
            )
            convex_hull.CreateHullVertexLimitAttr().Set(expected_vertex_limit)
            convex_hull.CreateMinThicknessAttr().Set(expected_minimum_thickness)
            actual_vertex_limit = int(
                convex_hull.GetHullVertexLimitAttr().Get()
            )
            actual_minimum_thickness = float(
                convex_hull.GetMinThicknessAttr().Get()
            )
            if actual_vertex_limit != expected_vertex_limit or not math.isclose(
                actual_minimum_thickness,
                expected_minimum_thickness,
                rel_tol=1.0e-6,
                abs_tol=1.0e-12,
            ):
                raise RuntimeError(
                    f"convex hull cooking readback mismatch for {path}: "
                    f"vertices={actual_vertex_limit}, "
                    f"minimum_thickness_m={actual_minimum_thickness}"
                )
            convex_hull_cooking_readback[path] = {
                "hull_vertex_limit": actual_vertex_limit,
                "minimum_thickness_m": actual_minimum_thickness,
            }
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(mesh.GetPrim())
        contact_offset_m = float(
            selected["grasp_geometry"]["contact_offset_m"]
        )
        rest_offset_m = (
            float(terminal_collision_config["pad_rest_offset_m"])
            if role == "BLUE_PAD_CONTACT"
            else float(selected["grasp_geometry"]["rest_offset_m"])
        )
        if not 0.0 <= rest_offset_m < contact_offset_m:
            raise RuntimeError(
                f"invalid {role} rest/contact offsets: "
                f"rest={rest_offset_m}, contact={contact_offset_m}"
            )
        physx_collision.CreateContactOffsetAttr(contact_offset_m)
        physx_collision.CreateRestOffsetAttr(rest_offset_m)
        if not math.isclose(
            float(physx_collision.GetContactOffsetAttr().Get()),
            contact_offset_m,
            abs_tol=1.0e-9,
        ) or not math.isclose(
            float(physx_collision.GetRestOffsetAttr().Get()),
            rest_offset_m,
            abs_tol=1.0e-9,
        ):
            raise RuntimeError(f"{role} contact/rest offset readback changed")
        UsdShade.MaterialBindingAPI(mesh.GetPrim()).Bind(
            material, materialPurpose="physics"
        )
        mesh.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set(role)
        mesh.GetPrim().CreateAttribute(
            "kcg:finger", Sdf.ValueTypeNames.Token
        ).Set(link_name)
        mesh.GetPrim().CreateAttribute(
            "kcg:sourceGeometry", Sdf.ValueTypeNames.Token
        ).Set(
            "AUTHORED_VISUAL_CAD_COMPONENT"
            if component_inventory is None
            else "ALL_REMAINING_AUTHORED_VISUAL_CAD_COMPONENTS"
        )
        robot_collision_paths.add(path)
        return path

    for link_name in ACTIVE_PAD_LINKS:
        terminals = [
            prim
            for prim in Usd.PrimRange(robot_prim)
            if prim.GetName() == link_name and prim.HasAPI(UsdPhysics.RigidBodyAPI)
        ]
        if len(terminals) != 1:
            raise RuntimeError(
                f"expected one terminal rigid body for {link_name}, got {len(terminals)}"
            )
        terminal = terminals[0]
        if terminal.IsInstance():
            terminal.SetInstanceable(False)
            terminal = stage.GetPrimAtPath(terminal.GetPath())
        old_colliders = [
            prim
            for prim in Usd.PrimRange(terminal)
            if prim.HasAPI(UsdPhysics.CollisionAPI)
        ]
        if len(old_colliders) != 1 or "_convex" not in str(old_colliders[0].GetPath()):
            raise RuntimeError(
                f"{link_name} whole-terminal collider identity changed: "
                f"{[str(prim.GetPath()) for prim in old_colliders]}"
            )
        old_collision = UsdPhysics.CollisionAPI(old_colliders[0])
        old_collision.CreateCollisionEnabledAttr().Set(False)
        if old_collision.GetCollisionEnabledAttr().Get() is not False:
            raise RuntimeError(f"failed to disable old terminal hull for {link_name}")
        disabled_terminal_hulls.append(str(old_colliders[0].GetPath()))
        mass_api = UsdPhysics.MassAPI(terminal)
        terminal_mass_readback[link_name] = (
            mass_api.GetMassAttr().Get() if terminal.HasAPI(UsdPhysics.MassAPI) else None
        )

        geometry = role_geometry[link_name]
        if geometry.pad_component_rank_by_area != 1:
            raise RuntimeError(f"{link_name} blue contact component changed")
        if geometry.tip_component_rank_by_area != 4:
            raise RuntimeError(f"{link_name} red tip component changed")
        pad_paths[link_name] = author_collision_mesh(
            terminal=terminal,
            prim_name="BLUE_PAD_CAD_COLLISION",
            component=geometry.pad_component,
            role="BLUE_PAD_CONTACT",
            material=pad_material,
            approximation=UsdPhysics.Tokens.convexDecomposition,
            maximum_convex_hulls=int(
                terminal_collision_config["pad_maximum_convex_hulls"]
            ),
            link_name=link_name,
        )
        tip_paths[link_name] = author_collision_mesh(
            terminal=terminal,
            prim_name="RED_TIP_CAD_COLLISION",
            component=geometry.tip_component,
            role="RED_TIP_BLOCKER",
            material=blocker_material,
            approximation=UsdPhysics.Tokens.convexHull,
            maximum_convex_hulls=1,
            link_name=link_name,
        )
        side_paths[link_name] = author_collision_mesh(
            terminal=terminal,
            prim_name="FINGERTIP_BODY_CAD_COLLISION",
            component=geometry.components_by_area[0],
            component_inventory=tuple(
                component
                for rank, component in enumerate(geometry.components_by_area)
                if rank
                not in {
                    geometry.pad_component_rank_by_area,
                    geometry.tip_component_rank_by_area,
                }
            ),
            role="FINGERTIP_BODY_BLOCKER",
            material=blocker_material,
            approximation=UsdPhysics.Tokens.convexDecomposition,
            maximum_convex_hulls=int(
                terminal_collision_config["side_maximum_convex_hulls"]
            ),
            link_name=link_name,
        )

    if len(disabled_terminal_hulls) != int(
        scene_config["expected_disabled_terminal_hull_count"]
    ):
        raise RuntimeError("old whole-terminal hull count changed")
    disabled_set = set(disabled_terminal_hulls)
    for link_name, paths_for_finger in original_finger_colliders.items():
        retained_finger_colliders[link_name] = sorted(
            path for path in paths_for_finger if path not in disabled_set
        )
    retained_count = sum(len(value) for value in retained_finger_colliders.values())
    if retained_count != int(scene_config["expected_retained_finger_collider_count"]):
        raise RuntimeError(f"retained finger collider count changed: {retained_count}")
    finger_collision_paths = sorted(
        path
        for values in retained_finger_colliders.values()
        for path in values
    ) + sorted(pad_paths.values()) + sorted(tip_paths.values()) + sorted(
        side_paths.values()
    )
    if len(pad_paths) != int(scene_config["expected_pad_collider_count"]):
        raise RuntimeError("blue contact collider count changed")
    if len(tip_paths) != int(scene_config["expected_tip_collider_count"]):
        raise RuntimeError("red tip blocker count changed")
    if len(side_paths) != int(scene_config["expected_side_collider_count"]):
        raise RuntimeError("fingertip body blocker count changed")
    if len(finger_collision_paths) != int(
        scene_config["expected_active_finger_collider_count"]
    ):
        raise RuntimeError("active finger collision inventory changed")

    authorized_grip_path = plan["scene"]["authorized_grip_collider_path"]
    authorized_grip_prim = stage.GetPrimAtPath(authorized_grip_path)
    if (
        not authorized_grip_prim.IsValid()
        or not authorized_grip_prim.HasAPI(UsdPhysics.CollisionAPI)
        or float(UsdGeom.Cylinder(authorized_grip_prim).GetRadiusAttr().Get())
        != float(scene_config["authorized_grip_radius_m"])
        or float(UsdGeom.Cylinder(authorized_grip_prim).GetHeightAttr().Get())
        != float(scene_config["authorized_grip_height_m"])
    ):
        raise RuntimeError("authorized coupling-nut grasp collider changed")
    # The frozen contact coefficient is realized only on the authorized
    # external grasp surface and the three PAD proxies.  All other connector
    # and hand materials remain asset-owned.
    UsdShade.MaterialBindingAPI(authorized_grip_prim).Bind(
        pad_material, materialPurpose="physics"
    )

    body_root = tabletop.asset.body_prim_path
    nut_root = tabletop.asset.nut_prim_path
    fixed_root = tabletop.asset.fixed_receptacle_prim_path

    def author_rear_face_table_support(
        *, owner: str, root_path: str, support_config: Mapping[str, Any]
    ) -> tuple[str, dict[str, Any]]:
        owner_prim = stage.GetPrimAtPath(root_path)
        if (
            not owner_prim.IsValid()
            or not owner_prim.HasAPI(UsdPhysics.RigidBodyAPI)
            or not owner_prim.HasAPI(UsdPhysics.MassAPI)
        ):
            raise RuntimeError(f"{owner} rigid body or explicit mass is missing")
        mass_api = UsdPhysics.MassAPI(owner_prim)
        mass_before_kg = float(mass_api.GetMassAttr().Get())
        support_path = root_path + "/" + str(support_config["prim_name"])
        if stage.GetPrimAtPath(support_path).IsValid():
            raise RuntimeError(f"{owner} rear-face support collider already exists")

        support = UsdGeom.Cylinder.Define(stage, support_path)
        support.CreateAxisAttr(UsdGeom.Tokens.z)
        support.CreateRadiusAttr(float(support_config["radius_m"]))
        support.CreateHeightAttr(float(support_config["height_m"]))
        support.AddTranslateOp().Set(
            Gf.Vec3d(0.0, 0.0, float(support_config["center_local_z_m"]))
        )
        support.CreatePurposeAttr(UsdGeom.Tokens.guide)
        support.CreateDisplayColorAttr([Gf.Vec3f(0.42, 0.46, 0.52)])
        collision = UsdPhysics.CollisionAPI.Apply(support.GetPrim())
        collision.CreateCollisionEnabledAttr(True)
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(support.GetPrim())
        physx_collision.CreateContactOffsetAttr(
            float(support_config["contact_offset_m"])
        )
        physx_collision.CreateRestOffsetAttr(
            float(support_config["rest_offset_m"])
        )
        support.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set(str(support_config["collision_role"]))
        support.GetPrim().CreateAttribute(
            "kcg:sourceGeometry", Sdf.ValueTypeNames.Token
        ).Set(str(support_config["source_geometry"]))
        support.GetPrim().CreateAttribute(
            "kcg:tableSupportOnly", Sdf.ValueTypeNames.Bool
        ).Set(True)

        actual_rear_z_m = float(
            support_config["center_local_z_m"]
        ) + 0.5 * float(support_config["height_m"])
        readback = {
            "owner": owner,
            "path": support_path,
            "axis": str(support.GetAxisAttr().Get()),
            "radius_m": float(support.GetRadiusAttr().Get()),
            "height_m": float(support.GetHeightAttr().Get()),
            "center_local_z_m": float(
                support.GetOrderedXformOps()[0].Get()[2]
            ),
            "rear_face_local_z_m": actual_rear_z_m,
            "contact_offset_m": float(
                physx_collision.GetContactOffsetAttr().Get()
            ),
            "rest_offset_m": float(physx_collision.GetRestOffsetAttr().Get()),
            "source_geometry": str(support_config["source_geometry"]),
            "material_binding_authored": False,
        }
        expected_values = {
            "radius_m": float(support_config["radius_m"]),
            "height_m": float(support_config["height_m"]),
            "center_local_z_m": float(support_config["center_local_z_m"]),
            "rear_face_local_z_m": float(
                support_config["visual_local_rear_face_z_m"]
            ),
            "contact_offset_m": float(support_config["contact_offset_m"]),
            "rest_offset_m": float(support_config["rest_offset_m"]),
        }
        if readback["axis"] != "Z" or any(
            not math.isclose(
                float(readback[name]),
                expected,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
            for name, expected in expected_values.items()
        ):
            raise RuntimeError(f"{owner} rear-face support readback changed: {readback}")
        if (
            support.GetPrim().HasAPI(UsdPhysics.RigidBodyAPI)
            or support.GetPrim().HasAPI(UsdPhysics.MassAPI)
        ):
            raise RuntimeError(
                "rear-face support must not create a new rigid body or mass"
            )
        mass_after_kg = float(mass_api.GetMassAttr().Get())
        if not math.isclose(
            mass_before_kg, mass_after_kg, rel_tol=0.0, abs_tol=1.0e-12
        ):
            raise RuntimeError(f"rear-face support changed frozen {owner} mass")
        readback["owner_mass_before_kg"] = mass_before_kg
        readback["owner_mass_after_kg"] = mass_after_kg
        return support_path, readback

    # The complete public visual CAD reaches local +Z=30.5 mm.  Supporting the
    # load-bearing BodyAssembly closes the missing rear envelope for the whole
    # jointed plug without over-constraining both moving rigid bodies against
    # the same table plane.  This authors no mass, material, friction, or
    # controller state.
    body_table_support_path, body_support_readback = (
        author_rear_face_table_support(
            owner="BodyAssembly",
            root_path=body_root,
            support_config=scene_config["body_table_support_collision"],
        )
    )

    plug_collision_prims = {"body": [], "nut": []}
    fixed_collision_prims: list[str] = []
    for prim in stage.Traverse():
        if not prim.HasAPI(UsdPhysics.CollisionAPI):
            continue
        path = str(prim.GetPath())
        if path == body_root or path.startswith(body_root + "/"):
            plug_collision_prims["body"].append(path)
        elif path == nut_root or path.startswith(nut_root + "/"):
            plug_collision_prims["nut"].append(path)
        elif path == fixed_root or path.startswith(fixed_root + "/"):
            fixed_collision_prims.append(path)
    expected_counts = {
        "body": int(scene_config["expected_body_collider_count"]),
        "nut": int(scene_config["expected_nut_collider_count"]),
    }
    actual_counts = {name: len(values) for name, values in plug_collision_prims.items()}
    if actual_counts != expected_counts:
        raise RuntimeError(
            f"multilayer collider counts changed: expected={expected_counts} actual={actual_counts}"
        )
    if plug_collision_prims["nut"].count(authorized_grip_path) != 1:
        raise RuntimeError("authorized grip collider is not unique")
    body_table_support_paths = sorted(
        path
        for path in plug_collision_prims["body"]
        if path == body_table_support_path
    )
    if len(body_table_support_paths) != int(
        scene_config["expected_body_table_support_collider_count"]
    ):
        raise RuntimeError("body-assembly table-support collider count changed")
    non_grip_nut_paths = sorted(
        path
        for path in plug_collision_prims["nut"]
        if path != authorized_grip_path
    )
    shoulder_signs = ("PositiveStop", "NegativeStop")
    body_shoulders = {
        sign: sorted(
            path
            for path in plug_collision_prims["body"]
            if f"/NutBearingShoulders/{sign}/" in path
        )
        for sign in shoulder_signs
    }
    nut_shoulders = {
        sign: sorted(
            path
            for path in non_grip_nut_paths
            if f"/NutBearingShoulders/{sign}/" in path
        )
        for sign in shoulder_signs
    }
    if any(
        len(body_shoulders[sign]) != 1 or len(nut_shoulders[sign]) != 3
        for sign in shoulder_signs
    ):
        raise RuntimeError("multilayer shoulder role partition changed")
    body_shoulder_paths = [
        path for sign in shoulder_signs for path in body_shoulders[sign]
    ]
    body_non_shoulder = sorted(
        set(plug_collision_prims["body"])
        - set(body_shoulder_paths)
        - set(body_table_support_paths)
    )
    if len(body_non_shoulder) != 70 or len(non_grip_nut_paths) != 6:
        raise RuntimeError("multilayer non-grip collider partition changed")
    if not fixed_collision_prims:
        raise RuntimeError("fixed receptacle colliders are missing")

    groups_root = tabletop.world.root_prim_path + "/FullIiwaGraspCollisionGroups"
    UsdGeom.Scope.Define(stage, groups_root)

    def explicit_group(name: str, members: Sequence[str]) -> tuple[str, Any]:
        group_path = groups_root + "/" + name
        group = UsdPhysics.CollisionGroup.Define(stage, group_path)
        group.CreateInvertFilteredGroupsAttr(False)
        collection = group.GetCollidersCollectionAPI()
        collection.CreateExpansionRuleAttr("explicitOnly")
        collection.CreateIncludeRootAttr(False)
        collection.CreateIncludesRel().SetTargets([Sdf.Path(path) for path in members])
        return group_path, group

    fixed_group_path, fixed_group = explicit_group(
        "FixedReceptacle", sorted(fixed_collision_prims)
    )
    body_non_path, body_non_group = explicit_group(
        "BodyNonShoulder", body_non_shoulder
    )
    body_positive_path, body_positive_group = explicit_group(
        "BodyShoulderPositive", body_shoulders["PositiveStop"]
    )
    body_negative_path, body_negative_group = explicit_group(
        "BodyShoulderNegative", body_shoulders["NegativeStop"]
    )
    body_table_support_group_path, body_table_support_group = explicit_group(
        "BodyAssemblyRearFaceTableSupport", body_table_support_paths
    )
    nut_grip_path, nut_grip_group = explicit_group(
        "AuthorizedCouplingNutGrip", [authorized_grip_path]
    )
    nut_positive_path, nut_positive_group = explicit_group(
        "NutShoulderPositive", nut_shoulders["PositiveStop"]
    )
    nut_negative_path, nut_negative_group = explicit_group(
        "NutShoulderNegative", nut_shoulders["NegativeStop"]
    )
    finger_group_path, finger_group = explicit_group(
        "ThreeRobotFingers", finger_collision_paths
    )

    def filter_groups(group: Any, targets: Sequence[str]) -> None:
        relation = group.CreateFilteredGroupsRel()
        relation.SetTargets([Sdf.Path(path) for path in targets])

    filter_groups(
        nut_grip_group,
        (
            fixed_group_path,
            body_non_path,
            body_positive_path,
            body_negative_path,
            body_table_support_group_path,
        ),
    )
    filter_groups(
        nut_positive_group,
        (
            fixed_group_path,
            body_non_path,
            body_negative_path,
            body_table_support_group_path,
        ),
    )
    filter_groups(
        nut_negative_group,
        (
            fixed_group_path,
            body_non_path,
            body_positive_path,
            body_table_support_group_path,
        ),
    )
    filter_groups(
        body_table_support_group,
        (
            fixed_group_path,
            nut_grip_path,
            nut_positive_path,
            nut_negative_path,
        ),
    )
    filter_groups(body_positive_group, (fixed_group_path,))
    filter_groups(body_negative_group, (fixed_group_path,))
    # Isaac/PhysX collides groups by default.  The complete robot must collide
    # with the table and every connector region; only the connector's own
    # internal assembly pairs retain their existing filters above.
    filter_groups(finger_group, ())
    authored_groups = {
        "fixed": fixed_group,
        "body_non": body_non_group,
        "body_positive": body_positive_group,
        "body_negative": body_negative_group,
        "body_table_support": body_table_support_group,
        "nut_grip": nut_grip_group,
        "nut_positive": nut_positive_group,
        "nut_negative": nut_negative_group,
        "fingers": finger_group,
    }
    collision_group_readback = {
        name: {
            "members": sorted(
                str(path)
                for path in group.GetCollidersCollectionAPI()
                .GetIncludesRel()
                .GetTargets()
            ),
            "filters": sorted(
                str(path) for path in group.GetFilteredGroupsRel().GetTargets()
            ),
        }
        for name, group in authored_groups.items()
    }
    if collision_group_readback["fingers"]["members"] != sorted(
        finger_collision_paths
    ):
        raise RuntimeError("finger collision group readback changed")
    if collision_group_readback["fingers"]["filters"]:
        raise RuntimeError("robot-to-environment collision filtering survived")

    contact_report_body_count = 0
    for prim in stage.Traverse():
        path = str(prim.GetPath())
        if (
            (
                path.startswith(robot_root + "/")
                and prim.HasAPI(UsdPhysics.RigidBodyAPI)
            )
            or path in (body_root, nut_root)
        ):
            PhysxSchema.PhysxContactReportAPI.Apply(prim).CreateThresholdAttr().Set(0.0)
            contact_report_body_count += 1
    if contact_report_body_count < 19:
        raise RuntimeError(
            f"contact reporting is incomplete: {contact_report_body_count}"
        )

    live_visualizer: FullIiwaLiveVisualizer | None = None
    if run_arguments.visual_overlay_complete:
        requested_video = Path(
            run_arguments.video_output or "B_FULL_IIWA_LIVE_RUN.mp4"
        ).expanduser()
        if not requested_video.is_absolute():
            requested_video = output / requested_video
        live_visualizer = FullIiwaLiveVisualizer(
            repository=REPOSITORY,
            output=output,
            stage=stage,
            application=run_arguments.application,
            visual_asset=(
                REPOSITORY
                / "artifacts/kcg_connector/isaac/d38999_multilayer_v1"
                / "D38999_VISUAL_COMPLETE_V1.usda"
            ),
            physical_asset=connector_asset,
            physical_fixed_path=fixed_root,
            physical_body_path=body_root,
            physical_nut_path=nut_root,
            pad_paths=pad_paths,
            tip_paths=tip_paths,
            side_paths=side_paths,
            visual_mode=run_arguments.live_visual_mode,
            source_robot_urdf=paths["source_hand_urdf"],
            table_center_m=tabletop.table.center_m,
            table_size_m=tabletop.table.size_m,
            authorized_grip_local_center_m=scene_config[
                "authorized_grip_local_center_m"
            ],
            authorized_grip_radius_m=scene_config["authorized_grip_radius_m"],
            authorized_grip_height_m=scene_config["authorized_grip_height_m"],
            sim_rate_hz=rate_hz,
            record_live_video=bool(run_arguments.record_live_video),
            video_output=requested_video,
            Gf=Gf,
            Usd=Usd,
            UsdGeom=UsdGeom,
            UsdLux=UsdLux,
            UsdPhysics=UsdPhysics,
        )

    stage_path = output / "FULL_IIWA_STAGE.usda"
    stage.Export(str(stage_path))
    robot = world.scene.add(
        SingleArticulation(
            prim_path=str(scene_config["articulation_prim_path"]),
            name="full_iiwa_b_goal_mode_robot",
        )
    )
    body = world.scene.add(
        SingleRigidPrim(prim_path=body_root, name="full_iiwa_b_goal_mode_body")
    )
    nut = world.scene.add(
        SingleRigidPrim(prim_path=nut_root, name="full_iiwa_b_goal_mode_nut")
    )
    world.reset()
    if not robot.handles_initialized:
        raise RuntimeError("full iiwa articulation handles were not initialized")
    world.get_physics_context().set_gravity(tabletop.physics.gravity_m_s2)
    if live_visualizer is not None:
        initial_body_position, initial_body_orientation = body.get_world_pose()
        initial_nut_position, initial_nut_orientation = nut.get_world_pose()
        live_visualizer.sync(
            body_position_m=initial_body_position,
            body_orientation_wxyz=initial_body_orientation,
            nut_position_m=initial_nut_position,
            nut_orientation_wxyz=initial_nut_orientation,
        )
        live_visualizer.initialize_capture()
    if run_arguments.gui:
        configure_gui_camera(
            stage=stage,
            preset=run_arguments.gui_camera_preset,
            application=run_arguments.application,
            UsdGeom=UsdGeom,
        )

    dof_names = list(robot.dof_names)
    arm_names = tuple(robot_config["arm_joint_names"])
    hand_names = tuple(robot_config["active_hand_joint_names"])
    required_names = arm_names + hand_names
    missing = [name for name in required_names if name not in dof_names]
    if missing:
        raise RuntimeError(f"full iiwa articulation lacks DOFs: {missing}")
    indices = {name: dof_names.index(name) for name in dof_names}
    arm_indices = np.asarray([indices[name] for name in arm_names], dtype=np.int32)
    hand_indices = np.asarray([indices[name] for name in hand_names], dtype=np.int32)
    root_indices = np.asarray(
        [indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32
    )
    controlled_indices = np.concatenate((arm_indices, hand_indices))

    initial = np.zeros(robot.num_dof, dtype=np.float32)
    consistent_hand = {
        "f1j1": float(candidate["open_preshape_rad"]),
        "f3j1": float(candidate["open_preshape_rad"]),
        "f1j2": float(candidate["open_flexion_rad"]),
        "f1j3": float(candidate["open_flexion_rad"]),
        "f2j1": float(candidate["open_flexion_rad"]),
        "f2j2": float(candidate["open_flexion_rad"]),
        "f3j2": float(candidate["open_flexion_rad"]),
        "f3j3": float(candidate["open_flexion_rad"]),
    }
    for name, value in consistent_hand.items():
        if name in indices:
            initial[indices[name]] = value
    robot.set_joint_positions(initial)
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
    controller = robot.get_articulation_controller()
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[arm_indices] = float(robot_config["arm_stiffness"])
    kds[arm_indices] = float(robot_config["arm_damping"])
    kps[hand_indices] = float(robot_config["searching_hand_stiffness"])
    kds[hand_indices] = float(robot_config["hand_damping"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

    current_arm_target = np.asarray(robot_config["home_arm_rad"], dtype=np.float64)
    current_hand_target = np.asarray(
        (
            candidate["open_preshape_rad"],
            candidate["open_flexion_rad"],
            candidate["open_flexion_rad"],
            candidate["open_flexion_rad"],
        ),
        dtype=np.float64,
    )
    interface = get_physx_simulation_interface()
    metadata_joint_indices = dict(robot._articulation_view._metadata.joint_indices)
    if "hand2arm" not in metadata_joint_indices:
        raise RuntimeError("hand2arm measurement joint is absent")
    wrist_reaction_row = int(metadata_joint_indices["hand2arm"]) + 1
    selected_wrench = np.asarray(
        robot.get_measured_joint_forces(
            joint_indices=np.asarray([wrist_reaction_row], dtype=np.int32)
        ),
        dtype=np.float64,
    )
    all_wrenches = np.asarray(robot.get_measured_joint_forces(), dtype=np.float64)
    if (
        selected_wrench.shape != (1, 6)
        or wrist_reaction_row >= all_wrenches.shape[0]
        or not np.array_equal(selected_wrench[0], all_wrenches[wrist_reaction_row])
    ):
        raise RuntimeError("hand2arm reaction-row mapping failed")

    trace_fields = [
        "step",
        "phase",
        "phase_step",
        "arm_target_z_offset_m",
        "arm_tracking_compensation_z_m",
        "tcp_z_m",
        "tcp_tracking_error_m",
        "maximum_arm_tracking_error_rad",
        "body_x_m",
        "body_y_m",
        "body_z_m",
        "nut_x_m",
        "nut_y_m",
        "nut_z_m",
        "object_lift_m",
        "object_lateral_drift_m",
        "object_rotation_rad",
        "table_normal_force_n",
        "unauthorized_contact_count",
        "unauthorized_contact_pairs",
        "raw_wrist_force_norm_n",
        "raw_wrist_moment_norm_nm",
        "wrist_force_increment_norm_n",
        "wrist_moment_increment_norm_nm",
        "force_target_level_n",
        "adaptive_event",
        "slip_monitor_armed",
        "slip_confirmation_count",
        "slip_precursor_reasons",
        "step_wall_s",
    ]
    cad_trace_joint_names = tuple(arm_names) + tuple(
        name for name in dof_names if name.startswith(("f1", "f2", "f3"))
    )
    trace_fields.extend(
        f"cad_joint_{name}_position_rad" for name in cad_trace_joint_names
    )
    for name in ROOT_TORQUE_JOINTS:
        trace_fields.extend(
            (
                f"{name}_target_rad",
                f"{name}_position_rad",
                f"{name}_velocity_rad_s",
                f"{name}_qdot_fd_rad_s",
                f"{name}_effort_nm",
                f"{name}_effort_delta_nm",
            )
        )
    for prefix in FINGER_PREFIX.values():
        trace_fields.extend(
            (
                f"{prefix}_contact_state",
                f"{prefix}_desired_force_n",
                f"{prefix}_estimated_force_n",
                f"{prefix}_normal_force_n",
                f"{prefix}_tangential_force_n",
                f"{prefix}_friction_utilization",
                f"{prefix}_contact_normal_x",
                f"{prefix}_contact_normal_y",
                f"{prefix}_contact_normal_z",
                f"{prefix}_contact_point_x_m",
                f"{prefix}_contact_point_y_m",
                f"{prefix}_contact_point_z_m",
                f"{prefix}_pad_normal_impulse_ns",
                f"{prefix}_other_structure_normal_impulse_ns",
                f"{prefix}_pad_share",
                f"{prefix}_controller_offset_rad",
                f"{prefix}_controller_differential_error_n",
            )
        )
    trace_fields.extend(
        (
            "controller_common_error_n",
            "controller_first_step_frozen",
            "controller_rate_limit",
            "controller_cumulative_limit",
            "force_controller_frozen",
            "hand_target_change_max_rad",
            "rho_above_one_consecutive_max",
        )
    )
    trace_path = output / "FULL_IIWA_TRACE.csv"
    trace_stream = trace_path.open("w", newline="", encoding="utf-8")
    writer = csv.DictWriter(trace_stream, fieldnames=trace_fields)
    writer.writeheader()
    trace_stream.flush()

    plug_collision_set = set(
        plug_collision_prims["body"] + plug_collision_prims["nut"]
    )
    fixed_collision_set = set(fixed_collision_prims)
    finger_collision_set = set(finger_collision_paths)
    pad_path_to_finger = {path: name for name, path in pad_paths.items()}
    table_path = tabletop.table.prim_path
    fixture_path = tabletop.fixed_endpoint.fixture_prim_path
    trace_rows: list[dict[str, Any]] = []
    first_step_wall_s: float | None = None
    maximum_arm_speed = 0.0
    maximum_hand_speed = 0.0
    maximum_arm_tracking_error = 0.0
    maximum_estimated_force = np.zeros(3, dtype=np.float64)
    maximum_diagnostic_force = np.zeros(3, dtype=np.float64)
    maximum_friction_utilization = np.zeros(3, dtype=np.float64)
    role_impulse_totals = {
        name: {"PAD": 0.0, "OTHER_STRUCTURE": 0.0}
        for name in ACTIVE_PAD_LINKS
    }
    unauthorized_pairs: dict[str, int] = {}
    first_unauthorized_contact_snapshot: dict[str, Any] | None = None
    table_force_peak = 0.0
    latches: dict[str, IndependentContactLatch] | None = None
    force_control: BumplessThreeFingerForceController | None = None
    controller_output: ForceControlOutput | None = None
    slip_monitor: ProprioceptiveSlipMonitor | None = None
    slip_observation: ProprioceptiveSlipObservation | None = None
    force_controller_frozen = False
    quiet_hold_report: dict[str, Any] | None = None
    force_target_level = 0.0
    adaptive_events: list[dict[str, Any]] = []
    first_contact = {name: None for name in ACTIVE_PAD_LINKS}
    wrist_tare: np.ndarray | None = None
    wrist_raw_force_peak = 0.0
    wrist_raw_moment_peak = 0.0
    wrist_increment_force_peak = 0.0
    wrist_increment_moment_peak = 0.0
    wrist_soft_exceed_steps = 0
    wrist_recovery_exceed_steps = 0
    wrist_recovery_consecutive = 0
    wrist_emergency_triggered = False
    latest_wrist_increment_moment = 0.0
    object_reference: dict[str, np.ndarray] | None = None
    final_hold_pad_contact_steps = np.zeros(3, dtype=np.int64)
    final_hold_sample_count = 0
    object_pose_write_after_physics_count = 0
    physics_started = False
    arm_target_z_offset = float("nan")
    arm_tracking_compensation_z_m = 0.0
    precontact_tracking_joint_bias = np.zeros(7, dtype=np.float64)
    precontact_tracking_compensation_report: dict[str, Any] | None = None
    previous_root_positions: np.ndarray | None = None
    previous_hand_target_command: np.ndarray | None = None
    rho_above_one_consecutive = np.zeros(3, dtype=np.int64)
    maximum_rho_above_one_consecutive = np.zeros(3, dtype=np.int64)

    def apply_gains() -> None:
        for link_name, joint_name in zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS):
            locked = latches is not None and latches[link_name].locked
            kps[indices[joint_name]] = float(
                robot_config["locked_hand_stiffness"]
                if locked
                else robot_config["searching_hand_stiffness"]
            )
        controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

    def apply_targets() -> None:
        command = np.concatenate((current_arm_target, current_hand_target))
        robot.apply_action(
            ArticulationAction(
                joint_positions=command.astype(np.float32),
                joint_indices=controlled_indices,
            )
        )

    def read_wrist() -> np.ndarray:
        value = np.asarray(
            robot.get_measured_joint_forces(
                joint_indices=np.asarray([wrist_reaction_row], dtype=np.int32)
            ),
            dtype=np.float64,
        )
        if value.shape != (1, 6) or not np.all(np.isfinite(value)):
            raise RuntimeGuardError(
                "invalid hand2arm reaction wrench",
                {"reason": "INVALID_WRIST_WRENCH", "shape": list(value.shape)},
            )
        return value[0]

    def sample_contacts() -> dict[str, Any]:
        pad_raw = {
            name: {"impulses": [], "normals": [], "points": [], "friction": []}
            for name in ACTIVE_PAD_LINKS
        }
        role_step = {
            name: {"PAD": 0.0, "OTHER_STRUCTURE": 0.0}
            for name in ACTIVE_PAD_LINKS
        }
        table_normal_impulse = 0.0
        unauthorized_count = 0
        unauthorized_pairs_step: set[str] = set()
        unauthorized_manifolds_step: list[dict[str, Any]] = []
        headers, contacts, friction = interface.get_full_contact_report()
        for header in headers:
            collider0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
            collider1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
            pair = {collider0, collider1}
            start = int(header.contact_data_offset)
            stop = start + int(header.num_contact_data)
            contact_slice = [contacts[index] for index in range(start, stop)]
            active_contact_slice = [
                contact
                for contact in contact_slice
                if _contact_record_is_active(contact)
            ]

            if table_path in pair and pair.intersection(plug_collision_set):
                table_normal_impulse += sum(
                    _normal_impulse(contact) for contact in active_contact_slice
                )

            robot_member = next(
                (path for path in pair if path in robot_collision_paths), None
            )
            plug_member = next(
                (path for path in pair if path in plug_collision_set), None
            )
            if robot_member is not None:
                other = collider1 if robot_member == collider0 else collider0
                forbidden_robot_pair = bool(
                    other == table_path
                    or other == fixture_path
                    or other in fixed_collision_set
                    or (
                        other in plug_collision_set
                        and not (
                            robot_member in finger_collision_set
                            and other == authorized_grip_path
                            and run_arguments.scenario != "precheck"
                        )
                    )
                )
                if forbidden_robot_pair and active_contact_slice:
                    unauthorized_count += 1
                    key = "<->".join(sorted(pair))
                    unauthorized_pairs_step.add(key)
                    unauthorized_pairs[key] = unauthorized_pairs.get(key, 0) + 1
                    unauthorized_manifolds_step.append(
                        {
                            "pair": key,
                            "collider0": collider0,
                            "collider1": collider1,
                            "contact_points": [
                                {
                                    "position_m": [
                                        float(value) for value in contact.position
                                    ],
                                    "normal": [
                                        float(value) for value in contact.normal
                                    ],
                                    "separation_m": float(contact.separation),
                                    "impulse_ns": [
                                        float(value) for value in contact.impulse
                                    ],
                                }
                                for contact in active_contact_slice
                            ],
                        }
                    )

            if (
                plug_member == authorized_grip_path
                and robot_member in finger_collision_set
                and active_contact_slice
            ):
                finger = _semantic_finger(str(robot_member))
                if finger is None:
                    raise RuntimeError("finger collision lost semantic owner")
                role = "PAD" if robot_member == pad_paths[finger] else "OTHER_STRUCTURE"
                normal_impulse = sum(
                    _normal_impulse(contact) for contact in active_contact_slice
                )
                role_step[finger][role] += normal_impulse
                role_impulse_totals[finger][role] += normal_impulse
                if role == "PAD":
                    for contact in active_contact_slice:
                        pad_raw[finger]["impulses"].append(
                            [float(value) for value in contact.impulse]
                        )
                        pad_raw[finger]["normals"].append(
                            [float(value) for value in contact.normal]
                        )
                        pad_raw[finger]["points"].append(
                            [float(value) for value in contact.position]
                        )
                    anchor_start = int(
                        getattr(header, "friction_anchors_offset", 0)
                    )
                    anchor_stop = anchor_start + int(
                        getattr(header, "num_friction_anchors_data", 0)
                    )
                    for index in range(anchor_start, anchor_stop):
                        pad_raw[finger]["friction"].append(
                            [float(value) for value in friction[index].impulse]
                        )

        measured: dict[str, dict[str, Any]] = {}
        for name, values in pad_raw.items():
            if not values["impulses"]:
                measured[name] = {
                    "valid": False,
                    "normal_force_n": 0.0,
                    "tangential_force_n": 0.0,
                    "friction_utilization": 0.0,
                    "contact_normal": None,
                    "contact_point_m": None,
                }
            else:
                aggregate = aggregate_contact_wrench(
                    contact_impulses_ns=values["impulses"],
                    contact_normals=values["normals"],
                    contact_points_m=values["points"],
                    friction_anchor_impulses_ns=values["friction"],
                    dt_s=dt_s,
                    friction_coefficient=mu,
                ).as_dict()
                aggregate["valid"] = True
                measured[name] = aggregate
        return {
            "pad": measured,
            "role_step": role_step,
            "table_normal_force_n": table_normal_impulse / dt_s,
            "unauthorized_count": unauthorized_count,
            "unauthorized_pairs": sorted(unauthorized_pairs_step),
            "unauthorized_manifolds": unauthorized_manifolds_step,
        }

    def estimate_forces(root_efforts: np.ndarray) -> np.ndarray:
        if latches is None:
            return np.zeros(3, dtype=np.float64)
        return np.asarray(
            [
                fits[name].estimate_normal_force_n(
                    latches[name].effort_delta_nm(float(root_efforts[index]))
                )
                for index, name in enumerate(ACTIVE_PAD_LINKS)
            ],
            dtype=np.float64,
        )

    def object_diagnostics() -> dict[str, Any]:
        body_position_raw, body_orientation_raw = body.get_world_pose()
        nut_position_raw, nut_orientation_raw = nut.get_world_pose()
        body_position = np.asarray(body_position_raw, dtype=np.float64)
        body_orientation = np.asarray(body_orientation_raw, dtype=np.float64)
        nut_position = np.asarray(nut_position_raw, dtype=np.float64)
        nut_orientation = np.asarray(nut_orientation_raw, dtype=np.float64)
        result = {
            "body_position": body_position,
            "body_orientation": body_orientation,
            "nut_position": nut_position,
            "nut_orientation": nut_orientation,
            "lift": None,
            "lateral": None,
            "rotation": None,
        }
        if object_reference is not None:
            delta = body_position - object_reference["body_position"]
            result["lift"] = float(delta[2])
            result["lateral"] = float(np.linalg.norm(delta[:2]))
            result["rotation"] = quaternion_angle_rad(
                object_reference["body_orientation"], body_orientation
            )
        return result

    def physics_step(
        phase: str,
        phase_step: int,
        *,
        adaptive_event: str = "",
    ) -> tuple[
        np.ndarray,
        np.ndarray,
        np.ndarray,
        dict[str, Any],
        np.ndarray,
        dict[str, Any],
        np.ndarray,
    ]:
        nonlocal physics_started, first_step_wall_s
        nonlocal maximum_arm_speed, maximum_hand_speed
        nonlocal maximum_arm_tracking_error, table_force_peak
        nonlocal wrist_raw_force_peak, wrist_raw_moment_peak
        nonlocal wrist_increment_force_peak, wrist_increment_moment_peak
        nonlocal wrist_soft_exceed_steps, wrist_recovery_exceed_steps
        nonlocal wrist_recovery_consecutive, wrist_emergency_triggered
        nonlocal latest_wrist_increment_moment, final_hold_sample_count
        nonlocal previous_root_positions, previous_hand_target_command
        nonlocal rho_above_one_consecutive, maximum_rho_above_one_consecutive
        nonlocal first_unauthorized_contact_snapshot
        commanded_hand_target = current_hand_target.copy()
        hand_target_change = (
            0.0
            if previous_hand_target_command is None
            else float(
                np.max(
                    np.abs(commanded_hand_target - previous_hand_target_command)
                )
            )
        )
        previous_hand_target_command = commanded_hand_target
        apply_targets()
        started = time.perf_counter()
        if live_visualizer is None:
            world.step(render=bool(run_arguments.gui))
        else:
            if not world.is_playing():
                world.play()
            world.step(render=False, update_fabric=True)
        physics_started = True
        wall = time.perf_counter() - started
        if first_step_wall_s is None:
            first_step_wall_s = wall
            if wall > float(safety["first_physics_step_deadline_s"]):
                raise RuntimeGuardError(
                    "first physics step deadline exceeded",
                    {
                        "reason": "FIRST_PHYSICS_STEP_DEADLINE_EXCEEDED",
                        "wall_s": wall,
                    },
                )
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts = np.asarray(
            robot.get_measured_joint_efforts(
                joint_indices=np.arange(robot.num_dof, dtype=np.int32)
            ),
            dtype=np.float64,
        )
        root_positions = positions[root_indices]
        qdot_fd = (
            np.zeros(3, dtype=np.float64)
            if previous_root_positions is None
            else (root_positions - previous_root_positions) / dt_s
        )
        previous_root_positions = root_positions.copy()
        if not (
            np.all(np.isfinite(positions))
            and np.all(np.isfinite(velocities))
            and np.all(np.isfinite(efforts))
        ):
            raise RuntimeGuardError(
                "non-finite articulation state",
                {
                    "reason": "NONFINITE_ARTICULATION_STATE",
                    "step": len(trace_rows) + 1,
                },
            )
        arm_speed = float(np.max(np.abs(velocities[arm_indices])))
        hand_speed = float(np.max(np.abs(velocities[hand_indices])))
        maximum_arm_speed = max(maximum_arm_speed, arm_speed)
        maximum_hand_speed = max(maximum_hand_speed, hand_speed)
        if arm_speed > float(safety["maximum_arm_joint_speed_rad_s"]):
            fastest_local_index = int(
                np.argmax(np.abs(velocities[arm_indices]))
            )
            fastest_dof_index = int(arm_indices[fastest_local_index])
            robot_contact_pairs: set[str] = set()
            contact_headers, _, _ = interface.get_full_contact_report()
            for header in contact_headers:
                if int(header.num_contact_data) <= 0:
                    continue
                collider0 = str(
                    PhysicsSchemaTools.intToSdfPath(header.collider0)
                )
                collider1 = str(
                    PhysicsSchemaTools.intToSdfPath(header.collider1)
                )
                if (
                    collider0 in robot_collision_paths
                    or collider1 in robot_collision_paths
                ):
                    robot_contact_pairs.add(
                        "<->".join(sorted((collider0, collider1)))
                    )
            raise RuntimeGuardError(
                "arm joint speed guard",
                {
                    "reason": "ARM_JOINT_SPEED_GUARD",
                    "step": len(trace_rows) + 1,
                    "phase": phase,
                    "phase_step": phase_step,
                    "speed_rad_s": arm_speed,
                    "fastest_arm_joint": dof_names[fastest_dof_index],
                    "arm_joint_velocities_rad_s": [
                        float(value) for value in velocities[arm_indices]
                    ],
                    "arm_joint_positions_rad": [
                        float(value) for value in positions[arm_indices]
                    ],
                    "arm_joint_targets_rad": [
                        float(value) for value in current_arm_target
                    ],
                    "robot_contact_pairs": sorted(robot_contact_pairs),
                },
            )
        if hand_speed > float(safety["maximum_hand_joint_speed_rad_s"]):
            raise RuntimeGuardError(
                "hand joint speed guard",
                {
                    "reason": "HAND_JOINT_SPEED_GUARD",
                    "step": len(trace_rows) + 1,
                    "speed_rad_s": hand_speed,
                },
            )
        arm_error = float(np.max(np.abs(positions[arm_indices] - current_arm_target)))
        maximum_arm_tracking_error = max(maximum_arm_tracking_error, arm_error)
        if arm_error > float(safety["maximum_transient_arm_tracking_error_rad"]):
            raise RuntimeGuardError(
                "transient arm tracking error guard",
                {
                    "reason": "ARM_TRACKING_ERROR_GUARD",
                    "step": len(trace_rows) + 1,
                    "error_rad": arm_error,
                },
            )
        root_efforts = efforts[root_indices]
        contacts = sample_contacts()
        if (
            first_unauthorized_contact_snapshot is None
            and contacts["unauthorized_count"] > 0
        ):
            realized_contact_tcp = np.asarray(
                iiwa14_grasp_tcp_transform(
                    tuple(float(value) for value in positions[arm_indices])
                ),
                dtype=np.float64,
            )
            target_contact_tcp = np.asarray(
                iiwa14_grasp_tcp_transform(
                    tuple(float(value) for value in current_arm_target)
                ),
                dtype=np.float64,
            )
            first_unauthorized_contact_snapshot = {
                "step": len(trace_rows) + 1,
                "phase": phase,
                "phase_step": phase_step,
                "arm_target_z_offset_m": arm_target_z_offset,
                "realized_tcp_position_m": [
                    float(value) for value in realized_contact_tcp[:3, 3]
                ],
                "target_tcp_position_m": [
                    float(value) for value in target_contact_tcp[:3, 3]
                ],
                "tcp_tracking_error_m": float(
                    np.linalg.norm(
                        realized_contact_tcp[:3, 3]
                        - target_contact_tcp[:3, 3]
                    )
                ),
                "arm_joint_positions_rad": {
                    name: float(positions[indices[name]]) for name in arm_names
                },
                "arm_joint_targets_rad": {
                    name: float(current_arm_target[index])
                    for index, name in enumerate(arm_names)
                },
                "active_hand_joint_positions_rad": {
                    name: float(positions[indices[name]]) for name in hand_names
                },
                "active_hand_joint_targets_rad": {
                    name: float(current_hand_target[index])
                    for index, name in enumerate(hand_names)
                },
                "finger_joint_positions_rad": {
                    name: float(positions[indices[name]])
                    for name in dof_names
                    if name.startswith(("f1", "f2", "f3"))
                },
                "pairs": contacts["unauthorized_pairs"],
                "manifolds": contacts["unauthorized_manifolds"],
            }
        estimated = estimate_forces(root_efforts)
        maximum_estimated_force[:] = np.maximum(maximum_estimated_force, estimated)
        if np.any(
            estimated
            > float(config["frozen_boundaries"]["absolute_force_ceiling_n_per_finger"])
        ):
            raise RuntimeGuardError(
                "estimated single-finger force ceiling",
                {
                    "reason": "ESTIMATED_FORCE_CEILING",
                    "step": len(trace_rows) + 1,
                    "force_n": estimated.tolist(),
                },
            )
        diagnostic = np.asarray(
            [
                contacts["pad"][name]["normal_force_n"]
                for name in ACTIVE_PAD_LINKS
            ],
            dtype=np.float64,
        )
        rho = np.asarray(
            [
                contacts["pad"][name]["friction_utilization"]
                for name in ACTIVE_PAD_LINKS
            ],
            dtype=np.float64,
        )
        maximum_diagnostic_force[:] = np.maximum(maximum_diagnostic_force, diagnostic)
        maximum_friction_utilization[:] = np.maximum(
            maximum_friction_utilization, rho
        )
        rho_above_one_consecutive = np.where(
            rho > float(safety["sustained_rho_failure_threshold"]),
            rho_above_one_consecutive + 1,
            0,
        )
        maximum_rho_above_one_consecutive[:] = np.maximum(
            maximum_rho_above_one_consecutive, rho_above_one_consecutive
        )
        table_force_peak = max(
            table_force_peak, float(contacts["table_normal_force_n"])
        )
        wrench = read_wrist()
        raw_force = float(np.linalg.norm(wrench[:3]))
        raw_moment = float(np.linalg.norm(wrench[3:]))
        wrist_raw_force_peak = max(wrist_raw_force_peak, raw_force)
        wrist_raw_moment_peak = max(wrist_raw_moment_peak, raw_moment)
        increment = np.zeros(6, dtype=np.float64)
        if wrist_tare is not None:
            increment = wrench - wrist_tare
            increment_force = float(np.linalg.norm(increment[:3]))
            increment_moment = float(np.linalg.norm(increment[3:]))
            latest_wrist_increment_moment = increment_moment
            wrist_increment_force_peak = max(
                wrist_increment_force_peak, increment_force
            )
            wrist_increment_moment_peak = max(
                wrist_increment_moment_peak, increment_moment
            )
            if increment_moment > float(safety["wrist_quality_soft_target_nm"]):
                wrist_soft_exceed_steps += 1
            if increment_moment > float(safety["wrist_recovery_gate_nm"]):
                wrist_recovery_exceed_steps += 1
                wrist_recovery_consecutive += 1
            else:
                wrist_recovery_consecutive = 0
            if increment_moment >= float(
                safety["wrist_simulation_emergency_gate_nm"]
            ):
                wrist_emergency_triggered = True
                raise RuntimeGuardError(
                    "simulation-only wrist emergency gate",
                    {
                        "reason": "WRIST_SIMULATION_EMERGENCY_GATE",
                        "step": len(trace_rows) + 1,
                        "phase": phase,
                        "phase_step": phase_step,
                        "arm_target_z_offset_m": arm_target_z_offset,
                        "increment_moment_nm": increment_moment,
                        "current_unauthorized_pairs": contacts[
                            "unauthorized_pairs"
                        ],
                        "current_unauthorized_manifolds": contacts[
                            "unauthorized_manifolds"
                        ],
                        "first_unauthorized_contact": (
                            first_unauthorized_contact_snapshot
                        ),
                        "precontact_tracking_compensation": (
                            precontact_tracking_compensation_report
                        ),
                    },
                )
        pose = object_diagnostics()
        if live_visualizer is not None:
            live_visualizer.sync(
                body_position_m=pose["body_position"],
                body_orientation_wxyz=pose["body_orientation"],
                nut_position_m=pose["nut_position"],
                nut_orientation_wxyz=pose["nut_orientation"],
            )
            if run_arguments.gui:
                world.render()
            live_visualizer.maybe_record_frame(
                phase=phase,
                physics_step=len(trace_rows) + 1,
                sim_time_s=(len(trace_rows) + 1) * dt_s,
                joint_positions_rad={
                    name: float(positions[indices[name]])
                    for name in cad_trace_joint_names
                },
                body_position_m=pose["body_position"],
                body_orientation_wxyz=pose["body_orientation"],
                nut_position_m=pose["nut_position"],
                nut_orientation_wxyz=pose["nut_orientation"],
                contacts=contacts,
            )
        realized_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in positions[arm_indices])
            ),
            dtype=np.float64,
        )
        target_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in current_arm_target)
            ),
            dtype=np.float64,
        )
        tcp_tracking_error = float(
            np.linalg.norm(realized_tcp[:3, 3] - target_tcp[:3, 3])
        )
        row: dict[str, Any] = {
            "step": len(trace_rows) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "arm_target_z_offset_m": arm_target_z_offset,
            "arm_tracking_compensation_z_m": arm_tracking_compensation_z_m,
            "tcp_z_m": float(realized_tcp[2, 3]),
            "tcp_tracking_error_m": tcp_tracking_error,
            "maximum_arm_tracking_error_rad": arm_error,
            "body_x_m": float(pose["body_position"][0]),
            "body_y_m": float(pose["body_position"][1]),
            "body_z_m": float(pose["body_position"][2]),
            "nut_x_m": float(pose["nut_position"][0]),
            "nut_y_m": float(pose["nut_position"][1]),
            "nut_z_m": float(pose["nut_position"][2]),
            "object_lift_m": "" if pose["lift"] is None else pose["lift"],
            "object_lateral_drift_m": ""
            if pose["lateral"] is None
            else pose["lateral"],
            "object_rotation_rad": ""
            if pose["rotation"] is None
            else pose["rotation"],
            "table_normal_force_n": contacts["table_normal_force_n"],
            "unauthorized_contact_count": contacts["unauthorized_count"],
            "unauthorized_contact_pairs": "|".join(
                contacts["unauthorized_pairs"]
            ),
            "raw_wrist_force_norm_n": raw_force,
            "raw_wrist_moment_norm_nm": raw_moment,
            "wrist_force_increment_norm_n": float(np.linalg.norm(increment[:3])),
            "wrist_moment_increment_norm_nm": float(np.linalg.norm(increment[3:])),
            "force_target_level_n": force_target_level,
            "adaptive_event": adaptive_event,
            "slip_monitor_armed": ""
            if slip_observation is None
            else slip_observation.armed,
            "slip_confirmation_count": ""
            if slip_observation is None
            else slip_observation.confirmation_count,
            "slip_precursor_reasons": ""
            if slip_observation is None
            else "|".join(slip_observation.reasons),
            "step_wall_s": wall,
            "controller_common_error_n": ""
            if controller_output is None
            else controller_output.common_error_n,
            "controller_first_step_frozen": ""
            if controller_output is None
            else controller_output.first_step_integrator_frozen,
            "controller_rate_limit": ""
            if controller_output is None
            else controller_output.rate_limit_active,
            "controller_cumulative_limit": ""
            if controller_output is None
            else controller_output.cumulative_limit_active,
            "force_controller_frozen": force_controller_frozen,
            "hand_target_change_max_rad": hand_target_change,
            "rho_above_one_consecutive_max": int(
                np.max(rho_above_one_consecutive)
            ),
        }
        for name in cad_trace_joint_names:
            row[f"cad_joint_{name}_position_rad"] = float(
                positions[indices[name]]
            )
        for index, (link_name, joint_name) in enumerate(
            zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS)
        ):
            prefix = FINGER_PREFIX[link_name]
            hand_local_index = hand_names.index(joint_name)
            row[f"{joint_name}_target_rad"] = current_hand_target[hand_local_index]
            row[f"{joint_name}_position_rad"] = float(
                positions[indices[joint_name]]
            )
            row[f"{joint_name}_velocity_rad_s"] = float(
                velocities[indices[joint_name]]
            )
            row[f"{joint_name}_qdot_fd_rad_s"] = float(qdot_fd[index])
            row[f"{joint_name}_effort_nm"] = float(root_efforts[index])
            row[f"{joint_name}_effort_delta_nm"] = (
                ""
                if latches is None
                else latches[link_name].effort_delta_nm(root_efforts[index])
            )
            row[f"{prefix}_contact_state"] = (
                "NOT_ACTIVE" if latches is None else latches[link_name].state
            )
            row[f"{prefix}_desired_force_n"] = (
                ""
                if controller_output is None
                else controller_output.desired_force_n[index]
            )
            row[f"{prefix}_estimated_force_n"] = estimated[index]
            measurement = contacts["pad"][link_name]
            row[f"{prefix}_normal_force_n"] = measurement["normal_force_n"]
            row[f"{prefix}_tangential_force_n"] = measurement[
                "tangential_force_n"
            ]
            row[f"{prefix}_friction_utilization"] = measurement[
                "friction_utilization"
            ]
            normal = measurement["contact_normal"]
            point = measurement["contact_point_m"]
            for component_index, component in enumerate(("x", "y", "z")):
                row[f"{prefix}_contact_normal_{component}"] = (
                    "" if normal is None else normal[component_index]
                )
                row[f"{prefix}_contact_point_{component}_m"] = (
                    "" if point is None else point[component_index]
                )
            pad_impulse = contacts["role_step"][link_name]["PAD"]
            other_impulse = contacts["role_step"][link_name]["OTHER_STRUCTURE"]
            denominator = pad_impulse + other_impulse
            row[f"{prefix}_pad_normal_impulse_ns"] = pad_impulse
            row[f"{prefix}_other_structure_normal_impulse_ns"] = other_impulse
            row[f"{prefix}_pad_share"] = (
                "" if denominator <= 1.0e-15 else pad_impulse / denominator
            )
            row[f"{prefix}_controller_offset_rad"] = (
                ""
                if controller_output is None
                else controller_output.cumulative_offset_rad[index]
            )
            row[f"{prefix}_controller_differential_error_n"] = (
                ""
                if controller_output is None
                else controller_output.differential_error_n[index]
            )
            if phase == "FINAL_HOLD" and measurement["valid"]:
                final_hold_pad_contact_steps[index] += 1
        if phase == "FINAL_HOLD":
            final_hold_sample_count += 1
        writer.writerow(row)
        trace_stream.flush()
        trace_rows.append(row)
        if (
            run_arguments.scenario == "precheck"
            and contacts["unauthorized_count"] > 0
        ):
            mimic_pairs = {
                "f3j1": "f1j1",
                "f1j3": "f1j2",
                "f2j2": "f2j1",
                "f3j3": "f3j2",
            }
            raise D0FirstCollisionReached(
                "D0 first collision reached",
                {
                    "reason": "D0_FIRST_COLLISION_REACHED",
                    "step": row["step"],
                    "phase": phase,
                    "phase_step": phase_step,
                    "pairs": contacts["unauthorized_pairs"],
                    "manifolds": contacts["unauthorized_manifolds"],
                    "arm_joint_positions_rad": {
                        name: float(positions[indices[name]]) for name in arm_names
                    },
                    "arm_joint_targets_rad": {
                        name: float(current_arm_target[index])
                        for index, name in enumerate(arm_names)
                    },
                    "active_hand_joint_positions_rad": {
                        name: float(positions[indices[name]]) for name in hand_names
                    },
                    "mimic_joint_positions_rad": {
                        follower: float(positions[indices[follower]])
                        for follower in mimic_pairs
                        if follower in indices
                    },
                    "mimic_following_error_rad": {
                        follower: float(
                            positions[indices[follower]]
                            - positions[indices[master]]
                        )
                        for follower, master in mimic_pairs.items()
                        if follower in indices and master in indices
                    },
                },
            )
        return positions, velocities, root_efforts, contacts, estimated, pose, wrench

    def open_loop_phase(name: str, steps: int) -> tuple[Any, ...]:
        values: tuple[Any, ...] | None = None
        for index in range(int(steps)):
            values = physics_step(name, index)
        assert values is not None
        return values

    def move_arm(name: str, target: np.ndarray, steps: int) -> tuple[Any, ...]:
        nonlocal current_arm_target
        start = current_arm_target.copy()
        values: tuple[Any, ...] | None = None
        for index in range(int(steps)):
            current_arm_target = np.asarray(
                interpolate_arm(
                    tuple(float(value) for value in start),
                    tuple(float(value) for value in target),
                    float(index + 1) / float(steps),
                ),
                dtype=np.float64,
            )
            values = physics_step(name, index)
        current_arm_target = target.copy()
        assert values is not None
        endpoint_error = float(
            np.max(np.abs(values[0][arm_indices] - current_arm_target))
        )
        if endpoint_error > float(safety["maximum_endpoint_arm_tracking_error_rad"]):
            raise RuntimeGuardError(
                "endpoint arm tracking error",
                {
                    "reason": "ENDPOINT_ARM_TRACKING_ERROR",
                    "phase": name,
                    "error_rad": endpoint_error,
                },
            )
        return values

    def force_step(
        name: str,
        index: int,
        desired: np.ndarray,
        previous_efforts: np.ndarray,
        *,
        adaptive_event: str = "",
    ) -> tuple[Any, ...]:
        nonlocal controller_output, current_hand_target
        assert force_control is not None
        if force_controller_frozen:
            raise RuntimeError("force controller update attempted while frozen")
        estimated_input = estimate_forces(previous_efforts)
        controller_output = force_control.update(
            desired_force_n=desired,
            estimated_force_n=estimated_input,
            dt_s=dt_s,
        )
        mapped_targets = map_force_controller_targets(
            equilibrium_targets,
            controller_output.target_positions_rad,
            closure_direction,
        )
        for joint_name, target in zip(ROOT_TORQUE_JOINTS, mapped_targets):
            current_hand_target[hand_names.index(joint_name)] = target
        return physics_step(name, index, adaptive_event=adaptive_event)

    def maybe_recover_wrist(
        previous_efforts: np.ndarray, phase_name: str
    ) -> tuple[np.ndarray, bool]:
        if wrist_recovery_consecutive < int(
            safety["wrist_recovery_confirmation_steps"]
        ):
            return previous_efforts, True
        clear_steps = 0
        for index in range(int(safety["wrist_recovery_maximum_steps"])):
            values = force_step(
                f"{phase_name}_WRIST_RECOVERY_HOLD",
                index,
                np.full(3, force_target_level, dtype=np.float64),
                previous_efforts,
            )
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            if latest_wrist_increment_moment <= float(
                safety["wrist_recovery_gate_nm"]
            ):
                clear_steps += 1
                if clear_steps >= int(safety["wrist_recovery_clear_steps"]):
                    return previous_efforts, True
            else:
                clear_steps = 0
        return previous_efforts, False

    def update_adaptive_force(
        values: tuple[Any, ...], pending_event: str
    ) -> str:
        nonlocal slip_observation, force_target_level
        if slip_monitor is None:
            return pending_event
        slip_observation = slip_monitor.update(
            estimated_force_n=values[4],
            joint_velocity_rad_s=[
                float(values[1][indices[name]]) for name in ROOT_TORQUE_JOINTS
            ],
            force_target_n=force_target_level,
        )
        if (
            slip_observation.confirmed_event
            and force_target_level
            < float(g5["adaptive_force_ceiling_n_per_finger"])
        ):
            old = force_target_level
            force_target_level = min(
                float(g5["adaptive_force_ceiling_n_per_finger"]),
                force_target_level + float(g5["adaptive_force_increment_n"]),
            )
            adaptive_events.append(
                {
                    "physics_step": len(trace_rows),
                    "from_n": old,
                    "to_n": force_target_level,
                    "reason": "PROPRIOCEPTIVE_SLIP_PRECURSOR",
                    "signals": slip_observation.as_dict(),
                }
            )
            slip_monitor.acknowledge_force_increment()
            return f"ADAPTIVE_FORCE_{old:.0f}_TO_{force_target_level:.0f}N"
        return pending_event

    def capture_visual_milestone(
        milestone: str,
        source_phase: str,
        values: tuple[Any, ...],
    ) -> None:
        if live_visualizer is None:
            return
        realized_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in values[0][arm_indices])
            ),
            dtype=np.float64,
        )
        live_visualizer.capture_milestone(
            milestone,
            source_phase=source_phase,
            physics_step=len(trace_rows),
            sim_time_s=len(trace_rows) * dt_s,
            contacts=values[3],
            tcp_position_world_m=realized_tcp[:3, 3],
        )

    def base_result(status: str, classification: str) -> dict[str, Any]:
        pad_shares = {}
        for name, totals in role_impulse_totals.items():
            denominator = totals["PAD"] + totals["OTHER_STRUCTURE"]
            pad_shares[name] = (
                0.0 if denominator <= 1.0e-15 else totals["PAD"] / denominator
            )
        final_contact_fraction = (
            np.zeros(3, dtype=np.float64)
            if final_hold_sample_count == 0
            else final_hold_pad_contact_steps.astype(np.float64)
            / float(final_hold_sample_count)
        )
        return {
            "schema": RESULT_SCHEMA,
            "status": status,
            "classification": classification,
            "goal_id": SCENARIO_GOALS[run_arguments.scenario],
            "scenario": run_arguments.scenario,
            "validation_index": run_arguments.validation_index,
            "candidate_id": plan["candidate_id"],
            "claim_scope": CLAIM_SCOPE,
            "physics_started": physics_started,
            "physics_steps": len(trace_rows),
            "first_physics_step_wall_s": first_step_wall_s,
            "maximum_arm_joint_speed_rad_s": maximum_arm_speed,
            "maximum_hand_joint_speed_rad_s": maximum_hand_speed,
            "maximum_arm_tracking_error_rad": maximum_arm_tracking_error,
            "maximum_estimated_force_n": maximum_estimated_force.tolist(),
            "maximum_posthoc_normal_force_n": maximum_diagnostic_force.tolist(),
            "maximum_posthoc_friction_utilization": maximum_friction_utilization.tolist(),
            "maximum_consecutive_rho_above_one_steps": maximum_rho_above_one_consecutive.tolist(),
            "pad_normal_impulse_share": pad_shares,
            "final_hold_pad_contact_fraction": final_contact_fraction.tolist(),
            "unauthorized_contact_pairs": unauthorized_pairs,
            "peak_table_normal_force_n": table_force_peak,
            "wrist": {
                "raw_force_peak_n": wrist_raw_force_peak,
                "raw_moment_peak_nm": wrist_raw_moment_peak,
                "tare_compensated_force_peak_n": wrist_increment_force_peak,
                "tare_compensated_moment_peak_nm": wrist_increment_moment_peak,
                "soft_target_exceed_duration_s": wrist_soft_exceed_steps * dt_s,
                "recovery_gate_exceed_duration_s": wrist_recovery_exceed_steps * dt_s,
                "simulation_emergency_triggered": wrist_emergency_triggered,
                "soft_target_nm": float(safety["wrist_quality_soft_target_nm"]),
                "recovery_gate_nm": float(safety["wrist_recovery_gate_nm"]),
                "simulation_emergency_gate_nm": float(
                    safety["wrist_simulation_emergency_gate_nm"]
                ),
                "gate_role": "SIMULATION_ONLY_TARE_COMPENSATED_NOT_HARDWARE_CLAIM",
            },
            "adaptive_events": adaptive_events,
            "precontact_tracking_compensation": (
                precontact_tracking_compensation_report
            ),
            "force_controller": None
            if force_control is None
            else force_control.state(),
            "force_quiet_hold": quiet_hold_report,
            "proprioceptive_slip_monitor": None
            if slip_monitor is None
            else slip_monitor.state(),
            "first_contact": first_contact,
            "root_torque_force_proxy": serialize_fits(fits),
            "scene_authoring": scene_authoring,
            "collision_authoring": {
                "disabled_old_terminal_hulls": disabled_terminal_hulls,
                "old_terminal_hull_enabled_count": 0,
                "pad_collision_paths": pad_paths,
                "tip_collision_paths": tip_paths,
                "side_collision_paths": side_paths,
                "convex_hull_cooking_readback": convex_hull_cooking_readback,
                "side_source_component_count": {
                    link_name: len(geometry.components_by_area) - 2
                    for link_name, geometry in role_geometry.items()
                },
                "complete_terminal_source_component_count": {
                    link_name: len(geometry.components_by_area)
                    for link_name, geometry in role_geometry.items()
                },
                "pad_collision_count": len(pad_paths),
                "tip_collision_count": len(tip_paths),
                "side_collision_count": len(side_paths),
                "maximum_convex_hulls_per_terminal": int(
                    terminal_collision_config["pad_maximum_convex_hulls"]
                    + terminal_collision_config["tip_maximum_convex_hulls"]
                    + terminal_collision_config["side_maximum_convex_hulls"]
                ),
                "source_geometry": "AUTHORED_VISUAL_CAD_COMPONENTS",
                "robot_environment_filters": [],
                "retained_nonterminal_finger_collider_count": retained_count,
                "active_finger_collision_group_count": len(finger_collision_paths),
                "terminal_mass_readback": terminal_mass_readback,
                "authorized_grip_collider": authorized_grip_path,
                "connector_table_support_collisions": {
                    "body_assembly": body_support_readback,
                },
                "collision_group_readback": collision_group_readback,
            },
            "trace_csv": str(trace_path),
            "stage_usda": str(stage_path),
            "truth_boundary": {
                "online_force_estimate_inputs": [
                    "root_joint_effort",
                ],
                "force_quiet_hold_acceptance_inputs": [
                    "root_joint_effort_force_proxy",
                    "joint_position",
                    "finite_difference_joint_position",
                ],
                "raw_generalized_velocity_role": "DIAGNOSTIC_PLUS_8_RAD_S_SAFETY_AND_SLIP_MONITOR_ONLY",
                "online_slip_inputs": [
                    "estimated_normal_force_proxy",
                    "root_joint_velocity",
                ],
                "physx_contact_role": "POST_STEP_DIAGNOSTIC_ONLY",
                "physx_contact_changes_commands": False,
                "rho_role": "POST_STEP_DIAGNOSTIC_AND_FINAL_SUSTAINED_12_STEP_TASK_GATE",
                "object_pose_role": "POST_STEP_DIAGNOSTIC_ONLY",
                "object_pose_changes_commands": False,
                "object_pose_write_after_physics_count": object_pose_write_after_physics_count,
            },
            "formal_b_passed": False,
        }

    try:
        open_loop_phase("OBJECT_SETTLE_AND_ROBOT_HOLD", int(motion["object_settle_steps"]))
        open_loop_phase("INITIAL_ROBOT_HOLD", int(motion["initial_robot_hold_steps"]))
        for waypoint in motion["approach_waypoints"]:
            move_arm(
                str(waypoint["name"]),
                np.asarray(waypoint["arm_rad"], dtype=np.float64),
                int(waypoint["steps"]),
            )
        high_offset = float(motion["candidate_high_offset_m"])
        arm_target_z_offset = high_offset
        move_arm(
            "CANDIDATE_HIGH_APPROACH",
            _ik_solution(plan, high_offset),
            int(motion["candidate_high_steps"]),
        )
        start_hand = current_hand_target.copy()
        approach_flexion = np.asarray(
            candidate.get(
                "approach_flexion_rad",
                (
                    candidate["open_flexion_rad"],
                    candidate["open_flexion_rad"],
                    candidate["open_flexion_rad"],
                ),
            ),
            dtype=np.float64,
        )
        collision_safe_descent_target = np.asarray(
            (
                candidate.get(
                    "approach_preshape_rad", candidate["open_preshape_rad"]
                ),
                approach_flexion[0],
                approach_flexion[1],
                approach_flexion[2],
            ),
            dtype=np.float64,
        )
        preshape_steps = int(motion["preshape_steps"])
        for index in range(preshape_steps):
            for component in range(4):
                current_hand_target[component] = minimum_jerk(
                    start_hand[component],
                    collision_safe_descent_target[component],
                    index,
                    preshape_steps,
                )
            physics_step("COLLISION_SAFE_HAND_AT_HIGH_APPROACH", index)
        current_hand_target = collision_safe_descent_target.copy()
        pregrasp_offset = float(motion["candidate_pregrasp_offset_m"])
        arm_target_z_offset = pregrasp_offset
        approach_values = move_arm(
            "CANDIDATE_PREGRASP",
            _ik_solution(plan, pregrasp_offset),
            int(motion["candidate_pregrasp_steps"]),
        )
        closure_start_offset = float(
            candidate.get("closure_start_offset_m", 0.0)
        )
        arm_target_z_offset = closure_start_offset
        closure_start_values = move_arm(
            "DESCEND_TO_CLOSURE_START",
            _ik_solution(plan, closure_start_offset),
            int(motion["descend_steps"]),
        )
        capture_visual_milestone(
            "APPROACH", "DESCEND_TO_CLOSURE_START", closure_start_values
        )

        if run_arguments.scenario == "precheck":
            closure_start_values = open_loop_phase(
                "D0_CLOSURE_START_HOLD",
                int(motion["contact_settle_steps"]),
            )
            zero_environment_contact = not unauthorized_pairs and all(
                totals["PAD"] + totals["OTHER_STRUCTURE"] <= 1.0e-15
                for totals in role_impulse_totals.values()
            )
            passed = bool(
                zero_environment_contact
                and maximum_arm_speed
                <= float(safety["maximum_arm_joint_speed_rad_s"])
                and maximum_hand_speed
                <= float(safety["maximum_hand_joint_speed_rad_s"])
            )
            result = base_result(
                "PASS" if passed else "FAIL",
                "FULL_IIWA_D0_ZERO_PRECONTACT_PASS"
                if passed
                else "FULL_IIWA_D0_ZERO_PRECONTACT_FAIL",
            )
            result["precheck"] = {
                "closure_start_offset_m": closure_start_offset,
                "closure_start_tcp_z_m": float(
                    np.asarray(
                        iiwa14_grasp_tcp_transform(
                            tuple(
                                float(value)
                                for value in closure_start_values[0][arm_indices]
                            )
                        ),
                        dtype=np.float64,
                    )[2, 3]
                ),
                "zero_robot_environment_contact": zero_environment_contact,
                "closure_executed": False,
                "lift_executed": False,
                "object_remained_dynamic_on_table": True,
            }
            return result

        nominal_closure_start_arm = _ik_solution(plan, closure_start_offset)
        tracking_position_samples: list[np.ndarray] = []
        for index in range(int(motion["tare_steps"])):
            values = physics_step("PRECONTACT_ARM_TRACKING_CALIBRATION", index)
            tracking_position_samples.append(
                np.asarray(values[0][arm_indices], dtype=np.float64).copy()
            )
        tracking_window_steps = min(
            len(tracking_position_samples),
            max(1, int(motion["contact_settle_steps"])),
        )
        realized_closure_start_arm = np.mean(
            np.stack(tracking_position_samples[-tracking_window_steps:]),
            axis=0,
        )
        raw_tracking_joint_error = (
            nominal_closure_start_arm - realized_closure_start_arm
        )
        precontact_tracking_joint_bias = raw_tracking_joint_error.copy()
        precontact_tracking_joint_bias[6] = 0.0
        maximum_tracking_bias = float(
            np.max(np.abs(precontact_tracking_joint_bias))
        )
        if maximum_tracking_bias > float(
            safety["maximum_endpoint_arm_tracking_error_rad"]
        ):
            raise RuntimeGuardError(
                "precontact arm tracking compensation exceeds endpoint bound",
                {
                    "reason": "PRECONTACT_TRACKING_COMPENSATION_BOUND",
                    "maximum_joint_bias_rad": maximum_tracking_bias,
                    "bound_rad": float(
                        safety["maximum_endpoint_arm_tracking_error_rad"]
                    ),
                },
            )
        compensated_closure_start_arm = (
            nominal_closure_start_arm + precontact_tracking_joint_bias
        )
        arm_lower = np.asarray(
            robot_config["arm_lower_limits_rad"], dtype=np.float64
        )
        arm_upper = np.asarray(
            robot_config["arm_upper_limits_rad"], dtype=np.float64
        )
        if np.any(compensated_closure_start_arm <= arm_lower) or np.any(
            compensated_closure_start_arm >= arm_upper
        ):
            raise RuntimeGuardError(
                "precontact arm tracking compensation exceeds joint limits",
                {
                    "reason": "PRECONTACT_TRACKING_COMPENSATION_JOINT_LIMIT",
                    "corrected_arm_rad": compensated_closure_start_arm.tolist(),
                },
            )
        desired_closure_start_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in nominal_closure_start_arm)
            ),
            dtype=np.float64,
        )
        realized_closure_start_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in realized_closure_start_arm)
            ),
            dtype=np.float64,
        )
        compensated_command_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in compensated_closure_start_arm)
            ),
            dtype=np.float64,
        )
        predicted_tcp_compensation = (
            compensated_command_tcp[:3, 3]
            - desired_closure_start_tcp[:3, 3]
        )
        arm_tracking_compensation_z_m = float(predicted_tcp_compensation[2])
        move_arm(
            "APPLY_PRECONTACT_ARM_TRACKING_COMPENSATION",
            compensated_closure_start_arm,
            int(motion["tare_steps"]),
        )
        compensated_hold_values = open_loop_phase(
            "PRECONTACT_ARM_TRACKING_COMPENSATED_HOLD",
            int(motion["contact_settle_steps"]),
        )
        realized_compensated_arm = np.asarray(
            compensated_hold_values[0][arm_indices], dtype=np.float64
        )
        realized_compensated_tcp = np.asarray(
            iiwa14_grasp_tcp_transform(
                tuple(float(value) for value in realized_compensated_arm)
            ),
            dtype=np.float64,
        )
        precontact_tracking_compensation_report = {
            "source": "ROBOT_JOINT_POSITION_FK_ONLY",
            "online_object_truth_used": False,
            "online_contact_truth_used": False,
            "physx_contact_changes_commands": False,
            "single_calibration_only": True,
            "calibration_offset_m": closure_start_offset,
            "calibration_sample_count": len(tracking_position_samples),
            "calibration_window_steps": tracking_window_steps,
            "nominal_arm_rad": nominal_closure_start_arm.tolist(),
            "realized_arm_before_rad": realized_closure_start_arm.tolist(),
            "raw_joint_tracking_error_rad": raw_tracking_joint_error.tolist(),
            "applied_joint_bias_rad": precontact_tracking_joint_bias.tolist(),
            "q7_bias_rad": float(precontact_tracking_joint_bias[6]),
            "maximum_joint_bias_rad": maximum_tracking_bias,
            "desired_tcp_position_m": desired_closure_start_tcp[:3, 3].tolist(),
            "realized_tcp_before_m": realized_closure_start_tcp[:3, 3].tolist(),
            "compensated_command_tcp_position_m": compensated_command_tcp[
                :3, 3
            ].tolist(),
            "predicted_command_tcp_delta_m": predicted_tcp_compensation.tolist(),
            "realized_arm_after_rad": realized_compensated_arm.tolist(),
            "realized_tcp_after_m": realized_compensated_tcp[:3, 3].tolist(),
            "realized_tcp_error_before_m": float(
                np.linalg.norm(
                    realized_closure_start_tcp[:3, 3]
                    - desired_closure_start_tcp[:3, 3]
                )
            ),
            "realized_tcp_error_after_m": float(
                np.linalg.norm(
                    realized_compensated_tcp[:3, 3]
                    - desired_closure_start_tcp[:3, 3]
                )
            ),
        }

        tare_effort_samples = {name: [] for name in ACTIVE_PAD_LINKS}
        tare_position_samples: list[np.ndarray] = []
        wrist_tare_samples: list[np.ndarray] = []
        precontact_pad_steps = 0
        for index in range(int(motion["tare_steps"])):
            values = physics_step("PRECONTACT_TARE", index)
            tare_position_samples.append(values[0][root_indices].copy())
            for finger_index, name in enumerate(ACTIVE_PAD_LINKS):
                tare_effort_samples[name].append(float(values[2][finger_index]))
            wrist_tare_samples.append(values[6].copy())
            if any(values[3]["pad"][name]["valid"] for name in ACTIVE_PAD_LINKS):
                precontact_pad_steps += 1
        wrist_tare = np.mean(np.stack(wrist_tare_samples), axis=0)
        latches = {
            name: IndependentContactLatch(
                tare=compute_tare_statistics(
                    tare_effort_samples[name],
                    minimum_threshold_nm=float(g2["minimum_contact_torque_delta_nm"]),
                    sigma_multiplier=float(g2["tare_sigma_multiplier"]),
                ),
                confirmation_steps=int(g2["contact_confirmation_steps"]),
                loss_threshold_fraction=float(g2["loss_threshold_fraction"]),
                loss_confirmation_steps=int(g2["loss_confirmation_steps"]),
            )
            for name in ACTIVE_PAD_LINKS
        }
        apply_gains()
        increment = float(g2["search_velocity_rad_s"]) * dt_s
        limits = {
            name: float(target)
            + float(direction) * float(g2["maximum_extra_closure_rad"])
            for name, target, direction in zip(
                ACTIVE_PAD_LINKS,
                candidate["finger_flexion_targets_rad"],
                closure_direction,
            )
        }
        all_locked_stable = 0
        search_complete = False
        last_values: tuple[Any, ...] | None = None
        closure_descent_steps = int(motion["descend_steps"])
        if closure_descent_steps <= 0 or int(g2["maximum_search_steps"]) < (
            closure_descent_steps + int(g2["all_locked_stable_steps"])
        ):
            raise RuntimeError("contact search cannot complete the coupled closure")
        closure_start_arm = (
            _ik_solution(plan, closure_start_offset)
            + precontact_tracking_joint_bias
        )
        closure_target_arm = (
            _ik_solution(plan, 0.0) + precontact_tracking_joint_bias
        )
        target_flexion = np.asarray(
            candidate["finger_flexion_targets_rad"], dtype=np.float64
        )
        for index in range(int(g2["maximum_search_steps"])):
            coupled_closure = index < closure_descent_steps
            if coupled_closure:
                fraction = float(index + 1) / float(closure_descent_steps)
                current_arm_target = np.asarray(
                    interpolate_arm(
                        tuple(float(value) for value in closure_start_arm),
                        tuple(float(value) for value in closure_target_arm),
                        fraction,
                    ),
                    dtype=np.float64,
                )
                arm_target_z_offset = minimum_jerk(
                    closure_start_offset,
                    0.0,
                    index,
                    closure_descent_steps,
                )
            else:
                current_arm_target = closure_target_arm.copy()
                arm_target_z_offset = 0.0
            for finger_index, (name, joint_name) in enumerate(
                zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS)
            ):
                hand_index = hand_names.index(joint_name)
                latch = latches[name]
                current_hand_target[hand_index] = (
                    float(latch.lock_target_rad)
                    if latch.locked
                    else (
                        minimum_jerk(
                            approach_flexion[finger_index],
                            target_flexion[finger_index],
                            index,
                            closure_descent_steps,
                        )
                        if coupled_closure
                        else advance_closure_target(
                            current_hand_target[hand_index],
                            limits[name],
                            closure_direction[finger_index],
                            increment,
                        )
                    )
                )
            values = physics_step("INDEPENDENT_CONTACT_SEARCH", index)
            gain_changed = False
            for finger_index, (name, joint_name) in enumerate(
                zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS)
            ):
                event = latches[name].update(
                    effort_nm=float(values[2][finger_index]),
                    current_target_rad=float(
                        current_hand_target[hand_names.index(joint_name)]
                    ),
                    actual_position_rad=float(values[0][indices[joint_name]]),
                    physics_step=len(trace_rows),
                )
                gain_changed = gain_changed or event is not None
                if event == "CONTACT_LOCKED" and first_contact[name] is None:
                    first_contact[name] = {
                        "physics_step": len(trace_rows),
                        "target_position_rad": float(
                            current_hand_target[hand_names.index(joint_name)]
                        ),
                        "actual_position_rad": float(
                            values[0][indices[joint_name]]
                        ),
                        "root_effort_delta_nm": latches[name].effort_delta_nm(
                            float(values[2][finger_index])
                        ),
                        "posthoc_contact_snapshot": dict(
                            values[3]["pad"][name]
                        ),
                    }
            if gain_changed:
                apply_gains()
            all_locked_stable = (
                all_locked_stable + 1
                if all(latch.locked for latch in latches.values())
                else 0
            )
            last_values = values
            if (
                index + 1 >= closure_descent_steps
                and all_locked_stable >= int(g2["all_locked_stable_steps"])
            ):
                search_complete = True
                break
        if not search_complete or last_values is None:
            return base_result("FAIL", "INDEPENDENT_CONTACT_ACQUISITION_FAIL")
        current_arm_target = closure_target_arm.copy()
        arm_target_z_offset = 0.0
        capture_visual_milestone(
            "THREE_PAD_CONTACT", "INDEPENDENT_CONTACT_SEARCH", last_values
        )
        locked_position_samples: list[np.ndarray] = []
        for index in range(int(motion["contact_settle_steps"])):
            last_values = physics_step("CONTACT_LOCKED_SETTLE", index)
            locked_position_samples.append(last_values[0][root_indices].copy())

        equilibrium_targets = [
            float(current_hand_target[hand_names.index(name)])
            for name in ROOT_TORQUE_JOINTS
        ]
        equilibrium_estimated = estimate_forces(np.asarray(last_values[2]))
        force_control = BumplessThreeFingerForceController(
            equilibrium_target_positions_rad=equilibrium_targets,
            common_rate_gain_rad_s_per_n=float(
                g4["common_rate_gain_rad_s_per_n"]
            ),
            differential_rate_gain_rad_s_per_n=float(
                g4["differential_rate_gain_rad_s_per_n"]
            ),
            maximum_offset_rate_rad_s=float(g4["maximum_offset_rate_rad_s"]),
            maximum_target_step_rad=float(g4["maximum_target_step_rad"]),
            minimum_cumulative_offset_rad=float(
                g4["minimum_cumulative_offset_rad"]
            ),
            maximum_cumulative_offset_rad=float(
                g4["maximum_cumulative_offset_rad"]
            ),
        )
        previous_efforts = np.asarray(last_values[2], dtype=np.float64)
        first_force_targets = equilibrium_estimated.copy()
        target_force = float(g4["first_force_target_n_per_finger"])
        force_target_level = float(np.mean(first_force_targets))
        first_output: ForceControlOutput | None = None
        for index in range(int(motion["force_ramp_steps"])):
            desired = np.asarray(
                [
                    minimum_jerk(
                        float(value),
                        target_force,
                        index,
                        int(motion["force_ramp_steps"]),
                    )
                    for value in first_force_targets
                ],
                dtype=np.float64,
            )
            force_target_level = float(np.mean(desired))
            values = force_step(
                "FORCE_TARGET_RAMP", index, desired, previous_efforts
            )
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            if first_output is None:
                first_output = controller_output
        assert first_output is not None
        force_target_level = target_force
        force_stable_steps = 0
        diagnostic_settle_samples: list[np.ndarray] = []
        for index in range(int(motion["force_settle_steps"])):
            values = force_step(
                "FORCE_TARGET_SETTLE",
                index,
                np.full(3, target_force, dtype=np.float64),
                previous_efforts,
            )
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            estimated = np.asarray(values[4], dtype=np.float64)
            proprio_stable = bool(
                np.all(
                    np.abs(estimated - target_force)
                    <= float(g4["stable_estimated_force_tolerance_n"])
                )
                and all(latch.locked for latch in latches.values())
            )
            force_stable_steps = force_stable_steps + 1 if proprio_stable else 0
            diagnostic_settle_samples.append(
                np.asarray(
                    [
                        values[3]["pad"][name]["normal_force_n"]
                        for name in ACTIVE_PAD_LINKS
                    ],
                    dtype=np.float64,
                )
            )
            if force_stable_steps >= int(
                quiet_hold_config["entry_consecutive_force_steps"]
            ):
                break
        force_entry_pass = bool(
            first_output.first_step_integrator_frozen
            and force_stable_steps
            >= int(quiet_hold_config["entry_consecutive_force_steps"])
            and all(latch.locked for latch in latches.values())
        )
        if not force_entry_pass:
            result = base_result("FAIL", "PROPRIOCEPTIVE_FORCE_SETTLE_FAIL")
            result["force_settle"] = {
                "proprioceptive_passed": False,
                "stable_steps": force_stable_steps,
                "raw_generalized_velocity_used_for_settle": False,
                "first_controller_output": first_output.as_dict(),
                "posthoc_diagnostic_samples": [
                    row.tolist() for row in diagnostic_settle_samples[-48:]
                ],
            }
            return result

        frozen_target_positions = np.asarray(
            [
                current_hand_target[hand_names.index(name)]
                for name in ROOT_TORQUE_JOINTS
            ],
            dtype=np.float64,
        )
        force_controller_frozen = True
        quiet_positions: list[np.ndarray] = []
        quiet_raw_velocities: list[np.ndarray] = []
        quiet_targets: list[np.ndarray] = []
        quiet_estimated: list[np.ndarray] = []
        quiet_diagnostic: list[np.ndarray] = []
        quiet_values: tuple[Any, ...] | None = None
        for index in range(int(quiet_hold_config["hold_steps"])):
            quiet_values = physics_step("FORCE_QUIET_HOLD", index)
            previous_efforts = np.asarray(quiet_values[2], dtype=np.float64)
            quiet_positions.append(quiet_values[0][root_indices].copy())
            quiet_raw_velocities.append(quiet_values[1][root_indices].copy())
            quiet_targets.append(
                np.asarray(
                    [
                        current_hand_target[hand_names.index(name)]
                        for name in ROOT_TORQUE_JOINTS
                    ],
                    dtype=np.float64,
                )
            )
            quiet_estimated.append(np.asarray(quiet_values[4], dtype=np.float64))
            quiet_diagnostic.append(
                np.asarray(
                    [
                        quiet_values[3]["pad"][name]["normal_force_n"]
                        for name in ACTIVE_PAD_LINKS
                    ],
                    dtype=np.float64,
                )
            )
        assert quiet_values is not None
        assessment = assess_force_quiet_hold(
            tare_positions_rad=tare_position_samples[
                -int(quiet_hold_config["tare_baseline_steps"]) :
            ],
            locked_positions_rad=locked_position_samples[
                -int(quiet_hold_config["locked_baseline_steps"]) :
            ],
            hold_positions_rad=quiet_positions,
            hold_raw_generalized_velocity_rad_s=quiet_raw_velocities,
            hold_target_positions_rad=quiet_targets,
            hold_estimated_force_n=quiet_estimated,
            dt_s=dt_s,
            target_force_n=target_force,
            force_tolerance_n=float(g4["stable_estimated_force_tolerance_n"]),
            position_baseline_multiplier=float(
                quiet_hold_config["position_baseline_multiplier"]
            ),
            qdot_fd_baseline_multiplier=float(
                quiet_hold_config["qdot_fd_baseline_multiplier"]
            ),
            maximum_position_peak_to_peak_rad=float(
                quiet_hold_config["maximum_position_peak_to_peak_rad"]
            ),
            maximum_qdot_fd_rms_rad_s=float(
                quiet_hold_config["maximum_qdot_fd_rms_rad_s"]
            ),
            raw_to_fd_diagnostic_ratio=float(
                quiet_hold_config["raw_to_fd_diagnostic_ratio"]
            ),
        )
        quiet_hold_report = assessment.as_dict()
        quiet_hold_report.update(
            {
                "hold_steps": len(quiet_positions),
                "controller_integrator_updates_during_hold": 0,
                "frozen_target_positions_rad": frozen_target_positions.tolist(),
                "all_contact_states_locked": all(
                    latch.locked for latch in latches.values()
                ),
                "posthoc_normal_force_mean_n": np.mean(
                    np.asarray(quiet_diagnostic, dtype=np.float64), axis=0
                ).tolist(),
                "posthoc_normal_force_std_n": np.std(
                    np.asarray(quiet_diagnostic, dtype=np.float64), axis=0
                ).tolist(),
            }
        )
        force_controller_frozen = False
        g4_proprio_pass = bool(
            force_entry_pass
            and assessment.passed
            and all(latch.locked for latch in latches.values())
        )
        if not g4_proprio_pass:
            result = base_result("FAIL", "FORCE_QUIET_HOLD_FAIL")
            result["force_settle"] = {
                "proprioceptive_passed": False,
                "stable_steps": force_stable_steps,
                "raw_generalized_velocity_used_for_settle": False,
                "first_controller_output": first_output.as_dict(),
            }
            return result
        capture_visual_milestone(
            "COMPLIANT_GRASP", "FORCE_QUIET_HOLD", quiet_values
        )

        proprioception_window = [
            {
                "estimated": estimated.tolist(),
                "root_velocity_rad_s": velocity.tolist(),
            }
            for estimated, velocity in zip(quiet_estimated, quiet_raw_velocities)
        ]
        baseline_window = proprioception_window[
            -int(g5["pre_release_stable_steps"]) :
        ]
        slip_monitor = ProprioceptiveSlipMonitor(
            baseline_estimated_force_n=np.mean(
                np.asarray(
                    [row["estimated"] for row in baseline_window],
                    dtype=np.float64,
                ),
                axis=0,
            ),
            baseline_maximum_abs_velocity_rad_s=np.max(
                np.abs(
                    np.asarray(
                        [row["root_velocity_rad_s"] for row in baseline_window],
                        dtype=np.float64,
                    )
                ),
                axis=0,
            ),
            initial_force_target_n=target_force,
            force_bias_shift_trigger_n=float(
                g5["proprioceptive_force_bias_shift_trigger_n"]
            ),
            velocity_excess_trigger_rad_s=float(
                g5["proprioceptive_velocity_excess_trigger_rad_s"]
            ),
            force_drop_trigger_n=float(g5["force_drop_trigger_n"]),
            confirmation_steps=int(g5["slip_confirmation_steps"]),
            stabilization_steps=int(g5["adaptive_settle_steps"]),
            stabilization_force_tolerance_n=float(
                g5["adaptive_stable_force_tolerance_n"]
            ),
        )
        body_reference_position, body_reference_orientation = body.get_world_pose()
        nut_reference_position, nut_reference_orientation = nut.get_world_pose()
        object_reference = {
            "body_position": np.asarray(body_reference_position, dtype=np.float64),
            "body_orientation": np.asarray(
                body_reference_orientation, dtype=np.float64
            ),
            "nut_position": np.asarray(nut_reference_position, dtype=np.float64),
            "nut_orientation": np.asarray(
                nut_reference_orientation, dtype=np.float64
            ),
        }
        stage_results: list[dict[str, Any]] = []
        pending_event = ""
        baseline_tcp_z = float(
            np.asarray(
                iiwa14_grasp_tcp_transform(
                    tuple(
                        float(value)
                        for value in np.asarray(
                            robot.get_joint_positions(), dtype=np.float64
                        )[arm_indices]
                    )
                ),
                dtype=np.float64,
            )[2, 3]
        )
        load_transfer_joint_compensation = (
            precontact_tracking_joint_bias.copy()
        )
        load_transfer_compensation_report: dict[str, Any] | None = None

        def measure_lift_stage(samples: Sequence[tuple[Any, ...]]) -> dict[str, Any]:
            realized_tcp_z = float(
                np.asarray(
                    iiwa14_grasp_tcp_transform(
                        tuple(float(value) for value in samples[-1][0][arm_indices])
                    ),
                    dtype=np.float64,
                )[2, 3]
            )
            achieved = realized_tcp_z - baseline_tcp_z
            stage_pose = samples[-1][5]
            object_lift = (
                None if stage_pose["lift"] is None else float(stage_pose["lift"])
            )
            relative_axial_slip = (
                None if object_lift is None else abs(achieved - object_lift)
            )
            return {
                "realized_tcp_z_m": realized_tcp_z,
                "achieved_tcp_lift_m": achieved,
                "stage_pose": stage_pose,
                "object_lift_m": object_lift,
                "relative_axial_slip_m": relative_axial_slip,
                "mean_table_normal_force_n": float(
                    np.mean(
                        [
                            float(value[3]["table_normal_force_n"])
                            for value in samples
                        ]
                    )
                ),
            }

        for stage_index, (target, steps, settle_steps) in enumerate(
            zip(
                motion["lift_targets_m"],
                motion["lift_motion_steps"],
                motion["lift_settle_steps"],
            )
        ):
            target = float(target)
            arm_target_z_offset = target
            start_arm = current_arm_target.copy()
            final_arm = (
                _ik_solution(plan, target) + load_transfer_joint_compensation
            )
            nominal_stage_tcp = np.asarray(
                iiwa14_grasp_tcp_transform(
                    tuple(float(value) for value in _ik_solution(plan, target))
                ),
                dtype=np.float64,
            )
            compensated_stage_tcp = np.asarray(
                iiwa14_grasp_tcp_transform(
                    tuple(float(value) for value in final_arm)
                ),
                dtype=np.float64,
            )
            arm_tracking_compensation_z_m = float(
                compensated_stage_tcp[2, 3] - nominal_stage_tcp[2, 3]
            )
            for index in range(int(steps)):
                previous_efforts, recovered = maybe_recover_wrist(
                    previous_efforts, f"LIFT_{target * 1000:.1f}MM"
                )
                if not recovered:
                    return base_result("FAIL", "WRIST_MOMENT_RECOVERY_FAILED")
                current_arm_target = np.asarray(
                    interpolate_arm(
                        tuple(float(value) for value in start_arm),
                        tuple(float(value) for value in final_arm),
                        float(index + 1) / float(steps),
                    ),
                    dtype=np.float64,
                )
                values = force_step(
                    f"LIFT_{target * 1000:.1f}MM",
                    index,
                    np.full(3, force_target_level, dtype=np.float64),
                    previous_efforts,
                    adaptive_event=pending_event,
                )
                pending_event = ""
                previous_efforts = np.asarray(values[2], dtype=np.float64)
                pending_event = update_adaptive_force(values, pending_event)
            current_arm_target = final_arm.copy()
            settle_values: list[tuple[Any, ...]] = []
            stage_settle_steps = int(settle_steps)
            if stage_index == 0:
                stage_settle_steps = max(
                    stage_settle_steps, int(motion["clearance_hold_steps"])
                )
            for index in range(stage_settle_steps):
                previous_efforts, recovered = maybe_recover_wrist(
                    previous_efforts, f"LIFT_SETTLE_{target * 1000:.1f}MM"
                )
                if not recovered:
                    return base_result("FAIL", "WRIST_MOMENT_RECOVERY_FAILED")
                values = force_step(
                    f"LIFT_SETTLE_{target * 1000:.1f}MM",
                    index,
                    np.full(3, force_target_level, dtype=np.float64),
                    previous_efforts,
                    adaptive_event=pending_event,
                )
                pending_event = ""
                previous_efforts = np.asarray(values[2], dtype=np.float64)
                pending_event = update_adaptive_force(values, pending_event)
                settle_values.append(values)
            measurement = measure_lift_stage(settle_values)
            achieved = float(measurement["achieved_tcp_lift_m"])
            pre_compensation_tracking_ratio: float | None = None
            if (
                stage_index == 0
                and achieved / target
                < float(safety["minimum_lift_tracking_ratio"])
            ):
                pre_compensation_tracking_ratio = achieved / target
                incremental_corrected_arm, load_transfer_compensation_report = (
                    compute_proprioceptive_load_transfer_compensation(
                        plan,
                        target_offset_m=target,
                        achieved_tcp_offset_m=achieved,
                    )
                )
                incremental_load_transfer_bias = (
                    incremental_corrected_arm - _ik_solution(plan, target)
                )
                load_transfer_joint_compensation = (
                    precontact_tracking_joint_bias
                    + incremental_load_transfer_bias
                )
                corrected_arm = (
                    _ik_solution(plan, target)
                    + load_transfer_joint_compensation
                )
                corrected_tcp = np.asarray(
                    iiwa14_grasp_tcp_transform(
                        tuple(float(value) for value in corrected_arm)
                    ),
                    dtype=np.float64,
                )
                arm_tracking_compensation_z_m = float(
                    corrected_tcp[2, 3] - nominal_stage_tcp[2, 3]
                )
                load_transfer_compensation_report[
                    "precontact_joint_bias_rad"
                ] = precontact_tracking_joint_bias.tolist()
                load_transfer_compensation_report[
                    "incremental_load_transfer_bias_rad"
                ] = incremental_load_transfer_bias.tolist()
                load_transfer_compensation_report[
                    "total_joint_bias_rad"
                ] = load_transfer_joint_compensation.tolist()
                load_transfer_compensation_report[
                    "total_predicted_tcp_z_correction_m"
                ] = arm_tracking_compensation_z_m
                load_transfer_compensation_report["applied_physics_step"] = (
                    len(trace_rows) + 1
                )
                correction_start = current_arm_target.copy()
                correction_steps = int(settle_steps)
                for index in range(correction_steps):
                    previous_efforts, recovered = maybe_recover_wrist(
                        previous_efforts, "LIFT_LOAD_TRANSFER_COMPENSATION"
                    )
                    if not recovered:
                        return base_result(
                            "FAIL", "WRIST_MOMENT_RECOVERY_FAILED"
                        )
                    current_arm_target = np.asarray(
                        interpolate_arm(
                            tuple(float(value) for value in correction_start),
                            tuple(float(value) for value in corrected_arm),
                            float(index + 1) / float(correction_steps),
                        ),
                        dtype=np.float64,
                    )
                    values = force_step(
                        "LIFT_LOAD_TRANSFER_COMPENSATION",
                        index,
                        np.full(3, force_target_level, dtype=np.float64),
                        previous_efforts,
                        adaptive_event=pending_event,
                    )
                    pending_event = ""
                    previous_efforts = np.asarray(values[2], dtype=np.float64)
                    pending_event = update_adaptive_force(values, pending_event)
                current_arm_target = corrected_arm.copy()
                compensation_settle_values: list[tuple[Any, ...]] = []
                for index in range(correction_steps):
                    previous_efforts, recovered = maybe_recover_wrist(
                        previous_efforts,
                        "LIFT_LOAD_TRANSFER_COMPENSATION_SETTLE",
                    )
                    if not recovered:
                        return base_result(
                            "FAIL", "WRIST_MOMENT_RECOVERY_FAILED"
                        )
                    values = force_step(
                        "LIFT_LOAD_TRANSFER_COMPENSATION_SETTLE",
                        index,
                        np.full(3, force_target_level, dtype=np.float64),
                        previous_efforts,
                        adaptive_event=pending_event,
                    )
                    pending_event = ""
                    previous_efforts = np.asarray(values[2], dtype=np.float64)
                    pending_event = update_adaptive_force(values, pending_event)
                    compensation_settle_values.append(values)
                settle_values = compensation_settle_values
                measurement = measure_lift_stage(settle_values)
                achieved = float(measurement["achieved_tcp_lift_m"])

            object_lift = measurement["object_lift_m"]
            relative_axial_slip = measurement["relative_axial_slip_m"]
            stage_table_force = float(measurement["mean_table_normal_force_n"])
            tcp_tracking_passed = achieved / target >= float(
                safety["minimum_lift_tracking_ratio"]
            )
            object_following_passed = bool(
                object_lift is not None
                and relative_axial_slip is not None
                and relative_axial_slip
                <= float(g6["maximum_relative_axial_slip_m"])
            )
            table_clearance_passed = bool(
                stage_index != 0
                or stage_table_force
                <= float(safety["maximum_final_table_normal_force_n"])
            )
            stage_results.append(
                {
                    "target_m": target,
                    "achieved_tcp_lift_m": achieved,
                    "achieved_object_lift_m": object_lift,
                    "relative_axial_slip_m": relative_axial_slip,
                    "mean_table_normal_force_n": stage_table_force,
                    "tracking_ratio": achieved / target,
                    "pre_compensation_tracking_ratio": (
                        pre_compensation_tracking_ratio
                    ),
                    "load_transfer_compensation_active": bool(
                        np.any(load_transfer_joint_compensation != 0.0)
                    ),
                    "endpoint_arm_error_rad": float(
                        np.max(
                            np.abs(
                                settle_values[-1][0][arm_indices]
                                - current_arm_target
                            )
                        )
                    ),
                    "tcp_tracking_passed": tcp_tracking_passed,
                    "object_following_passed": object_following_passed,
                    "table_clearance_passed": table_clearance_passed,
                    "passed": bool(
                        tcp_tracking_passed
                        and object_following_passed
                        and table_clearance_passed
                    ),
                    "clearance_hold_steps": stage_settle_steps
                    if stage_index == 0
                    else 0,
                }
            )
            if stage_index == 0:
                capture_visual_milestone(
                    "OFFTABLE_0P5MM",
                    "LIFT_SETTLE_0.5MM",
                    settle_values[-1],
                )

        final_values: list[tuple[Any, ...]] = []
        for index in range(int(motion["final_hold_steps"])):
            previous_efforts, recovered = maybe_recover_wrist(
                previous_efforts, "FINAL_HOLD"
            )
            if not recovered:
                return base_result("FAIL", "WRIST_MOMENT_RECOVERY_FAILED")
            values = force_step(
                "FINAL_HOLD",
                index,
                np.full(3, force_target_level, dtype=np.float64),
                previous_efforts,
                adaptive_event=pending_event,
            )
            pending_event = ""
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            pending_event = update_adaptive_force(values, pending_event)
            final_values.append(values)

        capture_visual_milestone(
            "LIFT_40MM", "FINAL_HOLD", final_values[-1]
        )

        final_pose = final_values[-1][5]
        body_nut_initial = float(
            np.linalg.norm(
                object_reference["nut_position"]
                - object_reference["body_position"]
            )
        )
        body_nut_final = float(
            np.linalg.norm(
                final_pose["nut_position"] - final_pose["body_position"]
            )
        )
        body_nut_separation_change = abs(body_nut_final - body_nut_initial)
        final_realized_tcp_z = float(
            np.asarray(
                iiwa14_grasp_tcp_transform(
                    tuple(
                        float(value)
                        for value in final_values[-1][0][arm_indices]
                    )
                ),
                dtype=np.float64,
            )[2, 3]
        )
        final_tcp_lift = final_realized_tcp_z - baseline_tcp_z
        final_relative_axial_slip = (
            None
            if final_pose["lift"] is None
            else abs(final_tcp_lift - float(final_pose["lift"]))
        )
        final_table_force = float(
            np.mean(
                [
                    float(row["table_normal_force_n"])
                    for row in trace_rows[-min(120, len(trace_rows)) :]
                ]
            )
        )
        pad_shares = {}
        for name, totals in role_impulse_totals.items():
            total = totals["PAD"] + totals["OTHER_STRUCTURE"]
            pad_shares[name] = 0.0 if total <= 1.0e-15 else totals["PAD"] / total
        final_contact_fraction = (
            final_hold_pad_contact_steps.astype(np.float64)
            / float(max(1, final_hold_sample_count))
        )
        posthoc_force_settle = np.asarray(quiet_diagnostic, dtype=np.float64)
        posthoc_force_stable = bool(
            posthoc_force_settle.size > 0
            and np.all(
                np.abs(posthoc_force_settle - target_force)
                <= float(g4["stable_diagnostic_force_tolerance_n"])
            )
        )
        passed = bool(
            all(row["passed"] for row in stage_results)
            and final_pose["lift"] is not None
            and float(final_pose["lift"]) >= 0.039
            and float(final_pose["lateral"])
            <= float(safety["maximum_lateral_object_drift_m"])
            and float(final_pose["rotation"])
            <= float(safety["maximum_object_tilt_rad"])
            and body_nut_separation_change
            <= float(safety["maximum_body_nut_separation_change_m"])
            and final_relative_axial_slip is not None
            and final_relative_axial_slip
            <= float(g6["maximum_relative_axial_slip_m"])
            and final_table_force
            <= float(safety["maximum_final_table_normal_force_n"])
            and all(
                value >= float(safety["minimum_pad_normal_impulse_share"])
                for value in pad_shares.values()
            )
            and np.all(
                final_contact_fraction
                >= float(safety["minimum_final_pad_contact_fraction"])
            )
            and not unauthorized_pairs
            and np.all(
                maximum_estimated_force
                <= float(
                    config["frozen_boundaries"][
                        "absolute_force_ceiling_n_per_finger"
                    ]
                )
            )
            and np.all(
                maximum_diagnostic_force
                <= float(
                    config["frozen_boundaries"][
                        "absolute_force_ceiling_n_per_finger"
                    ]
                )
            )
            and not wrist_emergency_triggered
            and quiet_hold_report is not None
            and bool(quiet_hold_report["passed"])
            and np.all(
                maximum_rho_above_one_consecutive
                < int(safety["sustained_rho_failure_steps"])
            )
            and precontact_pad_steps == 0
        )
        classification_prefix = (
            "FULL_IIWA_TABLE_PICK_VALIDATION"
            if run_arguments.scenario == "validation"
            else "FULL_IIWA_INTEGRATION_QUIET_HOLD"
        )
        result = base_result(
            "PASS" if passed else "FAIL",
            f"{classification_prefix}_{'PASS' if passed else 'FAIL'}",
        )
        result["lift"] = {
            "stage_results": stage_results,
            "load_transfer_compensation": load_transfer_compensation_report,
            "object_lift_m": final_pose["lift"],
            "object_lateral_drift_m": final_pose["lateral"],
            "object_rotation_rad": final_pose["rotation"],
            "tcp_lift_m": final_tcp_lift,
            "relative_axial_slip_m": final_relative_axial_slip,
            "maximum_relative_axial_slip_m": float(
                g6["maximum_relative_axial_slip_m"]
            ),
            "body_nut_separation_change_m": body_nut_separation_change,
            "final_table_normal_force_n": final_table_force,
            "final_hold_steps": len(final_values),
            "three_pad_contact_maintained": bool(
                np.all(
                    final_contact_fraction
                    >= float(safety["minimum_final_pad_contact_fraction"])
                )
            ),
        }
        result["force_settle"] = {
            "proprioceptive_passed": g4_proprio_pass,
            "stable_steps": force_stable_steps,
            "raw_generalized_velocity_used_for_settle": False,
            "posthoc_precontact_pad_steps": precontact_pad_steps,
            "posthoc_diagnostic_force_stable": posthoc_force_stable,
            "posthoc_diagnostic_force_stable_role": "DIAGNOSTIC_ONLY",
            "posthoc_diagnostic_tail_n": posthoc_force_settle.tolist(),
            "posthoc_result_did_not_change_commands": True,
        }
        result["red_tip_main_bearing"] = any(
            value < float(safety["minimum_pad_normal_impulse_share"])
            for value in pad_shares.values()
        )
        result["old_terminal_hull_in_contact_chain"] = False
        result["diagnostic_baseline_passed"] = passed
        return result
    except D0FirstCollisionReached as first_collision_event:
        pairs = list(first_collision_event.diagnostic.get("pairs", ()))
        expected_pairs = {
            frozenset((authorized_grip_path, pad_path))
            for pad_path in pad_paths.values()
        }
        pair_sets = {
            frozenset(pair.split("<->", maxsplit=1))
            for pair in pairs
        }
        authorized_pad_contact = bool(pair_sets) and pair_sets.issubset(expected_pairs)
        result = base_result(
            "FAIL",
            "FULL_IIWA_STANDARD_COLLIDER_FIRST_CONTACT_REJECTED",
        )
        result["precheck"] = {
            "first_contact": dict(first_collision_event.diagnostic),
            "first_contact_is_blue_pad_on_authorized_grip": authorized_pad_contact,
            "precheck_requires_zero_contact": True,
            "contact_stopped_trajectory_immediately": True,
            "no_prior_robot_environment_contact": True,
            "object_remained_dynamic_on_table": True,
        }
        return result
    finally:
        if live_visualizer is not None:
            live_visualizer.finalize()
        trace_stream.flush()
        trace_stream.close()


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    if run_arguments.dry_run:
        report = dry_run(run_arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0
    portable = Path(run_arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    output = Path(run_arguments.output_dir).resolve()
    application = None
    exit_code = 1
    try:
        from isaacsim import SimulationApp

        renderer = (
            run_arguments.gui_renderer
            if run_arguments.gui or run_arguments.record_live_video
            else "Minimal"
        )
        application = SimulationApp(
            {
                "headless": not bool(run_arguments.gui),
                "hide_ui": not bool(run_arguments.gui),
                "renderer": renderer,
                "multi_gpu": False,
                "fast_shutdown": not bool(run_arguments.gui),
                "enable_crashreporter": False,
            }
        )
        run_arguments.application = application
        report = run_isaac(run_arguments)
        live_audit_path = output / "LIVE_CAPTURE_AUDIT.json"
        if live_audit_path.is_file():
            report["live_visualization"] = json.loads(
                live_audit_path.read_text(encoding="utf-8")
            )
        overlay_audit_path = output / "VISUAL_OVERLAY_AUDIT.json"
        if overlay_audit_path.is_file():
            report["visual_overlay"] = json.loads(
                overlay_audit_path.read_text(encoding="utf-8")
            )
        physics_passed = report.get("status") == "PASS"
        visual_passed = (
            not run_arguments.record_live_video
            or bool(report.get("live_visualization", {}).get("passed"))
        )
        exit_code = 0 if physics_passed and visual_passed else (4 if physics_passed else 3)
        if run_arguments.gui and run_arguments.gui_hold_seconds > 0.0:
            deadline = time.monotonic() + run_arguments.gui_hold_seconds
            while time.monotonic() < deadline:
                application.update()
                time.sleep(1.0 / 60.0)
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"{SCENARIO_GOALS[run_arguments.scenario]}_{type(error).__name__.upper()}",
            "goal_id": SCENARIO_GOALS[run_arguments.scenario],
            "scenario": run_arguments.scenario,
            "validation_index": run_arguments.validation_index,
            "error_type": type(error).__name__,
            "error": str(error),
            "runtime_diagnostic": error.diagnostic
            if isinstance(error, RuntimeGuardError)
            else None,
            "traceback": traceback.format_exc(),
            "claim_scope": CLAIM_SCOPE,
            "formal_b_passed": False,
        }
        exit_code = 2
    write_json(output / "FULL_IIWA_RESULT.json", report)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
