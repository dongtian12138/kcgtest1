#!/usr/bin/env python3
"""Interactive, post-hoc viewer for one freshly accepted full-iiwa trace.

The source run is validated before Isaac starts.  This process never executes
the grasp controller and is never dynamic acceptance evidence.  It disables
collisions and gravity, applies recorded poses at 20 Hz, and keeps the final
pose visible for at least 120 seconds so the user can pause, orbit, pan, and
zoom without perturbing the accepted physics process.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np


REPOSITORY = Path(__file__).resolve().parents[4]
SCHEMA = "D38999_B_ALL_COLLISION_TRACE_GUI_VIEWER_V1"
ARTICULATION_PATH = "/World/HandArm/Geometry/world"
OVERLAY_BODY_PATH = "/World/BFullIiwaVisualOverlay/LoosePlug/BodyAssembly"
OVERLAY_NUT_PATH = "/World/BFullIiwaVisualOverlay/LoosePlug/CouplingNut"
CAMERA_PATH = "/World/BAllCollisionTruthInteractiveCamera"
CAMERAS = {
    "overview": {
        "eye_m": (1.80, -1.75, 1.25),
        "target_m": (0.25, -0.10, 0.48),
    },
    "grasp": {
        "eye_m": (0.20, -0.55, 0.34),
        "target_m": (0.520, -0.210, 0.245),
    },
    "side": {
        "eye_m": (0.18, 0.02, 0.32),
        "target_m": (0.520, -0.210, 0.245),
    },
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--trace", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root")
    parser.add_argument("--visual-mode", choices=("clean", "collision_debug"), default="clean")
    parser.add_argument("--camera-preset", choices=tuple(CAMERAS), default="grasp")
    parser.add_argument("--source-sim-rate-hz", type=int, default=240)
    parser.add_argument("--playback-fps", type=int, default=20)
    parser.add_argument("--final-hold-seconds", type=float, default=120.0)
    parser.add_argument("--dry-run", action="store_true")
    values = parser.parse_args(argv)
    if values.source_sim_rate_hz <= 0 or values.playback_fps <= 0:
        parser.error("source-sim-rate-hz and playback-fps must be positive")
    if values.source_sim_rate_hz % values.playback_fps != 0:
        parser.error("source-sim-rate-hz must be divisible by playback-fps")
    if values.final_hold_seconds < 120.0:
        parser.error("final-hold-seconds must be at least 120")
    if not values.dry_run and not values.kit_portable_root:
        parser.error("--kit-portable-root is required outside dry-run")
    return values


def _load_source(arguments: argparse.Namespace) -> tuple[dict[str, Any], list[dict[str, str]], dict[str, Any]]:
    paths = {
        "stage": Path(arguments.stage).expanduser().resolve(),
        "trace": Path(arguments.trace).expanduser().resolve(),
        "result": Path(arguments.result).expanduser().resolve(),
    }
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    with paths["result"].open(encoding="utf-8") as stream:
        result = json.load(stream)
    with paths["trace"].open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        fieldnames = tuple(reader.fieldnames or ())
    if not isinstance(result, dict) or not rows:
        raise RuntimeError("viewer source result or trace is empty")
    accepted_classifications = {
        "FULL_IIWA_INTEGRATION_QUIET_HOLD_PASS",
        "FULL_IIWA_TABLE_PICK_VALIDATION_PASS",
    }
    if result.get("status") != "PASS" or result.get("classification") not in accepted_classifications:
        raise RuntimeError("viewer source is not an accepted full-iiwa dynamic run")
    if not result.get("physics_started") or int(result.get("physics_steps", -1)) != len(rows):
        raise RuntimeError("viewer source physics step count does not match its trace")
    if any(not bool(stage.get("passed")) for stage in result["lift"]["stage_results"]):
        raise RuntimeError("viewer source contains a failed lift stage")
    if any(float(value) < 0.90 for value in result["pad_normal_impulse_share"].values()):
        raise RuntimeError("viewer source PAD impulse share is below 0.90")
    if result.get("unauthorized_contact_pairs"):
        raise RuntimeError("viewer source contains unauthorized contacts")
    required = {
        "step",
        "phase",
        "body_x_m",
        "body_y_m",
        "body_z_m",
        "nut_x_m",
        "nut_y_m",
        "nut_z_m",
    }
    if not required.issubset(fieldnames):
        raise RuntimeError("viewer source trace lacks required pose columns")
    joint_columns = sorted(name for name in fieldnames if name.startswith("cad_joint_") and name.endswith("_position_rad"))
    if len(joint_columns) != 15:
        raise RuntimeError(f"expected 15 recorded CAD joint columns, found {len(joint_columns)}")
    expected_steps = list(range(1, len(rows) + 1))
    if [int(row["step"]) for row in rows] != expected_steps:
        raise RuntimeError("viewer source trace steps are not contiguous from 1")
    stride = arguments.source_sim_rate_hz // arguments.playback_fps
    sampled_indices = list(range(0, len(rows), stride))
    if sampled_indices[-1] != len(rows) - 1:
        sampled_indices.append(len(rows) - 1)
    source = {
        "schema": SCHEMA,
        "status": "SOURCE_VALIDATION_PASS",
        "scope": "POSTHOC_VIEW_ONLY_NOT_DYNAMIC_EVIDENCE",
        "candidate_id": result["candidate_id"],
        "source_classification": result["classification"],
        "source_physics_steps": len(rows),
        "source_paths": {name: str(path) for name, path in paths.items()},
        "source_sha256": {name: _sha256(path) for name, path in paths.items()},
        "joint_columns": joint_columns,
        "playback_stride_physics_steps": stride,
        "playback_frame_count": len(sampled_indices),
        "playback_fps": arguments.playback_fps,
        "final_hold_seconds_required": arguments.final_hold_seconds,
        "visual_mode": arguments.visual_mode,
        "camera_preset": arguments.camera_preset,
        "truth_boundary": {
            "controller_executed": False,
            "viewer_physics_stepped": False,
            "source_contact_or_object_truth_changes_commands": False,
            "viewer_pose_writes_are_posthoc": True,
            "viewer_collisions_enabled": False,
            "viewer_gravity_enabled": False,
            "dynamic_acceptance_evidence": False,
        },
    }
    source["sampled_indices"] = sampled_indices
    return result, rows, source


def _disable_collisions(stage: Any, UsdPhysics: Any) -> int:
    count = 0
    for prim in stage.Traverse():
        if prim.HasAPI(UsdPhysics.CollisionAPI):
            UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(False).Set(False)
            count += 1
    return count


def _configure_visibility(stage: Any, UsdGeom: Any, Gf: Any, mode: str) -> dict[str, int]:
    hidden = 0
    debug_visible = 0
    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Imageable):
            continue
        path = str(prim.GetPath()).lower()
        name = prim.GetName().lower()
        always_hide = (
            name == "pad_core_capsule"
            or name.endswith("_convex")
            or "/continuousplugguidecollision" in path
            or "/continuousguidering/outerbackbone" in path
            or "/continuousguidering/boreguidebetweenkeyways" in path
        )
        terminal_collision = any(
            token in name
            for token in (
                "blue_pad_cad_collision",
                "red_tip_cad_collision",
                "fingertip_body_cad_collision",
            )
        )
        imageable = UsdGeom.Imageable(prim)
        if always_hide or (mode == "clean" and terminal_collision):
            imageable.MakeInvisible()
            hidden += 1
            continue
        if mode == "collision_debug" and terminal_collision:
            imageable.MakeVisible()
            imageable.CreatePurposeAttr(UsdGeom.Tokens.default_)
            if prim.IsA(UsdGeom.Gprim):
                gprim = UsdGeom.Gprim(prim)
                color = (
                    Gf.Vec3f(0.0, 0.447, 0.698)
                    if "blue_pad" in name
                    else Gf.Vec3f(0.835, 0.369, 0.0)
                    if "red_tip" in name
                    else Gf.Vec3f(0.45, 0.45, 0.45)
                )
                gprim.CreateDisplayColorAttr([color])
                gprim.CreateDisplayOpacityAttr([0.42])
            debug_visible += 1
    return {"hidden_prim_count": hidden, "debug_visible_prim_count": debug_visible}


def _find_visual_sync_op(stage: Any, UsdGeom: Any, path: str) -> Any | None:
    prim = stage.GetPrimAtPath(path)
    if not prim.IsValid():
        return None
    for operation in UsdGeom.Xformable(prim).GetOrderedXformOps():
        if "visualSync" in operation.GetOpName():
            return operation
    return None


def _pose_matrix(Gf: Any, position: Sequence[float], orientation: Sequence[float]) -> Any:
    matrix = Gf.Matrix4d(1.0)
    matrix.SetRotate(
        Gf.Quatd(
            float(orientation[0]),
            Gf.Vec3d(float(orientation[1]), float(orientation[2]), float(orientation[3])),
        )
    )
    matrix.SetTranslateOnly(Gf.Vec3d(*[float(value) for value in position]))
    return matrix


def _run_isaac(arguments: argparse.Namespace, rows: list[dict[str, str]], source: dict[str, Any]) -> dict[str, Any]:
    import omni.ui as ui
    import omni.usd
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation, SingleRigidPrim
    from isaacsim.core.rendering_manager import ViewportManager
    from pxr import Gf, UsdGeom, UsdLux, UsdPhysics

    output = Path(arguments.output_dir).expanduser().resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite GUI viewer evidence: {output}")
    output.mkdir(parents=True)
    _write_json(output / "GUI_VIEWER_PLAN.json", source)

    context = omni.usd.get_context()
    if context.open_stage(source["source_paths"]["stage"]) is not True:
        raise RuntimeError("failed to open accepted full-iiwa stage")
    for _ in range(6):
        arguments.application.update()
    stage = context.get_stage()
    disabled_collision_count = _disable_collisions(stage, UsdPhysics)
    visibility = _configure_visibility(stage, UsdGeom, Gf, arguments.visual_mode)

    World.clear_instance()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(arguments.source_sim_rate_hz),
        rendering_dt=1.0 / 60.0,
        backend="numpy",
        device="cpu",
    )
    body_path = json.loads(Path(source["source_paths"]["result"]).read_text(encoding="utf-8"))["scene_authoring"]["body_prim_path"]
    nut_path = json.loads(Path(source["source_paths"]["result"]).read_text(encoding="utf-8"))["scene_authoring"]["nut_prim_path"]
    robot = world.scene.add(SingleArticulation(prim_path=ARTICULATION_PATH, name="b_all_collision_trace_viewer_robot"))
    body = world.scene.add(SingleRigidPrim(prim_path=body_path, name="b_all_collision_trace_viewer_body"))
    nut = world.scene.add(SingleRigidPrim(prim_path=nut_path, name="b_all_collision_trace_viewer_nut"))
    world.reset()
    if not robot.handles_initialized:
        raise RuntimeError("GUI trace viewer articulation handles were not initialized")
    world.get_physics_context().set_gravity(0.0)
    world.pause()

    body_orientation = np.asarray(body.get_world_pose()[1], dtype=np.float64)
    nut_orientation = np.asarray(nut.get_world_pose()[1], dtype=np.float64)
    dof_names = list(robot.dof_names)
    joint_column_by_name = {
        column[len("cad_joint_") : -len("_position_rad")]: column
        for column in source["joint_columns"]
    }
    missing = sorted(set(joint_column_by_name) - set(dof_names))
    if missing:
        raise RuntimeError(f"GUI trace viewer articulation lacks recorded joints: {missing}")
    body_overlay_op = _find_visual_sync_op(stage, UsdGeom, OVERLAY_BODY_PATH)
    nut_overlay_op = _find_visual_sync_op(stage, UsdGeom, OVERLAY_NUT_PATH)

    camera = UsdGeom.Camera.Define(stage, CAMERA_PATH)
    camera.CreateFocalLengthAttr(32.0)
    camera.CreateHorizontalApertureAttr(20.955)
    camera.CreateVerticalApertureAttr(20.955 * 720.0 / 1280.0)
    camera.CreateClippingRangeAttr(Gf.Vec2f(0.02, 12.0))
    camera_values = CAMERAS[arguments.camera_preset]
    ViewportManager.set_camera_view(
        camera=camera,
        eye=np.asarray(camera_values["eye_m"], dtype=np.float64),
        target=np.asarray(camera_values["target_m"], dtype=np.float64),
    )
    dome = UsdLux.DomeLight.Define(stage, "/World/BAllCollisionViewerFill")
    dome.CreateIntensityAttr(850.0)
    dome.CreateColorAttr(Gf.Vec3f(0.94, 0.97, 1.0))
    key = UsdLux.DistantLight.Define(stage, "/World/BAllCollisionViewerKey")
    key.CreateIntensityAttr(1700.0)
    key.CreateColorAttr(Gf.Vec3f(1.0, 0.91, 0.82))
    UsdGeom.Xformable(key).AddRotateXYZOp().Set(Gf.Vec3f(-38.0, 28.0, 32.0))

    state = {"playing": True, "frame": 0, "exit_requested": False, "restart": False, "jump_final": False}
    status_label: Any | None = None

    def set_playing(value: bool) -> None:
        state["playing"] = bool(value)

    def request_restart() -> None:
        state["restart"] = True

    def request_final() -> None:
        state["jump_final"] = True

    def request_exit() -> None:
        state["exit_requested"] = True

    window = ui.Window("B Collision Truth - Accepted Trace Viewer", width=510, height=190)
    with window.frame:
        with ui.VStack(spacing=5):
            ui.Label("POSTHOC VIEWER — NOT DYNAMIC EVIDENCE", style={"color": 0xFF44AAFF, "font_size": 18})
            ui.Label("Fresh physics PASS is frozen; this window cannot change it.")
            status_label = ui.Label("Loading accepted trace...")
            with ui.HStack(spacing=6):
                ui.Button("Play", clicked_fn=lambda: set_playing(True))
                ui.Button("Pause", clicked_fn=lambda: set_playing(False))
                ui.Button("Restart", clicked_fn=request_restart)
                ui.Button("Final pose", clicked_fn=request_final)
                ui.Button("Exit", clicked_fn=request_exit)
            ui.Label("Viewport: drag to orbit/pan, wheel to zoom. Final pose remains for >=120 s.")

    sampled_indices = list(source["sampled_indices"])
    maximum_joint_readback_error = 0.0
    applied_frame_count = 0

    def apply_trace_row(row_index: int) -> None:
        nonlocal maximum_joint_readback_error, applied_frame_count
        row = rows[row_index]
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        for name, column in joint_column_by_name.items():
            value = float(row[column])
            if not math.isfinite(value):
                raise RuntimeError(f"non-finite recorded joint position: {name}")
            positions[dof_names.index(name)] = value
        robot.set_joint_positions(positions.astype(np.float32))
        robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
        readback = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        maximum_joint_readback_error = max(
            maximum_joint_readback_error,
            float(np.max(np.abs(readback - positions))),
        )
        body_position = np.asarray([float(row[f"body_{axis}_m"]) for axis in "xyz"], dtype=np.float64)
        nut_position = np.asarray([float(row[f"nut_{axis}_m"]) for axis in "xyz"], dtype=np.float64)
        body.set_world_pose(position=body_position, orientation=body_orientation)
        nut.set_world_pose(position=nut_position, orientation=nut_orientation)
        if body_overlay_op is not None:
            body_overlay_op.Set(_pose_matrix(Gf, body_position, body_orientation))
        if nut_overlay_op is not None:
            nut_overlay_op.Set(_pose_matrix(Gf, nut_position, nut_orientation))
        applied_frame_count += 1
        if status_label is not None:
            status_label.text = (
                f"Source step {row['step']}/{len(rows)} | phase {row['phase']} | "
                f"mode {arguments.visual_mode}"
            )

    apply_trace_row(sampled_indices[0])
    for _ in range(12):
        arguments.application.update()

    frame_interval = 1.0 / float(arguments.playback_fps)
    next_frame_time = time.monotonic()
    final_reached_time: float | None = None
    closed_early = False
    while arguments.application.is_running():
        now = time.monotonic()
        if state["exit_requested"]:
            closed_early = final_reached_time is None or now - final_reached_time < arguments.final_hold_seconds
            break
        if state["restart"]:
            state["restart"] = False
            state["frame"] = 0
            state["playing"] = True
            final_reached_time = None
            next_frame_time = now
        if state["jump_final"]:
            state["jump_final"] = False
            state["frame"] = len(sampled_indices) - 1
            state["playing"] = False
            apply_trace_row(sampled_indices[-1])
            final_reached_time = now
        if state["playing"] and now >= next_frame_time:
            frame_index = int(state["frame"])
            apply_trace_row(sampled_indices[frame_index])
            if frame_index >= len(sampled_indices) - 1:
                state["playing"] = False
                final_reached_time = now
            else:
                state["frame"] = frame_index + 1
            next_frame_time = now + frame_interval
        arguments.application.update()
        if final_reached_time is not None and now - final_reached_time >= arguments.final_hold_seconds:
            break
        time.sleep(1.0 / 120.0)
    if not arguments.application.is_running() and final_reached_time is None:
        closed_early = True

    final_hold_observed = 0.0 if final_reached_time is None else max(0.0, time.monotonic() - final_reached_time)
    passed = bool(
        not closed_early
        and final_reached_time is not None
        and final_hold_observed >= arguments.final_hold_seconds
        and maximum_joint_readback_error <= 5.0e-3
        and disabled_collision_count > 0
    )
    report = {
        **{key: value for key, value in source.items() if key != "sampled_indices"},
        "status": "GUI_TRACE_VIEWER_PASS" if passed else "GUI_TRACE_VIEWER_FAIL",
        "passed": passed,
        "gui_opened": True,
        "source_validation_repeated_in_viewer": False,
        "controller_executed": False,
        "viewer_physics_stepped": False,
        "viewer_pose_sync_step_count": applied_frame_count,
        "viewer_pose_sync_role": "POSTHOC_VISUAL_STATE_PROPAGATION_ONLY",
        "disabled_collision_prim_count": disabled_collision_count,
        "gravity_m_s2": 0.0,
        "maximum_joint_readback_error_rad": maximum_joint_readback_error,
        "final_pose_reached": final_reached_time is not None,
        "final_hold_seconds_observed": final_hold_observed,
        "closed_or_exited_early": closed_early,
        "interactive_controls": ["Play", "Pause", "Restart", "Final pose", "Exit", "viewport orbit", "viewport pan", "viewport zoom"],
        "visibility": visibility,
    }
    _write_json(output / "GUI_VIEWER_RESULT.json", report)
    return report


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    output = Path(arguments.output_dir).expanduser().resolve()
    _result, rows, source = _load_source(arguments)
    if arguments.dry_run:
        if output.exists():
            raise FileExistsError(f"refusing to overwrite GUI viewer dry-run: {output}")
        output.mkdir(parents=True)
        _write_json(output / "GUI_VIEWER_PLAN.json", source)
        print(json.dumps({"status": "DRY_RUN_PASS", "source": source}, sort_keys=True))
        return 0

    portable = Path(arguments.kit_portable_root).expanduser().resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    report: dict[str, Any] | None = None
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": False,
                "hide_ui": False,
                "renderer": "RayTracedLighting",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        arguments.application = application
        report = _run_isaac(arguments, rows, source)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0 if report["passed"] else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        report = {
            "schema": SCHEMA,
            "status": "GUI_TRACE_VIEWER_ERROR",
            "passed": False,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "scope": "POSTHOC_VIEW_ONLY_NOT_DYNAMIC_EVIDENCE",
        }
        _write_json(output / "GUI_VIEWER_RESULT.json", report)
        return 2
    finally:
        if application is not None:
            application.close()


if __name__ == "__main__":
    raise SystemExit(main())
