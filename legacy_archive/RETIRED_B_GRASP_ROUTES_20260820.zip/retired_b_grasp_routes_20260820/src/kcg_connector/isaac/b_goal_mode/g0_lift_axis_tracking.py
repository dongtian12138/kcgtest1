#!/usr/bin/env python3
"""G0: prove real lift_z tracking before any grasp or object experiment."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np
import yaml

from kcg_connector.grasp.b_goal_mode.lift_axis_controller import (
    LiftAxisDesign,
    design_lift_axis,
    minimum_jerk,
)
from kcg_connector.grasp.b_goal_mode.minimal_hand_rig import (
    HAND_JOINTS,
    build_collision_free_hand_urdf,
)


REPOSITORY = Path(__file__).resolve().parents[4]
DEFAULT_CONFIG = REPOSITORY / "src/kcg_connector/config/b_goal_mode/b_goal_mode.yaml"
DEFAULT_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
RESULT_SCHEMA = "D38999_B_GOAL_MODE_G0_RESULT_V1"
TRACE_FIELDS = (
    "step",
    "phase",
    "phase_step",
    "lift_target_m",
    "lift_position_m",
    "lift_velocity_m_s",
    "lift_effort_n",
    "tracking_error_m",
    "maximum_hand_joint_speed_rad_s",
    "step_wall_s",
)


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gui", action="store_true")
    return parser.parse_args(argv)


def load_config(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if payload.get("mode") != "B_GOAL_MODE_AUTONOMOUS":
        raise ValueError("configuration is not B_GOAL_MODE_AUTONOMOUS")
    g0 = payload["g0_lift_axis"]
    targets = list(g0["stage_targets_m"])
    if targets != [0.0005, 0.002, 0.010, 0.040]:
        raise ValueError(f"G0 targets changed: {targets}")
    if len(targets) != len(g0["motion_steps"]) or len(targets) != len(g0["settle_steps"]):
        raise ValueError("G0 trajectory arrays have inconsistent lengths")
    if float(g0["drive_force_multiplier"]) < 3.0:
        raise ValueError("G0 drive force multiplier is below 3x moved weight")
    return payload


def prepare_design(
    *, config: Mapping[str, Any], source_urdf: Path, output: Path
) -> tuple[dict[str, Any], LiftAxisDesign]:
    # First build with the generous source-URDF hard limit to measure the exact
    # moved mass, then rebuild with the mass-derived G0 force limit.
    urdf_path = output / "d38999_b_goal_mode_g0.urdf"
    preliminary = build_collision_free_hand_urdf(
        source_urdf=source_urdf,
        destination=urdf_path,
        lift_effort_limit_n=500.0,
    )
    simulation = config["simulation"]
    g0 = config["g0_lift_axis"]
    design = design_lift_axis(
        moved_mass_kg=float(preliminary["moved_mass_kg"]),
        targets_m=g0["stage_targets_m"],
        gravity_m_s2=float(simulation["gravity_m_s2"]),
        minimum_tracking_ratio=float(g0["minimum_tracking_ratio"]),
        maximum_absolute_error_m=float(g0["maximum_final_error_m"]),
        stiffness_margin=float(g0["stiffness_margin"]),
        damping_ratio=float(g0["damping_ratio"]),
        drive_force_multiplier=float(g0["drive_force_multiplier"]),
    )
    rig = build_collision_free_hand_urdf(
        source_urdf=source_urdf,
        destination=urdf_path,
        lift_effort_limit_n=design.maximum_drive_force_n,
    )
    return rig, design


def dry_run(run_arguments: argparse.Namespace) -> dict[str, Any]:
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = load_config(Path(run_arguments.config).resolve())
    rig, design = prepare_design(
        config=config,
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    report = {
        "schema": RESULT_SCHEMA,
        "status": "DRY_RUN_PASS",
        "goal_id": "G0_LIFT_AXIS_TRACKING",
        "rig": rig,
        "drive_design": design.as_dict(),
        "targets_m": config["g0_lift_axis"]["stage_targets_m"],
        "activity_object_present": False,
        "table_present": False,
        "collision_count": 0,
    }
    write_json(output / "G0_LIFT_AXIS_DRY_RUN_RESULT.json", report)
    return report


def run_isaac(run_arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    import omni.usd
    from pxr import PhysxSchema, Usd, UsdPhysics

    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = load_config(Path(run_arguments.config).resolve())
    rig, design = prepare_design(
        config=config,
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    urdf_path = Path(rig["temporary_urdf"])
    import_dir = output / "rig_usd"
    import_dir.mkdir()
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=str(urdf_path),
            usd_path=str(import_dir),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    if not imported_path.exists():
        raise RuntimeError(f"G0 URDF import failed: {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    simulation = config["simulation"]
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(simulation["physics_rate_hz"]),
        rendering_dt=1.0 / float(simulation["rendering_rate_hz"]),
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/G0Rig")
    roots = [prim for prim in stage.Traverse() if prim.HasAPI(UsdPhysics.ArticulationRootAPI)]
    if len(roots) != 1:
        raise RuntimeError(f"G0 requires one articulation root, got {[str(p.GetPath()) for p in roots]}")
    root = roots[0]
    collisions = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if collisions:
        raise RuntimeError(f"G0 imported collision geometry: {collisions}")
    scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(scenes) != 1:
        raise RuntimeError(f"G0 expected one physics scene, got {len(scenes)}")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(-float(simulation["gravity_m_s2"]))

    robot = world.scene.add(SingleArticulation(prim_path=str(root.GetPath()), name="g0_hand"))
    world.reset()
    dof_names = list(robot.dof_names)
    required = ("lift_z",) + HAND_JOINTS
    missing = [name for name in required if name not in dof_names]
    if missing:
        raise RuntimeError(f"G0 articulation missing DOFs: {missing}; got {dof_names}")
    indices = {name: dof_names.index(name) for name in required}

    controller = robot.get_articulation_controller()
    hand_control = config["hand_control"]
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[indices["lift_z"]] = float(design.kp_n_per_m)
    kds[indices["lift_z"]] = float(design.kd_n_s_per_m)
    for name in HAND_JOINTS:
        kps[indices[name]] = float(hand_control["position_kp"])
        kds[indices[name]] = float(hand_control["position_kd"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)
    controller.set_max_efforts(
        np.asarray([design.maximum_drive_force_n], dtype=np.float32),
        joint_indices=np.asarray([indices["lift_z"]], dtype=np.int32),
    )

    initial = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initial[indices["lift_z"]] = 0.0
    initial[indices["f1j1"]] = float(hand_control["open_preshape_rad"])
    initial[indices["f3j1"]] = float(hand_control["open_preshape_rad"])
    for name in ("f1j2", "f1j3", "f2j1", "f2j2", "f3j2", "f3j3"):
        initial[indices[name]] = float(hand_control["open_flexion_rad"])
    robot.set_joint_positions(initial.astype(np.float32))
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))

    controlled_names = ("lift_z", "f1j1", "f1j2", "f2j1", "f3j2")
    targets = {
        "lift_z": 0.0,
        "f1j1": float(hand_control["open_preshape_rad"]),
        "f1j2": float(hand_control["open_flexion_rad"]),
        "f2j1": float(hand_control["open_flexion_rad"]),
        "f3j2": float(hand_control["open_flexion_rad"]),
    }
    trace_path = output / "G0_LIFT_AXIS_TRACE.csv"
    trace_stream = trace_path.open("w", newline="", encoding="utf-8")
    writer = csv.DictWriter(trace_stream, fieldnames=TRACE_FIELDS)
    writer.writeheader()
    trace_stream.flush()
    rows: list[dict[str, Any]] = []
    first_step_wall_s: float | None = None
    maximum_lift_speed = 0.0
    maximum_hand_speed = 0.0

    def step(phase: str, phase_step: int) -> dict[str, Any]:
        nonlocal first_step_wall_s, maximum_lift_speed, maximum_hand_speed
        robot.apply_action(
            ArticulationAction(
                joint_positions=np.asarray([targets[name] for name in controlled_names], dtype=np.float32),
                joint_indices=np.asarray([indices[name] for name in controlled_names], dtype=np.int32),
            )
        )
        started = time.perf_counter()
        world.step(render=bool(run_arguments.gui))
        wall = time.perf_counter() - started
        if first_step_wall_s is None:
            first_step_wall_s = wall
            if wall > float(simulation["first_physics_step_deadline_s"]):
                raise RuntimeError(f"G0 first physics step exceeded deadline: {wall}")
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts = np.asarray(
            robot.get_measured_joint_efforts(
                joint_indices=np.arange(robot.num_dof, dtype=np.int32)
            ),
            dtype=np.float64,
        )
        if not (
            np.all(np.isfinite(positions))
            and np.all(np.isfinite(velocities))
            and np.all(np.isfinite(efforts))
        ):
            raise RuntimeError(f"G0 non-finite articulation state at step {len(rows) + 1}")
        lift_speed = abs(float(velocities[indices["lift_z"]]))
        hand_speed = max(abs(float(velocities[indices[name]])) for name in HAND_JOINTS)
        maximum_lift_speed = max(maximum_lift_speed, lift_speed)
        maximum_hand_speed = max(maximum_hand_speed, hand_speed)
        if lift_speed > float(config["g0_lift_axis"]["maximum_joint_speed_m_s"]):
            raise RuntimeError(f"G0 lift speed guard at step {len(rows) + 1}: {lift_speed}")
        row = {
            "step": len(rows) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "lift_target_m": targets["lift_z"],
            "lift_position_m": float(positions[indices["lift_z"]]),
            "lift_velocity_m_s": float(velocities[indices["lift_z"]]),
            "lift_effort_n": float(efforts[indices["lift_z"]]),
            "tracking_error_m": targets["lift_z"] - float(positions[indices["lift_z"]]),
            "maximum_hand_joint_speed_rad_s": hand_speed,
            "step_wall_s": wall,
        }
        writer.writerow(row)
        trace_stream.flush()
        rows.append(row)
        return row

    try:
        g0 = config["g0_lift_axis"]
        for index in range(int(g0["initial_hold_steps"])):
            step("INITIAL_HOLD", index)
        baseline_window = rows[-min(96, len(rows)) :]
        baseline = float(np.mean([row["lift_position_m"] for row in baseline_window]))
        stage_results: list[dict[str, Any]] = []
        previous_target = 0.0
        for target, motion_steps, settle_steps in zip(
            g0["stage_targets_m"], g0["motion_steps"], g0["settle_steps"]
        ):
            target = float(target)
            for index in range(int(motion_steps)):
                targets["lift_z"] = minimum_jerk(previous_target, target, index, int(motion_steps))
                step(f"MOVE_{target * 1000.0:.1f}MM", index)
            targets["lift_z"] = target
            settle_rows = [step(f"SETTLE_{target * 1000.0:.1f}MM", index) for index in range(int(settle_steps))]
            evaluation = settle_rows[-min(96, len(settle_rows)) :]
            positions = np.asarray([row["lift_position_m"] for row in evaluation], dtype=np.float64)
            velocities = np.asarray([row["lift_velocity_m_s"] for row in evaluation], dtype=np.float64)
            achieved = float(np.mean(positions) - baseline)
            error = abs(target - achieved)
            ratio = achieved / target
            peak_to_peak = float(np.max(positions) - np.min(positions))
            max_settle_velocity = float(np.max(np.abs(velocities)))
            stage_passed = (
                ratio >= float(g0["minimum_tracking_ratio"])
                and error <= float(g0["maximum_final_error_m"])
                and peak_to_peak <= float(g0["maximum_settle_peak_to_peak_m"])
                and max_settle_velocity <= float(g0["maximum_settle_velocity_m_s"])
            )
            stage_results.append(
                {
                    "target_m": target,
                    "achieved_mean_m": achieved,
                    "tracking_ratio": ratio,
                    "absolute_error_m": error,
                    "settle_peak_to_peak_m": peak_to_peak,
                    "maximum_settle_velocity_m_s": max_settle_velocity,
                    "passed": stage_passed,
                }
            )
            previous_target = target
        passed = all(stage["passed"] for stage in stage_results)
        return {
            "schema": RESULT_SCHEMA,
            "status": "PASS" if passed else "FAIL",
            "classification": "G0_LIFT_AXIS_TRACKING_PASS" if passed else "G0_LIFT_AXIS_TRACKING_FAIL",
            "goal_id": "G0_LIFT_AXIS_TRACKING",
            "physics_steps": len(rows),
            "first_physics_step_wall_s": first_step_wall_s,
            "maximum_lift_speed_m_s": maximum_lift_speed,
            "maximum_hand_joint_speed_rad_s": maximum_hand_speed,
            "baseline_lift_position_m": baseline,
            "stage_results": stage_results,
            "drive_design": design.as_dict(),
            "rig": rig,
            "dof_names": dof_names,
            "articulation_root": str(root.GetPath()),
            "articulation_root_count": len(roots),
            "collision_count": len(collisions),
            "object_present": False,
            "table_present": False,
            "trace_csv": str(trace_path),
            "formal_b_passed": False,
        }
    finally:
        trace_stream.flush()
        trace_stream.close()


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    if run_arguments.dry_run:
        report = dry_run(run_arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0

    portable = Path(run_arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    output = Path(run_arguments.output_dir).resolve()
    application = None
    exit_code = 1
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": not bool(run_arguments.gui),
                "hide_ui": not bool(run_arguments.gui),
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = run_isaac(run_arguments)
        exit_code = 0 if report.get("status") == "PASS" else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"G0_LIFT_AXIS_{type(error).__name__.upper()}",
            "goal_id": "G0_LIFT_AXIS_TRACKING",
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "formal_b_passed": False,
        }
        exit_code = 2
    write_json(output / "G0_LIFT_AXIS_RESULT.json", report)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
