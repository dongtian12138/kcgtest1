#!/usr/bin/env python3
"""G1: measure PAD contact normal/tangent channels without closing-loop truth use."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np
import yaml

from kcg_connector.grasp.b_goal_mode.contact_wrench_audit import (
    aggregate_contact_wrench,
)
from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    ACTIVE_PAD_LINKS,
    ROOT_TORQUE_JOINTS,
    candidate_world_geometry,
    load_seed_geometry,
    select_candidate,
    selected_pad_capsules,
)
from kcg_connector.grasp.b_goal_mode.lift_axis_controller import (
    design_lift_axis,
    minimum_jerk,
)
from kcg_connector.grasp.b_goal_mode.minimal_hand_rig import (
    HAND_JOINTS,
    build_collision_free_hand_urdf,
)


REPOSITORY = Path(__file__).resolve().parents[4]
DEFAULT_CONFIG = REPOSITORY / "src/kcg_connector/config/b_goal_mode/b_goal_mode.yaml"
DEFAULT_CANDIDATES = (
    REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json"
)
DEFAULT_PAD_CORE = (
    REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
)
DEFAULT_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
RESULT_SCHEMA = "D38999_B_GOAL_MODE_G1_RESULT_V1"
FINGER_PREFIX = {"f1Link3": "f1", "f2Link2": "f2", "f3Link3": "f3"}
ACTIVE_CONTROL_JOINTS = ("f1j1", "f1j2", "f2j1", "f3j2")


class G1GuardError(RuntimeError):
    def __init__(self, message: str, diagnostic: Mapping[str, Any]):
        super().__init__(message)
        self.diagnostic = dict(diagnostic)


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--candidates", default=str(DEFAULT_CANDIDATES))
    parser.add_argument("--pad-core", default=str(DEFAULT_PAD_CORE))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gui", action="store_true")
    return parser.parse_args(argv)


def load_config(path: Path) -> dict[str, Any]:
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    if config.get("mode") != "B_GOAL_MODE_AUTONOMOUS":
        raise ValueError("configuration is not B_GOAL_MODE_AUTONOMOUS")
    geometry = config["grasp_geometry"]
    frozen = config["frozen_boundaries"]
    expected = {
        "object_mass_kg": 0.310,
        "pad_object_friction": 0.50,
        "first_grip_force_n_per_finger": 8.0,
        "nominal_assembly_force_n_per_finger": 10.0,
        "adaptive_force_ceiling_n_per_finger": 12.0,
        "absolute_force_ceiling_n_per_finger": 15.0,
    }
    for key, value in expected.items():
        if float(frozen[key]) != value:
            raise ValueError(f"frozen boundary changed: {key}={frozen[key]}")
    for key in (
        "sdf_allowed",
        "coacd_allowed",
        "whole_terminal_convex_hull_allowed",
        "object_pose_write_after_physics_allowed",
    ):
        if frozen[key] is not False:
            raise ValueError(f"forbidden route enabled: {key}")
    if float(geometry["object_mass_kg"]) != expected["object_mass_kg"]:
        raise ValueError("runtime object mass differs from frozen boundary")
    if float(geometry["pad_object_friction"]) != expected["pad_object_friction"]:
        raise ValueError("runtime friction differs from frozen boundary")
    g1 = config["g1_contact_wrench"]
    for key in (
        "initial_hold_steps",
        "raised_preclose_steps",
        "descend_steps",
        "diagnostic_close_steps",
        "diagnostic_hold_steps",
        "stable_contact_steps",
    ):
        if int(g1[key]) <= 0:
            raise ValueError(f"G1 step count must be positive: {key}")
    if float(g1["maximum_root_torque_delta_nm"]) != 0.75:
        raise ValueError("G1 diagnostic root-torque cap changed")
    return config


def prepare(
    *,
    config: Mapping[str, Any],
    candidates_path: Path,
    pad_core_path: Path,
    source_urdf: Path,
    output: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], Any]:
    candidates, pad_core = load_seed_geometry(
        candidates_path=candidates_path,
        pad_core_path=pad_core_path,
        source_urdf=source_urdf,
    )
    candidate = select_candidate(
        candidates, str(config["g1_contact_wrench"]["seed_candidate_id"])
    )
    capsules = selected_pad_capsules(pad_core)
    geometry = candidate_world_geometry(
        hand_mount_rpy_rad=config["grasp_geometry"]["hand_mount_rpy_rad"],
        object_world_center_m=config["grasp_geometry"]["object_offtable_world_center_m"],
        candidate=candidate,
    )
    urdf_path = output / "d38999_b_goal_mode_g1.urdf"
    preliminary = build_collision_free_hand_urdf(
        source_urdf=source_urdf,
        destination=urdf_path,
        lift_effort_limit_n=500.0,
        handbase_origin_xyz_m=geometry["handbase_world_m"],
        handbase_origin_rpy_rad=geometry["hand_mount_rpy_rad"],
        lift_axis_in_joint_frame=geometry["lift_axis_in_joint_frame"],
    )
    simulation = config["simulation"]
    g0 = config["g0_lift_axis"]
    lift_design = design_lift_axis(
        moved_mass_kg=float(preliminary["moved_mass_kg"]),
        targets_m=g0["stage_targets_m"],
        gravity_m_s2=float(simulation["gravity_m_s2"]),
        minimum_tracking_ratio=float(g0["minimum_tracking_ratio"]),
        maximum_absolute_error_m=float(g0["maximum_final_error_m"]),
        stiffness_margin=float(g0["stiffness_margin"]),
        damping_ratio=float(g0["damping_ratio"]),
        drive_force_multiplier=float(g0["drive_force_multiplier"]),
    )
    rig = build_collision_free_hand_urdf(
        source_urdf=source_urdf,
        destination=urdf_path,
        lift_effort_limit_n=lift_design.maximum_drive_force_n,
        handbase_origin_xyz_m=geometry["handbase_world_m"],
        handbase_origin_rpy_rad=geometry["hand_mount_rpy_rad"],
        lift_axis_in_joint_frame=geometry["lift_axis_in_joint_frame"],
    )
    return rig, candidate, capsules, geometry, lift_design


def dry_run(run_arguments: argparse.Namespace) -> dict[str, Any]:
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = load_config(Path(run_arguments.config).resolve())
    rig, candidate, capsules, geometry, lift_design = prepare(
        config=config,
        candidates_path=Path(run_arguments.candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    report = {
        "schema": RESULT_SCHEMA,
        "status": "DRY_RUN_PASS",
        "goal_id": "G1_CONTACT_WRENCH_MEASUREMENT",
        "candidate_id": candidate["candidate_id"],
        "rig": rig,
        "geometry": geometry,
        "lift_design": lift_design.as_dict(),
        "pad_capsules": capsules,
        "pad_primitive_count": len(capsules),
        "tip_collision_count": 0,
        "whole_terminal_convex_hull_count": 0,
        "object_is_kinematic_during_g1": True,
        "contact_truth_changes_commands": False,
        "formal_b_passed": False,
    }
    write_json(output / "G1_CONTACT_WRENCH_DRY_RUN_RESULT.json", report)
    return report


def run_isaac(run_arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    import omni.usd
    from pxr import (
        Gf,
        PhysicsSchemaTools,
        PhysxSchema,
        Sdf,
        Usd,
        UsdGeom,
        UsdPhysics,
        UsdShade,
    )

    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = load_config(Path(run_arguments.config).resolve())
    rig, candidate, capsules, geometry, lift_design = prepare(
        config=config,
        candidates_path=Path(run_arguments.candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    import_dir = output / "rig_usd"
    import_dir.mkdir()
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=rig["temporary_urdf"],
            usd_path=str(import_dir),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    if not imported_path.exists():
        raise RuntimeError(f"G1 URDF import failed: {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    simulation = config["simulation"]
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(simulation["physics_rate_hz"]),
        rendering_dt=1.0 / float(simulation["rendering_rate_hz"]),
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/G1Rig")
    roots = [prim for prim in stage.Traverse() if prim.HasAPI(UsdPhysics.ArticulationRootAPI)]
    if len(roots) != 1:
        raise RuntimeError(f"G1 requires one articulation root, got {[str(p.GetPath()) for p in roots]}")
    root = roots[0]
    imported_collisions = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if imported_collisions:
        raise RuntimeError(f"G1 imported forbidden source collisions: {imported_collisions}")
    scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(scenes) != 1:
        raise RuntimeError(f"G1 expected one physics scene, got {len(scenes)}")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(-float(simulation["gravity_m_s2"]))

    material_scope = "/World/PhysicsMaterials"
    UsdGeom.Scope.Define(stage, material_scope)

    def make_material(path: str, coefficient: float) -> Any:
        material = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(material.GetPrim())
        api.CreateStaticFrictionAttr(float(coefficient))
        api.CreateDynamicFrictionAttr(float(coefficient))
        api.CreateRestitutionAttr(0.0)
        return material

    coefficient = float(config["grasp_geometry"]["pad_object_friction"])
    pad_material = make_material(material_scope + "/PAD", coefficient)
    object_material = make_material(material_scope + "/OBJECT", coefficient)

    pad_paths_by_finger: dict[str, str] = {}
    pad_collision_apis: list[Any] = []
    for link_name in ACTIVE_PAD_LINKS:
        matches = [
            prim
            for prim in stage.Traverse()
            if prim.GetName() == link_name and prim.HasAPI(UsdPhysics.RigidBodyAPI)
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one terminal rigid prim for {link_name}, got {len(matches)}")
        terminal = matches[0]
        if terminal.IsInstance():
            terminal.SetInstanceable(False)
            terminal = stage.GetPrimAtPath(terminal.GetPath())
        PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
        capsule = capsules[link_name]
        path = str(terminal.GetPath()) + "/PAD_CORE_CAPSULE"
        geometry_prim = UsdGeom.Capsule.Define(stage, path)
        geometry_prim.CreateAxisAttr(UsdGeom.Tokens.z)
        geometry_prim.CreateRadiusAttr(float(capsule["radius_m"]))
        geometry_prim.CreateHeightAttr(float(capsule["cylinder_height_m"]))
        xform = UsdGeom.Xformable(geometry_prim)
        xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
        rotation = Gf.Rotation(
            Gf.Vec3d(0.0, 0.0, 1.0), Gf.Vec3d(*capsule["axis_unit_local"])
        )
        xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
        collision = UsdPhysics.CollisionAPI.Apply(geometry_prim.GetPrim())
        collision.CreateCollisionEnabledAttr(False)
        pad_collision_apis.append(collision)
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(geometry_prim.GetPrim())
        physx_collision.CreateContactOffsetAttr(
            float(config["grasp_geometry"]["contact_offset_m"])
        )
        physx_collision.CreateRestOffsetAttr(
            float(config["grasp_geometry"]["rest_offset_m"])
        )
        UsdShade.MaterialBindingAPI(geometry_prim.GetPrim()).Bind(
            pad_material, materialPurpose="physics"
        )
        geometry_prim.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set("PAD_CONTACT_SURFACE_PROXY")
        geometry_prim.GetPrim().CreateAttribute("kcg:finger", Sdf.ValueTypeNames.Token).Set(
            link_name
        )
        pad_paths_by_finger[link_name] = path

    object_path = "/World/G1KinematicConnector"
    obj = UsdGeom.Cylinder.Define(stage, object_path)
    obj.CreateAxisAttr(UsdGeom.Tokens.z)
    obj.CreateRadiusAttr(float(config["grasp_geometry"]["object_radius_m"]))
    obj.CreateHeightAttr(float(config["grasp_geometry"]["object_height_m"]))
    UsdGeom.Xformable(obj).AddTranslateOp().Set(
        Gf.Vec3d(*geometry["object_world_center_m"])
    )
    object_collision = UsdPhysics.CollisionAPI.Apply(obj.GetPrim())
    object_collision.CreateCollisionEnabledAttr(False)
    object_rigid = UsdPhysics.RigidBodyAPI.Apply(obj.GetPrim())
    object_rigid.CreateRigidBodyEnabledAttr(True)
    object_rigid.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(obj.GetPrim()).CreateMassAttr(
        float(config["grasp_geometry"]["object_mass_kg"])
    )
    object_contact = PhysxSchema.PhysxCollisionAPI.Apply(obj.GetPrim())
    object_contact.CreateContactOffsetAttr(
        float(config["grasp_geometry"]["contact_offset_m"])
    )
    object_contact.CreateRestOffsetAttr(
        float(config["grasp_geometry"]["rest_offset_m"])
    )
    UsdShade.MaterialBindingAPI(obj.GetPrim()).Bind(
        object_material, materialPurpose="physics"
    )
    PhysxSchema.PhysxContactReportAPI.Apply(obj.GetPrim()).CreateThresholdAttr().Set(0.0)

    robot = world.scene.add(SingleArticulation(prim_path=str(root.GetPath()), name="g1_hand"))
    world.reset()
    required = ("lift_z",) + HAND_JOINTS
    dof_names = list(robot.dof_names)
    missing = [name for name in required if name not in dof_names]
    if missing:
        raise RuntimeError(f"G1 articulation missing DOFs: {missing}; got {dof_names}")
    indices = {name: dof_names.index(name) for name in required}

    controller = robot.get_articulation_controller()
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[indices["lift_z"]] = float(lift_design.kp_n_per_m)
    kds[indices["lift_z"]] = float(lift_design.kd_n_s_per_m)
    for name in ACTIVE_CONTROL_JOINTS:
        kps[indices[name]] = float(config["hand_control"]["position_kp"])
        kds[indices[name]] = float(config["hand_control"]["position_kd"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)
    controller.set_max_efforts(
        np.asarray([lift_design.maximum_drive_force_n], dtype=np.float32),
        joint_indices=np.asarray([indices["lift_z"]], dtype=np.int32),
    )

    initial = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initial[indices["lift_z"]] = float(candidate["approach_lift_m"])
    initial[indices["f1j1"]] = float(candidate["open_preshape_rad"])
    initial[indices["f3j1"]] = float(candidate["open_preshape_rad"])
    initial_flexion = [float(candidate["open_flexion_rad"])] * 3
    for name, value in (
        ("f1j2", initial_flexion[0]),
        ("f1j3", initial_flexion[0]),
        ("f2j1", initial_flexion[1]),
        ("f2j2", initial_flexion[1]),
        ("f3j2", initial_flexion[2]),
        ("f3j3", initial_flexion[2]),
    ):
        initial[indices[name]] = value
    robot.set_joint_positions(initial.astype(np.float32))
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))

    current_targets = {
        "lift_z": float(candidate["approach_lift_m"]),
        "f1j1": float(candidate["open_preshape_rad"]),
        "f1j2": initial_flexion[0],
        "f2j1": initial_flexion[1],
        "f3j2": initial_flexion[2],
    }
    for api in pad_collision_apis:
        api.GetCollisionEnabledAttr().Set(True)
    object_collision.GetCollisionEnabledAttr().Set(True)

    stage_path = output / "G1_CONTACT_WRENCH_STAGE.usda"
    stage.Export(str(stage_path))
    interface = get_physx_simulation_interface()
    dt_s = 1.0 / float(simulation["physics_rate_hz"])
    object_center = np.asarray(geometry["object_world_center_m"], dtype=np.float64)
    g1 = config["g1_contact_wrench"]
    trace_fields = [
        "step",
        "phase",
        "phase_step",
        "lift_target_m",
        "lift_position_m",
        *[f"{name}_target_rad" for name in ACTIVE_CONTROL_JOINTS],
        *[f"{name}_position_rad" for name in required],
        *[f"{name}_velocity_rad_s" for name in required],
        *[f"{name}_effort_nm" for name in ROOT_TORQUE_JOINTS],
        *[f"{name}_effort_delta_nm" for name in ROOT_TORQUE_JOINTS],
    ]
    for prefix in FINGER_PREFIX.values():
        trace_fields.extend(
            (
                f"{prefix}_normal_force_n",
                f"{prefix}_tangential_force_n",
                f"{prefix}_friction_utilization",
                f"{prefix}_contact_normal_x",
                f"{prefix}_contact_normal_y",
                f"{prefix}_contact_normal_z",
                f"{prefix}_contact_point_x_m",
                f"{prefix}_contact_point_y_m",
                f"{prefix}_contact_point_z_m",
                f"{prefix}_contact_count",
                f"{prefix}_friction_anchor_count",
                f"{prefix}_tangential_source",
            )
        )
    trace_fields.extend(("maximum_impulse_reconstruction_error_ns", "step_wall_s"))
    trace_path = output / "G1_CONTACT_WRENCH_TRACE.csv"
    trace_stream = trace_path.open("w", newline="", encoding="utf-8")
    writer = csv.DictWriter(trace_stream, fieldnames=trace_fields)
    writer.writeheader()
    trace_stream.flush()

    first_step_wall_s: float | None = None
    tare: np.ndarray | None = None
    trace_rows: list[dict[str, Any]] = []
    maximum_joint_speed = 0.0
    maximum_root_delta = np.zeros(3, dtype=np.float64)
    maximum_normal_unit_error = 0.0
    maximum_reconstruction_error = 0.0
    friction_anchor_steps = {name: 0 for name in ACTIVE_PAD_LINKS}
    last_valid_measurement: dict[str, dict[str, Any] | None] = {
        name: None for name in ACTIVE_PAD_LINKS
    }

    def apply_targets() -> None:
        names = tuple(current_targets)
        robot.apply_action(
            ArticulationAction(
                joint_positions=np.asarray(
                    [current_targets[name] for name in names], dtype=np.float32
                ),
                joint_indices=np.asarray([indices[name] for name in names], dtype=np.int32),
            )
        )

    def sample_contacts() -> dict[str, dict[str, Any]]:
        records = {
            name: {"impulses": [], "normals": [], "points": [], "friction": []}
            for name in ACTIVE_PAD_LINKS
        }
        headers, contacts, friction_anchors = interface.get_full_contact_report()
        for header in headers:
            collider0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
            collider1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
            pair = {collider0, collider1}
            for link_name, pad_path in pad_paths_by_finger.items():
                if object_path not in pair or pad_path not in pair:
                    continue
                start = int(header.contact_data_offset)
                stop = start + int(header.num_contact_data)
                for index in range(start, stop):
                    contact = contacts[index]
                    records[link_name]["impulses"].append(
                        [float(value) for value in contact.impulse]
                    )
                    records[link_name]["normals"].append(
                        [float(value) for value in contact.normal]
                    )
                    records[link_name]["points"].append(
                        [float(value) for value in contact.position]
                    )
                friction_start = int(getattr(header, "friction_anchors_offset", 0))
                friction_stop = friction_start + int(
                    getattr(header, "num_friction_anchors_data", 0)
                )
                for index in range(friction_start, friction_stop):
                    records[link_name]["friction"].append(
                        [float(value) for value in friction_anchors[index].impulse]
                    )
        measured: dict[str, dict[str, Any]] = {}
        for link_name, values in records.items():
            if not values["impulses"]:
                measured[link_name] = {
                    "valid": False,
                    "normal_force_n": 0.0,
                    "tangential_force_n": 0.0,
                    "friction_utilization": 0.0,
                    "contact_normal": None,
                    "contact_point_m": None,
                    "contact_count": 0,
                    "friction_anchor_count": 0,
                    "tangential_source": "NO_CONTACT",
                    "maximum_normal_unit_error": 0.0,
                    "maximum_impulse_reconstruction_error_ns": 0.0,
                }
                continue
            aggregate = aggregate_contact_wrench(
                contact_impulses_ns=values["impulses"],
                contact_normals=values["normals"],
                contact_points_m=values["points"],
                friction_anchor_impulses_ns=values["friction"],
                dt_s=dt_s,
                friction_coefficient=coefficient,
                orient_normals_toward_point_m=object_center,
            ).as_dict()
            aggregate["valid"] = True
            measured[link_name] = aggregate
        return measured

    def step(phase: str, phase_step: int) -> tuple[np.ndarray, dict[str, dict[str, Any]]]:
        nonlocal first_step_wall_s, maximum_joint_speed
        nonlocal maximum_normal_unit_error, maximum_reconstruction_error
        apply_targets()
        started = time.perf_counter()
        world.step(render=bool(run_arguments.gui))
        wall = time.perf_counter() - started
        if first_step_wall_s is None:
            first_step_wall_s = wall
            if wall > float(simulation["first_physics_step_deadline_s"]):
                raise G1GuardError(
                    "G1 first physics step exceeded deadline",
                    {
                        "reason": "FIRST_PHYSICS_STEP_DEADLINE_EXCEEDED",
                        "first_step_wall_s": wall,
                        "deadline_s": float(simulation["first_physics_step_deadline_s"]),
                    },
                )
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts = np.asarray(
            robot.get_measured_joint_efforts(
                joint_indices=np.arange(robot.num_dof, dtype=np.int32)
            ),
            dtype=np.float64,
        )
        if not (
            np.all(np.isfinite(positions))
            and np.all(np.isfinite(velocities))
            and np.all(np.isfinite(efforts))
        ):
            raise G1GuardError(
                "G1 non-finite articulation state",
                {
                    "reason": "NONFINITE_ARTICULATION_STATE",
                    "phase": phase,
                    "phase_step": phase_step,
                    "physics_step": len(trace_rows) + 1,
                },
            )
        speed = max(abs(float(velocities[indices[name]])) for name in HAND_JOINTS)
        maximum_joint_speed = max(maximum_joint_speed, speed)
        if speed > float(g1["maximum_joint_speed_rad_s"]):
            raise G1GuardError(
                "G1 hand joint speed guard",
                {
                    "reason": "JOINT_SPEED_GUARD",
                    "phase": phase,
                    "phase_step": phase_step,
                    "physics_step": len(trace_rows) + 1,
                    "maximum_joint_speed_rad_s": speed,
                },
            )
        root_efforts = efforts[
            np.asarray([indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32)
        ]
        root_delta = np.zeros(3, dtype=np.float64) if tare is None else np.abs(root_efforts - tare)
        if tare is not None:
            maximum_root_delta[:] = np.maximum(maximum_root_delta, root_delta)
            if np.any(root_delta > float(g1["maximum_root_torque_delta_nm"])):
                raise G1GuardError(
                    "G1 root torque diagnostic cap",
                    {
                        "reason": "ROOT_TORQUE_DIAGNOSTIC_CAP",
                        "phase": phase,
                        "phase_step": phase_step,
                        "physics_step": len(trace_rows) + 1,
                        "root_torque_delta_nm": root_delta.tolist(),
                        "cap_nm": float(g1["maximum_root_torque_delta_nm"]),
                    },
                )
        measurements = sample_contacts()
        row: dict[str, Any] = {
            "step": len(trace_rows) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "lift_target_m": current_targets["lift_z"],
            "lift_position_m": float(positions[indices["lift_z"]]),
            "maximum_impulse_reconstruction_error_ns": 0.0,
            "step_wall_s": wall,
        }
        for name in ACTIVE_CONTROL_JOINTS:
            row[f"{name}_target_rad"] = current_targets[name]
        for name in required:
            row[f"{name}_position_rad"] = float(positions[indices[name]])
            row[f"{name}_velocity_rad_s"] = float(velocities[indices[name]])
        for index, name in enumerate(ROOT_TORQUE_JOINTS):
            row[f"{name}_effort_nm"] = float(root_efforts[index])
            row[f"{name}_effort_delta_nm"] = (
                "" if tare is None else float(root_delta[index])
            )
        for link_name, measurement in measurements.items():
            prefix = FINGER_PREFIX[link_name]
            row[f"{prefix}_normal_force_n"] = measurement["normal_force_n"]
            row[f"{prefix}_tangential_force_n"] = measurement["tangential_force_n"]
            row[f"{prefix}_friction_utilization"] = measurement["friction_utilization"]
            normal = measurement["contact_normal"]
            point = measurement["contact_point_m"]
            for suffix, values in (("contact_normal", normal), ("contact_point", point)):
                components = ("x", "y", "z")
                units = "_m" if suffix == "contact_point" else ""
                for component_index, component in enumerate(components):
                    row[f"{prefix}_{suffix}_{component}{units}"] = (
                        "" if values is None else float(values[component_index])
                    )
            row[f"{prefix}_contact_count"] = measurement["contact_count"]
            row[f"{prefix}_friction_anchor_count"] = measurement["friction_anchor_count"]
            row[f"{prefix}_tangential_source"] = measurement["tangential_source"]
            if measurement["valid"]:
                last_valid_measurement[link_name] = dict(measurement)
                if int(measurement["friction_anchor_count"]) > 0:
                    friction_anchor_steps[link_name] += 1
            maximum_normal_unit_error = max(
                maximum_normal_unit_error,
                float(measurement["maximum_normal_unit_error"]),
            )
            maximum_reconstruction_error = max(
                maximum_reconstruction_error,
                float(measurement["maximum_impulse_reconstruction_error_ns"]),
            )
            row["maximum_impulse_reconstruction_error_ns"] = max(
                float(row["maximum_impulse_reconstruction_error_ns"]),
                float(measurement["maximum_impulse_reconstruction_error_ns"]),
            )
        writer.writerow(row)
        trace_stream.flush()
        trace_rows.append(row)
        return root_efforts, measurements

    try:
        initial_efforts: list[np.ndarray] = []
        for index in range(int(g1["initial_hold_steps"])):
            efforts, _measurements = step("INITIAL_HOLD", index)
            initial_efforts.append(efforts)
        tare = np.mean(np.asarray(initial_efforts[-min(96, len(initial_efforts)) :]), axis=0)

        preclose_steps = int(g1["raised_preclose_steps"])
        for index in range(preclose_steps):
            current_targets["f1j1"] = minimum_jerk(
                float(candidate["open_preshape_rad"]),
                float(candidate["preclose_preshape_rad"]),
                index,
                preclose_steps,
            )
            for name, target in zip(ROOT_TORQUE_JOINTS, candidate["preclose_flexion_rad"]):
                current_targets[name] = minimum_jerk(
                    float(candidate["open_flexion_rad"]),
                    float(target),
                    index,
                    preclose_steps,
                )
            step("RAISED_PRECLOSE", index)

        descend_steps = int(g1["descend_steps"])
        for index in range(descend_steps):
            current_targets["lift_z"] = minimum_jerk(
                float(candidate["approach_lift_m"]), 0.0, index, descend_steps
            )
            step("DESCEND_TO_GRASP", index)

        close_steps = int(g1["diagnostic_close_steps"])
        extra = float(g1["diagnostic_extra_closure_rad"])
        for index in range(close_steps):
            current_targets["f1j1"] = minimum_jerk(
                float(candidate["preclose_preshape_rad"]),
                float(candidate["preshape_rad"]),
                index,
                close_steps,
            )
            for name, start, target in zip(
                ROOT_TORQUE_JOINTS,
                candidate["preclose_flexion_rad"],
                candidate["finger_flexion_targets_rad"],
            ):
                current_targets[name] = minimum_jerk(
                    float(start), float(target) + extra, index, close_steps
                )
            step("PRECOMMITTED_DIAGNOSTIC_CLOSE", index)

        consecutive = {name: 0 for name in ACTIVE_PAD_LINKS}
        maximum_consecutive = {name: 0 for name in ACTIVE_PAD_LINKS}
        hold_measurements: dict[str, list[dict[str, Any]]] = {
            name: [] for name in ACTIVE_PAD_LINKS
        }
        for index in range(int(g1["diagnostic_hold_steps"])):
            _efforts, measurements = step("DIAGNOSTIC_HOLD", index)
            for link_name, measurement in measurements.items():
                valid = (
                    measurement["valid"]
                    and float(measurement["normal_force_n"])
                    >= float(g1["minimum_stable_normal_force_n"])
                    and float(measurement["maximum_normal_unit_error"])
                    <= float(g1["maximum_normal_unit_error"])
                    and float(measurement["maximum_impulse_reconstruction_error_ns"])
                    <= float(g1["maximum_impulse_reconstruction_error_ns"])
                )
                consecutive[link_name] = consecutive[link_name] + 1 if valid else 0
                maximum_consecutive[link_name] = max(
                    maximum_consecutive[link_name], consecutive[link_name]
                )
                if measurement["valid"]:
                    hold_measurements[link_name].append(dict(measurement))

        stable_required = int(g1["stable_contact_steps"])
        stable_pass = all(
            maximum_consecutive[name] >= stable_required for name in ACTIVE_PAD_LINKS
        )
        unit_pass = maximum_normal_unit_error <= float(g1["maximum_normal_unit_error"])
        reconstruction_pass = maximum_reconstruction_error <= float(
            g1["maximum_impulse_reconstruction_error_ns"]
        )
        torque_pass = bool(
            np.all(maximum_root_delta <= float(g1["maximum_root_torque_delta_nm"]))
        )
        passed = stable_pass and unit_pass and reconstruction_pass and torque_pass
        summaries: dict[str, Any] = {}
        for link_name in ACTIVE_PAD_LINKS:
            samples = hold_measurements[link_name]
            summaries[link_name] = {
                "valid_hold_samples": len(samples),
                "maximum_consecutive_stable_steps": maximum_consecutive[link_name],
                "mean_normal_force_n": (
                    float(np.mean([row["normal_force_n"] for row in samples]))
                    if samples
                    else 0.0
                ),
                "maximum_normal_force_n": (
                    max(float(row["normal_force_n"]) for row in samples) if samples else 0.0
                ),
                "mean_tangential_force_n": (
                    float(np.mean([row["tangential_force_n"] for row in samples]))
                    if samples
                    else 0.0
                ),
                "maximum_friction_utilization": (
                    max(float(row["friction_utilization"]) for row in samples)
                    if samples
                    else 0.0
                ),
                "friction_anchor_steps": friction_anchor_steps[link_name],
                "last_valid_contact": last_valid_measurement[link_name],
            }
        return {
            "schema": RESULT_SCHEMA,
            "status": "PASS" if passed else "FAIL",
            "classification": (
                "G1_CONTACT_WRENCH_MEASUREMENT_PASS"
                if passed
                else "G1_CONTACT_WRENCH_MEASUREMENT_FAIL"
            ),
            "goal_id": "G1_CONTACT_WRENCH_MEASUREMENT",
            "candidate_id": candidate["candidate_id"],
            "physics_steps": len(trace_rows),
            "first_physics_step_wall_s": first_step_wall_s,
            "maximum_hand_joint_speed_rad_s": maximum_joint_speed,
            "maximum_root_torque_delta_nm": maximum_root_delta.tolist(),
            "maximum_normal_unit_error": maximum_normal_unit_error,
            "maximum_impulse_reconstruction_error_ns": maximum_reconstruction_error,
            "stable_contact_steps_required": stable_required,
            "per_finger": summaries,
            "rig": rig,
            "geometry": geometry,
            "lift_design": lift_design.as_dict(),
            "dof_names": dof_names,
            "articulation_root": str(root.GetPath()),
            "articulation_root_count": len(roots),
            "pad_primitive_count": len(pad_paths_by_finger),
            "tip_collision_count": 0,
            "whole_terminal_convex_hull_count": 0,
            "trace_csv": str(trace_path),
            "stage_usda": str(stage_path),
            "force_semantics": {
                "normal_force": "sum(abs(dot(contact_impulse, unit_contact_normal))) / dt",
                "tangential_force_primary": "friction_anchor_tangent_impulse / dt",
                "tangential_force_fallback": "contact_vector_tangent_residual / dt",
                "friction_utilization": "tangential_force / (mu * normal_force + epsilon)",
                "legacy_total_impulse_norm_accepted_as_normal_force": False,
            },
            "truth_boundary": {
                "contact_report_role": "G1_DIAGNOSTIC_MEASUREMENT_ONLY",
                "contact_truth_changes_commands": False,
                "command_schedule": "PRECOMMITTED_MINIMUM_JERK",
                "object_pose_read_count": 0,
                "object_pose_write_after_first_physics_step_count": 0,
                "formal_online_truth_controller_claimed": False,
            },
            "formal_b_passed": False,
        }
    finally:
        trace_stream.flush()
        trace_stream.close()


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    if run_arguments.dry_run:
        report = dry_run(run_arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0

    portable = Path(run_arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    output = Path(run_arguments.output_dir).resolve()
    application = None
    exit_code = 1
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": not bool(run_arguments.gui),
                "hide_ui": not bool(run_arguments.gui),
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = run_isaac(run_arguments)
        exit_code = 0 if report.get("status") == "PASS" else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        diagnostic = error.diagnostic if isinstance(error, G1GuardError) else None
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"G1_CONTACT_WRENCH_{type(error).__name__.upper()}",
            "goal_id": "G1_CONTACT_WRENCH_MEASUREMENT",
            "error_type": type(error).__name__,
            "error": str(error),
            "runtime_diagnostic": diagnostic,
            "traceback": traceback.format_exc(),
            "formal_b_passed": False,
        }
        exit_code = 2
    write_json(output / "G1_CONTACT_WRENCH_RESULT.json", report)
    write_json(
        output / "CONTACT_WRENCH_MEASUREMENT_AUDIT.json",
        {
            "schema": "D38999_B_GOAL_MODE_CONTACT_WRENCH_AUDIT_V1",
            "goal_id": "G1_CONTACT_WRENCH_MEASUREMENT",
            "result_status": report.get("status"),
            "result_classification": report.get("classification"),
            "force_semantics": report.get("force_semantics"),
            "truth_boundary": report.get("truth_boundary"),
            "per_finger": report.get("per_finger"),
            "formal_b_passed": False,
        },
    )
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
