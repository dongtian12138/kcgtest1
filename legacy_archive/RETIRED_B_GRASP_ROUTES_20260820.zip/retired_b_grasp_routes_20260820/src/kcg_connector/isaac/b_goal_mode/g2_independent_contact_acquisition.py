#!/usr/bin/env python3
"""G2: acquire and latch each blue PAD contact from proprioception independently."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np

from kcg_connector.grasp.b_goal_mode.contact_wrench_audit import aggregate_contact_wrench
from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    ACTIVE_PAD_LINKS,
    ROOT_TORQUE_JOINTS,
)
from kcg_connector.grasp.b_goal_mode.independent_contact_latch import (
    IndependentContactLatch,
    compute_tare_statistics,
)
from kcg_connector.grasp.b_goal_mode.lift_axis_controller import minimum_jerk
from kcg_connector.grasp.b_goal_mode.minimal_hand_rig import HAND_JOINTS

from g1_contact_wrench_measurement import (
    ACTIVE_CONTROL_JOINTS,
    DEFAULT_CANDIDATES,
    DEFAULT_CONFIG,
    DEFAULT_PAD_CORE,
    DEFAULT_URDF,
    FINGER_PREFIX,
    load_config,
    prepare,
    write_json,
)


RESULT_SCHEMA = "D38999_B_GOAL_MODE_G2_RESULT_V1"


class G2GuardError(RuntimeError):
    def __init__(self, message: str, diagnostic: Mapping[str, Any]):
        super().__init__(message)
        self.diagnostic = dict(diagnostic)


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--candidates", default=str(DEFAULT_CANDIDATES))
    parser.add_argument("--pad-core", default=str(DEFAULT_PAD_CORE))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gui", action="store_true")
    return parser.parse_args(argv)


def load_g2_config(path: Path) -> dict[str, Any]:
    config = load_config(path)
    g2 = config["g2_independent_contact"]
    if str(g2["seed_candidate_id"]) != str(
        config["g1_contact_wrench"]["seed_candidate_id"]
    ):
        raise ValueError("G2 candidate must match the G1-measured seed")
    if not 0.03 <= float(g2["search_velocity_rad_s"]) <= 0.08:
        raise ValueError("G2 search velocity is outside the authorized range")
    if float(g2["minimum_contact_torque_delta_nm"]) != 0.03:
        raise ValueError("G2 minimum contact torque gate changed")
    if float(g2["tare_sigma_multiplier"]) != 5.0:
        raise ValueError("G2 tare sigma multiplier changed")
    if int(g2["contact_confirmation_steps"]) != 12:
        raise ValueError("G2 contact confirmation must be 12 steps")
    if int(g2["all_locked_stable_steps"]) != 24:
        raise ValueError("G2 all-locked confirmation must be 24 steps")
    if float(g2["maximum_root_torque_delta_nm"]) != 0.75:
        raise ValueError("G2 diagnostic torque cap changed")
    if not 0.0 < float(g2["locked_position_kp"]) < float(g2["searching_position_kp"]):
        raise ValueError("locked finger stiffness must be positive and lower than search stiffness")
    return config


def dry_run(run_arguments: argparse.Namespace) -> dict[str, Any]:
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = load_g2_config(Path(run_arguments.config).resolve())
    rig, candidate, capsules, geometry, lift_design = prepare(
        config=config,
        candidates_path=Path(run_arguments.candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    g2 = config["g2_independent_contact"]
    report = {
        "schema": RESULT_SCHEMA,
        "status": "DRY_RUN_PASS",
        "goal_id": "G2_INDEPENDENT_CONTACT_ACQUISITION",
        "candidate_id": candidate["candidate_id"],
        "rig": rig,
        "geometry": geometry,
        "lift_design": lift_design.as_dict(),
        "pad_capsules": capsules,
        "search_velocity_rad_s": float(g2["search_velocity_rad_s"]),
        "search_increment_rad_per_step": float(g2["search_velocity_rad_s"])
        / float(config["simulation"]["physics_rate_hz"]),
        "contact_detector_input": "ROOT_TORQUE_AND_JOINT_PROPRIOCEPTION_ONLY",
        "diagnostic_contact_truth_changes_commands": False,
        "pad_primitive_count": 3,
        "tip_collision_count": 0,
        "whole_terminal_convex_hull_count": 0,
        "formal_b_passed": False,
    }
    write_json(output / "G2_INDEPENDENT_CONTACT_DRY_RUN_RESULT.json", report)
    return report


def run_isaac(run_arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    import omni.usd
    from pxr import (
        Gf,
        PhysicsSchemaTools,
        PhysxSchema,
        Sdf,
        Usd,
        UsdGeom,
        UsdPhysics,
        UsdShade,
    )

    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = load_g2_config(Path(run_arguments.config).resolve())
    rig, candidate, capsules, geometry, lift_design = prepare(
        config=config,
        candidates_path=Path(run_arguments.candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    g2 = config["g2_independent_contact"]
    import_dir = output / "rig_usd"
    import_dir.mkdir()
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=rig["temporary_urdf"],
            usd_path=str(import_dir),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    if not imported_path.exists():
        raise RuntimeError(f"G2 URDF import failed: {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    simulation = config["simulation"]
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(simulation["physics_rate_hz"]),
        rendering_dt=1.0 / float(simulation["rendering_rate_hz"]),
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/G2Rig")
    roots = [prim for prim in stage.Traverse() if prim.HasAPI(UsdPhysics.ArticulationRootAPI)]
    if len(roots) != 1:
        raise RuntimeError(f"G2 requires one articulation root, got {[str(p.GetPath()) for p in roots]}")
    root = roots[0]
    imported_collisions = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if imported_collisions:
        raise RuntimeError(f"G2 imported forbidden source collisions: {imported_collisions}")
    scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(scenes) != 1:
        raise RuntimeError(f"G2 expected one physics scene, got {len(scenes)}")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(-float(simulation["gravity_m_s2"]))

    UsdGeom.Scope.Define(stage, "/World/PhysicsMaterials")

    def make_material(path: str, coefficient: float) -> Any:
        material = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(material.GetPrim())
        api.CreateStaticFrictionAttr(float(coefficient))
        api.CreateDynamicFrictionAttr(float(coefficient))
        api.CreateRestitutionAttr(0.0)
        return material

    coefficient = float(config["grasp_geometry"]["pad_object_friction"])
    pad_material = make_material("/World/PhysicsMaterials/PAD", coefficient)
    object_material = make_material("/World/PhysicsMaterials/OBJECT", coefficient)
    pad_paths_by_finger: dict[str, str] = {}
    pad_collision_apis: list[Any] = []
    for link_name in ACTIVE_PAD_LINKS:
        matches = [
            prim
            for prim in stage.Traverse()
            if prim.GetName() == link_name and prim.HasAPI(UsdPhysics.RigidBodyAPI)
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one terminal rigid prim for {link_name}, got {len(matches)}")
        terminal = matches[0]
        if terminal.IsInstance():
            terminal.SetInstanceable(False)
            terminal = stage.GetPrimAtPath(terminal.GetPath())
        PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
        capsule = capsules[link_name]
        path = str(terminal.GetPath()) + "/PAD_CORE_CAPSULE"
        geometry_prim = UsdGeom.Capsule.Define(stage, path)
        geometry_prim.CreateAxisAttr(UsdGeom.Tokens.z)
        geometry_prim.CreateRadiusAttr(float(capsule["radius_m"]))
        geometry_prim.CreateHeightAttr(float(capsule["cylinder_height_m"]))
        xform = UsdGeom.Xformable(geometry_prim)
        xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
        rotation = Gf.Rotation(
            Gf.Vec3d(0.0, 0.0, 1.0), Gf.Vec3d(*capsule["axis_unit_local"])
        )
        xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
        collision = UsdPhysics.CollisionAPI.Apply(geometry_prim.GetPrim())
        collision.CreateCollisionEnabledAttr(False)
        pad_collision_apis.append(collision)
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(geometry_prim.GetPrim())
        physx_collision.CreateContactOffsetAttr(
            float(config["grasp_geometry"]["contact_offset_m"])
        )
        physx_collision.CreateRestOffsetAttr(
            float(config["grasp_geometry"]["rest_offset_m"])
        )
        UsdShade.MaterialBindingAPI(geometry_prim.GetPrim()).Bind(
            pad_material, materialPurpose="physics"
        )
        geometry_prim.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set("PAD_CONTACT_SURFACE_PROXY")
        geometry_prim.GetPrim().CreateAttribute("kcg:finger", Sdf.ValueTypeNames.Token).Set(
            link_name
        )
        pad_paths_by_finger[link_name] = path

    object_path = "/World/G2KinematicConnector"
    obj = UsdGeom.Cylinder.Define(stage, object_path)
    obj.CreateAxisAttr(UsdGeom.Tokens.z)
    obj.CreateRadiusAttr(float(config["grasp_geometry"]["object_radius_m"]))
    obj.CreateHeightAttr(float(config["grasp_geometry"]["object_height_m"]))
    UsdGeom.Xformable(obj).AddTranslateOp().Set(Gf.Vec3d(*geometry["object_world_center_m"]))
    object_collision = UsdPhysics.CollisionAPI.Apply(obj.GetPrim())
    object_collision.CreateCollisionEnabledAttr(False)
    object_rigid = UsdPhysics.RigidBodyAPI.Apply(obj.GetPrim())
    object_rigid.CreateRigidBodyEnabledAttr(True)
    object_rigid.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(obj.GetPrim()).CreateMassAttr(
        float(config["grasp_geometry"]["object_mass_kg"])
    )
    object_contact = PhysxSchema.PhysxCollisionAPI.Apply(obj.GetPrim())
    object_contact.CreateContactOffsetAttr(float(config["grasp_geometry"]["contact_offset_m"]))
    object_contact.CreateRestOffsetAttr(float(config["grasp_geometry"]["rest_offset_m"]))
    UsdShade.MaterialBindingAPI(obj.GetPrim()).Bind(object_material, materialPurpose="physics")
    PhysxSchema.PhysxContactReportAPI.Apply(obj.GetPrim()).CreateThresholdAttr().Set(0.0)

    robot = world.scene.add(SingleArticulation(prim_path=str(root.GetPath()), name="g2_hand"))
    world.reset()
    required = ("lift_z",) + HAND_JOINTS
    dof_names = list(robot.dof_names)
    missing = [name for name in required if name not in dof_names]
    if missing:
        raise RuntimeError(f"G2 articulation missing DOFs: {missing}; got {dof_names}")
    indices = {name: dof_names.index(name) for name in required}
    controller = robot.get_articulation_controller()
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[indices["lift_z"]] = float(lift_design.kp_n_per_m)
    kds[indices["lift_z"]] = float(lift_design.kd_n_s_per_m)
    for name in ACTIVE_CONTROL_JOINTS:
        kps[indices[name]] = float(g2["searching_position_kp"])
        kds[indices[name]] = float(g2["position_kd"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)
    controller.set_max_efforts(
        np.asarray([lift_design.maximum_drive_force_n], dtype=np.float32),
        joint_indices=np.asarray([indices["lift_z"]], dtype=np.int32),
    )

    initial = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initial[indices["lift_z"]] = float(candidate["approach_lift_m"])
    initial[indices["f1j1"]] = float(candidate["open_preshape_rad"])
    initial[indices["f3j1"]] = float(candidate["open_preshape_rad"])
    for name in ("f1j2", "f1j3", "f2j1", "f2j2", "f3j2", "f3j3"):
        initial[indices[name]] = float(candidate["open_flexion_rad"])
    robot.set_joint_positions(initial.astype(np.float32))
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
    current_targets = {
        "lift_z": float(candidate["approach_lift_m"]),
        "f1j1": float(candidate["open_preshape_rad"]),
        "f1j2": float(candidate["open_flexion_rad"]),
        "f2j1": float(candidate["open_flexion_rad"]),
        "f3j2": float(candidate["open_flexion_rad"]),
    }
    for api in pad_collision_apis:
        api.GetCollisionEnabledAttr().Set(True)
    object_collision.GetCollisionEnabledAttr().Set(True)
    stage_path = output / "G2_INDEPENDENT_CONTACT_STAGE.usda"
    stage.Export(str(stage_path))
    interface = get_physx_simulation_interface()
    dt_s = 1.0 / float(simulation["physics_rate_hz"])
    object_center = np.asarray(geometry["object_world_center_m"], dtype=np.float64)

    trace_fields = [
        "step",
        "phase",
        "phase_step",
        "lift_target_m",
        "lift_position_m",
        *[f"{name}_target_rad" for name in ACTIVE_CONTROL_JOINTS],
        *[f"{name}_position_rad" for name in required],
        *[f"{name}_velocity_rad_s" for name in required],
        *[f"{name}_effort_nm" for name in ROOT_TORQUE_JOINTS],
        *[f"{name}_effort_delta_nm" for name in ROOT_TORQUE_JOINTS],
    ]
    for prefix in FINGER_PREFIX.values():
        trace_fields.extend(
            (
                f"{prefix}_contact_state",
                f"{prefix}_contact_event",
                f"{prefix}_contact_threshold_nm",
                f"{prefix}_normal_force_n",
                f"{prefix}_tangential_force_n",
                f"{prefix}_friction_utilization",
                f"{prefix}_contact_normal_x",
                f"{prefix}_contact_normal_y",
                f"{prefix}_contact_normal_z",
                f"{prefix}_contact_point_x_m",
                f"{prefix}_contact_point_y_m",
                f"{prefix}_contact_point_z_m",
            )
        )
    trace_fields.extend(("all_locked_stable_steps", "step_wall_s"))
    trace_path = output / "G2_INDEPENDENT_CONTACT_TRACE.csv"
    trace_stream = trace_path.open("w", newline="", encoding="utf-8")
    writer = csv.DictWriter(trace_stream, fieldnames=trace_fields)
    writer.writeheader()
    trace_stream.flush()

    first_step_wall_s: float | None = None
    trace_rows: list[dict[str, Any]] = []
    maximum_joint_speed = 0.0
    latches: dict[str, IndependentContactLatch] | None = None
    all_locked_stable = 0
    maximum_all_locked_stable = 0
    maximum_root_delta = np.zeros(3, dtype=np.float64)
    first_contact_diagnostics: dict[str, dict[str, Any] | None] = {
        name: None for name in ACTIVE_PAD_LINKS
    }
    search_measurement_history: list[dict[str, dict[str, Any]]] = []

    def apply_gains() -> None:
        if latches is not None:
            for link_name, joint_name in zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS):
                kps[indices[joint_name]] = float(
                    g2["locked_position_kp"]
                    if latches[link_name].locked
                    else g2["searching_position_kp"]
                )
        controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

    def apply_targets() -> None:
        names = tuple(current_targets)
        robot.apply_action(
            ArticulationAction(
                joint_positions=np.asarray(
                    [current_targets[name] for name in names], dtype=np.float32
                ),
                joint_indices=np.asarray([indices[name] for name in names], dtype=np.int32),
            )
        )

    def sample_contacts() -> dict[str, dict[str, Any]]:
        records = {
            name: {"impulses": [], "normals": [], "points": [], "friction": []}
            for name in ACTIVE_PAD_LINKS
        }
        headers, contacts, friction_anchors = interface.get_full_contact_report()
        for header in headers:
            pair = {
                str(PhysicsSchemaTools.intToSdfPath(header.collider0)),
                str(PhysicsSchemaTools.intToSdfPath(header.collider1)),
            }
            for link_name, pad_path in pad_paths_by_finger.items():
                if object_path not in pair or pad_path not in pair:
                    continue
                start = int(header.contact_data_offset)
                stop = start + int(header.num_contact_data)
                for index in range(start, stop):
                    contact = contacts[index]
                    records[link_name]["impulses"].append(
                        [float(value) for value in contact.impulse]
                    )
                    records[link_name]["normals"].append(
                        [float(value) for value in contact.normal]
                    )
                    records[link_name]["points"].append(
                        [float(value) for value in contact.position]
                    )
                anchor_start = int(getattr(header, "friction_anchors_offset", 0))
                anchor_stop = anchor_start + int(
                    getattr(header, "num_friction_anchors_data", 0)
                )
                for index in range(anchor_start, anchor_stop):
                    records[link_name]["friction"].append(
                        [float(value) for value in friction_anchors[index].impulse]
                    )
        result: dict[str, dict[str, Any]] = {}
        for link_name, values in records.items():
            if not values["impulses"]:
                result[link_name] = {
                    "valid": False,
                    "normal_force_n": 0.0,
                    "tangential_force_n": 0.0,
                    "friction_utilization": 0.0,
                    "contact_normal": None,
                    "contact_point_m": None,
                    "maximum_normal_unit_error": 0.0,
                    "maximum_impulse_reconstruction_error_ns": 0.0,
                }
                continue
            aggregate = aggregate_contact_wrench(
                contact_impulses_ns=values["impulses"],
                contact_normals=values["normals"],
                contact_points_m=values["points"],
                friction_anchor_impulses_ns=values["friction"],
                dt_s=dt_s,
                friction_coefficient=coefficient,
                orient_normals_toward_point_m=object_center,
            ).as_dict()
            aggregate["valid"] = True
            result[link_name] = aggregate
        return result

    def physics_step(
        phase: str, phase_step: int
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, dict[str, Any]], float]:
        nonlocal first_step_wall_s, maximum_joint_speed
        apply_targets()
        started = time.perf_counter()
        world.step(render=bool(run_arguments.gui))
        wall = time.perf_counter() - started
        if first_step_wall_s is None:
            first_step_wall_s = wall
            if wall > float(simulation["first_physics_step_deadline_s"]):
                raise G2GuardError(
                    "G2 first physics step exceeded deadline",
                    {"reason": "FIRST_PHYSICS_STEP_DEADLINE_EXCEEDED", "wall_s": wall},
                )
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts = np.asarray(
            robot.get_measured_joint_efforts(
                joint_indices=np.arange(robot.num_dof, dtype=np.int32)
            ),
            dtype=np.float64,
        )
        if not (
            np.all(np.isfinite(positions))
            and np.all(np.isfinite(velocities))
            and np.all(np.isfinite(efforts))
        ):
            raise G2GuardError(
                "G2 non-finite articulation state",
                {"reason": "NONFINITE_ARTICULATION_STATE", "physics_step": len(trace_rows) + 1},
            )
        speed = max(abs(float(velocities[indices[name]])) for name in HAND_JOINTS)
        maximum_joint_speed = max(maximum_joint_speed, speed)
        if speed > float(g2["maximum_joint_speed_rad_s"]):
            raise G2GuardError(
                "G2 joint speed guard",
                {"reason": "JOINT_SPEED_GUARD", "physics_step": len(trace_rows) + 1, "speed": speed},
            )
        root_efforts = efforts[
            np.asarray([indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32)
        ]
        return positions, velocities, root_efforts, sample_contacts(), wall

    def record(
        *,
        phase: str,
        phase_step: int,
        positions: np.ndarray,
        velocities: np.ndarray,
        root_efforts: np.ndarray,
        measurements: Mapping[str, Mapping[str, Any]],
        wall: float,
        events: Mapping[str, str | None] | None = None,
    ) -> None:
        row: dict[str, Any] = {
            "step": len(trace_rows) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "lift_target_m": current_targets["lift_z"],
            "lift_position_m": float(positions[indices["lift_z"]]),
            "all_locked_stable_steps": all_locked_stable,
            "step_wall_s": wall,
        }
        for name in ACTIVE_CONTROL_JOINTS:
            row[f"{name}_target_rad"] = current_targets[name]
        for name in required:
            row[f"{name}_position_rad"] = float(positions[indices[name]])
            row[f"{name}_velocity_rad_s"] = float(velocities[indices[name]])
        for index, name in enumerate(ROOT_TORQUE_JOINTS):
            row[f"{name}_effort_nm"] = float(root_efforts[index])
            link_name = ACTIVE_PAD_LINKS[index]
            row[f"{name}_effort_delta_nm"] = (
                ""
                if latches is None
                else latches[link_name].effort_delta_nm(float(root_efforts[index]))
            )
        for link_name, measurement in measurements.items():
            prefix = FINGER_PREFIX[link_name]
            row[f"{prefix}_contact_state"] = (
                "NOT_ACTIVE" if latches is None else latches[link_name].state
            )
            row[f"{prefix}_contact_event"] = "" if events is None else events.get(link_name) or ""
            row[f"{prefix}_contact_threshold_nm"] = (
                "" if latches is None else latches[link_name].tare.contact_threshold_nm
            )
            row[f"{prefix}_normal_force_n"] = measurement["normal_force_n"]
            row[f"{prefix}_tangential_force_n"] = measurement["tangential_force_n"]
            row[f"{prefix}_friction_utilization"] = measurement["friction_utilization"]
            normal = measurement["contact_normal"]
            point = measurement["contact_point_m"]
            for component_index, component in enumerate(("x", "y", "z")):
                row[f"{prefix}_contact_normal_{component}"] = (
                    "" if normal is None else float(normal[component_index])
                )
                row[f"{prefix}_contact_point_{component}_m"] = (
                    "" if point is None else float(point[component_index])
                )
        writer.writerow(row)
        trace_stream.flush()
        trace_rows.append(row)

    def execute_open_loop_phase(phase: str, count: int) -> None:
        for index in range(count):
            values = physics_step(phase, index)
            record(
                phase=phase,
                phase_step=index,
                positions=values[0],
                velocities=values[1],
                root_efforts=values[2],
                measurements=values[3],
                wall=values[4],
            )

    try:
        execute_open_loop_phase("INITIAL_HOLD", int(g2["initial_hold_steps"]))
        preclose_steps = int(g2["raised_preclose_steps"])
        for index in range(preclose_steps):
            current_targets["f1j1"] = minimum_jerk(
                float(candidate["open_preshape_rad"]),
                float(candidate["preshape_rad"]),
                index,
                preclose_steps,
            )
            for name, target in zip(ROOT_TORQUE_JOINTS, candidate["preclose_flexion_rad"]):
                current_targets[name] = minimum_jerk(
                    float(candidate["open_flexion_rad"]), float(target), index, preclose_steps
                )
            values = physics_step("RAISED_PRECLOSE", index)
            record(
                phase="RAISED_PRECLOSE",
                phase_step=index,
                positions=values[0], velocities=values[1], root_efforts=values[2],
                measurements=values[3], wall=values[4],
            )
        descend_steps = int(g2["descend_steps"])
        for index in range(descend_steps):
            current_targets["lift_z"] = minimum_jerk(
                float(candidate["approach_lift_m"]), 0.0, index, descend_steps
            )
            values = physics_step("DESCEND_TO_GRASP", index)
            record(
                phase="DESCEND_TO_GRASP",
                phase_step=index,
                positions=values[0], velocities=values[1], root_efforts=values[2],
                measurements=values[3], wall=values[4],
            )

        tare_samples = {name: [] for name in ACTIVE_PAD_LINKS}
        unexpected_tare_contact_steps = 0
        for index in range(int(g2["search_tare_steps"])):
            values = physics_step("PER_FINGER_TARE", index)
            for finger_index, link_name in enumerate(ACTIVE_PAD_LINKS):
                tare_samples[link_name].append(float(values[2][finger_index]))
            if any(measurement["valid"] for measurement in values[3].values()):
                unexpected_tare_contact_steps += 1
            record(
                phase="PER_FINGER_TARE",
                phase_step=index,
                positions=values[0], velocities=values[1], root_efforts=values[2],
                measurements=values[3], wall=values[4],
            )
        latches = {
            link_name: IndependentContactLatch(
                tare=compute_tare_statistics(
                    tare_samples[link_name],
                    minimum_threshold_nm=float(g2["minimum_contact_torque_delta_nm"]),
                    sigma_multiplier=float(g2["tare_sigma_multiplier"]),
                ),
                confirmation_steps=int(g2["contact_confirmation_steps"]),
                loss_threshold_fraction=float(g2["loss_threshold_fraction"]),
                loss_confirmation_steps=int(g2["loss_confirmation_steps"]),
            )
            for link_name in ACTIVE_PAD_LINKS
        }
        apply_gains()
        search_increment = float(g2["search_velocity_rad_s"]) * dt_s
        target_limits = {
            link_name: float(target) + float(g2["maximum_extra_closure_rad"])
            for link_name, target in zip(
                ACTIVE_PAD_LINKS, candidate["finger_flexion_targets_rad"]
            )
        }
        completed_by_proprioception = False
        for index in range(int(g2["maximum_search_steps"])):
            for link_name, joint_name in zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS):
                latch = latches[link_name]
                if latch.locked:
                    current_targets[joint_name] = float(latch.lock_target_rad)
                else:
                    current_targets[joint_name] = min(
                        target_limits[link_name], current_targets[joint_name] + search_increment
                    )
            positions, velocities, root_efforts, measurements, wall = physics_step(
                "INDEPENDENT_CONTACT_SEARCH", index
            )
            events: dict[str, str | None] = {}
            for finger_index, (link_name, joint_name) in enumerate(
                zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS)
            ):
                latch = latches[link_name]
                delta = latch.effort_delta_nm(float(root_efforts[finger_index]))
                maximum_root_delta[finger_index] = max(maximum_root_delta[finger_index], delta)
                if delta > float(g2["maximum_root_torque_delta_nm"]):
                    raise G2GuardError(
                        "G2 root torque diagnostic cap",
                        {
                            "reason": "ROOT_TORQUE_DIAGNOSTIC_CAP",
                            "finger": link_name,
                            "physics_step": len(trace_rows) + 1,
                            "actual_delta_nm": delta,
                            "cap_nm": float(g2["maximum_root_torque_delta_nm"]),
                        },
                    )
                event = latch.update(
                    effort_nm=float(root_efforts[finger_index]),
                    current_target_rad=current_targets[joint_name],
                    actual_position_rad=float(positions[indices[joint_name]]),
                    physics_step=len(trace_rows) + 1,
                )
                events[link_name] = event
                if event == "CONTACT_LOCKED" and first_contact_diagnostics[link_name] is None:
                    first_contact_diagnostics[link_name] = {
                        "physics_step": len(trace_rows) + 1,
                        "target_position_rad": current_targets[joint_name],
                        "actual_position_rad": float(positions[indices[joint_name]]),
                        "root_effort_nm": float(root_efforts[finger_index]),
                        "root_effort_delta_nm": delta,
                        "diagnostic_pad_contact": dict(measurements[link_name]),
                    }
            if any(event is not None for event in events.values()):
                apply_gains()
            all_locked_stable = all_locked_stable + 1 if all(
                latch.locked for latch in latches.values()
            ) else 0
            maximum_all_locked_stable = max(maximum_all_locked_stable, all_locked_stable)
            record(
                phase="INDEPENDENT_CONTACT_SEARCH",
                phase_step=index,
                positions=positions,
                velocities=velocities,
                root_efforts=root_efforts,
                measurements=measurements,
                wall=wall,
                events=events,
            )
            search_measurement_history.append(
                {name: dict(value) for name, value in measurements.items()}
            )
            if all_locked_stable >= int(g2["all_locked_stable_steps"]):
                completed_by_proprioception = True
                break

        stable_required = int(g2["all_locked_stable_steps"])
        final_window = search_measurement_history[-stable_required:]
        diagnostic_pad_pass = len(final_window) == stable_required and all(
            measurement[link_name]["valid"]
            and float(measurement[link_name]["normal_force_n"])
            >= float(g2["minimum_diagnostic_normal_force_n"])
            and float(measurement[link_name]["maximum_normal_unit_error"])
            <= float(g2["maximum_normal_unit_error"])
            and float(measurement[link_name]["maximum_impulse_reconstruction_error_ns"])
            <= float(g2["maximum_impulse_reconstruction_error_ns"])
            for measurement in final_window
            for link_name in ACTIVE_PAD_LINKS
        )
        no_motion_after_lock = True
        for link_name, joint_name in zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS):
            latch = latches[link_name]
            if latch.locked and latch.lock_target_rad is not None:
                no_motion_after_lock = no_motion_after_lock and abs(
                    current_targets[joint_name] - latch.lock_target_rad
                ) <= 1.0e-12
        passed = (
            completed_by_proprioception
            and diagnostic_pad_pass
            and no_motion_after_lock
            and unexpected_tare_contact_steps == 0
            and all(value is not None for value in first_contact_diagnostics.values())
        )
        return {
            "schema": RESULT_SCHEMA,
            "status": "PASS" if passed else "FAIL",
            "classification": (
                "G2_INDEPENDENT_CONTACT_ACQUISITION_PASS"
                if passed
                else "G2_INDEPENDENT_CONTACT_ACQUISITION_FAIL"
            ),
            "goal_id": "G2_INDEPENDENT_CONTACT_ACQUISITION",
            "candidate_id": candidate["candidate_id"],
            "physics_steps": len(trace_rows),
            "first_physics_step_wall_s": first_step_wall_s,
            "maximum_hand_joint_speed_rad_s": maximum_joint_speed,
            "maximum_root_torque_delta_nm": maximum_root_delta.tolist(),
            "maximum_all_locked_stable_steps": maximum_all_locked_stable,
            "completed_by_proprioception": completed_by_proprioception,
            "diagnostic_pad_contact_pass": diagnostic_pad_pass,
            "unexpected_tare_contact_steps": unexpected_tare_contact_steps,
            "no_target_motion_after_final_lock": no_motion_after_lock,
            "per_finger_latch": {
                name: latch.as_dict() for name, latch in latches.items()
            },
            "first_contact": first_contact_diagnostics,
            "final_contact": (
                search_measurement_history[-1] if search_measurement_history else None
            ),
            "search_velocity_rad_s": float(g2["search_velocity_rad_s"]),
            "search_increment_rad_per_step": search_increment,
            "rig": rig,
            "geometry": geometry,
            "dof_names": dof_names,
            "articulation_root": str(root.GetPath()),
            "articulation_root_count": len(roots),
            "pad_primitive_count": 3,
            "tip_collision_count": 0,
            "whole_terminal_convex_hull_count": 0,
            "trace_csv": str(trace_path),
            "stage_usda": str(stage_path),
            "truth_boundary": {
                "contact_latch_inputs": ["root_joint_effort", "joint_position"],
                "contact_truth_role": "POST_STEP_DIAGNOSTIC_ACCEPTANCE_ONLY",
                "contact_truth_changes_motion_commands": False,
                "object_pose_read_count": 0,
                "object_pose_write_after_first_physics_step_count": 0,
                "formal_b_passed": False,
            },
            "formal_b_passed": False,
        }
    finally:
        trace_stream.flush()
        trace_stream.close()


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    if run_arguments.dry_run:
        report = dry_run(run_arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0
    portable = Path(run_arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    output = Path(run_arguments.output_dir).resolve()
    application = None
    exit_code = 1
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": not bool(run_arguments.gui),
                "hide_ui": not bool(run_arguments.gui),
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = run_isaac(run_arguments)
        exit_code = 0 if report.get("status") == "PASS" else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"G2_INDEPENDENT_CONTACT_{type(error).__name__.upper()}",
            "goal_id": "G2_INDEPENDENT_CONTACT_ACQUISITION",
            "error_type": type(error).__name__,
            "error": str(error),
            "runtime_diagnostic": (
                error.diagnostic if isinstance(error, G2GuardError) else None
            ),
            "traceback": traceback.format_exc(),
            "formal_b_passed": False,
        }
        exit_code = 2
    write_json(output / "G2_INDEPENDENT_CONTACT_RESULT.json", report)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
