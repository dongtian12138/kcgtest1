#!/usr/bin/env python3
"""G3: evaluate actual G2 PAD contact geometry and bounded task wrenches offline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import yaml

from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import ACTIVE_PAD_LINKS
from kcg_connector.grasp.b_goal_mode.task_force_closure import (
    build_friction_pyramid,
    circular_contact_metrics,
    evaluate_task_suite,
    radial_alignment_metrics,
    signed_basis_force_closure,
)


REPOSITORY = Path(__file__).resolve().parents[4]
DEFAULT_CONFIG = REPOSITORY / "src/kcg_connector/config/b_goal_mode/b_goal_mode.yaml"
RESULT_SCHEMA = "D38999_B_GOAL_MODE_G3_RESULT_V1"


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--g2-result", required=True)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args(argv)


def load_inputs(config_path: Path, result_path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    result = json.loads(result_path.read_text(encoding="utf-8"))
    if config.get("mode") != "B_GOAL_MODE_AUTONOMOUS":
        raise ValueError("configuration is not B_GOAL_MODE_AUTONOMOUS")
    if result.get("status") != "PASS" or result.get("goal_id") != "G2_INDEPENDENT_CONTACT_ACQUISITION":
        raise ValueError("G3 requires one passing G2 result")
    frozen = config["frozen_boundaries"]
    if [float(value) for value in (
        frozen["first_grip_force_n_per_finger"],
        frozen["nominal_assembly_force_n_per_finger"],
        frozen["adaptive_force_ceiling_n_per_finger"],
        frozen["absolute_force_ceiling_n_per_finger"],
    )] != [8.0, 10.0, 12.0, 15.0]:
        raise ValueError("G3 frozen force ladder changed")
    g3 = config["g3_task_force_closure"]
    if [float(value) for value in g3["normal_force_caps_n_per_finger"]] != [8.0, 10.0, 12.0]:
        raise ValueError("G3 evaluation force caps changed")
    if g3["reference_abort_envelope_is_gate"] is not False:
        raise ValueError("downstream abort reference cannot silently become the G3 gate")
    return config, result


def build_task_wrenches(config: Mapping[str, Any]) -> dict[str, list[float]]:
    g3 = config["g3_task_force_closure"]
    mass = float(config["grasp_geometry"]["object_mass_kg"])
    gravity = float(config["simulation"]["gravity_m_s2"])
    weight = mass * gravity
    lift_load = mass * (gravity + float(g3["lift_acceleration_m_s2"]))
    axial = float(g3["downstream_axial_force_n"])
    lateral = float(g3["lateral_disturbance_n"])
    tilt = float(g3["finite_tilt_moment_nm"])
    torsion = float(g3["finite_torsion_moment_nm"])
    result = {
        "gravity": [0.0, 0.0, -weight, 0.0, 0.0, 0.0],
        "b_lift_acceleration": [0.0, 0.0, -lift_load, 0.0, 0.0, 0.0],
        "downstream_axial_compression": [0.0, 0.0, -(weight + axial), 0.0, 0.0, 0.0],
        "downstream_axial_pull": [0.0, 0.0, axial - weight, 0.0, 0.0, 0.0],
    }
    for axis, label in ((0, "x"), (1, "y")):
        for sign, suffix in ((-1.0, "negative"), (1.0, "positive")):
            wrench = [0.0, 0.0, -weight, 0.0, 0.0, 0.0]
            wrench[axis] = sign * lateral
            result[f"lateral_{label}_{suffix}"] = wrench
            wrench = [0.0, 0.0, -weight, 0.0, 0.0, 0.0]
            wrench[3 + axis] = sign * tilt
            result[f"tilt_{label}_{suffix}"] = wrench
    for sign, suffix in ((-1.0, "negative"), (1.0, "positive")):
        wrench = [0.0, 0.0, -weight, 0.0, 0.0, sign * torsion]
        result[f"torsion_z_{suffix}"] = wrench
    return result


def evaluate(config: Mapping[str, Any], g2: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    g3 = config["g3_task_force_closure"]
    contacts = g2["final_contact"]
    points = [contacts[name]["contact_point_m"] for name in ACTIVE_PAD_LINKS]
    normals = [contacts[name]["contact_normal"] for name in ACTIVE_PAD_LINKS]
    if not all(contacts[name]["valid"] for name in ACTIVE_PAD_LINKS):
        raise ValueError("G3 input contains a missing final PAD contact")
    center = g2["geometry"]["object_world_center_m"]
    coefficient = float(config["grasp_geometry"]["pad_object_friction"])
    pyramid = build_friction_pyramid(
        contact_points_m=points,
        contact_normals=normals,
        center_of_mass_m=center,
        friction_coefficient=coefficient,
        edges_per_contact=int(g3["friction_cone_edges"]),
    )
    circular = circular_contact_metrics(points, center)
    radial = radial_alignment_metrics(
        contact_points_m=points,
        contact_normals=normals,
        connector_axis_center_xy_m=center[:2],
    )
    force_closure = signed_basis_force_closure(
        pyramid,
        characteristic_length_m=float(config["grasp_geometry"]["object_radius_m"]),
        normal_force_cap_n_per_finger=float(g3["maximum_task_evaluation_cap_n"]),
    )
    task_wrenches = build_task_wrenches(config)
    task_results = evaluate_task_suite(
        pyramid,
        task_wrenches=task_wrenches,
        normal_force_caps_n=g3["normal_force_caps_n_per_finger"],
    )

    reference_moment = float(g3["reference_abort_bending_moment_nm"])
    weight = float(config["grasp_geometry"]["object_mass_kg"]) * float(
        config["simulation"]["gravity_m_s2"]
    )
    reference_wrenches: dict[str, list[float]] = {}
    for axis, label in ((3, "x"), (4, "y")):
        for sign, suffix in ((-1.0, "negative"), (1.0, "positive")):
            wrench = [0.0, 0.0, -weight, 0.0, 0.0, 0.0]
            wrench[axis] = sign * reference_moment
            reference_wrenches[f"reference_bending_{label}_{suffix}"] = wrench
    reference_results = evaluate_task_suite(
        pyramid,
        task_wrenches=reference_wrenches,
        normal_force_caps_n=[float(g3["maximum_task_evaluation_cap_n"])],
    )

    gravity_cap_key = f"{float(g3['gravity_safety_evaluation_cap_n']):g}N"
    lift_cap_key = f"{float(g3['lift_safety_evaluation_cap_n']):g}N"
    maximum_cap_key = f"{float(g3['maximum_task_evaluation_cap_n']):g}N"
    gravity_sf = task_results["gravity"]["safety_factor_by_normal_cap"][gravity_cap_key][
        "maximum_scale"
    ]
    lift_sf = task_results["b_lift_acceleration"]["safety_factor_by_normal_cap"][lift_cap_key][
        "maximum_scale"
    ]
    other_names = [name for name in task_results if name not in {"gravity", "b_lift_acceleration"}]
    minimum_other_sf = min(
        task_results[name]["safety_factor_by_normal_cap"][maximum_cap_key]["maximum_scale"]
        for name in other_names
    )
    maximum_required_peak = max(
        float(task_results[name]["minimum_peak_normal_force"]["minimum_peak_normal_force_n"])
        for name in task_results
        if task_results[name]["minimum_peak_normal_force"]["solver_success"]
    )
    reference_minimum_sf = min(
        result["safety_factor_by_normal_cap"][maximum_cap_key]["maximum_scale"]
        for result in reference_results.values()
    )
    gates = {
        "three_pad_contacts": bool(
            g2.get("pad_primitive_count") == 3
            and g2.get("tip_collision_count") == 0
            and g2.get("whole_terminal_convex_hull_count") == 0
        ),
        "circular_distribution": circular["maximum_gap_deg"]
        < float(g3["maximum_circular_gap_deg"]),
        "radial_alignment": radial["minimum_radial_alignment"]
        >= float(g3["minimum_radial_alignment"]),
        "grasp_matrix_rank_six": bool(
            np.linalg.matrix_rank(pyramid.grasp_matrix, tol=1.0e-9) == 6
        ),
        "signed_force_closure": bool(force_closure["force_closure"]),
        "gravity_safety_factor": gravity_sf
        >= float(g3["minimum_gravity_safety_factor"]),
        "b_lift_safety_factor": lift_sf >= float(g3["minimum_lift_safety_factor"]),
        "bounded_other_tasks": minimum_other_sf
        >= float(g3["minimum_other_task_safety_factor"]),
        "maximum_predicted_single_finger_normal": maximum_required_peak
        <= float(g3["maximum_task_evaluation_cap_n"]),
    }
    gws = {
        "schema": "D38999_B_GOAL_MODE_G3_GWS_V1",
        "candidate_id": g2["candidate_id"],
        "contact_points_m": points,
        "contact_normals": normals,
        "center_of_mass_m": center,
        "friction_coefficient": coefficient,
        "friction_cone_edges": int(g3["friction_cone_edges"]),
        "grasp_matrix": pyramid.grasp_matrix.tolist(),
        "grasp_matrix_rank": int(np.linalg.matrix_rank(pyramid.grasp_matrix, tol=1.0e-9)),
        "circular_contact_metrics": circular,
        "radial_alignment_metrics": radial,
        "signed_basis_force_closure": force_closure,
    }
    tws = {
        "schema": "D38999_B_GOAL_MODE_G3_TWS_V1",
        "task_envelope_provenance": g3["task_envelope_provenance"],
        "task_results": task_results,
        "minimum_other_task_safety_factor_at_12n": minimum_other_sf,
        "maximum_required_peak_normal_force_n": maximum_required_peak,
        "reference_abort_envelope": {
            "gate": False,
            "bending_moment_nm": reference_moment,
            "results": reference_results,
            "minimum_safety_factor_at_12n": reference_minimum_sf,
            "qualified": reference_minimum_sf >= 1.0,
            "interpretation": "REPORT_ONLY_FULL_CHAIN_ABORT_REFERENCE_NOT_B_G3_GATE",
        },
    }
    report = {
        "schema": RESULT_SCHEMA,
        "status": "PASS" if all(gates.values()) else "FAIL",
        "classification": (
            "G3_TASK_FORCE_CLOSURE_PASS"
            if all(gates.values())
            else "G3_TASK_FORCE_CLOSURE_FAIL"
        ),
        "goal_id": "G3_TASK_FORCE_CLOSURE",
        "candidate_id": g2["candidate_id"],
        "gates": gates,
        "gravity_safety_factor_at_8n": gravity_sf,
        "b_lift_safety_factor_at_8n": lift_sf,
        "minimum_other_task_safety_factor_at_12n": minimum_other_sf,
        "maximum_required_peak_normal_force_n": maximum_required_peak,
        "reference_abort_bending_minimum_safety_factor_at_12n": reference_minimum_sf,
        "reference_abort_bending_qualified": reference_minimum_sf >= 1.0,
        "reference_abort_envelope_is_gate": False,
        "gws_result": "G3_GRASP_WRENCH_SPACE_RESULTS.json",
        "tws_result": "G3_TASK_WRENCH_SPACE_RESULTS.json",
        "source_g2_result": g2.get("trace_csv"),
        "formal_b_passed": False,
    }
    return report, gws, tws


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    try:
        config, g2 = load_inputs(
            Path(run_arguments.config).resolve(), Path(run_arguments.g2_result).resolve()
        )
        report, gws, tws = evaluate(config, g2)
        exit_code = 0 if report["status"] == "PASS" else 3
    except BaseException as error:
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"G3_TASK_FORCE_CLOSURE_{type(error).__name__.upper()}",
            "goal_id": "G3_TASK_FORCE_CLOSURE",
            "error_type": type(error).__name__,
            "error": str(error),
            "formal_b_passed": False,
        }
        gws = {"schema": "D38999_B_GOAL_MODE_G3_GWS_V1", "status": "UNAVAILABLE"}
        tws = {"schema": "D38999_B_GOAL_MODE_G3_TWS_V1", "status": "UNAVAILABLE"}
        exit_code = 2
    write_json(output / "G3_TASK_FORCE_CLOSURE_RESULT.json", report)
    write_json(output / "G3_GRASP_WRENCH_SPACE_RESULTS.json", gws)
    write_json(output / "G3_TASK_WRENCH_SPACE_RESULTS.json", tws)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
