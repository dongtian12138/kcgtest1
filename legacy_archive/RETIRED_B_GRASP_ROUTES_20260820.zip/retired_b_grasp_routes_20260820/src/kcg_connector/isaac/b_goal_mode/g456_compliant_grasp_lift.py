#!/usr/bin/env python3
"""Shared G4/G5/G6/G7 dynamic chain with proprioceptive finger control."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np

from kcg_connector.grasp.b_goal_mode.bumpless_force_controller import (
    BumplessThreeFingerForceController,
    ForceControlOutput,
)
from kcg_connector.grasp.b_goal_mode.contact_wrench_audit import aggregate_contact_wrench
from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    ACTIVE_PAD_LINKS,
    ROOT_TORQUE_JOINTS,
)
from kcg_connector.grasp.b_goal_mode.independent_contact_latch import (
    IndependentContactLatch,
    compute_tare_statistics,
)
from kcg_connector.grasp.b_goal_mode.lift_axis_controller import minimum_jerk
from kcg_connector.grasp.b_goal_mode.minimal_hand_rig import HAND_JOINTS
from kcg_connector.grasp.b_goal_mode.root_torque_force_calibration import (
    RootTorqueForceFit,
    fit_g1_trace,
    serialize_fits,
)
from kcg_connector.grasp.b_goal_mode.slip_monitor import (
    ProprioceptiveSlipMonitor,
    ProprioceptiveSlipObservation,
)

from g1_contact_wrench_measurement import (
    ACTIVE_CONTROL_JOINTS,
    DEFAULT_CANDIDATES,
    DEFAULT_CONFIG,
    DEFAULT_PAD_CORE,
    DEFAULT_URDF,
    FINGER_PREFIX,
    prepare,
    write_json,
)
from g2_independent_contact_acquisition import load_g2_config


SCENARIO_GOAL = {
    "g4_switch": "G4_BUMPLESS_COMPLIANT_FORCE_CONTROL",
    "g5_hold": "G5_UNSUPPORTED_HOLD",
    "g6_lift": "G6_REAL_LIFT",
    "g7_validation": "G7_THREE_PROCESS_VALIDATION",
    "top3_comparison": "TOP3_DYNAMIC_COMPARISON",
}
RESULT_SCHEMA = "D38999_B_GOAL_MODE_G4567_RESULT_V2"
TOP3_CANDIDATES = {"BG_P120_Z15", "BG_P124_Z15", "BG_P128_Z15"}
SUSTAINED_RHO_FAILURE_STEPS = 12


class RuntimeGuardError(RuntimeError):
    def __init__(self, message: str, diagnostic: Mapping[str, Any]):
        super().__init__(message)
        self.diagnostic = dict(diagnostic)


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=tuple(SCENARIO_GOAL), required=True)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--candidates", default=str(DEFAULT_CANDIDATES))
    parser.add_argument("--pad-core", default=str(DEFAULT_PAD_CORE))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--g1-trace", required=True)
    parser.add_argument("--g2-result")
    parser.add_argument("--prerequisite-result")
    parser.add_argument("--validation-index", type=int, default=0)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gui", action="store_true")
    return parser.parse_args(argv)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_runtime_inputs(run_arguments: argparse.Namespace) -> tuple[
    dict[str, Any], dict[str, Any], dict[str, Any], dict[str, RootTorqueForceFit]
]:
    config = load_g2_config(Path(run_arguments.config).resolve())
    candidate_id = str(config["g4_compliant_force_control"]["seed_candidate_id"])
    if run_arguments.scenario == "top3_comparison":
        if candidate_id not in TOP3_CANDIDATES:
            raise ValueError("top3 comparison is restricted to the frozen top three")
        if config["g7_candidate_search"].get("active_candidate_id") != candidate_id:
            raise ValueError("active candidate differs from comparison candidate")
        g2 = {
            "status": "REEXECUTED_IN_CURRENT_PROCESS",
            "goal_id": "G2_INDEPENDENT_CONTACT_ACQUISITION",
            "candidate_id": candidate_id,
        }
        prerequisite = {
            "status": "PASS",
            "goal_id": "TOP3_OFFLINE_STATIC_PASS",
            "candidate_id": candidate_id,
        }
    else:
        if not run_arguments.g2_result or not run_arguments.prerequisite_result:
            raise ValueError("this scenario requires G2 and prerequisite results")
        g2 = read_json(Path(run_arguments.g2_result).resolve())
        prerequisite = read_json(Path(run_arguments.prerequisite_result).resolve())
        if (
            g2.get("status") != "PASS"
            or g2.get("goal_id") != "G2_INDEPENDENT_CONTACT_ACQUISITION"
        ):
            raise ValueError("compliant chain requires a passing G2 result")
        expected_prerequisite = {
            "g4_switch": "G3_TASK_FORCE_CLOSURE",
            "g5_hold": "G4_BUMPLESS_COMPLIANT_FORCE_CONTROL",
            "g6_lift": "G5_UNSUPPORTED_HOLD",
            "g7_validation": "G6_REAL_LIFT",
        }[run_arguments.scenario]
        if (
            prerequisite.get("status") != "PASS"
            or prerequisite.get("goal_id") != expected_prerequisite
        ):
            raise ValueError(
                f"{run_arguments.scenario} requires passing {expected_prerequisite}, got "
                f"{prerequisite.get('goal_id')}:{prerequisite.get('status')}"
            )
        if g2.get("candidate_id") != candidate_id:
            raise ValueError("G2 candidate differs from G4 candidate")
    if float(config["g4_compliant_force_control"]["first_force_target_n_per_finger"]) != 8.0:
        raise ValueError("first force target must remain 8 N/finger")
    if float(config["g5_unsupported_hold"]["adaptive_force_ceiling_n_per_finger"]) != 12.0:
        raise ValueError("adaptive force ceiling must remain 12 N/finger")
    if float(config["frozen_boundaries"]["absolute_force_ceiling_n_per_finger"]) != 15.0:
        raise ValueError("absolute force ceiling must remain 15 N/finger")
    if run_arguments.scenario == "g7_validation" and run_arguments.validation_index not in (1, 2, 3):
        raise ValueError("G7 validation index must be 1, 2 or 3")
    if run_arguments.scenario != "g7_validation" and run_arguments.validation_index != 0:
        raise ValueError("validation index is only valid for G7 validation")
    fits = fit_g1_trace(Path(run_arguments.g1_trace).resolve())
    return config, g2, prerequisite, fits


def quaternion_angle_rad(first: Sequence[float], second: Sequence[float]) -> float:
    q0 = np.asarray(first, dtype=np.float64)
    q1 = np.asarray(second, dtype=np.float64)
    q0 /= np.linalg.norm(q0)
    q1 /= np.linalg.norm(q1)
    return 2.0 * math.acos(float(np.clip(abs(q0 @ q1), 0.0, 1.0)))


def dry_run(run_arguments: argparse.Namespace) -> dict[str, Any]:
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config, g2, prerequisite, fits = load_runtime_inputs(run_arguments)
    rig, candidate, capsules, geometry, lift_design = prepare(
        config=config,
        candidates_path=Path(run_arguments.candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    report = {
        "schema": RESULT_SCHEMA,
        "status": "DRY_RUN_PASS",
        "goal_id": SCENARIO_GOAL[run_arguments.scenario],
        "scenario": run_arguments.scenario,
        "validation_index": run_arguments.validation_index,
        "candidate_id": candidate["candidate_id"],
        "rig": rig,
        "geometry": geometry,
        "lift_design": lift_design.as_dict(),
        "pad_capsules": capsules,
        "root_torque_force_proxy": serialize_fits(fits),
        "contact_acquisition_reexecuted": True,
        "online_contact_truth_used_by_controller": False,
        "object_pose_write_after_physics_count": 0,
        "prerequisite_goal": prerequisite["goal_id"],
        "source_g2_candidate": g2["candidate_id"],
        "contact_acquisition_evidence_role": (
            "REEXECUTED_IN_CURRENT_PROCESS"
            if run_arguments.scenario == "top3_comparison"
            else "HISTORICAL_PREREQUISITE_AND_REEXECUTED_IN_CURRENT_PROCESS"
        ),
        "formal_b_passed": False,
    }
    write_json(output / "G4567_DRY_RUN_RESULT.json", report)
    return report


def run_isaac(run_arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation, SingleRigidPrim
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    import omni.usd
    from pxr import (
        Gf,
        PhysicsSchemaTools,
        PhysxSchema,
        Sdf,
        Usd,
        UsdGeom,
        UsdPhysics,
        UsdShade,
    )

    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config, g2_evidence, prerequisite, fits = load_runtime_inputs(run_arguments)
    rig, candidate, capsules, geometry, lift_design = prepare(
        config=config,
        candidates_path=Path(run_arguments.candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        output=output,
    )
    write_json(output / "ROOT_TORQUE_FORCE_PROXY.json", serialize_fits(fits))
    g2 = config["g2_independent_contact"]
    g4 = config["g4_compliant_force_control"]
    g5 = config["g5_unsupported_hold"]
    g6 = config["g6_real_lift"]
    simulation = config["simulation"]
    import_dir = output / "rig_usd"
    import_dir.mkdir()
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=rig["temporary_urdf"],
            usd_path=str(import_dir),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    if not imported_path.exists():
        raise RuntimeError(f"URDF import failed: {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(simulation["physics_rate_hz"]),
        rendering_dt=1.0 / float(simulation["rendering_rate_hz"]),
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/GoalModeRig")
    roots = [prim for prim in stage.Traverse() if prim.HasAPI(UsdPhysics.ArticulationRootAPI)]
    if len(roots) != 1:
        raise RuntimeError(f"expected one articulation root, got {[str(p.GetPath()) for p in roots]}")
    root = roots[0]
    source_collisions = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if source_collisions:
        raise RuntimeError(f"forbidden source collisions imported: {source_collisions}")
    scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(scenes) != 1:
        raise RuntimeError(f"expected one physics scene, got {len(scenes)}")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(-float(simulation["gravity_m_s2"]))

    UsdGeom.Scope.Define(stage, "/World/PhysicsMaterials")

    def material(path: str, coefficient: float) -> Any:
        value = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(value.GetPrim())
        api.CreateStaticFrictionAttr(coefficient)
        api.CreateDynamicFrictionAttr(coefficient)
        api.CreateRestitutionAttr(0.0)
        return value

    mu = float(config["grasp_geometry"]["pad_object_friction"])
    pad_material = material("/World/PhysicsMaterials/PAD", mu)
    object_material = material("/World/PhysicsMaterials/OBJECT", mu)
    pad_paths: dict[str, str] = {}
    pad_collision_apis: list[Any] = []
    for link_name in ACTIVE_PAD_LINKS:
        matches = [
            prim
            for prim in stage.Traverse()
            if prim.GetName() == link_name and prim.HasAPI(UsdPhysics.RigidBodyAPI)
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one terminal prim for {link_name}, got {len(matches)}")
        terminal = matches[0]
        if terminal.IsInstance():
            terminal.SetInstanceable(False)
            terminal = stage.GetPrimAtPath(terminal.GetPath())
        PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
        capsule = capsules[link_name]
        path = str(terminal.GetPath()) + "/PAD_CORE_CAPSULE"
        shape = UsdGeom.Capsule.Define(stage, path)
        shape.CreateAxisAttr(UsdGeom.Tokens.z)
        shape.CreateRadiusAttr(float(capsule["radius_m"]))
        shape.CreateHeightAttr(float(capsule["cylinder_height_m"]))
        xform = UsdGeom.Xformable(shape)
        xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
        rotation = Gf.Rotation(
            Gf.Vec3d(0.0, 0.0, 1.0), Gf.Vec3d(*capsule["axis_unit_local"])
        )
        xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
        collision = UsdPhysics.CollisionAPI.Apply(shape.GetPrim())
        collision.CreateCollisionEnabledAttr(False)
        pad_collision_apis.append(collision)
        contact_api = PhysxSchema.PhysxCollisionAPI.Apply(shape.GetPrim())
        contact_api.CreateContactOffsetAttr(float(config["grasp_geometry"]["contact_offset_m"]))
        contact_api.CreateRestOffsetAttr(float(config["grasp_geometry"]["rest_offset_m"]))
        UsdShade.MaterialBindingAPI(shape.GetPrim()).Bind(pad_material, materialPurpose="physics")
        shape.GetPrim().CreateAttribute("kcg:collisionRole", Sdf.ValueTypeNames.Token).Set(
            "PAD_CONTACT_SURFACE_PROXY"
        )
        pad_paths[link_name] = path

    object_path = "/World/GoalModeConnector"
    obj = UsdGeom.Cylinder.Define(stage, object_path)
    obj.CreateAxisAttr(UsdGeom.Tokens.z)
    obj.CreateRadiusAttr(float(config["grasp_geometry"]["object_radius_m"]))
    obj.CreateHeightAttr(float(config["grasp_geometry"]["object_height_m"]))
    UsdGeom.Xformable(obj).AddTranslateOp().Set(Gf.Vec3d(*geometry["object_world_center_m"]))
    object_collision = UsdPhysics.CollisionAPI.Apply(obj.GetPrim())
    object_collision.CreateCollisionEnabledAttr(False)
    object_rigid = UsdPhysics.RigidBodyAPI.Apply(obj.GetPrim())
    object_rigid.CreateRigidBodyEnabledAttr(True)
    object_rigid.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(obj.GetPrim()).CreateMassAttr(
        float(config["grasp_geometry"]["object_mass_kg"])
    )
    object_contact = PhysxSchema.PhysxCollisionAPI.Apply(obj.GetPrim())
    object_contact.CreateContactOffsetAttr(float(config["grasp_geometry"]["contact_offset_m"]))
    object_contact.CreateRestOffsetAttr(float(config["grasp_geometry"]["rest_offset_m"]))
    UsdShade.MaterialBindingAPI(obj.GetPrim()).Bind(object_material, materialPurpose="physics")
    PhysxSchema.PhysxContactReportAPI.Apply(obj.GetPrim()).CreateThresholdAttr().Set(0.0)

    robot = world.scene.add(SingleArticulation(prim_path=str(root.GetPath()), name="goal_mode_hand"))
    world.reset()
    # A kinematic rigid body must not be registered with Scene before reset:
    # RigidPrim.post_reset() writes linear/angular velocity, which PhysX rejects
    # for kinematic actors.  We only need a read-only pose view, so initialize it
    # after reset and never include it in the Scene reset lifecycle.
    object_view = SingleRigidPrim(prim_path=object_path, name="goal_mode_object")
    object_view.initialize()
    required = ("lift_z",) + HAND_JOINTS
    dof_names = list(robot.dof_names)
    missing = [name for name in required if name not in dof_names]
    if missing:
        raise RuntimeError(f"articulation missing DOFs: {missing}; got {dof_names}")
    indices = {name: dof_names.index(name) for name in required}
    controller = robot.get_articulation_controller()
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[indices["lift_z"]] = float(lift_design.kp_n_per_m)
    kds[indices["lift_z"]] = float(lift_design.kd_n_s_per_m)
    for name in ACTIVE_CONTROL_JOINTS:
        kps[indices[name]] = float(g2["searching_position_kp"])
        kds[indices[name]] = float(g4["position_kd"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)
    controller.set_max_efforts(
        np.asarray([lift_design.maximum_drive_force_n], dtype=np.float32),
        joint_indices=np.asarray([indices["lift_z"]], dtype=np.int32),
    )

    initial = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initial[indices["lift_z"]] = float(candidate["approach_lift_m"])
    initial[indices["f1j1"]] = float(candidate["open_preshape_rad"])
    initial[indices["f3j1"]] = float(candidate["open_preshape_rad"])
    for name in ("f1j2", "f1j3", "f2j1", "f2j2", "f3j2", "f3j3"):
        initial[indices[name]] = float(candidate["open_flexion_rad"])
    robot.set_joint_positions(initial.astype(np.float32))
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
    current_targets = {
        "lift_z": float(candidate["approach_lift_m"]),
        "f1j1": float(candidate["open_preshape_rad"]),
        "f1j2": float(candidate["open_flexion_rad"]),
        "f2j1": float(candidate["open_flexion_rad"]),
        "f3j2": float(candidate["open_flexion_rad"]),
    }
    for api in pad_collision_apis:
        api.GetCollisionEnabledAttr().Set(True)
    object_collision.GetCollisionEnabledAttr().Set(True)
    stage_path = output / "G4567_STAGE.usda"
    stage.Export(str(stage_path))

    interface = get_physx_simulation_interface()
    dt_s = 1.0 / float(simulation["physics_rate_hz"])
    object_center = np.asarray(geometry["object_world_center_m"], dtype=np.float64)
    trace_fields = [
        "step", "phase", "phase_step", "lift_target_m", "lift_position_m",
        "lift_velocity_m_s", "object_x_m", "object_y_m", "object_z_m",
        "relative_axial_slip_m", "relative_rotation_rad", "force_target_level_n",
        "all_locked_stable_steps", "force_stable_steps", "adaptive_event", "step_wall_s",
        "slip_monitor_armed", "slip_confirmation_count", "adaptive_stabilization_count",
        "force_bias_shift_n", "maximum_velocity_excess_rad_s", "slip_precursor_reasons",
        "rho_above_one_consecutive_max",
    ]
    for name in ROOT_TORQUE_JOINTS:
        trace_fields.extend(
            (f"{name}_target_rad", f"{name}_position_rad", f"{name}_velocity_rad_s", f"{name}_effort_nm", f"{name}_effort_delta_nm")
        )
    for prefix in FINGER_PREFIX.values():
        trace_fields.extend(
            (
                f"{prefix}_contact_state", f"{prefix}_desired_force_n",
                f"{prefix}_estimated_force_n", f"{prefix}_diagnostic_normal_force_n",
                f"{prefix}_diagnostic_tangential_force_n", f"{prefix}_friction_utilization",
                f"{prefix}_rho_above_one_consecutive",
                f"{prefix}_contact_normal_x", f"{prefix}_contact_normal_y",
                f"{prefix}_contact_normal_z", f"{prefix}_contact_point_x_m",
                f"{prefix}_contact_point_y_m", f"{prefix}_contact_point_z_m",
                f"{prefix}_controller_offset_rad", f"{prefix}_controller_differential_error_n",
            )
        )
    trace_fields.extend(
        ("controller_common_error_n", "controller_first_step_frozen", "controller_rate_limit", "controller_cumulative_limit")
    )
    trace_path = output / "G4567_TRACE.csv"
    trace_stream = trace_path.open("w", newline="", encoding="utf-8")
    writer = csv.DictWriter(trace_stream, fieldnames=trace_fields)
    writer.writeheader()
    trace_stream.flush()

    trace_rows: list[dict[str, Any]] = []
    first_step_wall_s: float | None = None
    maximum_joint_speed = 0.0
    maximum_estimated_force = np.zeros(3, dtype=np.float64)
    maximum_diagnostic_force = np.zeros(3, dtype=np.float64)
    maximum_rho = np.zeros(3, dtype=np.float64)
    rho_above_one_consecutive = np.zeros(3, dtype=np.int64)
    maximum_rho_above_one_consecutive = np.zeros(3, dtype=np.int64)
    contact_loss_steps = np.zeros(3, dtype=np.int64)
    latches: dict[str, IndependentContactLatch] | None = None
    force_control: BumplessThreeFingerForceController | None = None
    controller_output: ForceControlOutput | None = None
    force_target_level = 0.0
    all_locked_stable = 0
    force_stable_steps = 0
    release_reference: dict[str, Any] | None = None
    maximum_axial_slip = 0.0
    maximum_relative_rotation = 0.0
    adaptive_events: list[dict[str, Any]] = []
    slip_monitor: ProprioceptiveSlipMonitor | None = None
    slip_observation: ProprioceptiveSlipObservation | None = None
    first_contact: dict[str, dict[str, Any] | None] = {
        name: None for name in ACTIVE_PAD_LINKS
    }

    def apply_gains() -> None:
        for link_name, joint_name in zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS):
            locked = latches is not None and latches[link_name].locked
            kps[indices[joint_name]] = float(
                g4["contact_position_kp"] if locked else g2["searching_position_kp"]
            )
        controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

    def apply_targets() -> None:
        names = tuple(current_targets)
        robot.apply_action(
            ArticulationAction(
                joint_positions=np.asarray([current_targets[name] for name in names], dtype=np.float32),
                joint_indices=np.asarray([indices[name] for name in names], dtype=np.int32),
            )
        )

    def sample_contacts() -> dict[str, dict[str, Any]]:
        raw = {
            name: {"impulses": [], "normals": [], "points": [], "friction": []}
            for name in ACTIVE_PAD_LINKS
        }
        headers, contacts, friction = interface.get_full_contact_report()
        for header in headers:
            pair = {
                str(PhysicsSchemaTools.intToSdfPath(header.collider0)),
                str(PhysicsSchemaTools.intToSdfPath(header.collider1)),
            }
            for link_name, pad_path in pad_paths.items():
                if object_path not in pair or pad_path not in pair:
                    continue
                start = int(header.contact_data_offset)
                stop = start + int(header.num_contact_data)
                for index in range(start, stop):
                    contact = contacts[index]
                    raw[link_name]["impulses"].append([float(value) for value in contact.impulse])
                    raw[link_name]["normals"].append([float(value) for value in contact.normal])
                    raw[link_name]["points"].append([float(value) for value in contact.position])
                anchor_start = int(getattr(header, "friction_anchors_offset", 0))
                anchor_stop = anchor_start + int(getattr(header, "num_friction_anchors_data", 0))
                for index in range(anchor_start, anchor_stop):
                    raw[link_name]["friction"].append([float(value) for value in friction[index].impulse])
        measured: dict[str, dict[str, Any]] = {}
        for link_name, values in raw.items():
            if not values["impulses"]:
                measured[link_name] = {
                    "valid": False, "normal_force_n": 0.0, "tangential_force_n": 0.0,
                    "friction_utilization": 0.0, "contact_normal": None, "contact_point_m": None,
                }
            else:
                aggregate = aggregate_contact_wrench(
                    contact_impulses_ns=values["impulses"],
                    contact_normals=values["normals"],
                    contact_points_m=values["points"],
                    friction_anchor_impulses_ns=values["friction"],
                    dt_s=dt_s,
                    friction_coefficient=mu,
                    orient_normals_toward_point_m=object_center,
                ).as_dict()
                aggregate["valid"] = True
                measured[link_name] = aggregate
        return measured

    def estimate_forces(root_efforts: np.ndarray) -> np.ndarray:
        if latches is None:
            return np.zeros(3, dtype=np.float64)
        return np.asarray(
            [
                fits[link_name].estimate_normal_force_n(
                    latches[link_name].effort_delta_nm(float(root_efforts[index]))
                )
                for index, link_name in enumerate(ACTIVE_PAD_LINKS)
            ],
            dtype=np.float64,
        )

    def object_diagnostics(lift_position: float) -> dict[str, Any]:
        nonlocal maximum_axial_slip, maximum_relative_rotation
        if release_reference is None:
            return {"position": None, "slip": None, "rotation": None}
        position_raw, orientation_raw = object_view.get_world_pose()
        position = np.asarray(position_raw, dtype=np.float64)
        orientation = np.asarray(orientation_raw, dtype=np.float64)
        slip = float(
            (position[2] - release_reference["object_position"][2])
            - (lift_position - release_reference["lift_position"])
        )
        rotation = quaternion_angle_rad(release_reference["object_orientation"], orientation)
        maximum_axial_slip = max(maximum_axial_slip, abs(slip))
        maximum_relative_rotation = max(maximum_relative_rotation, rotation)
        return {"position": position, "slip": slip, "rotation": rotation}

    def physics_step(
        phase: str,
        phase_step: int,
        *,
        adaptive_event: str = "",
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, dict[str, Any]], np.ndarray, dict[str, Any]]:
        nonlocal first_step_wall_s, maximum_joint_speed
        apply_targets()
        started = time.perf_counter()
        world.step(render=bool(run_arguments.gui))
        wall = time.perf_counter() - started
        if first_step_wall_s is None:
            first_step_wall_s = wall
            if wall > float(simulation["first_physics_step_deadline_s"]):
                raise RuntimeGuardError("first physics step deadline", {"reason": "FIRST_PHYSICS_STEP_DEADLINE_EXCEEDED", "wall_s": wall})
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts = np.asarray(
            robot.get_measured_joint_efforts(joint_indices=np.arange(robot.num_dof, dtype=np.int32)),
            dtype=np.float64,
        )
        if not (np.all(np.isfinite(positions)) and np.all(np.isfinite(velocities)) and np.all(np.isfinite(efforts))):
            raise RuntimeGuardError("non-finite articulation", {"reason": "NONFINITE_ARTICULATION_STATE", "step": len(trace_rows) + 1})
        speed = max(abs(float(velocities[indices[name]])) for name in HAND_JOINTS)
        maximum_joint_speed = max(maximum_joint_speed, speed)
        if speed > float(g4["maximum_joint_speed_rad_s"]):
            raise RuntimeGuardError("joint speed guard", {"reason": "JOINT_SPEED_GUARD", "step": len(trace_rows) + 1, "speed": speed})
        root_efforts = efforts[np.asarray([indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32)]
        measurements = sample_contacts()
        estimated = estimate_forces(root_efforts)
        maximum_estimated_force[:] = np.maximum(maximum_estimated_force, estimated)
        diagnostic = np.asarray([measurements[name]["normal_force_n"] for name in ACTIVE_PAD_LINKS], dtype=np.float64)
        rhos = np.asarray([measurements[name]["friction_utilization"] for name in ACTIVE_PAD_LINKS], dtype=np.float64)
        maximum_diagnostic_force[:] = np.maximum(maximum_diagnostic_force, diagnostic)
        maximum_rho[:] = np.maximum(maximum_rho, rhos)
        if release_reference is not None:
            rho_above_one_consecutive[:] = np.where(
                rhos > 1.0, rho_above_one_consecutive + 1, 0
            )
            maximum_rho_above_one_consecutive[:] = np.maximum(
                maximum_rho_above_one_consecutive, rho_above_one_consecutive
            )
        contact_loss_steps[:] += np.asarray([0 if measurements[name]["valid"] else 1 for name in ACTIVE_PAD_LINKS], dtype=np.int64)
        if np.any(estimated > float(g4["maximum_estimated_force_n_per_finger"])):
            raise RuntimeGuardError("estimated force ceiling", {"reason": "ESTIMATED_FORCE_CEILING", "step": len(trace_rows) + 1, "force_n": estimated.tolist()})
        if np.any(diagnostic > float(g4["maximum_diagnostic_force_n_per_finger"])):
            raise RuntimeGuardError("diagnostic force ceiling", {"reason": "DIAGNOSTIC_FORCE_CEILING", "step": len(trace_rows) + 1, "force_n": diagnostic.tolist()})
        pose = object_diagnostics(float(positions[indices["lift_z"]]))
        row: dict[str, Any] = {
            "step": len(trace_rows) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "lift_target_m": current_targets["lift_z"],
            "lift_position_m": float(positions[indices["lift_z"]]),
            "lift_velocity_m_s": float(velocities[indices["lift_z"]]),
            "object_x_m": "" if pose["position"] is None else float(pose["position"][0]),
            "object_y_m": "" if pose["position"] is None else float(pose["position"][1]),
            "object_z_m": "" if pose["position"] is None else float(pose["position"][2]),
            "relative_axial_slip_m": "" if pose["slip"] is None else pose["slip"],
            "relative_rotation_rad": "" if pose["rotation"] is None else pose["rotation"],
            "force_target_level_n": force_target_level,
            "all_locked_stable_steps": all_locked_stable,
            "force_stable_steps": force_stable_steps,
            "adaptive_event": adaptive_event,
            "step_wall_s": wall,
            "slip_monitor_armed": "" if slip_observation is None else slip_observation.armed,
            "slip_confirmation_count": "" if slip_observation is None else slip_observation.confirmation_count,
            "adaptive_stabilization_count": "" if slip_observation is None else slip_observation.stabilization_count,
            "force_bias_shift_n": "" if slip_observation is None else slip_observation.force_bias_shift_n,
            "maximum_velocity_excess_rad_s": "" if slip_observation is None else slip_observation.maximum_velocity_excess_rad_s,
            "slip_precursor_reasons": "" if slip_observation is None else "|".join(slip_observation.reasons),
            "rho_above_one_consecutive_max": int(
                np.max(maximum_rho_above_one_consecutive)
            ),
            "controller_common_error_n": "" if controller_output is None else controller_output.common_error_n,
            "controller_first_step_frozen": "" if controller_output is None else controller_output.first_step_integrator_frozen,
            "controller_rate_limit": "" if controller_output is None else controller_output.rate_limit_active,
            "controller_cumulative_limit": "" if controller_output is None else controller_output.cumulative_limit_active,
        }
        for index, (link_name, joint_name) in enumerate(zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS)):
            prefix = FINGER_PREFIX[link_name]
            row[f"{joint_name}_target_rad"] = current_targets[joint_name]
            row[f"{joint_name}_position_rad"] = float(positions[indices[joint_name]])
            row[f"{joint_name}_velocity_rad_s"] = float(velocities[indices[joint_name]])
            row[f"{joint_name}_effort_nm"] = float(root_efforts[index])
            row[f"{joint_name}_effort_delta_nm"] = "" if latches is None else latches[link_name].effort_delta_nm(float(root_efforts[index]))
            row[f"{prefix}_contact_state"] = "NOT_ACTIVE" if latches is None else latches[link_name].state
            row[f"{prefix}_desired_force_n"] = "" if controller_output is None else controller_output.desired_force_n[index]
            row[f"{prefix}_estimated_force_n"] = estimated[index]
            row[f"{prefix}_diagnostic_normal_force_n"] = diagnostic[index]
            row[f"{prefix}_diagnostic_tangential_force_n"] = measurements[link_name]["tangential_force_n"]
            row[f"{prefix}_friction_utilization"] = rhos[index]
            row[f"{prefix}_rho_above_one_consecutive"] = int(
                rho_above_one_consecutive[index]
            )
            normal = measurements[link_name]["contact_normal"]
            point = measurements[link_name]["contact_point_m"]
            for component_index, component in enumerate(("x", "y", "z")):
                row[f"{prefix}_contact_normal_{component}"] = "" if normal is None else normal[component_index]
                row[f"{prefix}_contact_point_{component}_m"] = "" if point is None else point[component_index]
            row[f"{prefix}_controller_offset_rad"] = "" if controller_output is None else controller_output.cumulative_offset_rad[index]
            row[f"{prefix}_controller_differential_error_n"] = "" if controller_output is None else controller_output.differential_error_n[index]
        writer.writerow(row)
        trace_stream.flush()
        trace_rows.append(row)
        return positions, velocities, root_efforts, measurements, estimated, pose

    def open_loop_phase(name: str, steps: int) -> None:
        for index in range(steps):
            physics_step(name, index)

    def force_step(
        name: str,
        index: int,
        desired: np.ndarray,
        previous_efforts: np.ndarray,
        *,
        adaptive_event: str = "",
    ) -> tuple[Any, ...]:
        nonlocal controller_output
        assert force_control is not None
        estimated_input = estimate_forces(previous_efforts)
        controller_output = force_control.update(
            desired_force_n=desired,
            estimated_force_n=estimated_input,
            dt_s=dt_s,
        )
        for joint_name, target in zip(ROOT_TORQUE_JOINTS, controller_output.target_positions_rad):
            current_targets[joint_name] = target
        return physics_step(name, index, adaptive_event=adaptive_event)

    def base_result(status: str, classification: str) -> dict[str, Any]:
        return {
            "schema": RESULT_SCHEMA,
            "status": status,
            "classification": classification,
            "goal_id": SCENARIO_GOAL[run_arguments.scenario],
            "scenario": run_arguments.scenario,
            "validation_index": run_arguments.validation_index,
            "candidate_id": candidate["candidate_id"],
            "physics_steps": len(trace_rows),
            "first_physics_step_wall_s": first_step_wall_s,
            "maximum_hand_joint_speed_rad_s": maximum_joint_speed,
            "maximum_estimated_force_n": maximum_estimated_force.tolist(),
            "maximum_diagnostic_force_n": maximum_diagnostic_force.tolist(),
            "maximum_friction_utilization": maximum_rho.tolist(),
            "maximum_consecutive_rho_above_one_steps": (
                maximum_rho_above_one_consecutive.tolist()
            ),
            "contact_loss_steps": contact_loss_steps.tolist(),
            "maximum_axial_slip_m": maximum_axial_slip,
            "maximum_relative_rotation_rad": maximum_relative_rotation,
            "adaptive_events": adaptive_events,
            "proprioceptive_slip_monitor": None if slip_monitor is None else slip_monitor.state(),
            "first_contact": first_contact,
            "root_torque_force_proxy": serialize_fits(fits),
            "force_controller": None if force_control is None else force_control.state(),
            "rig": rig,
            "lift_design": lift_design.as_dict(),
            "trace_csv": str(trace_path),
            "stage_usda": str(stage_path),
            "pad_primitive_count": 3,
            "tip_collision_count": 0,
            "whole_terminal_convex_hull_count": 0,
            "table_present": False,
            "truth_boundary": {
                "online_force_estimate_inputs": ["root_joint_effort", "joint_position", "joint_velocity"],
                "physx_contact_role": "POST_STEP_DIAGNOSTIC_AND_ABSOLUTE_FORCE_SAFETY_ONLY",
                "physx_contact_changes_nominal_force_command": False,
                "object_pose_role": "POST_RELEASE_DIAGNOSTIC_ONLY",
                "object_pose_changes_commands": False,
                "object_pose_write_after_first_physics_step_count": 0,
            },
            "formal_b_passed": False,
        }

    try:
        open_loop_phase("INITIAL_HOLD", int(g4["initial_hold_steps"]))
        preclose_steps = int(g4["raised_preclose_steps"])
        for index in range(preclose_steps):
            current_targets["f1j1"] = minimum_jerk(
                float(candidate["open_preshape_rad"]), float(candidate["preshape_rad"]), index, preclose_steps
            )
            for joint_name, target in zip(ROOT_TORQUE_JOINTS, candidate["preclose_flexion_rad"]):
                current_targets[joint_name] = minimum_jerk(
                    float(candidate["open_flexion_rad"]), float(target), index, preclose_steps
                )
            physics_step("RAISED_PRECLOSE", index)
        descend_steps = int(g4["descend_steps"])
        for index in range(descend_steps):
            current_targets["lift_z"] = minimum_jerk(
                float(candidate["approach_lift_m"]), 0.0, index, descend_steps
            )
            physics_step("DESCEND_TO_GRASP", index)

        tare_samples = {name: [] for name in ACTIVE_PAD_LINKS}
        tare_contact_steps = 0
        for index in range(int(g4["search_tare_steps"])):
            values = physics_step("PER_FINGER_TARE", index)
            for finger_index, link_name in enumerate(ACTIVE_PAD_LINKS):
                tare_samples[link_name].append(float(values[2][finger_index]))
            if any(measurement["valid"] for measurement in values[3].values()):
                tare_contact_steps += 1
        if tare_contact_steps:
            return base_result("FAIL", "PRECONTACT_TARE_CONTAMINATED")
        latches = {
            name: IndependentContactLatch(
                tare=compute_tare_statistics(
                    tare_samples[name],
                    minimum_threshold_nm=float(g2["minimum_contact_torque_delta_nm"]),
                    sigma_multiplier=float(g2["tare_sigma_multiplier"]),
                ),
                confirmation_steps=int(g2["contact_confirmation_steps"]),
                loss_threshold_fraction=float(g2["loss_threshold_fraction"]),
                loss_confirmation_steps=int(g2["loss_confirmation_steps"]),
            )
            for name in ACTIVE_PAD_LINKS
        }
        apply_gains()
        increment = float(g4["contact_replay_velocity_rad_s"]) * dt_s
        limits = {
            name: float(target) + float(g2["maximum_extra_closure_rad"])
            for name, target in zip(ACTIVE_PAD_LINKS, candidate["finger_flexion_targets_rad"])
        }
        search_complete = False
        last_values: tuple[Any, ...] | None = None
        for index in range(int(g2["maximum_search_steps"])):
            for name, joint_name in zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS):
                latch = latches[name]
                current_targets[joint_name] = (
                    float(latch.lock_target_rad)
                    if latch.locked
                    else min(limits[name], current_targets[joint_name] + increment)
                )
            values = physics_step("INDEPENDENT_CONTACT_SEARCH", index)
            events = False
            for finger_index, (name, joint_name) in enumerate(zip(ACTIVE_PAD_LINKS, ROOT_TORQUE_JOINTS)):
                event = latches[name].update(
                    effort_nm=float(values[2][finger_index]),
                    current_target_rad=current_targets[joint_name],
                    actual_position_rad=float(values[0][indices[joint_name]]),
                    physics_step=len(trace_rows),
                )
                events = events or event is not None
                if event == "CONTACT_LOCKED" and first_contact[name] is None:
                    first_contact[name] = {
                        "physics_step": len(trace_rows),
                        "target_position_rad": current_targets[joint_name],
                        "actual_position_rad": float(values[0][indices[joint_name]]),
                        "root_effort_delta_nm": latches[name].effort_delta_nm(float(values[2][finger_index])),
                        "diagnostic_contact": dict(values[3][name]),
                    }
            if events:
                apply_gains()
            all_locked_stable = all_locked_stable + 1 if all(latch.locked for latch in latches.values()) else 0
            last_values = values
            if all_locked_stable >= int(g2["all_locked_stable_steps"]):
                search_complete = True
                break
        if not search_complete or last_values is None:
            return base_result("FAIL", "INDEPENDENT_CONTACT_ACQUISITION_FAIL")
        for index in range(int(g4["contact_settle_steps"])):
            last_values = physics_step("CONTACT_LOCKED_SETTLE", index)
        if not all(last_values[3][name]["valid"] for name in ACTIVE_PAD_LINKS):
            return base_result("FAIL", "PAD_CONTACT_LOST_BEFORE_SWITCH")

        equilibrium_targets = [current_targets[name] for name in ROOT_TORQUE_JOINTS]
        equilibrium_actual = [float(last_values[0][indices[name]]) for name in ROOT_TORQUE_JOINTS]
        equilibrium_efforts = np.asarray(last_values[2], dtype=np.float64)
        equilibrium_estimated = estimate_forces(equilibrium_efforts)
        equilibrium_diagnostic = [last_values[3][name]["normal_force_n"] for name in ACTIVE_PAD_LINKS]
        switch_snapshot = {
            "target_positions_rad": equilibrium_targets,
            "actual_positions_rad": equilibrium_actual,
            "root_efforts_nm": equilibrium_efforts.tolist(),
            "estimated_normal_force_n": equilibrium_estimated.tolist(),
            "diagnostic_normal_force_n": equilibrium_diagnostic,
        }
        force_control = BumplessThreeFingerForceController(
            equilibrium_target_positions_rad=equilibrium_targets,
            common_rate_gain_rad_s_per_n=float(g4["common_rate_gain_rad_s_per_n"]),
            differential_rate_gain_rad_s_per_n=float(g4["differential_rate_gain_rad_s_per_n"]),
            maximum_offset_rate_rad_s=float(g4["maximum_offset_rate_rad_s"]),
            maximum_target_step_rad=float(g4["maximum_target_step_rad"]),
            minimum_cumulative_offset_rad=float(g4["minimum_cumulative_offset_rad"]),
            maximum_cumulative_offset_rad=float(g4["maximum_cumulative_offset_rad"]),
        )
        force_target_level = float(np.mean(equilibrium_estimated))
        previous_efforts = equilibrium_efforts
        first_target_before = np.asarray(equilibrium_targets, dtype=np.float64)
        first_output: ForceControlOutput | None = None
        ramp_steps = int(g4["force_ramp_steps"])
        first_targets = equilibrium_estimated.copy()
        target_force = float(g4["first_force_target_n_per_finger"])
        for index in range(ramp_steps):
            desired = np.asarray(
                [minimum_jerk(float(value), target_force, index, ramp_steps) for value in first_targets],
                dtype=np.float64,
            )
            force_target_level = float(np.mean(desired))
            values = force_step("FORCE_TARGET_RAMP", index, desired, previous_efforts)
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            if first_output is None:
                first_output = controller_output
        assert first_output is not None
        first_target_jump = float(
            np.max(np.abs(np.asarray(first_output.target_positions_rad) - first_target_before))
        )
        stable_window: list[dict[str, Any]] = []
        proprioception_window: list[dict[str, Any]] = []
        force_stable_steps = 0
        for index in range(int(g4["force_settle_steps"])):
            desired = np.full(3, target_force, dtype=np.float64)
            force_target_level = target_force
            values = force_step("FORCE_TARGET_SETTLE", index, desired, previous_efforts)
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            diagnostic = np.asarray([values[3][name]["normal_force_n"] for name in ACTIVE_PAD_LINKS])
            estimated = np.asarray(values[4])
            stable = bool(
                np.all(np.abs(estimated - target_force) <= float(g4["stable_estimated_force_tolerance_n"]))
                and np.all(np.abs(diagnostic - target_force) <= float(g4["stable_diagnostic_force_tolerance_n"]))
                and all(values[3][name]["valid"] for name in ACTIVE_PAD_LINKS)
            )
            force_stable_steps = force_stable_steps + 1 if stable else 0
            stable_window.append({"estimated": estimated.tolist(), "diagnostic": diagnostic.tolist(), "stable": stable})
            proprioception_window.append(
                {
                    "estimated": estimated.tolist(),
                    "root_velocity_rad_s": [
                        float(values[1][indices[name]]) for name in ROOT_TORQUE_JOINTS
                    ],
                }
            )
        g4_pass = bool(
            first_output.first_step_integrator_frozen
            and force_stable_steps >= int(g4["stable_force_steps"])
            and all(latch.locked for latch in latches.values())
            and np.all(maximum_estimated_force <= 15.0)
            and np.all(maximum_diagnostic_force <= 15.0)
        )
        g4_evidence = {
            "switch_snapshot": switch_snapshot,
            "first_controller_output": first_output.as_dict(),
            "first_target_jump_rad": first_target_jump,
            "first_target_jump_role": "DIAGNOSTIC_ONLY",
            "force_stable_steps": force_stable_steps,
            "target_force_n": target_force,
            "final_stable_window": stable_window[-int(g4["stable_force_steps"]):],
            "passed": g4_pass,
        }
        if run_arguments.scenario == "g4_switch":
            result = base_result(
                "PASS" if g4_pass else "FAIL",
                "G4_BUMPLESS_COMPLIANT_FORCE_CONTROL_PASS" if g4_pass else "G4_BUMPLESS_COMPLIANT_FORCE_CONTROL_FAIL",
            )
            result["g4_evidence"] = g4_evidence
            return result
        if not g4_pass:
            result = base_result("FAIL", "G4_PREREQUISITE_REPLAY_FAIL")
            result["g4_evidence"] = g4_evidence
            return result

        release_position_raw, release_orientation_raw = object_view.get_world_pose()
        release_reference = {
            "object_position": np.asarray(release_position_raw, dtype=np.float64),
            "object_orientation": np.asarray(release_orientation_raw, dtype=np.float64),
            "lift_position": float(last_values[0][indices["lift_z"]]),
        }
        baseline_window = proprioception_window[-int(g5["pre_release_stable_steps"]):]
        slip_monitor = ProprioceptiveSlipMonitor(
            baseline_estimated_force_n=np.mean(
                np.asarray([row["estimated"] for row in baseline_window], dtype=np.float64),
                axis=0,
            ),
            baseline_maximum_abs_velocity_rad_s=np.max(
                np.abs(
                    np.asarray(
                        [row["root_velocity_rad_s"] for row in baseline_window],
                        dtype=np.float64,
                    )
                ),
                axis=0,
            ),
            initial_force_target_n=target_force,
            force_bias_shift_trigger_n=float(g5["proprioceptive_force_bias_shift_trigger_n"]),
            velocity_excess_trigger_rad_s=float(g5["proprioceptive_velocity_excess_trigger_rad_s"]),
            force_drop_trigger_n=float(g5["force_drop_trigger_n"]),
            confirmation_steps=int(g5["slip_confirmation_steps"]),
            stabilization_steps=int(g5["adaptive_settle_steps"]),
            stabilization_force_tolerance_n=float(g5["adaptive_stable_force_tolerance_n"]),
        )
        object_rigid.GetKinematicEnabledAttr().Set(False)
        prelift_rows: list[tuple[Any, ...]] = []
        pending_event = ""
        latched_recovery_target_n = target_force
        for index in range(int(g5["unsupported_hold_steps"])):
            desired = np.full(3, force_target_level, dtype=np.float64)
            values = force_step(
                "UNSUPPORTED_HOLD",
                index,
                desired,
                previous_efforts,
                adaptive_event=pending_event,
            )
            pending_event = ""
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            estimated = np.asarray(values[4])
            slip_observation = slip_monitor.update(
                estimated_force_n=estimated,
                joint_velocity_rad_s=[
                    float(values[1][indices[name]]) for name in ROOT_TORQUE_JOINTS
                ],
                force_target_n=force_target_level,
            )
            if (
                slip_observation.confirmed_event
                and force_target_level < float(g5["adaptive_force_ceiling_n_per_finger"])
            ):
                old = force_target_level
                force_target_level = min(
                    float(g5["adaptive_force_ceiling_n_per_finger"]),
                    force_target_level + float(g5["adaptive_force_increment_n"]),
                )
                adaptive_events.append(
                    {
                        "physics_step": len(trace_rows),
                        "from_n": old,
                        "to_n": force_target_level,
                        "reason": "PROPRIOCEPTIVE_SLIP_PRECURSOR",
                        "signals": slip_observation.as_dict(),
                    }
                )
                latched_recovery_target_n = max(
                    latched_recovery_target_n,
                    min(
                        float(g5["minimum_force_after_confirmed_slip_n"]),
                        float(g5["adaptive_force_ceiling_n_per_finger"]),
                    ),
                )
                slip_monitor.acknowledge_force_increment()
                pending_event = f"ADAPTIVE_FORCE_{old:.0f}_TO_{force_target_level:.0f}N"
            elif (
                slip_monitor.armed
                and force_target_level < latched_recovery_target_n
            ):
                old = force_target_level
                force_target_level = min(
                    latched_recovery_target_n,
                    force_target_level + float(g5["adaptive_force_increment_n"]),
                )
                adaptive_events.append(
                    {
                        "physics_step": len(trace_rows),
                        "from_n": old,
                        "to_n": force_target_level,
                        "reason": "LATCHED_SLIP_RECOVERY_TARGET",
                        "signals": slip_observation.as_dict(),
                    }
                )
                slip_monitor.acknowledge_force_increment()
                pending_event = f"ADAPTIVE_FORCE_{old:.0f}_TO_{force_target_level:.0f}N"
            prelift_rows.append(values)
        final_hold_window = prelift_rows[-min(120, len(prelift_rows)) :]
        final_rho = np.asarray(
            [[row[3][name]["friction_utilization"] for name in ACTIVE_PAD_LINKS] for row in final_hold_window],
            dtype=np.float64,
        )
        final_contacts = all(
            row[3][name]["valid"] for row in final_hold_window for name in ACTIVE_PAD_LINKS
        )
        g5_pass = bool(
            maximum_axial_slip <= float(g5["maximum_axial_slip_m"])
            and maximum_relative_rotation <= float(g5["maximum_relative_rotation_rad"])
            and final_contacts
            and np.all(
                maximum_rho_above_one_consecutive
                < SUSTAINED_RHO_FAILURE_STEPS
            )
            and force_target_level <= 12.0
            and slip_monitor.armed
        )
        g5_evidence = {
            "passed": g5_pass,
            "release_reference_object_position_m": release_reference["object_position"].tolist(),
            "release_reference_object_orientation_wxyz": release_reference["object_orientation"].tolist(),
            "maximum_axial_slip_m": maximum_axial_slip,
            "maximum_relative_rotation_rad": maximum_relative_rotation,
            "final_window_maximum_rho": np.max(final_rho, axis=0).tolist(),
            "rho_0p70_role": "DEMOTE_SOFT_POSTHOC_QUALITY_METRIC",
            "maximum_consecutive_rho_above_one_steps": (
                maximum_rho_above_one_consecutive.tolist()
            ),
            "sustained_rho_failure_steps": SUSTAINED_RHO_FAILURE_STEPS,
            "final_contacts_all_three": final_contacts,
            "final_force_target_level_n": force_target_level,
            "adaptive_stabilization_complete": slip_monitor.armed,
            "proprioceptive_slip_monitor": slip_monitor.state(),
        }
        if run_arguments.scenario == "g5_hold":
            result = base_result(
                "PASS" if g5_pass else "FAIL",
                "G5_UNSUPPORTED_HOLD_PASS" if g5_pass else "G5_UNSUPPORTED_HOLD_FAIL",
            )
            result["g4_evidence"] = g4_evidence
            result["g5_evidence"] = g5_evidence
            return result
        if not g5_pass:
            result = base_result("FAIL", "G5_PREREQUISITE_REPLAY_FAIL")
            result["g4_evidence"] = g4_evidence
            result["g5_evidence"] = g5_evidence
            return result

        lift_baseline = float(prelift_rows[-1][0][indices["lift_z"]])
        previous_target = 0.0
        stage_results: list[dict[str, Any]] = []
        lift_contact_all = True
        lift_rows: list[tuple[Any, ...]] = []
        for target, motion_steps, settle_steps in zip(
            g6["stage_targets_m"], g6["motion_steps"], g6["settle_steps"]
        ):
            target = float(target)
            for index in range(int(motion_steps)):
                current_targets["lift_z"] = minimum_jerk(previous_target, target, index, int(motion_steps))
                desired = np.full(3, force_target_level, dtype=np.float64)
                values = force_step(f"LIFT_{target * 1000:.1f}MM", index, desired, previous_efforts)
                previous_efforts = np.asarray(values[2], dtype=np.float64)
                lift_contact_all = lift_contact_all and all(values[3][name]["valid"] for name in ACTIVE_PAD_LINKS)
                lift_rows.append(values)
            current_targets["lift_z"] = target
            settle_values: list[tuple[Any, ...]] = []
            for index in range(int(settle_steps)):
                desired = np.full(3, force_target_level, dtype=np.float64)
                values = force_step(f"LIFT_SETTLE_{target * 1000:.1f}MM", index, desired, previous_efforts)
                previous_efforts = np.asarray(values[2], dtype=np.float64)
                lift_contact_all = lift_contact_all and all(values[3][name]["valid"] for name in ACTIVE_PAD_LINKS)
                lift_rows.append(values)
                settle_values.append(values)
            achieved = float(np.mean([row[0][indices["lift_z"]] for row in settle_values[-min(96, len(settle_values)):]]) - lift_baseline)
            stage_results.append(
                {"target_m": target, "achieved_m": achieved, "tracking_ratio": achieved / target, "passed": achieved / target >= float(g6["minimum_tracking_ratio"])}
            )
            previous_target = target
        final_values: list[tuple[Any, ...]] = []
        for index in range(int(g6["final_hold_steps"])):
            desired = np.full(3, force_target_level, dtype=np.float64)
            values = force_step("FINAL_HOLD", index, desired, previous_efforts)
            previous_efforts = np.asarray(values[2], dtype=np.float64)
            lift_contact_all = lift_contact_all and all(values[3][name]["valid"] for name in ACTIVE_PAD_LINKS)
            final_values.append(values)
        final_object_position = final_values[-1][5]["position"]
        object_lift = float(final_object_position[2] - release_reference["object_position"][2])
        g6_pass = bool(
            all(stage["passed"] for stage in stage_results)
            and maximum_axial_slip <= float(g6["maximum_relative_axial_slip_m"])
            and maximum_relative_rotation <= float(g6["maximum_tilt_rad"])
            and lift_contact_all
            and np.all(maximum_estimated_force <= 15.0)
            and np.all(maximum_diagnostic_force <= 15.0)
            and np.all(
                maximum_rho_above_one_consecutive
                < SUSTAINED_RHO_FAILURE_STEPS
            )
            and object_lift >= 0.039
        )
        g6_evidence = {
            "passed": g6_pass,
            "stage_results": stage_results,
            "object_lift_m": object_lift,
            "maximum_relative_axial_slip_m": maximum_axial_slip,
            "maximum_relative_rotation_rad": maximum_relative_rotation,
            "three_pad_contact_maintained": lift_contact_all,
            "maximum_consecutive_rho_above_one_steps": (
                maximum_rho_above_one_consecutive.tolist()
            ),
            "final_hold_steps": len(final_values),
            "table_contact_force_n": 0.0,
            "table_present": False,
        }
        goal_prefix = {
            "g7_validation": "G7_VALIDATION",
            "top3_comparison": "TOP3_DYNAMIC_COMPARISON",
        }.get(run_arguments.scenario, "G6_REAL_LIFT")
        result = base_result(
            "PASS" if g6_pass else "FAIL",
            f"{goal_prefix}_PASS" if g6_pass else f"{goal_prefix}_FAIL",
        )
        result["g4_evidence"] = g4_evidence
        result["g5_evidence"] = g5_evidence
        result["g6_evidence"] = g6_evidence
        return result
    finally:
        trace_stream.flush()
        trace_stream.close()


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    if run_arguments.dry_run:
        report = dry_run(run_arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0
    portable = Path(run_arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    output = Path(run_arguments.output_dir).resolve()
    application = None
    exit_code = 1
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": not bool(run_arguments.gui),
                "hide_ui": not bool(run_arguments.gui),
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = run_isaac(run_arguments)
        exit_code = 0 if report.get("status") == "PASS" else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        report = {
            "schema": RESULT_SCHEMA,
            "status": "ERROR",
            "classification": f"{SCENARIO_GOAL[run_arguments.scenario]}_{type(error).__name__.upper()}",
            "goal_id": SCENARIO_GOAL[run_arguments.scenario],
            "scenario": run_arguments.scenario,
            "validation_index": run_arguments.validation_index,
            "error_type": type(error).__name__,
            "error": str(error),
            "runtime_diagnostic": error.diagnostic if isinstance(error, RuntimeGuardError) else None,
            "traceback": traceback.format_exc(),
            "formal_b_passed": False,
        }
        exit_code = 2
    write_json(output / "G4567_RESULT.json", report)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
