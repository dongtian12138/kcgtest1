#!/usr/bin/env python3
"""Generate and rank the bounded B_GOAL_MODE grasp set without Isaac."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    build_bounded_candidate_bundle,
)


REPOSITORY = Path(__file__).resolve().parents[4]
DEFAULT_CONFIG = REPOSITORY / "src/kcg_connector/config/b_goal_mode/b_goal_mode.yaml"
DEFAULT_SEEDS = REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json"
DEFAULT_PAD_CORE = REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
DEFAULT_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"


def arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--seed-candidates", default=str(DEFAULT_SEEDS))
    parser.add_argument("--pad-core", default=str(DEFAULT_PAD_CORE))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args(argv)


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def main(argv: Sequence[str] | None = None) -> int:
    run_arguments = arguments(argv)
    output = Path(run_arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    config_path = Path(run_arguments.config).resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if config.get("mode") != "B_GOAL_MODE_AUTONOMOUS":
        raise ValueError("configuration is not B_GOAL_MODE_AUTONOMOUS")
    bundle = build_bounded_candidate_bundle(
        config=config,
        source_urdf=Path(run_arguments.source_urdf).resolve(),
        seed_candidates_path=Path(run_arguments.seed_candidates).resolve(),
        pad_core_path=Path(run_arguments.pad_core).resolve(),
    )
    manifest_path = output / "B_GOAL_MODE_CANDIDATES.json"
    write_json(manifest_path, bundle)

    ranking = {
        "schema": "D38999_B_GOAL_MODE_CANDIDATE_RANKING_V1",
        "status": bundle["status"],
        "candidate_count": bundle["candidate_count"],
        "selected_dynamic_candidate_ids": bundle["selected_dynamic_candidate_ids"],
        "selection_policy": bundle["selection_policy"],
        "ranking": [
            {
                "rank": row["rank"],
                "dynamic_rank": row["dynamic_rank"],
                "candidate_id": row["candidate_id"],
                "static_pass": row["static_pass"],
                "grasp_local_z_mm": row["grasp_local_z_mm"],
                "preshape_rad": row["preshape_rad"],
                "wrist_rpy_offset_rad": row["wrist_rpy_offset_rad"],
                "object_axis_center_xy_hand_m": row[
                    "object_axis_center_xy_hand_m"
                ],
                "maximum_circular_gap_deg": row["task_metrics"][
                    "circular_contact_metrics"
                ]["maximum_gap_deg"],
                "maximum_required_peak_normal_force_n": row["task_metrics"][
                    "maximum_required_peak_normal_force_n"
                ],
                "minimum_joint_margin_rad": row["minimum_joint_margin_rad"],
                "geometry_score": row["geometry_score"],
            }
            for row in bundle["candidates"]
        ],
    }
    write_json(output / "B_GOAL_MODE_CANDIDATE_RANKING.json", ranking)

    with (output / "B_GOAL_MODE_CANDIDATES.csv").open(
        "w", encoding="utf-8", newline=""
    ) as stream:
        fieldnames = (
            "rank",
            "dynamic_rank",
            "candidate_id",
            "static_pass",
            "grasp_local_z_mm",
            "preshape_rad",
            "wrist_roll_offset_rad",
            "wrist_pitch_offset_rad",
            "object_axis_x_hand_m",
            "object_axis_y_hand_m",
            "maximum_circular_gap_deg",
            "maximum_required_peak_normal_force_n",
            "minimum_other_task_safety_factor_at_12n",
            "minimum_joint_margin_rad",
            "geometry_score",
        )
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in bundle["candidates"]:
            writer.writerow(
                {
                    "rank": row["rank"],
                    "dynamic_rank": row["dynamic_rank"],
                    "candidate_id": row["candidate_id"],
                    "static_pass": row["static_pass"],
                    "grasp_local_z_mm": row["grasp_local_z_mm"],
                    "preshape_rad": row["preshape_rad"],
                    "wrist_roll_offset_rad": row["wrist_rpy_offset_rad"][0],
                    "wrist_pitch_offset_rad": row["wrist_rpy_offset_rad"][1],
                    "object_axis_x_hand_m": row[
                        "object_axis_center_xy_hand_m"
                    ][0],
                    "object_axis_y_hand_m": row[
                        "object_axis_center_xy_hand_m"
                    ][1],
                    "maximum_circular_gap_deg": row["task_metrics"][
                        "circular_contact_metrics"
                    ]["maximum_gap_deg"],
                    "maximum_required_peak_normal_force_n": row["task_metrics"][
                        "maximum_required_peak_normal_force_n"
                    ],
                    "minimum_other_task_safety_factor_at_12n": row["task_metrics"][
                        "minimum_other_task_safety_factor_at_12n"
                    ],
                    "minimum_joint_margin_rad": row["minimum_joint_margin_rad"],
                    "geometry_score": row["geometry_score"],
                }
            )

    runtime_configs = output / "TOP3_RUNTIME_CONFIGS"
    runtime_configs.mkdir()
    selected = set(bundle["selected_dynamic_candidate_ids"])
    for row in bundle["candidates"]:
        if row["candidate_id"] not in selected:
            continue
        candidate_config = json.loads(json.dumps(config))
        candidate_id = row["candidate_id"]
        candidate_config["g1_contact_wrench"]["seed_candidate_id"] = candidate_id
        candidate_config["g2_independent_contact"]["seed_candidate_id"] = candidate_id
        candidate_config["g4_compliant_force_control"]["seed_candidate_id"] = candidate_id
        candidate_config["g7_candidate_search"]["active_candidate_id"] = candidate_id
        (runtime_configs / f"{candidate_id}.yaml").write_text(
            yaml.safe_dump(candidate_config, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )

    result = {
        "schema": "D38999_B_GOAL_MODE_G7_BOUNDED_SEARCH_RESULT_V1",
        "status": "PASS",
        "goal_id": "G7_BOUNDED_CANDIDATE_SEARCH",
        "candidate_count": bundle["candidate_count"],
        "static_pass_count": sum(
            bool(row["static_pass"]) for row in bundle["candidates"]
        ),
        "selected_dynamic_candidate_ids": bundle["selected_dynamic_candidate_ids"],
        "candidate_manifest": str(manifest_path),
        "isaac_started": False,
        "online_truth_used": False,
        "formal_b_passed": False,
    }
    write_json(output / "G7_BOUNDED_CANDIDATE_SEARCH_RESULT.json", result)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
