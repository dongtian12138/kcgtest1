#!/usr/bin/env python3
"""Render five publication views by replaying completed full-iiwa TRACE states.

This utility is deliberately post-hoc and render-only.  It opens the exact USD
stage exported by a completed formal validation, reconstructs robot joint poses
from the frozen IK plan plus recorded root-joint positions, restores the two
movable-end positions from the recorded TRACE, and captures RGB frames.  It
does not run a grasp controller, does not advance a commanded physics task, and
its pose writes are explicitly excluded from dynamic acceptance evidence.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import traceback
from typing import Any, Mapping, Sequence

import numpy as np


REPOSITORY = Path(__file__).resolve().parents[4]
DEFAULT_VALIDATION = (
    REPOSITORY
    / "artifacts/b_goal_mode/B_GOAL_MODE_SESSION_20260820T082003Z/experiments/"
    "FULL_IIWA_TABLE_PICK_VALIDATION_01"
)
SCHEMA = "D38999_B_FULL_IIWA_PUBLICATION_RENDER_REPLAY_V1"
RESOLUTION = (1280, 720)
CAMERA_PATH = "/World/BFullIiwaPublicationCamera"
MILESTONES = (
    {
        "id": "01_FULL_IIWA_APPROACH",
        "title": "Complete iiwa approach",
        "caption_cn": "完整 iiwa 在正式候选 P120 的预抓取接近姿态。该图由验证 01 的冻结 TRACE 状态做后处理回放获得，不是新的动态验收运行。",
        "caption_en": "Complete iiwa in the pre-grasp approach pose for the formally selected P120 candidate. This image is a post-hoc replay of a frozen Validation-01 TRACE state, not a new dynamic acceptance run.",
        "phase": "CANDIDATE_HIGH_APPROACH",
        "selection": "last",
        "camera": "overview",
    },
    {
        "id": "02_THREE_PAD_JUST_CONTACT",
        "title": "All three PAD contacts just locked",
        "caption_cn": "三根蓝色 PAD 均首次建立稳定接触后的瞬间；红色 TIP 不计入正式承载。姿态来源为验证 01 中三指首次接触步的最大值。",
        "caption_en": "Instant immediately after all three blue PAD contacts were first established; red TIP contact is excluded from formal load bearing. The pose is taken at the latest first-contact step in Validation 01.",
        "phase": "FIRST_CONTACT_MAX_STEP",
        "selection": "exact",
        "camera": "closeup",
    },
    {
        "id": "03_EIGHT_NEWTON_COMPLIANT_GRASP",
        "title": "8 N compliant grasp after FORCE_QUIET_HOLD",
        "caption_cn": "FORCE_QUIET_HOLD 完成后的 8 N/指无扰柔顺抓取姿态。8 N 是首次抓力目标；正式稳定判据来自实际关节漂移和位置差分速度。",
        "caption_en": "Bumpless 8 N-per-finger compliant grasp after FORCE_QUIET_HOLD. Eight newtons is the initial grip target; formal stability is evaluated from measured joint-position drift and position-difference velocity.",
        "phase": "FORCE_QUIET_HOLD",
        "selection": "last",
        "camera": "closeup",
    },
    {
        "id": "04_OFFTABLE_0P5MM",
        "title": "0.5 mm table clearance",
        "caption_cn": "活动端完成 0.5 mm 离桌及载荷转移后的姿态；桌面支撑通过真实 Z 位移自然消失。",
        "caption_en": "Movable-end pose after achieving 0.5 mm table clearance and load transfer; table support disappears through actual Z displacement.",
        "phase": "LIFT_LOAD_TRANSFER_COMPENSATION_SETTLE",
        "fallback_phase": "LIFT_SETTLE_0.5MM",
        "selection": "last",
        "camera": "closeup_clearance",
    },
    {
        "id": "05_LIFT_40MM",
        "title": "40 mm lift",
        "caption_cn": "完整 iiwa、三指手和 0.31 kg 活动端完成 40 mm 抬升后的最终保持姿态。",
        "caption_en": "Final hold pose after the complete iiwa and three-finger hand lifted the 0.31 kg movable end by 40 mm.",
        "phase": "LIFT_SETTLE_40.0MM",
        "selection": "last",
        "camera": "closeup_lifted",
    },
)
CAMERAS = {
    "overview": {
        "eye_m": (1.80, -1.75, 1.25),
        "target_m": (0.25, -0.10, 0.48),
        "focal_length_mm": 30.0,
        "horizontal_aperture_mm": 24.0,
        "clipping_range_m": (0.05, 5.0),
    },
    "closeup": {
        "eye_m": (0.58, -0.19, 0.60),
        "target_m": (0.520, -0.210, 0.235),
        "focal_length_mm": 45.0,
        "horizontal_aperture_mm": 24.0,
        "clipping_range_m": (0.02, 3.0),
    },
    "closeup_clearance": {
        "eye_m": (0.28, 0.06, 0.30),
        "target_m": (0.520, -0.210, 0.235),
        "focal_length_mm": 38.0,
        "horizontal_aperture_mm": 24.0,
        "clipping_range_m": (0.02, 3.0),
    },
    "closeup_lifted": {
        "eye_m": (0.28, 0.06, 0.34),
        "target_m": (0.520, -0.210, 0.275),
        "focal_length_mm": 38.0,
        "horizontal_aperture_mm": 24.0,
        "clipping_range_m": (0.02, 3.0),
    },
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise TypeError(f"expected JSON object: {path}")
    return value


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise RuntimeError(f"empty TRACE: {path}")
    return rows


def _number(value: Any) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"non-finite numeric value: {value!r}")
    return result


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", default=str(DEFAULT_VALIDATION / "FULL_IIWA_STAGE.usda"))
    parser.add_argument("--trace", default=str(DEFAULT_VALIDATION / "FULL_IIWA_TRACE.csv"))
    parser.add_argument("--result", default=str(DEFAULT_VALIDATION / "FULL_IIWA_RESULT.json"))
    parser.add_argument("--plan", default=str(DEFAULT_VALIDATION / "FULL_IIWA_PLAN.json"))
    parser.add_argument(
        "--config",
        default=str(REPOSITORY / "src/kcg_connector/config/b_goal_mode/full_iiwa_b_goal_mode.yaml"),
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--warmup-frames", type=int, default=8)
    parser.add_argument("--rt-subframes", type=int, default=4)
    result = parser.parse_args(argv)
    if result.warmup_frames < 1 or result.rt_subframes < 1:
        parser.error("warmup-frames and rt-subframes must be positive")
    if not result.dry_run and not result.kit_portable_root:
        parser.error("--kit-portable-root is required for Isaac rendering")
    return result


def _select_milestones(
    rows: Sequence[Mapping[str, str]], result: Mapping[str, Any]
) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    first_contact_step = max(
        int(item["physics_step"]) for item in result["first_contact"].values()
    )
    for milestone in MILESTONES:
        if milestone["phase"] == "FIRST_CONTACT_MAX_STEP":
            matches = [row for row in rows if int(row["step"]) == first_contact_step]
        else:
            matches = [row for row in rows if row["phase"] == milestone["phase"]]
            if not matches and milestone.get("fallback_phase"):
                matches = [
                    row for row in rows if row["phase"] == milestone["fallback_phase"]
                ]
        if not matches:
            raise RuntimeError(f"TRACE milestone missing: {milestone['id']}")
        row = dict(matches[-1])
        selected.append({**milestone, "trace_row": row})
    if selected[2]["trace_row"]["force_target_level_n"] != "8.0":
        raise RuntimeError("8 N render milestone no longer has an 8 N target")
    if result.get("classification") != "FULL_IIWA_TABLE_PICK_VALIDATION_PASS":
        raise RuntimeError("render source is not a passed formal full-iiwa validation")
    return selected


def _ik_for_offset(plan: Mapping[str, Any], offset_m: float) -> np.ndarray:
    solutions = plan["ik"]["solutions"]
    matches = [
        value
        for value in solutions.values()
        if abs(float(value["offset_m"]) - float(offset_m)) <= 1.0e-9
    ]
    if len(matches) != 1:
        raise RuntimeError(f"expected one frozen IK solution for offset {offset_m}")
    return np.asarray(matches[0]["arm_rad"], dtype=np.float64)


def _reconstructed_joint_map(
    milestone: Mapping[str, Any], plan: Mapping[str, Any], result: Mapping[str, Any]
) -> dict[str, float]:
    row = milestone["trace_row"]
    offset_m = _number(row["arm_target_z_offset_m"])
    arm = _ik_for_offset(plan, offset_m)
    compensation = result["lift"].get("load_transfer_compensation")
    if compensation and int(row["step"]) >= int(compensation["applied_physics_step"]):
        arm = arm + np.asarray(compensation["joint_target_delta_rad"], dtype=np.float64)
    candidate = plan["candidate"]
    preshape = (
        float(candidate["open_preshape_rad"])
        if milestone["id"] == "01_FULL_IIWA_APPROACH"
        else float(candidate["preshape_rad"])
    )
    f1 = _number(row["f1j2_position_rad"])
    f2 = _number(row["f2j1_position_rad"])
    f3 = _number(row["f3j2_position_rad"])
    joint_map = {f"iiwa_joint_{index + 1}": float(value) for index, value in enumerate(arm)}
    joint_map.update(
        {
            "f1j1": preshape,
            "f1j2": f1,
            "f1j3": f1,
            "f2j1": f2,
            "f2j2": f2,
            "f3j1": preshape,
            "f3j2": f3,
            "f3j3": f3,
        }
    )
    return joint_map


def _build_plan(arguments: argparse.Namespace) -> dict[str, Any]:
    paths = {
        "stage": Path(arguments.stage).expanduser().resolve(),
        "trace": Path(arguments.trace).expanduser().resolve(),
        "result": Path(arguments.result).expanduser().resolve(),
        "plan": Path(arguments.plan).expanduser().resolve(),
        "config": Path(arguments.config).expanduser().resolve(),
    }
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    result = _json(paths["result"])
    plan = _json(paths["plan"])
    rows = _rows(paths["trace"])
    milestones = _select_milestones(rows, result)
    planned = []
    for milestone in milestones:
        row = milestone["trace_row"]
        planned.append(
            {
                "id": milestone["id"],
                "title": milestone["title"],
                "caption_cn": milestone["caption_cn"],
                "caption_en": milestone["caption_en"],
                "source_trace_step": int(row["step"]),
                "source_phase": row["phase"],
                "force_target_n_per_finger": _number(row["force_target_level_n"]),
                "arm_target_z_offset_m": _number(row["arm_target_z_offset_m"]),
                "body_position_m": [_number(row[f"body_{axis}_m"]) for axis in "xyz"],
                "nut_position_m": [_number(row[f"nut_{axis}_m"]) for axis in "xyz"],
                "recorded_contact_points_m": {
                    finger: [
                        _number(row[f"{finger}_contact_point_{axis}_m"])
                        for axis in "xyz"
                    ]
                    for finger in ("f1", "f2", "f3")
                    if all(
                        row[f"{finger}_contact_point_{axis}_m"]
                        for axis in "xyz"
                    )
                },
                "joint_positions_rad": _reconstructed_joint_map(milestone, plan, result),
                "camera_id": milestone["camera"],
                "output_png": f"{milestone['id']}.png",
            }
        )
    return {
        "schema": SCHEMA,
        "status": "RENDER_REPLAY_PLAN_PASS",
        "scope": "POSTHOC_RENDER_ONLY_NOT_DYNAMIC_EVIDENCE",
        "source_validation_classification": result["classification"],
        "source_validation_index": result["validation_index"],
        "source_candidate": result["candidate_id"],
        "scene_prim_paths": {
            "articulation": "/World/HandArm/Geometry/world",
            "body": result["scene_authoring"]["body_prim_path"],
            "nut": result["scene_authoring"]["nut_prim_path"],
        },
        "source_paths": {name: str(path) for name, path in paths.items()},
        "source_sha256": {name: _sha256(path) for name, path in paths.items()},
        "milestones": planned,
        "camera_parameters": {
            name: {
                **value,
                "resolution_px": list(RESOLUTION),
                "vertical_aperture_mm": value["horizontal_aperture_mm"]
                * RESOLUTION[1]
                / RESOLUTION[0],
            }
            for name, value in CAMERAS.items()
        },
        "truth_boundary": {
            "trace_object_pose_used": True,
            "trace_contact_used_by_controller": False,
            "controller_executed": False,
            "formal_validation_repeated": False,
            "posthoc_render_sync_physics_steps": len(MILESTONES),
            "posthoc_collisions_disabled": True,
            "posthoc_gravity_disabled": True,
            "render_replay_pose_writes": 10,
            "formal_controller_pose_writes": 0,
            "render_replay_pose_write_role": "POSTHOC_RENDER_ONLY",
        },
    }


def _hide_nonvisual_proxies(stage: Any, UsdGeom: Any) -> list[str]:
    hidden = []
    for prim in stage.Traverse():
        path = str(prim.GetPath())
        lower_path = path.lower()
        should_hide = (
            prim.GetName() == "PAD_CORE_CAPSULE"
            or prim.GetName().endswith("_convex")
            or "/continuousplugguidecollision" in lower_path
            or "/continuousguidering/outerbackbone" in lower_path
            or "/continuousguidering/boreguidebetweenkeyways" in lower_path
        )
        if not should_hide or not prim.IsA(UsdGeom.Imageable):
            continue
        UsdGeom.Imageable(prim).MakeInvisible()
        hidden.append(path)
    return hidden


def _disable_posthoc_collisions(stage: Any, UsdPhysics: Any) -> list[str]:
    """Disable contacts only in the unsaved render layer before sync steps."""

    disabled = []
    for prim in stage.Traverse():
        if not prim.HasAPI(UsdPhysics.CollisionAPI):
            continue
        UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(False).Set(False)
        disabled.append(str(prim.GetPath()))
    return disabled


def _capture_rgb(
    *,
    rep: Any,
    annotator: Any,
    product: Any,
    camera: Any,
    camera_parameters: Mapping[str, Any],
    ViewportManager: Any,
    application: Any,
    warmup_frames: int,
    rt_subframes: int,
) -> np.ndarray:
    camera.CreateFocalLengthAttr(float(camera_parameters["focal_length_mm"]))
    camera.CreateHorizontalApertureAttr(float(camera_parameters["horizontal_aperture_mm"]))
    camera.CreateVerticalApertureAttr(
        float(camera_parameters["horizontal_aperture_mm"])
        * RESOLUTION[1]
        / RESOLUTION[0]
    )
    ViewportManager.set_camera_view(
        camera=camera,
        eye=np.asarray(camera_parameters["eye_m"], dtype=np.float64),
        target=np.asarray(camera_parameters["target_m"], dtype=np.float64),
    )
    for _ in range(3):
        application.update()
    for _ in range(warmup_frames):
        rep.orchestrator.step(
            rt_subframes=rt_subframes,
            delta_time=0.0,
            pause_timeline=True,
        )
    rgba = np.asarray(annotator.get_data())
    if rgba.ndim != 3 or rgba.shape[:2] != RESOLUTION[::-1] or rgba.shape[2] < 3:
        raise RuntimeError(f"invalid RGB frame: {rgba.shape}")
    rgb = np.asarray(rgba[:, :, :3], dtype=np.uint8)
    if rgb.size == 0 or float(np.std(rgb)) < 1.0:
        raise RuntimeError("rendered RGB frame is blank or near-constant")
    return rgb


def _run_isaac(arguments: argparse.Namespace, plan_record: Mapping[str, Any]) -> dict[str, Any]:
    import omni.replicator.core as rep
    import omni.usd
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation, SingleRigidPrim
    from isaacsim.core.rendering_manager import ViewportManager
    from isaacsim.core.utils.types import ArticulationAction
    from PIL import Image
    from pxr import Gf, Usd, UsdGeom, UsdLux, UsdPhysics

    output = Path(arguments.output_dir).expanduser().resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite render evidence: {output}")
    output.mkdir(parents=True)
    context = omni.usd.get_context()
    if context.open_stage(plan_record["source_paths"]["stage"]) is not True:
        raise RuntimeError("failed to open formal validation stage")
    for _ in range(4):
        arguments.application.update()
    stage = context.get_stage()
    hidden_proxies = _hide_nonvisual_proxies(stage, UsdGeom)
    disabled_collisions = _disable_posthoc_collisions(stage, UsdPhysics)
    required_visible_grasp_geometry_paths = [
        plan_record["scene_prim_paths"]["body"]
        + "/MatingShell/ContinuousPlugGuide",
        plan_record["scene_prim_paths"]["nut"]
        + "/CouplingNutGraspCollision",
    ]
    for required_path in required_visible_grasp_geometry_paths:
        required_prim = stage.GetPrimAtPath(required_path)
        if (
            not required_prim.IsValid()
            or not required_prim.IsA(UsdGeom.Imageable)
            or UsdGeom.Imageable(required_prim).ComputeVisibility()
            == UsdGeom.Tokens.invisible
        ):
            raise RuntimeError(
                f"required grasp geometry is not render-visible: {required_path}"
            )

    World.clear_instance()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / 240.0,
        rendering_dt=1.0 / 60.0,
        backend="numpy",
        device="cpu",
    )
    robot = world.scene.add(
        SingleArticulation(
            prim_path=plan_record["scene_prim_paths"]["articulation"],
            name="b_full_iiwa_publication_replay_robot",
        )
    )
    body = world.scene.add(
        SingleRigidPrim(
            prim_path=plan_record["scene_prim_paths"]["body"],
            name="b_full_iiwa_publication_replay_body",
        )
    )
    nut = world.scene.add(
        SingleRigidPrim(
            prim_path=plan_record["scene_prim_paths"]["nut"],
            name="b_full_iiwa_publication_replay_nut",
        )
    )
    world.reset()
    if not robot.handles_initialized:
        raise RuntimeError("publication replay articulation handles not initialized")
    world.get_physics_context().set_gravity(0.0)
    dof_names = list(robot.dof_names)
    required = set(plan_record["milestones"][0]["joint_positions_rad"])
    missing = sorted(required - set(dof_names))
    if missing:
        raise RuntimeError(f"publication replay missing DOFs: {missing}")
    body_orientation = np.asarray(body.get_world_pose()[1], dtype=np.float64)
    nut_orientation = np.asarray(nut.get_world_pose()[1], dtype=np.float64)
    pad_core_prims = [
        prim for prim in stage.Traverse() if prim.GetName() == "PAD_CORE_CAPSULE"
    ]
    if len(pad_core_prims) != 3:
        raise RuntimeError(
            f"expected exactly three PAD core prims, found {len(pad_core_prims)}"
        )

    camera = UsdGeom.Camera.Define(stage, CAMERA_PATH)
    camera.CreateClippingRangeAttr(Gf.Vec2f(0.02, 5.0))
    dome = UsdLux.DomeLight.Define(stage, "/World/BFullIiwaPublicationFill")
    dome.CreateIntensityAttr(900.0)
    dome.CreateColorAttr(Gf.Vec3f(0.94, 0.97, 1.0))
    key = UsdLux.DistantLight.Define(stage, "/World/BFullIiwaPublicationKey")
    key.CreateIntensityAttr(1800.0)
    key.CreateColorAttr(Gf.Vec3f(1.0, 0.90, 0.80))
    UsdGeom.Xformable(key).AddRotateXYZOp().Set(Gf.Vec3f(-35.0, 25.0, 30.0))
    product = rep.create.render_product(
        camera.GetPrim(), RESOLUTION, name="BFullIiwaPublicationRenderProduct"
    )
    annotator = rep.AnnotatorRegistry.get_annotator("rgb")
    annotator.attach([product.path])
    views = []
    render_sync_physics_steps = 0
    maximum_joint_readback_error_rad = 0.0
    try:
        for milestone in plan_record["milestones"]:
            joint_map = milestone["joint_positions_rad"]
            positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
            for name, value in joint_map.items():
                positions[dof_names.index(name)] = float(value)
            robot.set_joint_positions(positions)
            robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
            robot.apply_action(
                ArticulationAction(joint_positions=positions.astype(np.float32))
            )
            # The formal stage is exported before world.reset().  A single
            # collision-free, zero-gravity step is therefore required to
            # propagate the teleported articulation state to renderable link
            # transforms.  This is post-hoc pose synchronization, not a task
            # controller step or a repeated dynamic validation.
            world.step(render=False)
            render_sync_physics_steps += 1
            joint_readback = np.asarray(robot.get_joint_positions(), dtype=np.float64)
            joint_readback_error = float(np.max(np.abs(joint_readback - positions)))
            maximum_joint_readback_error_rad = max(
                maximum_joint_readback_error_rad, joint_readback_error
            )
            if not np.all(np.isfinite(joint_readback)) or joint_readback_error > 5.0e-3:
                raise RuntimeError(
                    "posthoc articulation pose synchronization failed: "
                    f"joint readback error {joint_readback_error:.9f} rad"
                )
            body.set_world_pose(
                position=np.asarray(milestone["body_position_m"], dtype=np.float64),
                orientation=body_orientation,
            )
            nut.set_world_pose(
                position=np.asarray(milestone["nut_position_m"], dtype=np.float64),
                orientation=nut_orientation,
            )
            arguments.application.update()
            xform_cache = UsdGeom.XformCache(Usd.TimeCode.Default())
            pad_core_centers = {
                str(prim.GetPath()): [
                    float(value)
                    for value in xform_cache.GetLocalToWorldTransform(
                        prim
                    ).ExtractTranslation()
                ]
                for prim in pad_core_prims
            }
            body_pose_readback = [
                float(value) for value in np.asarray(body.get_world_pose()[0])
            ]
            nut_pose_readback = [
                float(value) for value in np.asarray(nut.get_world_pose()[0])
            ]
            camera_parameters = CAMERAS[milestone["camera_id"]]
            rgb = _capture_rgb(
                rep=rep,
                annotator=annotator,
                product=product,
                camera=camera,
                camera_parameters=camera_parameters,
                ViewportManager=ViewportManager,
                application=arguments.application,
                warmup_frames=arguments.warmup_frames,
                rt_subframes=arguments.rt_subframes,
            )
            image_path = output / milestone["output_png"]
            Image.fromarray(rgb, "RGB").save(image_path, dpi=(300, 300))
            maximum = np.max(rgb, axis=2)
            red_mask = (rgb[:, :, 0] > rgb[:, :, 1] + 20) & (rgb[:, :, 0] > rgb[:, :, 2] + 20)
            blue_mask = (rgb[:, :, 2] > rgb[:, :, 0] + 15) & (rgb[:, :, 2] > rgb[:, :, 1] + 5)
            views.append(
                {
                    "id": milestone["id"],
                    "file": image_path.name,
                    "sha256": _sha256(image_path),
                    "source_trace_step": milestone["source_trace_step"],
                    "source_phase": milestone["source_phase"],
                    "camera_id": milestone["camera_id"],
                    "shape": list(rgb.shape),
                    "mean_rgb": [float(value) for value in np.mean(rgb, axis=(0, 1))],
                    "std_rgb": [float(value) for value in np.std(rgb, axis=(0, 1))],
                    "near_black_fraction": float(np.mean(maximum <= 2)),
                    "red_dominant_fraction_diagnostic": float(np.mean(red_mask)),
                    "blue_dominant_fraction_diagnostic": float(np.mean(blue_mask)),
                    "render_nonblank": bool(float(np.std(rgb)) >= 1.0),
                    "joint_readback_max_error_rad": joint_readback_error,
                    "body_pose_readback_m": body_pose_readback,
                    "nut_pose_readback_m": nut_pose_readback,
                    "pad_core_world_centers_m": pad_core_centers,
                    "recorded_contact_points_m": milestone[
                        "recorded_contact_points_m"
                    ],
                }
            )
    finally:
        try:
            annotator.detach([product.path])
        finally:
            product.destroy()

    camera_record = {
        "schema": SCHEMA,
        "resolution_px": list(RESOLUTION),
        "camera_prim_path": CAMERA_PATH,
        "coordinate_frame": "USD_WORLD_METERS",
        "views": plan_record["camera_parameters"],
        "reproduction_source": "RENDER_REPLAY_PLAN.json",
    }
    _write_json(output / "CAMERA_PARAMETERS.json", camera_record)
    _write_json(output / "RENDER_REPLAY_PLAN.json", plan_record)
    view_by_id = {view["id"]: view for view in views}
    manifest_path = output / "ISAAC_RENDER_MANIFEST.csv"
    manifest_fields = (
        "figure_id",
        "filename",
        "sha256",
        "title_en",
        "caption_cn",
        "caption_en",
        "source_trace_step",
        "source_phase",
        "camera_id",
        "width_px",
        "height_px",
        "evidence_role",
        "source_validation_index",
        "source_candidate",
        "source_result_sha256",
    )
    with manifest_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=manifest_fields)
        writer.writeheader()
        for milestone in plan_record["milestones"]:
            view = view_by_id[milestone["id"]]
            writer.writerow(
                {
                    "figure_id": milestone["id"],
                    "filename": milestone["output_png"],
                    "sha256": view["sha256"],
                    "title_en": milestone["title"],
                    "caption_cn": milestone["caption_cn"],
                    "caption_en": milestone["caption_en"],
                    "source_trace_step": milestone["source_trace_step"],
                    "source_phase": milestone["source_phase"],
                    "camera_id": milestone["camera_id"],
                    "width_px": RESOLUTION[0],
                    "height_px": RESOLUTION[1],
                    "evidence_role": "POSTHOC_RENDER_ONLY_NOT_DYNAMIC_EVIDENCE",
                    "source_validation_index": plan_record["source_validation_index"],
                    "source_candidate": plan_record["source_candidate"],
                    "source_result_sha256": plan_record["source_sha256"]["result"],
                }
            )
    caption_lines = [
        "# Isaac 渲染图中英文图注 / Bilingual captions",
        "",
        "> 证据边界：以下图片均是正式验证 01 冻结状态的后处理渲染，不是新的动态验收证据。",
        "> Evidence boundary: all images are post-hoc renders of frozen Validation-01 states, not new dynamic acceptance evidence.",
        "",
    ]
    for milestone in plan_record["milestones"]:
        caption_lines.extend(
            [
                f"## {milestone['id']} — {milestone['title']}",
                "",
                f"- 中文：{milestone['caption_cn']}",
                f"- English: {milestone['caption_en']}",
                f"- 来源：TRACE step {milestone['source_trace_step']}, phase `{milestone['source_phase']}`。",
                "",
            ]
        )
    (output / "ISAAC_RENDER_CAPTIONS_CN_EN.md").write_text(
        "\n".join(caption_lines), encoding="utf-8"
    )
    report = {
        "schema": SCHEMA,
        "status": "ISAAC_PUBLICATION_RENDER_REPLAY_PASS"
        if len(views) == 5 and all(view["render_nonblank"] for view in views)
        else "ISAAC_PUBLICATION_RENDER_REPLAY_FAIL",
        "passed": len(views) == 5 and all(view["render_nonblank"] for view in views),
        "scope": "POSTHOC_RENDER_ONLY_NOT_DYNAMIC_EVIDENCE",
        "source_validation_classification": plan_record[
            "source_validation_classification"
        ],
        "source_validation_repeated": False,
        "controller_executed": False,
        "commanded_physics_task_steps": 0,
        "posthoc_render_sync_physics_steps": render_sync_physics_steps,
        "posthoc_render_sync_role": "ARTICULATION_VISUAL_STATE_PROPAGATION_ONLY",
        "posthoc_collisions_disabled": True,
        "posthoc_collision_prim_count": len(disabled_collisions),
        "posthoc_gravity_disabled": True,
        "maximum_joint_readback_error_rad": maximum_joint_readback_error_rad,
        "render_replay_pose_writes": 10,
        "formal_controller_pose_writes": 0,
        "hidden_nonvisual_proxy_paths": hidden_proxies,
        "required_visible_grasp_geometry_paths": required_visible_grasp_geometry_paths,
        "views": views,
        "camera_parameters_file": "CAMERA_PARAMETERS.json",
        "plan_file": "RENDER_REPLAY_PLAN.json",
        "manifest_file": manifest_path.name,
        "captions_file": "ISAAC_RENDER_CAPTIONS_CN_EN.md",
    }
    _write_json(output / "ISAAC_RENDER_RESULT.json", report)
    return report


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    output = Path(arguments.output_dir).expanduser().resolve()
    plan_record = _build_plan(arguments)
    if arguments.dry_run:
        if output.exists():
            raise FileExistsError(f"refusing to overwrite render dry-run: {output}")
        output.mkdir(parents=True)
        _write_json(output / "RENDER_REPLAY_PLAN.json", plan_record)
        print(json.dumps({"status": "DRY_RUN_PASS", "output": str(output)}, sort_keys=True))
        return 0

    portable = Path(arguments.kit_portable_root).expanduser().resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": True,
                "hide_ui": True,
                "renderer": "RayTracedLighting",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        arguments.application = application
        report = _run_isaac(arguments, plan_record)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0 if report["passed"] else 3
    except BaseException as error:
        traceback.print_exc()
        output.mkdir(parents=True, exist_ok=True)
        _write_json(
            output / "ISAAC_RENDER_RESULT.json",
            {
                "schema": SCHEMA,
                "status": "ISAAC_PUBLICATION_RENDER_REPLAY_ERROR",
                "passed": False,
                "error_type": type(error).__name__,
                "error": str(error),
                "traceback": traceback.format_exc(),
                "scope": "POSTHOC_RENDER_ONLY_NOT_DYNAMIC_EVIDENCE",
            },
        )
        return 2
    finally:
        if application is not None:
            application.close()


if __name__ == "__main__":
    raise SystemExit(main())
