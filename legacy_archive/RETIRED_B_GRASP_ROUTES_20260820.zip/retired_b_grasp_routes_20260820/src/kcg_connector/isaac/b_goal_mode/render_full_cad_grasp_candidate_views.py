#!/usr/bin/env python3
"""Render full-CAD grasp-pose cards without launching Isaac Sim.

This is a pre-run visual review utility.  Candidate values come from the same
full-iiwa YAML (or an explicitly supplied JSON snapshot), terminal geometry
comes from the authored STL files, and link poses come from the source URDF.
The resulting pictures are render-only evidence: they neither step physics nor
claim collision or dynamic acceptance.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any, Iterable, Mapping, Sequence

os.environ.setdefault("MPLBACKEND", "Agg")

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import trimesh
import yaml


REPOSITORY = Path(__file__).resolve().parents[4]
PACKAGE_ROOT = REPOSITORY / "src/kcg_connector"
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from kcg_connector.d38999_tabletop_scene import load_d38999_tabletop_scene
from kcg_connector.grasp.d38999_b_minimal_v2 import hand_link_transforms
from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    candidate_world_geometry,
)
from kcg_connector.grasp.d38999_pad_contact_roles import (
    FINGER_PAD_ROLE_SPECS,
    build_finger_pad_role,
)


SCHEMA = "D38999_FULL_CAD_GRASP_POSE_CARD_V1"
DEFAULT_CONFIG = (
    REPOSITORY
    / "src/kcg_connector/config/b_goal_mode/full_iiwa_b_goal_mode.yaml"
)
TERMINAL_LINKS = ("f1Link3", "f2Link2", "f3Link3")
UPSTREAM_COLLISION_LINKS = (
    "handbase_link",
    "f1Link1",
    "f1Link2",
    "f2Link1",
    "f3Link1",
    "f3Link2",
)
STATE_ORDER = ("high_preshape", "pregrasp", "target_grasp")
VIEWS = {
    "top": (90.0, -90.0),
    "front": (9.0, -90.0),
    "side": (9.0, 0.0),
    "oblique": (28.0, -52.0),
}
ROLE_STYLE = {
    "PAD": ("#1686ff", 0.98),
    "TIP": ("#ef3340", 0.98),
    "SIDE": ("#8d99a6", 0.83),
    "UPSTREAM_COLLISION": ("#c1c8d0", 0.18),
    "CONNECTOR": ("#b58b45", 0.78),
    "AUTHORIZED_GRIP": ("#ffd166", 0.35),
    "TABLE": ("#394550", 0.32),
}
FINGER_COLORS = ("#00e5ff", "#ff4fd8", "#9cff57")
PUBLICATION_ROLE_STYLE = {
    "PAD": ("#0072B2", 1.00),
    "TIP": ("#D55E00", 1.00),
    "SIDE": ("#9DA4AD", 0.98),
    "UPSTREAM_COLLISION": ("#C7CDD4", 0.46),
    "CONNECTOR": ("#A98443", 0.88),
    "AUTHORIZED_GRIP": ("#D4B56A", 0.22),
    "TABLE": ("#E4E7EB", 0.10),
}
PUBLICATION_STATE_LABELS = {
    "high_preshape": "High preshape",
    "pregrasp": "Pregrasp",
    "target_grasp": "Target (search limit; not achieved)",
}
PUBLICATION_ROW_LABELS = {
    "high_preshape": "High preshape",
    "pregrasp": "Pregrasp",
    "target_grasp": "Target limit\n(not achieved)",
}
PUBLICATION_VIEW_LABELS = {
    "top": "Top",
    "front": "Front",
    "side": "Side",
    "oblique": "Oblique",
}
COMPARISON_LABELS = {
    "CAD_P118_Q658_Q539": "B",
    "CAD_P100_Q662_Q522": "A",
    "CAD_P136_Q659_Q538": "C",
}


# This is a verbatim snapshot of the former YAML Top-1 override.  It is used
# only when explicitly requested and is always rendered with a red rejection
# banner.  The inherited seed geometry is still loaded from candidate_bundle.
HISTORICAL_REJECTED_TOP1: dict[str, Any] = {
    "candidate_id": "CAD_P118_Q13103_Q290",
    "rank": 1,
    "preshape_rad": 1.18,
    "approach_preshape_rad": 1.18,
    "approach_flexion_rad": [1.07, 0.94, 1.07],
    "finger_flexion_targets_rad": [1.03, 0.90, 1.03],
    "closure_direction": [-1.0, -1.0, -1.0],
    "tcp_z_offset_m": -0.01629517478518594,
    "minimum_table_clearance_m": 0.0015,
    "predicted_contact_points_world_m": [
        [0.5069606022031912, -0.18985120090187563, 0.218463847675915],
        [0.5438323984151068, -0.21283139290519995, 0.21764657336200235],
        [0.5100487092224864, -0.23183968433520435, 0.2172730758317348],
    ],
    "predicted_contact_normals_world": [
        [0.5433082415337012, -0.8395332957551817, 0.0],
        [-0.9930166006294485, 0.11797470438333107, 0.0],
        [0.41463711572973655, 0.9099868473001822, 0.0],
    ],
    "target_gaps_m": [
        -0.000006156981498819936,
        -0.0000011803584495338748,
        -0.0000008855241430544281,
    ],
    "approach_gaps_m": [
        0.0033283284699110217,
        0.0034859669591528614,
        0.003376983135968282,
    ],
    "force_closure": True,
    "force_closure_scale": 8.655079493734618,
    "minimum_abs_normal_alignment": 0.9252481081576021,
    "maximum_required_peak_normal_force_n": 5.6780779880075345,
    "minimum_8n_lift_safety_factor": 3.6878117907599752,
    "minimum_12n_other_task_safety_factor": 2.1133911907065723,
    "seed_candidate_id": "BG_P120_Z12",
    "render_review_status": "REJECTED",
    "render_rejection_reason": "SELF-COLLISION-UNREACHABLE",
    "historical_source": "FORMER_FULL_IIWA_YAML_TOP1_2026-08-20",
}


@dataclass(frozen=True)
class TrianglePart:
    triangles: np.ndarray
    role: str
    source: str
    link_name: str | None = None


@dataclass(frozen=True)
class CandidateSource:
    candidate: dict[str, Any]
    status: str
    reason: str
    source_description: str


@dataclass(frozen=True)
class StateRenderData:
    parts: tuple[TrianglePart, ...]
    metrics: Mapping[str, Any]


@dataclass(frozen=True)
class PublicationCandidate:
    source: CandidateSource
    candidate_dir: Path
    object_center_world_m: np.ndarray
    table_top_z_m: float
    states: Mapping[str, StateRenderData]


@dataclass(frozen=True)
class CandidateRenderResult:
    contact_sheet: Path | None
    publication_plate_png: Path
    publication_plate_pdf: Path
    publication: PublicationCandidate


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument(
        "--candidate-id",
        help="Render one candidate from motion.real_cad_grasp_candidates.",
    )
    parser.add_argument(
        "--candidate-json",
        help="Render one explicit candidate record or {'candidate': record} JSON.",
    )
    parser.add_argument(
        "--historical-rejected-old-top1",
        action="store_true",
        help="Render the former Top-1 with a mandatory REJECTED banner.",
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--dpi", type=int, default=125)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--publication-only",
        action="store_true",
        help=(
            "Preserve existing debug views and CONTACT_SHEET; write only the "
            "SCI PNG/PDF products and refreshed manifests."
        ),
    )
    result = parser.parse_args(argv)
    selected_modes = sum(
        value is not None
        for value in (result.candidate_id, result.candidate_json)
    ) + int(result.historical_rejected_old_top1)
    if selected_modes > 1:
        parser.error(
            "--candidate-id, --candidate-json and "
            "--historical-rejected-old-top1 are mutually exclusive"
        )
    if result.dpi < 80 or result.dpi > 240:
        parser.error("--dpi must be between 80 and 240")
    return result


def _resolve(path: str | Path) -> Path:
    value = Path(path).expanduser()
    if not value.is_absolute():
        value = REPOSITORY / value
    return value.resolve()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path: Path) -> Any:
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def _yaml(path: Path) -> Any:
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def _finite_vector(value: Any, count: int, name: str) -> np.ndarray:
    result = np.asarray(value, dtype=np.float64)
    if result.shape != (count,) or not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must contain {count} finite values")
    return result


def _dependency_path(config: Mapping[str, Any], name: str) -> Path:
    row = config.get("dependencies", {}).get(name)
    if not isinstance(row, Mapping) or "path" not in row:
        raise ValueError(f"missing config dependency: {name}")
    path = _resolve(str(row["path"]))
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def _seed_candidate(config: Mapping[str, Any], seed_id: str) -> dict[str, Any]:
    bundle_path = _dependency_path(config, "candidate_bundle")
    bundle = _json(bundle_path)
    matches = [
        row
        for row in bundle.get("candidates", ())
        if isinstance(row, Mapping) and str(row.get("candidate_id")) == seed_id
    ]
    if len(matches) != 1:
        raise ValueError(f"candidate bundle has {len(matches)} records for {seed_id}")
    return dict(matches[0])


def _merge_with_seed(
    config: Mapping[str, Any], record: Mapping[str, Any]
) -> dict[str, Any]:
    seed_id = str(
        record.get(
            "seed_candidate_id",
            config.get("motion", {}).get("real_cad_candidate_seed_id", ""),
        )
    )
    if not seed_id:
        candidate = dict(record)
    else:
        candidate = _seed_candidate(config, seed_id)
        candidate.update(dict(record))
        candidate["seed_candidate_id"] = seed_id
    required = (
        "candidate_id",
        "object_axis_center_xy_hand_m",
        "object_center_z_hand_m",
        "preshape_rad",
        "finger_flexion_targets_rad",
    )
    missing = [name for name in required if name not in candidate]
    if missing:
        raise ValueError(f"candidate lacks render geometry fields: {missing}")
    return candidate


def _candidate_sources(
    args: argparse.Namespace, config: Mapping[str, Any]
) -> list[CandidateSource]:
    if args.historical_rejected_old_top1:
        return [
            CandidateSource(
                candidate=_merge_with_seed(config, HISTORICAL_REJECTED_TOP1),
                status="REJECTED",
                reason="SELF-COLLISION-UNREACHABLE",
                source_description=str(HISTORICAL_REJECTED_TOP1["historical_source"]),
            )
        ]
    if args.candidate_json:
        path = _resolve(args.candidate_json)
        payload = _json(path)
        raw = payload.get("candidate") if isinstance(payload, Mapping) else None
        if raw is None:
            raw = payload
        if not isinstance(raw, Mapping):
            raise TypeError("candidate JSON must contain one candidate mapping")
        candidate = _merge_with_seed(config, raw)
        status = str(raw.get("render_review_status", "REVIEW_PENDING"))
        reason = str(raw.get("render_rejection_reason", ""))
        return [CandidateSource(candidate, status, reason, f"JSON:{path}")]

    records = config.get("motion", {}).get("real_cad_grasp_candidates")
    if not isinstance(records, list) or not records:
        raise ValueError("YAML has no real_cad_grasp_candidates")
    if args.candidate_id:
        records = [
            row
            for row in records
            if isinstance(row, Mapping)
            and str(row.get("candidate_id")) == args.candidate_id
        ]
        if len(records) != 1:
            raise ValueError(
                f"YAML has {len(records)} candidates named {args.candidate_id}"
            )
    result: list[CandidateSource] = []
    for raw in records:
        if not isinstance(raw, Mapping):
            raise TypeError("real-CAD candidate must be a mapping")
        status = str(raw.get("render_review_status", "REVIEW_PENDING"))
        reason = str(raw.get("render_rejection_reason", ""))
        result.append(
            CandidateSource(
                _merge_with_seed(config, raw),
                status,
                reason,
                "CURRENT_FULL_IIWA_YAML",
            )
        )
    return result


def _terminal_local_parts() -> tuple[list[TrianglePart], dict[str, str]]:
    parts: list[TrianglePart] = []
    hashes: dict[str, str] = {}
    for spec in FINGER_PAD_ROLE_SPECS:
        build = build_finger_pad_role(spec)
        hashes[str(build.source_path)] = build.source_sha256
        side_triangles = [
            np.asarray(component.triangles, dtype=np.float64)
            for rank, component in enumerate(build.components_by_area)
            if rank
            not in (
                build.pad_component_rank_by_area,
                build.tip_component_rank_by_area,
            )
        ]
        parts.extend(
            (
                TrianglePart(
                    np.asarray(build.pad_component.triangles, dtype=np.float64),
                    "PAD",
                    str(build.source_path),
                    spec.link_name,
                ),
                TrianglePart(
                    np.asarray(build.tip_component.triangles, dtype=np.float64),
                    "TIP",
                    str(build.source_path),
                    spec.link_name,
                ),
                TrianglePart(
                    np.asarray(
                        build.pad_component.triangles[build.pad_contact_face_ids],
                        dtype=np.float64,
                    ),
                    "PAD_CONTACT_SAMPLE",
                    str(build.source_path),
                    spec.link_name,
                ),
                TrianglePart(
                    np.concatenate(side_triangles, axis=0),
                    "SIDE",
                    str(build.source_path),
                    spec.link_name,
                ),
            )
        )
    return parts, hashes


def _upstream_local_parts() -> tuple[list[TrianglePart], dict[str, str]]:
    parts: list[TrianglePart] = []
    hashes: dict[str, str] = {}
    root = REPOSITORY / "src/iiwa_description/meshes/hand/collision"
    for link_name in UPSTREAM_COLLISION_LINKS:
        path = root / f"{link_name}_convex.stl"
        mesh = trimesh.load_mesh(path, process=False)
        if not isinstance(mesh, trimesh.Trimesh):
            raise TypeError(f"upstream collider is not a triangle mesh: {path}")
        parts.append(
            TrianglePart(
                np.asarray(mesh.triangles, dtype=np.float64),
                "UPSTREAM_COLLISION",
                str(path.resolve()),
                link_name,
            )
        )
        hashes[str(path.resolve())] = _sha256(path)
    return parts, hashes


def _triangulate_faces(
    points: np.ndarray, counts: Sequence[int], indices: Sequence[int]
) -> np.ndarray:
    triangles: list[np.ndarray] = []
    cursor = 0
    for count_value in counts:
        count = int(count_value)
        polygon = np.asarray(indices[cursor : cursor + count], dtype=np.int64)
        cursor += count
        if count < 3:
            continue
        for index in range(1, count - 1):
            triangles.append(points[[polygon[0], polygon[index], polygon[index + 1]]])
    if not triangles:
        return np.empty((0, 3, 3), dtype=np.float64)
    return np.asarray(triangles, dtype=np.float64)


def _primitive_trimesh(type_name: str, prim: Any) -> trimesh.Trimesh | None:
    from pxr import UsdGeom

    if type_name == "Cube":
        size = float(UsdGeom.Cube(prim).GetSizeAttr().Get() or 2.0)
        return trimesh.creation.box(extents=(size, size, size))
    if type_name == "Cylinder":
        shape = UsdGeom.Cylinder(prim)
        radius = float(shape.GetRadiusAttr().Get() or 1.0)
        height = float(shape.GetHeightAttr().Get() or 2.0)
        mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=48)
        axis = str(shape.GetAxisAttr().Get() or "Z").upper()
        if axis == "X":
            mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, (0, 1, 0)))
        elif axis == "Y":
            mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, (1, 0, 0)))
        return mesh
    if type_name == "Sphere":
        radius = float(UsdGeom.Sphere(prim).GetRadiusAttr().Get() or 1.0)
        return trimesh.creation.icosphere(subdivisions=2, radius=radius)
    return None


def _matrix_points(matrix: Any, points: np.ndarray) -> np.ndarray:
    from pxr import Gf

    return np.asarray(
        [tuple(matrix.Transform(Gf.Vec3d(*map(float, point)))) for point in points],
        dtype=np.float64,
    )


def _connector_parts(
    asset_path: Path,
    loose_origin_world_m: Sequence[float],
) -> tuple[list[TrianglePart], str]:
    """Read the movable-end control geometry through OpenUSD, without Kit."""

    try:
        from pxr import Usd, UsdGeom
    except ImportError:
        return [], "OPENUSD_UNAVAILABLE_ANALYTIC_GRIP_ONLY"
    stage = Usd.Stage.Open(str(asset_path))
    if stage is None:
        return [], "OPENUSD_STAGE_OPEN_FAILED_ANALYTIC_GRIP_ONLY"
    loose_matches = [prim for prim in stage.Traverse() if prim.GetName() == "LoosePlug"]
    if len(loose_matches) != 1:
        return [], "OPENUSD_LOOSE_PLUG_NOT_UNIQUE_ANALYTIC_GRIP_ONLY"
    loose = loose_matches[0]
    cache = UsdGeom.XformCache(Usd.TimeCode.Default())
    orientation = np.diag((1.0, -1.0, -1.0))
    origin = _finite_vector(loose_origin_world_m, 3, "loose endpoint origin")
    result: list[TrianglePart] = []
    for prim in Usd.PrimRange(loose):
        type_name = prim.GetTypeName()
        if type_name not in {"Mesh", "Cube", "Cylinder", "Sphere"}:
            continue
        path_text = str(prim.GetPath())
        if "ContinuousPlugGuideCollision" in path_text:
            # The 64 collision segments duplicate ContinuousPlugGuide visually.
            continue
        transform = cache.GetLocalToWorldTransform(prim)
        if type_name == "Mesh":
            mesh = UsdGeom.Mesh(prim)
            points = np.asarray(mesh.GetPointsAttr().Get(), dtype=np.float64)
            if len(points) == 0:
                continue
            points = _matrix_points(transform, points)
            triangles = _triangulate_faces(
                points,
                mesh.GetFaceVertexCountsAttr().Get() or (),
                mesh.GetFaceVertexIndicesAttr().Get() or (),
            )
        else:
            primitive_mesh = _primitive_trimesh(type_name, prim)
            if primitive_mesh is None:
                continue
            vertices = _matrix_points(
                transform, np.asarray(primitive_mesh.vertices, dtype=np.float64)
            )
            triangles = vertices[np.asarray(primitive_mesh.faces, dtype=np.int64)]
        if len(triangles) == 0:
            continue
        triangles = triangles @ orientation.T + origin[None, None, :]
        role = (
            "AUTHORIZED_GRIP"
            if prim.GetName() == "CouplingNutGraspCollision"
            else "CONNECTOR"
        )
        result.append(TrianglePart(triangles, role, path_text, None))
    return result, "OPENUSD_MOVABLE_END_CONTROL_GEOMETRY"


def _box_triangles(center: Sequence[float], size: Sequence[float]) -> np.ndarray:
    mesh = trimesh.creation.box(extents=_finite_vector(size, 3, "box size"))
    mesh.apply_translation(_finite_vector(center, 3, "box center"))
    return np.asarray(mesh.triangles, dtype=np.float64)


def _candidate_pose(
    *,
    config: Mapping[str, Any],
    candidate: Mapping[str, Any],
    selected_goal: Mapping[str, Any],
    tabletop: Any,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    local_grip = _finite_vector(
        config["scene"]["authorized_grip_local_center_m"],
        3,
        "authorized grip center",
    )
    loose_rotation = np.diag((1.0, -1.0, -1.0))
    loose_origin = _finite_vector(
        tabletop.loose_settled_origin_m, 3, "settled loose origin"
    )
    object_world = loose_origin + loose_rotation @ local_grip
    geometry = candidate_world_geometry(
        hand_mount_rpy_rad=selected_goal["grasp_geometry"]["hand_mount_rpy_rad"],
        object_world_center_m=object_world,
        candidate=candidate,
    )
    rotation = np.asarray(geometry["rotation_world_from_hand"], dtype=np.float64)
    handbase = np.asarray(geometry["handbase_world_m"], dtype=np.float64)
    handbase[2] += float(candidate.get("tcp_z_offset_m", 0.0))
    return rotation, handbase, object_world


def _state_specs(
    config: Mapping[str, Any], candidate: Mapping[str, Any]
) -> dict[str, dict[str, Any]]:
    target = _finite_vector(
        candidate["finger_flexion_targets_rad"], 3, "target flexion"
    )
    approach = _finite_vector(
        candidate.get("approach_flexion_rad", target), 3, "approach flexion"
    )
    preshape = float(candidate["preshape_rad"])
    approach_preshape = float(candidate.get("approach_preshape_rad", preshape))
    return {
        "high_preshape": {
            "preshape_rad": approach_preshape,
            "flexion_rad": approach,
            "z_offset_m": float(config["motion"]["candidate_high_offset_m"]),
            "configured_gaps_m": None,
        },
        "pregrasp": {
            "preshape_rad": approach_preshape,
            "flexion_rad": approach,
            "z_offset_m": float(candidate.get("closure_start_offset_m", 0.0)),
            "configured_gaps_m": candidate.get("approach_gaps_m"),
        },
        "target_grasp": {
            "preshape_rad": preshape,
            "flexion_rad": target,
            "z_offset_m": 0.0,
            "configured_gaps_m": candidate.get(
                "target_gaps_m", candidate.get("predicted_closed_object_gaps_m")
            ),
        },
    }


def _transform_part(
    part: TrianglePart,
    link_transforms: Mapping[str, np.ndarray],
    hand_rotation: np.ndarray,
    handbase_world: np.ndarray,
) -> TrianglePart:
    if part.link_name is None:
        return part
    link = link_transforms[part.link_name]
    rotation = hand_rotation @ link[:3, :3]
    translation = handbase_world + hand_rotation @ link[:3, 3]
    world = part.triangles @ rotation.T + translation[None, None, :]
    return TrianglePart(world, part.role, part.source, part.link_name)


def _finite_cylinder_sdf(
    points: np.ndarray,
    center: np.ndarray,
    radius_m: float,
    height_m: float,
) -> np.ndarray:
    flat = np.asarray(points, dtype=np.float64).reshape((-1, 3))
    radial = np.linalg.norm(flat[:, :2] - center[None, :2], axis=1) - radius_m
    axial = np.abs(flat[:, 2] - center[2]) - 0.5 * height_m
    outside = np.linalg.norm(
        np.stack((np.maximum(radial, 0.0), np.maximum(axial, 0.0)), axis=1),
        axis=1,
    )
    inside = np.minimum(np.maximum(radial, axial), 0.0)
    return outside + inside


def _aabb_pair_clearance(parts: Sequence[TrianglePart]) -> float:
    bounds: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for link_name in TERMINAL_LINKS:
        vertices = np.concatenate(
            [
                part.triangles.reshape((-1, 3))
                for part in parts
                if part.link_name == link_name and part.role in {"PAD", "TIP", "SIDE"}
            ],
            axis=0,
        )
        bounds[link_name] = (np.min(vertices, axis=0), np.max(vertices, axis=0))
    values: list[float] = []
    for index, first in enumerate(TERMINAL_LINKS):
        for second in TERMINAL_LINKS[index + 1 :]:
            first_min, first_max = bounds[first]
            second_min, second_max = bounds[second]
            signed_axis = np.maximum(second_min - first_max, first_min - second_max)
            positive = np.maximum(signed_axis, 0.0)
            if np.any(positive > 0.0):
                values.append(float(np.linalg.norm(positive)))
            else:
                values.append(float(np.max(signed_axis)))
    return min(values)


def _state_metrics(
    parts: Sequence[TrianglePart],
    *,
    table_top_z_m: float,
    grip_center: np.ndarray,
    grip_radius_m: float,
    grip_height_m: float,
    configured_gaps_m: Any,
) -> dict[str, Any]:
    robot_parts = [
        part
        for part in parts
        if part.role in {"PAD", "TIP", "SIDE", "UPSTREAM_COLLISION"}
    ]
    all_robot = np.concatenate(
        [part.triangles.reshape((-1, 3)) for part in robot_parts], axis=0
    )
    per_finger_contact_face_gap: list[float] = []
    per_finger_full_pad_gap: list[float] = []
    for link_name in TERMINAL_LINKS:
        contact_face_points = np.concatenate(
            [
                part.triangles.reshape((-1, 3))
                for part in parts
                if part.link_name == link_name and part.role == "PAD_CONTACT_SAMPLE"
            ],
            axis=0,
        )
        full_pad_points = np.concatenate(
            [
                part.triangles.reshape((-1, 3))
                for part in parts
                if part.link_name == link_name and part.role == "PAD"
            ],
            axis=0,
        )
        per_finger_contact_face_gap.append(
            float(
                np.min(
                    _finite_cylinder_sdf(
                        contact_face_points,
                        grip_center,
                        grip_radius_m,
                        grip_height_m,
                    )
                )
            )
        )
        per_finger_full_pad_gap.append(
            float(
                np.min(
                    _finite_cylinder_sdf(
                        full_pad_points,
                        grip_center,
                        grip_radius_m,
                        grip_height_m,
                    )
                )
            )
        )
    configured = None
    if configured_gaps_m is not None:
        configured = _finite_vector(configured_gaps_m, 3, "configured gaps").tolist()
    return {
        "minimum_robot_table_clearance_m": float(
            np.min(all_robot[:, 2]) - table_top_z_m
        ),
        "minimum_interfinger_aabb_clearance_m": _aabb_pair_clearance(parts),
        "computed_contact_face_to_authorized_grip_sdf_m": (
            per_finger_contact_face_gap
        ),
        "sampled_full_pad_vertex_finite_cylinder_sdf_m": per_finger_full_pad_gap,
        "configured_candidate_gaps_m": configured,
    }


def _gap_sign_disagreements(metrics: Mapping[str, Any]) -> list[int]:
    """Return 1-based fingers whose candidate and sampled full-PAD signs differ."""

    configured = metrics.get("configured_candidate_gaps_m")
    sampled = metrics.get("sampled_full_pad_vertex_finite_cylinder_sdf_m")
    if configured is None or sampled is None:
        return []
    candidate_values = _finite_vector(configured, 3, "candidate contact metric")
    sampled_values = _finite_vector(sampled, 3, "sampled full-PAD SDF")

    def sign(value: float) -> int:
        if value > 1.0e-9:
            return 1
        if value < -1.0e-9:
            return -1
        return 0

    return [
        index + 1
        for index, (candidate_value, sampled_value) in enumerate(
            zip(candidate_values, sampled_values)
        )
        if sign(float(candidate_value)) != sign(float(sampled_value))
    ]


def _axis_limits(
    parts: Sequence[TrianglePart], object_center: np.ndarray, table_top_z_m: float
) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    terminal = np.concatenate(
        [
            part.triangles.reshape((-1, 3))
            for part in parts
            if part.role in {"PAD", "TIP", "SIDE"}
        ],
        axis=0,
    )
    xy_half = max(
        0.060,
        float(np.max(np.abs(terminal[:, :2] - object_center[None, :2]))) + 0.006,
    )
    xy_half = min(xy_half, 0.090)
    z_min = table_top_z_m - 0.012
    z_max = max(float(np.max(terminal[:, 2])) + 0.008, object_center[2] + 0.040)
    return (
        (float(object_center[0] - xy_half), float(object_center[0] + xy_half)),
        (float(object_center[1] - xy_half), float(object_center[1] + xy_half)),
        (float(z_min), float(z_max)),
    )


def _millimetres(values: Iterable[float]) -> str:
    return "/".join(f"{1000.0 * float(value):+.3f}" for value in values)


def _render_view(
    *,
    output_path: Path,
    dpi: int,
    candidate: Mapping[str, Any],
    status: str,
    reason: str,
    state_name: str,
    view_name: str,
    view_angles: tuple[float, float],
    parts: Sequence[TrianglePart],
    metrics: Mapping[str, Any],
    object_center: np.ndarray,
    table_top_z_m: float,
) -> None:
    figure = plt.figure(figsize=(9.6, 7.2), dpi=dpi, facecolor="#10151c")
    axis = figure.add_subplot(111, projection="3d", facecolor="#10151c")
    render_order = (
        "TABLE",
        "CONNECTOR",
        "AUTHORIZED_GRIP",
        "UPSTREAM_COLLISION",
        "SIDE",
        "TIP",
        "PAD",
    )
    for role in render_order:
        role_parts = [part for part in parts if part.role == role]
        if not role_parts:
            continue
        color, alpha = ROLE_STYLE[role]
        for part in role_parts:
            collection = Poly3DCollection(
                part.triangles,
                facecolor=color,
                edgecolor="#1b232d" if role in {"PAD", "TIP"} else "none",
                linewidth=0.04 if role in {"PAD", "TIP"} else 0.0,
                alpha=alpha,
            )
            axis.add_collection3d(collection)

    contact_points = candidate.get("predicted_contact_points_world_m")
    contact_normals = candidate.get("predicted_contact_normals_world")
    if (
        state_name == "target_grasp"
        and contact_points is not None
        and contact_normals is not None
    ):
        points = np.asarray(contact_points, dtype=np.float64)
        normals = np.asarray(contact_normals, dtype=np.float64)
        for finger_index, (point, normal) in enumerate(zip(points, normals)):
            color = FINGER_COLORS[finger_index]
            axis.scatter(
                [point[0]], [point[1]], [point[2]], s=42, c=color,
                edgecolors="black", linewidths=0.6, alpha=1.0,
                depthshade=False,
            )
            axis.quiver(
                point[0], point[1], point[2],
                normal[0], normal[1], normal[2],
                length=0.012, normalize=True, color=color,
                linewidth=1.6, alpha=1.0,
            )

    x_limit, y_limit, z_limit = _axis_limits(parts, object_center, table_top_z_m)
    axis.set_xlim(*x_limit)
    axis.set_ylim(*y_limit)
    axis.set_zlim(*z_limit)
    axis.set_box_aspect(
        (x_limit[1] - x_limit[0], y_limit[1] - y_limit[0], z_limit[1] - z_limit[0])
    )
    axis.view_init(elev=view_angles[0], azim=view_angles[1])
    axis.set_xlabel("world X [m]", color="#c8d1dc", labelpad=8)
    axis.set_ylabel("world Y [m]", color="#c8d1dc", labelpad=8)
    axis.set_zlabel("world Z [m]", color="#c8d1dc", labelpad=8)
    axis.tick_params(colors="#9aa7b5", labelsize=7)
    axis.xaxis.pane.set_alpha(0.03)
    axis.yaxis.pane.set_alpha(0.03)
    axis.zaxis.pane.set_alpha(0.03)
    axis.grid(True, color="#536170", alpha=0.18)

    title_color = "#ff4b55" if status == "REJECTED" else "#f2f5f8"
    axis.set_title(
        f"{candidate['candidate_id']} | {state_name} | {view_name}",
        color=title_color,
        fontsize=13,
        fontweight="bold",
        pad=16,
    )
    configured = metrics.get("configured_candidate_gaps_m")
    configured_text = (
        "n/a" if configured is None else _millimetres(configured)
    )
    note = (
        f"YAML PAD gap f1/f2/f3 [mm]: {configured_text}\n"
        f"Contact-face vertex SDF [mm]: "
        f"{_millimetres(metrics['computed_contact_face_to_authorized_grip_sdf_m'])}\n"
        f"Full-PAD vertex SDF [mm]: "
        f"{_millimetres(metrics['sampled_full_pad_vertex_finite_cylinder_sdf_m'])}\n"
        f"Rendered hand-to-table vertex clearance [mm]: "
        f"{1000.0 * metrics['minimum_robot_table_clearance_m']:+.3f} | "
        f"terminal AABB [mm]: "
        f"{1000.0 * metrics['minimum_interfinger_aabb_clearance_m']:+.3f}\n"
        "BLUE PAD contact | RED TIP blocker | GRAY physical shell"
    )
    figure.text(
        0.015,
        0.018,
        note,
        color="#e5ebf1",
        fontsize=8.3,
        family="monospace",
        bbox={"boxstyle": "round,pad=0.45", "fc": "#111820", "ec": "#52606d", "alpha": 0.9},
    )
    if status == "REJECTED":
        figure.text(
            0.985,
            0.018,
            f"REJECTED / {reason or 'UNSPECIFIED'}",
            color="white",
            fontsize=10,
            fontweight="bold",
            ha="right",
            va="bottom",
            bbox={"boxstyle": "round,pad=0.4", "fc": "#b80018", "ec": "#ff7785"},
        )
    figure.subplots_adjust(left=0.0, right=0.98, bottom=0.16, top=0.93)
    figure.savefig(output_path, facecolor=figure.get_facecolor())
    plt.close(figure)


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    path = Path("/usr/share/fonts/truetype/dejavu") / name
    try:
        return ImageFont.truetype(str(path), size=size)
    except OSError:
        return ImageFont.load_default()


def _contact_sheet(
    *,
    image_paths: Mapping[str, Mapping[str, Path]],
    output_path: Path,
    candidate_id: str,
    status: str,
    reason: str,
    source_description: str,
) -> None:
    tile_size = (600, 450)
    header_height = 110
    footer_height = 54
    canvas = Image.new(
        "RGB",
        (tile_size[0] * len(VIEWS), header_height + tile_size[1] * len(STATE_ORDER) + footer_height),
        "#0f141b",
    )
    draw = ImageDraw.Draw(canvas)
    status_color = (
        "#ff334b"
        if status == "REJECTED"
        else ("#ffc857" if status == "REVIEW_PENDING" else "#47d989")
    )
    draw.text((24, 14), candidate_id, fill="white", font=_font(32, bold=True))
    draw.text(
        (24, 55),
        f"STATUS: {status}" + (f" / {reason}" if reason else ""),
        fill=status_color,
        font=_font(22, bold=True),
    )
    draw.text(
        (24, 84),
        "Three planned states x four fixed views; render-only, not dynamic acceptance.",
        fill="#aeb9c5",
        font=_font(15),
    )
    for row, state_name in enumerate(STATE_ORDER):
        for column, view_name in enumerate(VIEWS):
            image = Image.open(image_paths[state_name][view_name]).convert("RGB")
            image.thumbnail(tile_size, Image.Resampling.LANCZOS)
            x = column * tile_size[0] + (tile_size[0] - image.width) // 2
            y = header_height + row * tile_size[1] + (tile_size[1] - image.height) // 2
            canvas.paste(image, (x, y))
    draw.text(
        (18, canvas.height - 39),
        f"source: {source_description}",
        fill="#95a3b2",
        font=_font(14),
    )
    canvas.save(output_path)


def _publication_coordinates(
    triangles: np.ndarray,
    *,
    object_center_world_m: np.ndarray,
    table_top_z_m: float,
) -> np.ndarray:
    reference = np.asarray(
        (
            object_center_world_m[0],
            object_center_world_m[1],
            table_top_z_m,
        ),
        dtype=np.float64,
    )
    return 1000.0 * (np.asarray(triangles, dtype=np.float64) - reference)


def _publication_limits_mm(
    parts: Sequence[TrianglePart],
    object_center_world_m: np.ndarray,
    table_top_z_m: float,
) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    x_world, y_world, z_world = _axis_limits(
        parts, object_center_world_m, table_top_z_m
    )
    return (
        (
            1000.0 * (x_world[0] - object_center_world_m[0]),
            1000.0 * (x_world[1] - object_center_world_m[0]),
        ),
        (
            1000.0 * (y_world[0] - object_center_world_m[1]),
            1000.0 * (y_world[1] - object_center_world_m[1]),
        ),
        (
            1000.0 * (z_world[0] - table_top_z_m),
            1000.0 * (z_world[1] - table_top_z_m),
        ),
    )


def _publication_clearance_text(
    candidate: Mapping[str, Any],
    state_name: str,
    metrics: Mapping[str, Any],
) -> str:
    table_mm = 1000.0 * float(metrics["minimum_robot_table_clearance_m"])
    configured = metrics.get("configured_candidate_gaps_m")
    sampled = metrics.get("sampled_full_pad_vertex_finite_cylinder_sdf_m")
    if state_name == "high_preshape":
        return (
            "Vertical offset +120.0 mm\n"
            f"Rendered hand-to-table vertex clearance: {table_mm:+.2f} mm"
        )
    if state_name == "pregrasp":
        if configured is None:
            return f"Rendered hand-to-table vertex clearance: {table_mm:+.2f} mm"
        return (
            f"Candidate contact metric: {_millimetres(configured)} mm\n"
            f"Sampled full-PAD finite-cylinder SDF: {_millimetres(sampled)} mm\n"
            f"Rendered hand-to-table vertex clearance: {table_mm:+.2f} mm"
        )
    sweep = candidate.get("complete_cad_sweep")
    if isinstance(sweep, Mapping):
        tip_mm = 1000.0 * float(sweep["minimum_tip_clearance_m"])
        other_mm = 1000.0 * float(sweep["minimum_non_pad_clearance_m"])
        self_mm = 1000.0 * float(
            sweep["minimum_terminal_self_aabb_clearance_m"]
        )
        return (
            f"Candidate contact metric: {_millimetres(configured)} mm\n"
            f"Sampled full-PAD finite-cylinder SDF: {_millimetres(sampled)} mm\n"
            f"Rendered hand-to-table vertex clearance: {table_mm:+.2f} mm\n"
            f"Sweep clearance: TIP {tip_mm:+.2f}, non-PAD {other_mm:+.2f}, "
            f"terminal {self_mm:+.2f} mm"
        )
    self_mm = 1000.0 * float(metrics["minimum_interfinger_aabb_clearance_m"])
    return (
        f"Candidate contact metric: {_millimetres(configured)} mm\n"
        f"Sampled full-PAD finite-cylinder SDF: {_millimetres(sampled)} mm\n"
        f"Rendered hand-to-table vertex clearance: {table_mm:+.2f} mm; "
        f"terminal AABB {self_mm:+.2f} mm"
    )


def _style_publication_axis(axis: Any) -> None:
    axis.set_facecolor("white")
    axis.set_proj_type("ortho")
    axis.grid(False)
    axis.set_axis_off()


def _draw_publication_table_plane(
    axis: Any,
    limits_mm: tuple[
        tuple[float, float], tuple[float, float], tuple[float, float]
    ],
) -> None:
    """Draw only the locally relevant z=0 table plane, never the full table box."""

    x_limit, y_limit, _ = limits_mm
    inset_x = 0.025 * (x_limit[1] - x_limit[0])
    inset_y = 0.025 * (y_limit[1] - y_limit[0])
    x0, x1 = x_limit[0] + inset_x, x_limit[1] - inset_x
    y0, y1 = y_limit[0] + inset_y, y_limit[1] - inset_y
    polygon = np.asarray(
        ((x0, y0, 0.0), (x1, y0, 0.0), (x1, y1, 0.0), (x0, y1, 0.0)),
        dtype=np.float64,
    )
    axis.add_collection3d(
        Poly3DCollection(
            [polygon],
            facecolor=PUBLICATION_ROLE_STYLE["TABLE"][0],
            edgecolor="#A9B0B7",
            linewidth=0.45,
            alpha=PUBLICATION_ROLE_STYLE["TABLE"][1],
            rasterized=False,
        )
    )


def _draw_publication_scale_bar(
    axis: Any,
    limits_mm: tuple[
        tuple[float, float], tuple[float, float], tuple[float, float]
    ],
    view_name: str,
) -> None:
    """Add an uncluttered projected 20 mm scale reference to every panel."""

    x_limit, y_limit, _ = limits_mm
    span = (
        y_limit[1] - y_limit[0]
        if view_name == "side"
        else x_limit[1] - x_limit[0]
    )
    fraction = min(0.20, max(0.08, 20.0 / max(span, 20.0)))
    x1 = 0.94
    x0 = x1 - fraction
    y = 0.055
    axis.add_artist(
        Line2D(
            (x0, x1),
            (y, y),
            transform=axis.transAxes,
            color="#20252A",
            linewidth=1.15,
            solid_capstyle="butt",
            clip_on=False,
        )
    )
    for x in (x0, x1):
        axis.add_artist(
            Line2D(
                (x, x),
                (y - 0.013, y + 0.013),
                transform=axis.transAxes,
                color="#20252A",
                linewidth=0.75,
                clip_on=False,
            )
        )
    axis.text2D(
        0.5 * (x0 + x1),
        y + 0.022,
        "20 mm",
        transform=axis.transAxes,
        ha="center",
        va="bottom",
        fontsize=6.1,
        color="#20252A",
    )


def _draw_publication_panel(
    *,
    axis: Any,
    publication: PublicationCandidate,
    state_name: str,
    view_name: str,
    panel_letter: str,
    panel_title: str,
    axis_limits_mm: tuple[
        tuple[float, float], tuple[float, float], tuple[float, float]
    ] | None = None,
    show_metric_text: bool = True,
    show_warning: bool = True,
    show_status_badge: bool = True,
) -> None:
    candidate = publication.source.candidate
    state = publication.states[state_name]
    _style_publication_axis(axis)
    if axis_limits_mm is None:
        axis_limits_mm = _publication_limits_mm(
            state.parts,
            publication.object_center_world_m,
            publication.table_top_z_m,
        )
    x_limit, y_limit, z_limit = axis_limits_mm
    _draw_publication_table_plane(axis, axis_limits_mm)
    render_order = (
        "CONNECTOR",
        "AUTHORIZED_GRIP",
        "UPSTREAM_COLLISION",
        "SIDE",
        "TIP",
        "PAD",
    )
    for role in render_order:
        color, alpha = PUBLICATION_ROLE_STYLE[role]
        for part in state.parts:
            if part.role != role:
                continue
            triangles_mm = _publication_coordinates(
                part.triangles,
                object_center_world_m=publication.object_center_world_m,
                table_top_z_m=publication.table_top_z_m,
            )
            collection = Poly3DCollection(
                triangles_mm,
                facecolor=color,
                edgecolor="none",
                linewidth=0.0,
                alpha=alpha,
                rasterized=False,
            )
            axis.add_collection3d(collection)

    if state_name == "target_grasp":
        contact_points = candidate.get("predicted_contact_points_world_m")
        contact_normals = candidate.get("predicted_contact_normals_world")
        if contact_points is not None and contact_normals is not None:
            reference = np.asarray(
                (
                    publication.object_center_world_m[0],
                    publication.object_center_world_m[1],
                    publication.table_top_z_m,
                ),
                dtype=np.float64,
            )
            points_mm = 1000.0 * (
                np.asarray(contact_points, dtype=np.float64) - reference
            )
            normals = np.asarray(contact_normals, dtype=np.float64)
            for point, normal in zip(points_mm, normals):
                axis.scatter(
                    [point[0]],
                    [point[1]],
                    [point[2]],
                    s=10,
                    marker="o",
                    facecolors="white",
                    edgecolors="#222222",
                    linewidths=0.65,
                    depthshade=False,
                    zorder=20,
                )
                axis.quiver(
                    point[0],
                    point[1],
                    point[2],
                    normal[0],
                    normal[1],
                    normal[2],
                    length=7.5,
                    normalize=True,
                    color="#222222",
                    linewidth=0.65,
                    arrow_length_ratio=0.22,
                )

    axis.set_xlim(*x_limit)
    axis.set_ylim(*y_limit)
    axis.set_zlim(*z_limit)
    axis.set_box_aspect(
        (
            x_limit[1] - x_limit[0],
            y_limit[1] - y_limit[0],
            z_limit[1] - z_limit[0],
        )
    )
    axis.view_init(elev=VIEWS[view_name][0], azim=VIEWS[view_name][1])
    _draw_publication_scale_bar(axis, axis_limits_mm, view_name)
    axis.text2D(
        0.01,
        0.97,
        f"({panel_letter})" + (f"  {panel_title}" if panel_title else ""),
        transform=axis.transAxes,
        ha="left",
        va="top",
        fontsize=6.8,
        fontweight="semibold",
        color="#1F2328",
    )
    if show_metric_text:
        axis.text2D(
            0.01,
            0.015,
            _publication_clearance_text(candidate, state_name, state.metrics),
            transform=axis.transAxes,
            ha="left",
            va="bottom",
            fontsize=5.5,
            color="#444B52",
        )
    disagreements = _gap_sign_disagreements(state.metrics)
    if show_warning and disagreements:
        finger_text = ", ".join(f"F{index}" for index in disagreements)
        axis.text2D(
            0.99,
            0.90,
            f"SIGN MISMATCH: {finger_text}",
            transform=axis.transAxes,
            ha="right",
            va="top",
            fontsize=5.4,
            fontweight="semibold",
            color="#7A4A00",
            bbox={
                "boxstyle": "round,pad=0.16",
                "facecolor": "#FFF4CC",
                "edgecolor": "#D18B00",
                "linewidth": 0.55,
            },
        )
    if show_status_badge and publication.source.status == "REJECTED":
        axis.text2D(
            0.99,
            0.98,
            "REJECTED",
            transform=axis.transAxes,
            ha="right",
            va="top",
            fontsize=7.1,
            fontweight="bold",
            color="#B2182B",
            bbox={
                "boxstyle": "round,pad=0.18",
                "facecolor": "#FFF2F1",
                "edgecolor": "#B2182B",
                "linewidth": 0.55,
            },
        )


def _publication_legend_handles() -> list[Any]:
    return [
        Patch(facecolor=PUBLICATION_ROLE_STYLE["PAD"][0], label="PAD contact"),
        Patch(facecolor=PUBLICATION_ROLE_STYLE["TIP"][0], label="TIP blocker"),
        Patch(facecolor=PUBLICATION_ROLE_STYLE["SIDE"][0], label="Structure"),
        Patch(facecolor=PUBLICATION_ROLE_STYLE["CONNECTOR"][0], label="Connector"),
        Patch(facecolor=PUBLICATION_ROLE_STYLE["TABLE"][0], label="Table"),
        Line2D(
            [0],
            [0],
            color="#222222",
            marker="o",
            markerfacecolor="white",
            linewidth=0.7,
            markersize=4,
            label="Contact / normal",
        ),
    ]


def _save_true_vector_and_600dpi(
    figure: Any,
    *,
    png_path: Path,
    pdf_path: Path,
    title: str,
) -> None:
    figure.savefig(
        pdf_path,
        format="pdf",
        facecolor="white",
        edgecolor="none",
        metadata={
            "Title": title,
            "Subject": "Offline full-CAD grasp-pose geometry screening",
            "Creator": "KCG full-CAD pose-card renderer",
        },
    )
    figure.savefig(
        png_path,
        format="png",
        dpi=600,
        facecolor="white",
        edgecolor="none",
        pil_kwargs={"compress_level": 7},
    )


def _publication_plate(publication: PublicationCandidate) -> tuple[Path, Path]:
    candidate = publication.source.candidate
    candidate_id = str(candidate["candidate_id"])
    png_path = publication.candidate_dir / "SCI_POSE_PLATE_600DPI.png"
    pdf_path = publication.candidate_dir / "SCI_POSE_PLATE.pdf"
    with matplotlib.rc_context(
        {
            "font.family": "DejaVu Sans",
            "font.size": 7.0,
            "axes.linewidth": 0.45,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.transparent": False,
        }
    ):
        # 178 mm is a conventional two-column journal figure width.
        figure = plt.figure(figsize=(178.0 / 25.4, 190.0 / 25.4), facecolor="white")
        shared_pregrasp_target_limits = _publication_limits_mm(
            (
                *publication.states["pregrasp"].parts,
                *publication.states["target_grasp"].parts,
            ),
            publication.object_center_world_m,
            publication.table_top_z_m,
        )
        grid = figure.add_gridspec(
            6,
            4,
            height_ratios=(1.0, 0.15, 1.0, 0.22, 1.0, 0.30),
            left=0.055,
            right=0.985,
            bottom=0.105,
            top=0.920,
            wspace=0.015,
            hspace=0.035,
        )
        letter_index = 0
        for row, state_name in enumerate(STATE_ORDER):
            for column, view_name in enumerate(VIEWS):
                axis = figure.add_subplot(grid[2 * row, column], projection="3d")
                letter = chr(ord("a") + letter_index)
                letter_index += 1
                _draw_publication_panel(
                    axis=axis,
                    publication=publication,
                    state_name=state_name,
                    view_name=view_name,
                    panel_letter=letter,
                    panel_title="",
                    axis_limits_mm=(
                        shared_pregrasp_target_limits
                        if state_name in {"pregrasp", "target_grasp"}
                        else None
                    ),
                    show_metric_text=False,
                    show_warning=False,
                    show_status_badge=False,
                )
                if row == 0:
                    axis.set_title(
                        PUBLICATION_VIEW_LABELS[view_name],
                        fontsize=7.4,
                        fontweight="semibold",
                        color="#252A2F",
                        pad=0.5,
                    )

            info_axis = figure.add_subplot(grid[2 * row + 1, :])
            info_axis.set_xticks(())
            info_axis.set_yticks(())
            for spine in info_axis.spines.values():
                spine.set_visible(False)
            state_metrics = publication.states[state_name].metrics
            disagreements = _gap_sign_disagreements(state_metrics)
            is_amber = bool(disagreements)
            info_axis.set_facecolor("#FFF4CC" if is_amber else "#F4F6F8")
            info_axis.patch.set_edgecolor("#D18B00" if is_amber else "#D7DCE1")
            info_axis.patch.set_linewidth(0.55)
            info_axis.text(
                0.008,
                0.5,
                _publication_clearance_text(candidate, state_name, state_metrics),
                transform=info_axis.transAxes,
                ha="left",
                va="center",
                fontsize=6.5,
                color="#343A40",
                linespacing=1.20,
            )
            if disagreements:
                finger_text = ", ".join(f"F{index}" for index in disagreements)
                info_axis.text(
                    0.992,
                    0.5,
                    f"AMBER: candidate/full-PAD SDF sign mismatch — {finger_text}",
                    transform=info_axis.transAxes,
                    ha="right",
                    va="center",
                    fontsize=6.4,
                    fontweight="semibold",
                    color="#7A4A00",
                )

        row_centres = (0.824, 0.548, 0.271)
        for y, state_name in zip(row_centres, STATE_ORDER):
            figure.text(
                0.018,
                y,
                PUBLICATION_ROW_LABELS[state_name],
                ha="center",
                va="center",
                rotation=90,
                fontsize=7.4,
                fontweight="semibold",
                color="#252A2F",
            )
        title_color = (
            "#B2182B" if publication.source.status == "REJECTED" else "#1F2328"
        )
        figure.suptitle(
            f"Complete-CAD grasp pose screening — {candidate_id}",
            x=0.5,
            y=0.985,
            fontsize=9.3,
            fontweight="semibold",
            color=title_color,
        )
        if publication.source.status == "REJECTED":
            figure.text(
                0.5,
                0.956,
                f"REJECTED — {publication.source.reason}",
                ha="center",
                va="top",
                fontsize=7.2,
                fontweight="bold",
                color="#B2182B",
            )
        figure.legend(
            handles=_publication_legend_handles(),
            loc="lower center",
            bbox_to_anchor=(0.5, 0.052),
            ncol=6,
            frameon=False,
            fontsize=6.4,
            handlelength=1.5,
            columnspacing=1.4,
        )
        figure.text(
            0.5,
            0.014,
            "Offline kinematic render; no physics stepped; not collision/dynamic acceptance",
            ha="center",
            va="bottom",
            fontsize=6.5,
            color="#4C535A",
        )
        _save_true_vector_and_600dpi(
            figure,
            png_path=png_path,
            pdf_path=pdf_path,
            title=f"Complete-CAD grasp pose screening — {candidate_id}",
        )
        plt.close(figure)
    return png_path, pdf_path


def _file_record(path: Path) -> dict[str, Any]:
    return {
        "path": str(path),
        "sha256": _sha256(path),
        "size_bytes": path.stat().st_size,
    }


def _pdf_vector_checks(pdf_path: Path) -> dict[str, Any]:
    """Run reviewer-facing vector-PDF checks with machine-readable evidence."""

    payload = pdf_path.read_bytes()
    checks: dict[str, Any] = {
        "pdf_magic_valid": payload.startswith(b"%PDF-"),
        "binary_image_xobject_count": payload.count(b"/Subtype /Image"),
        "pdffonts_available": shutil.which("pdffonts") is not None,
        "pdfimages_available": shutil.which("pdfimages") is not None,
    }

    if checks["pdffonts_available"]:
        completed = subprocess.run(
            ("pdffonts", str(pdf_path)),
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
        font_rows = [
            line
            for line in completed.stdout.splitlines()
            if re.search(r"\s+(?:yes|no)\s+(?:yes|no)\s+(?:yes|no)\s+\d+\s+\d+\s*$", line)
        ]
        embedded = []
        for line in font_rows:
            match = re.search(
                r"\s+(yes|no)\s+(yes|no)\s+(yes|no)\s+\d+\s+\d+\s*$",
                line,
            )
            embedded.append(bool(match and match.group(1) == "yes"))
        checks.update(
            {
                "pdffonts_returncode": completed.returncode,
                "font_row_count": len(font_rows),
                "all_fonts_embedded": bool(font_rows) and all(embedded),
                "pdffonts_stdout": completed.stdout.strip(),
                "pdffonts_stderr": completed.stderr.strip(),
            }
        )
    else:
        checks.update(
            {
                "pdffonts_returncode": None,
                "font_row_count": None,
                "all_fonts_embedded": None,
                "pdffonts_stdout": None,
                "pdffonts_stderr": None,
            }
        )

    if checks["pdfimages_available"]:
        completed = subprocess.run(
            ("pdfimages", "-list", str(pdf_path)),
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
        image_rows = [
            line
            for line in completed.stdout.splitlines()
            if re.match(r"^\s*\d+\s+\d+\s+", line)
        ]
        checks.update(
            {
                "pdfimages_returncode": completed.returncode,
                "raster_image_row_count": len(image_rows),
                "pdfimages_stdout": completed.stdout.strip(),
                "pdfimages_stderr": completed.stderr.strip(),
            }
        )
    else:
        checks.update(
            {
                "pdfimages_returncode": None,
                "raster_image_row_count": None,
                "pdfimages_stdout": None,
                "pdfimages_stderr": None,
            }
        )

    checks["true_vector_gate_passed"] = bool(
        checks["pdf_magic_valid"]
        and checks["binary_image_xobject_count"] == 0
        and checks["pdffonts_available"]
        and checks["pdffonts_returncode"] == 0
        and checks["font_row_count"]
        and checks["all_fonts_embedded"]
        and checks["pdfimages_available"]
        and checks["pdfimages_returncode"] == 0
        and checks["raster_image_row_count"] == 0
    )
    return checks


def _require_true_vector_pdf(pdf_path: Path) -> dict[str, Any]:
    checks = _pdf_vector_checks(pdf_path)
    if not checks["true_vector_gate_passed"]:
        raise RuntimeError(
            f"true-vector PDF reviewer gate failed for {pdf_path}: "
            f"{json.dumps(checks, ensure_ascii=False, sort_keys=True)}"
        )
    return checks


def _top3_comparison(
    publications: Sequence[PublicationCandidate], output_root: Path
) -> tuple[Path, Path, Path]:
    ordered = sorted(
        publications,
        key=lambda item: int(item.source.candidate.get("rank", 9999)),
    )
    if len(ordered) != 3:
        raise ValueError("SCI Top-3 comparison requires exactly three candidates")
    reference = ordered[0]
    all_target_parts = tuple(
        part
        for publication in ordered
        for part in publication.states["target_grasp"].parts
    )
    shared_limits = _publication_limits_mm(
        all_target_parts,
        reference.object_center_world_m,
        reference.table_top_z_m,
    )
    png_path = output_root / "SCI_TOP3_COMPARISON_600DPI.png"
    pdf_path = output_root / "SCI_TOP3_COMPARISON.pdf"
    manifest_path = output_root / "SCI_TOP3_COMPARISON_MANIFEST.json"
    with matplotlib.rc_context(
        {
            "font.family": "DejaVu Sans",
            "font.size": 7.0,
            "axes.linewidth": 0.45,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.transparent": False,
        }
    ):
        figure = plt.figure(figsize=(14.2, 7.4), facecolor="white")
        panel_index = 0
        for row, view_name in enumerate(("top", "oblique")):
            for column, publication in enumerate(ordered):
                candidate = publication.source.candidate
                candidate_id = str(candidate["candidate_id"])
                label = COMPARISON_LABELS.get(candidate_id, str(column + 1))
                axis = figure.add_subplot(2, 3, row * 3 + column + 1, projection="3d")
                _draw_publication_panel(
                    axis=axis,
                    publication=publication,
                    state_name="target_grasp",
                    view_name=view_name,
                    panel_letter=chr(ord("a") + panel_index),
                    panel_title=(
                        f"Candidate {label}, rank {int(candidate.get('rank', column + 1))} "
                        f"— {PUBLICATION_VIEW_LABELS[view_name]}"
                    ),
                    axis_limits_mm=shared_limits,
                )
                panel_index += 1
        figure.suptitle(
            "Top-3 complete-CAD grasp candidates at the unachieved search limit",
            x=0.5,
            y=0.987,
            fontsize=13.0,
            fontweight="semibold",
            color="#1F2328",
        )
        figure.legend(
            handles=_publication_legend_handles(),
            loc="lower center",
            bbox_to_anchor=(0.5, 0.045),
            ncol=6,
            frameon=False,
            fontsize=7.0,
            handlelength=1.5,
            columnspacing=1.4,
        )
        figure.text(
            0.5,
            0.015,
            "Offline kinematic render; no physics stepped; not collision/dynamic acceptance",
            ha="center",
            va="bottom",
            fontsize=7.2,
            color="#4C535A",
        )
        figure.subplots_adjust(
            left=0.018,
            right=0.988,
            bottom=0.095,
            top=0.945,
            wspace=0.015,
            hspace=0.08,
        )
        _save_true_vector_and_600dpi(
            figure,
            png_path=png_path,
            pdf_path=pdf_path,
            title="Top-3 complete-CAD grasp candidate comparison",
        )
        plt.close(figure)
    vector_checks = _require_true_vector_pdf(pdf_path)
    _write_json(
        manifest_path,
        {
            "schema": "D38999_FULL_CAD_GRASP_TOP3_SCI_COMPARISON_V1",
            "candidate_ids_by_rank": [
                str(item.source.candidate["candidate_id"]) for item in ordered
            ],
            "states": ["target_grasp"],
            "views": ["top", "oblique"],
            "shared_axis_limits_mm": {
                "x": list(shared_limits[0]),
                "y": list(shared_limits[1]),
                "z_above_table": list(shared_limits[2]),
            },
            "publication_files": [_file_record(png_path), _file_record(pdf_path)],
            "vector_pdf_checks": vector_checks,
            "target_state_semantics": "SEARCH_LIMIT_NOT_ACHIEVED",
            "footer": (
                "Offline kinematic render; no physics stepped; "
                "not collision/dynamic acceptance"
            ),
            "physics_started": False,
            "dynamic_acceptance_evidence": False,
        },
    )
    return png_path, pdf_path, manifest_path


def _safe_directory_name(candidate_id: str, status: str) -> str:
    cleaned = "".join(
        character if character.isalnum() or character in "-_." else "_"
        for character in candidate_id
    )
    return cleaned + ("_REJECTED" if status == "REJECTED" else "")


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def render_candidate(
    *,
    source: CandidateSource,
    config: Mapping[str, Any],
    config_path: Path,
    selected_goal: Mapping[str, Any],
    tabletop: Any,
    terminal_local: Sequence[TrianglePart],
    upstream_local: Sequence[TrianglePart],
    mesh_hashes: Mapping[str, str],
    connector_local_parts: Sequence[TrianglePart],
    connector_route: str,
    output_root: Path,
    dpi: int,
    overwrite: bool,
    publication_only: bool,
) -> CandidateRenderResult:
    candidate = source.candidate
    candidate_id = str(candidate["candidate_id"])
    candidate_dir = output_root / _safe_directory_name(candidate_id, source.status)
    expected_publication = (
        candidate_dir / "SCI_POSE_PLATE_600DPI.png",
        candidate_dir / "SCI_POSE_PLATE.pdf",
    )
    if candidate_dir.exists() and not overwrite and (
        not publication_only or any(path.exists() for path in expected_publication)
    ):
        raise FileExistsError(
            f"pose-card directory exists (use --overwrite): {candidate_dir}"
        )
    candidate_dir.mkdir(parents=True, exist_ok=True)

    hand_rotation, nominal_handbase, object_center = _candidate_pose(
        config=config,
        candidate=candidate,
        selected_goal=selected_goal,
        tabletop=tabletop,
    )
    authored_handbase_error_m = None
    if candidate.get("target_handbase_world_m") is not None:
        authored_handbase = _finite_vector(
            candidate["target_handbase_world_m"], 3, "authored target handbase"
        )
        authored_handbase_error_m = float(
            np.linalg.norm(nominal_handbase - authored_handbase)
        )
        if authored_handbase_error_m > 1.0e-9:
            raise ValueError(
                f"{candidate_id} target handbase does not match YAML geometry: "
                f"{authored_handbase_error_m} m"
            )
    target_tcp = nominal_handbase + hand_rotation @ np.asarray(
        (0.0, 0.0, 0.4), dtype=np.float64
    )
    authored_tcp_error_m = None
    if candidate.get("target_tcp_world_m") is not None:
        authored_tcp = _finite_vector(
            candidate["target_tcp_world_m"], 3, "authored target TCP"
        )
        authored_tcp_error_m = float(np.linalg.norm(target_tcp - authored_tcp))
        if authored_tcp_error_m > 1.0e-9:
            raise ValueError(
                f"{candidate_id} target TCP does not match YAML geometry: "
                f"{authored_tcp_error_m} m"
            )
    urdf_path = _dependency_path(config, "source_hand_urdf")
    table_center = np.asarray(tabletop.table.center_m, dtype=np.float64)
    table_size = np.asarray(tabletop.table.size_m, dtype=np.float64)
    table_top = float(table_center[2] + 0.5 * table_size[2])
    grip_radius = float(config["scene"]["authorized_grip_radius_m"])
    grip_height = float(config["scene"]["authorized_grip_height_m"])
    table_part = TrianglePart(
        _box_triangles(table_center, table_size),
        "TABLE",
        str(_dependency_path(config, "tabletop_config")),
        None,
    )

    state_manifest: dict[str, Any] = {}
    image_paths: dict[str, dict[str, Path]] = {}
    state_render_data: dict[str, StateRenderData] = {}
    for state_name, state in _state_specs(config, candidate).items():
        links = hand_link_transforms(
            urdf_path,
            preshape_rad=float(state["preshape_rad"]),
            finger_flexion_rad=state["flexion_rad"],
        )
        handbase = nominal_handbase + np.asarray(
            (0.0, 0.0, float(state["z_offset_m"])), dtype=np.float64
        )
        robot_parts = [
            _transform_part(part, links, hand_rotation, handbase)
            for part in (*terminal_local, *upstream_local)
        ]
        all_parts = [table_part, *connector_local_parts, *robot_parts]
        metrics = _state_metrics(
            all_parts,
            table_top_z_m=table_top,
            grip_center=object_center,
            grip_radius_m=grip_radius,
            grip_height_m=grip_height,
            configured_gaps_m=state["configured_gaps_m"],
        )
        state_manifest[state_name] = {
            "preshape_rad": float(state["preshape_rad"]),
            "flexion_rad": np.asarray(state["flexion_rad"], dtype=np.float64).tolist(),
            "handbase_world_m": handbase.tolist(),
            "vertical_offset_from_target_m": float(state["z_offset_m"]),
            **metrics,
            "candidate_vs_sampled_full_pad_sign_disagreement_fingers": (
                _gap_sign_disagreements(metrics)
            ),
        }
        state_render_data[state_name] = StateRenderData(tuple(all_parts), metrics)

        image_paths[state_name] = {
            view_name: candidate_dir / f"{state_name}_{view_name}.png"
            for view_name in VIEWS
        }
        if not publication_only:
            for view_name, view_angles in VIEWS.items():
                _render_view(
                    output_path=image_paths[state_name][view_name],
                    dpi=dpi,
                    candidate=candidate,
                    status=source.status,
                    reason=source.reason,
                    state_name=state_name,
                    view_name=view_name,
                    view_angles=view_angles,
                    parts=all_parts,
                    metrics=metrics,
                    object_center=object_center,
                    table_top_z_m=table_top,
                )

    sheet_path: Path | None = candidate_dir / "CONTACT_SHEET.png"
    if not publication_only:
        _contact_sheet(
            image_paths=image_paths,
            output_path=sheet_path,
            candidate_id=candidate_id,
            status=source.status,
            reason=source.reason,
            source_description=source.source_description,
        )
    elif not sheet_path.is_file():
        sheet_path = None

    publication = PublicationCandidate(
        source=source,
        candidate_dir=candidate_dir,
        object_center_world_m=object_center,
        table_top_z_m=table_top,
        states=state_render_data,
    )
    publication_png, publication_pdf = _publication_plate(publication)
    vector_checks = _require_true_vector_pdf(publication_pdf)

    images = [
        path
        for state in image_paths.values()
        for path in state.values()
        if path.is_file()
    ]
    if sheet_path is not None:
        images.append(sheet_path)
    manifest = {
        "schema": SCHEMA,
        "candidate_id": candidate_id,
        "render_review_status": source.status,
        "render_rejection_reason": source.reason,
        "candidate_source": source.source_description,
        "candidate": candidate,
        "config_path": str(config_path),
        "config_sha256": _sha256(config_path),
        "source_urdf_path": str(urdf_path),
        "source_urdf_sha256": _sha256(urdf_path),
        "source_mesh_sha256": dict(sorted(mesh_hashes.items())),
        "connector_geometry_route": connector_route,
        "connector_asset_path": str(_dependency_path(config, "connector_asset")),
        "connector_asset_sha256": _sha256(_dependency_path(config, "connector_asset")),
        "object_authorized_grip_center_world_m": object_center.tolist(),
        "hand_rotation_world_from_hand": hand_rotation.tolist(),
        "target_handbase_world_m": nominal_handbase.tolist(),
        "target_tcp_world_m": target_tcp.tolist(),
        "authored_target_handbase_reconstruction_error_m": authored_handbase_error_m,
        "authored_target_tcp_reconstruction_error_m": authored_tcp_error_m,
        "table_center_world_m": table_center.tolist(),
        "table_size_m": table_size.tolist(),
        "table_top_z_m": table_top,
        "states": state_manifest,
        "views": {
            name: {"elevation_deg": values[0], "azimuth_deg": values[1]}
            for name, values in VIEWS.items()
        },
        "images": [
            _file_record(path)
            for path in images
        ],
        "publication_only_mode": publication_only,
        "publication_files": [
            _file_record(publication_png),
            _file_record(publication_pdf),
        ],
        "vector_pdf_checks": vector_checks,
        "candidate_contact_metric_semantics": (
            "CONFIGURED_CANDIDATE_CONTACT_GAP; positive is separation, "
            "negative is intended PAD overlap at the unachieved search limit"
        ),
        "sampled_full_pad_sdf_semantics": (
            "MINIMUM_FINITE_CYLINDER_SDF_OVER_ALL_RENDERED_FULL_PAD_TRIANGLE_"
            "VERTICES; positive is outside, negative is inside"
        ),
        "target_state_semantics": "SEARCH_LIMIT_NOT_ACHIEVED",
        "footer": (
            "Offline kinematic render; no physics stepped; "
            "not collision/dynamic acceptance"
        ),
        "physics_started": False,
        "isaac_gui_started": False,
        "dynamic_acceptance_evidence": False,
        "collision_acceptance_claimed": False,
        "truth_boundary": (
            "OFFLINE_PRE_RUN_VISUAL_REVIEW_ONLY; CONTACTS_AND_GAPS_ARE_CONFIGURED_"
            "CANDIDATE_OR_POSTHOC_GEOMETRY_DIAGNOSTICS"
        ),
    }
    _write_json(candidate_dir / "RENDER_MANIFEST.json", manifest)
    return CandidateRenderResult(
        contact_sheet=sheet_path,
        publication_plate_png=publication_png,
        publication_plate_pdf=publication_pdf,
        publication=publication,
    )


def main(argv: Sequence[str] | None = None) -> int:
    args = _arguments(argv)
    config_path = _resolve(args.config)
    config = _yaml(config_path)
    if not isinstance(config, Mapping):
        raise TypeError("full-iiwa config must be a mapping")
    selected_goal_path = _dependency_path(config, "selected_goal_config")
    selected_goal = _yaml(selected_goal_path)
    tabletop_path = _dependency_path(config, "tabletop_config")
    tabletop = load_d38999_tabletop_scene(tabletop_path)
    sources = _candidate_sources(args, config)

    terminal_local, terminal_hashes = _terminal_local_parts()
    upstream_local, upstream_hashes = _upstream_local_parts()
    mesh_hashes = {**terminal_hashes, **upstream_hashes}
    connector_asset = _dependency_path(config, "connector_asset")
    connector_parts, connector_route = _connector_parts(
        connector_asset, tabletop.loose_settled_origin_m
    )
    if not connector_parts:
        local_center = _finite_vector(
            config["scene"]["authorized_grip_local_center_m"],
            3,
            "authorized grip center",
        )
        object_center = _finite_vector(tabletop.loose_settled_origin_m, 3, "loose origin")
        object_center += np.diag((1.0, -1.0, -1.0)) @ local_center
        grip = trimesh.creation.cylinder(
            radius=float(config["scene"]["authorized_grip_radius_m"]),
            height=float(config["scene"]["authorized_grip_height_m"]),
            sections=64,
        )
        grip.apply_translation(object_center)
        connector_parts = [
            TrianglePart(
                np.asarray(grip.triangles, dtype=np.float64),
                "AUTHORIZED_GRIP",
                str(connector_asset),
                None,
            )
        ]

    output_root = _resolve(args.output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    results = [
        render_candidate(
            source=source,
            config=config,
            config_path=config_path,
            selected_goal=selected_goal,
            tabletop=tabletop,
            terminal_local=terminal_local,
            upstream_local=upstream_local,
            mesh_hashes=mesh_hashes,
            connector_local_parts=connector_parts,
            connector_route=connector_route,
            output_root=output_root,
            dpi=args.dpi,
            overwrite=args.overwrite,
            publication_only=args.publication_only,
        )
        for source in sources
    ]
    comparison_files: list[str] = []
    if (
        args.candidate_id is None
        and args.candidate_json is None
        and not args.historical_rejected_old_top1
        and len(results) == 3
    ):
        comparison_files = [
            str(path)
            for path in _top3_comparison(
                [result.publication for result in results], output_root
            )
        ]
    print(
        json.dumps(
            {
                "schema": SCHEMA,
                "status": "RENDER_COMPLETE",
                "candidate_count": len(sources),
                "publication_only": args.publication_only,
                "contact_sheets": [
                    str(result.contact_sheet)
                    for result in results
                    if result.contact_sheet is not None
                ],
                "publication_pngs": [
                    str(result.publication_plate_png) for result in results
                ],
                "publication_pdfs": [
                    str(result.publication_plate_pdf) for result in results
                ],
                "top3_comparison_files": comparison_files,
                "physics_started": False,
                "dynamic_acceptance_evidence": False,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
