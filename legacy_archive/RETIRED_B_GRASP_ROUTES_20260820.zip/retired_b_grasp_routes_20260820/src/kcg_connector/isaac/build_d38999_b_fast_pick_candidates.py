#!/usr/bin/env python3
"""Generate deterministic B_FAST_PICK candidates from the audited PAD model."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from kcg_connector.grasp.d38999_b_fast_pick import write_candidates


REPOSITORY = Path(__file__).resolve().parents[3]
DEFAULT_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
DEFAULT_PROXY = (
    REPOSITORY
    / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2"
    / "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
    / "BLUE_PAD_CONSERVATIVE_CONVEX_PROXY_V1"
    / "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json"
)
DEFAULT_OUTPUT = REPOSITORY / "src/kcg_connector/config/d38999_b_fast_pick_candidates_v1.json"


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--proxy-manifest", default=str(DEFAULT_PROXY))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--grasp-z-mm", nargs="+", type=float, default=[14.0, 19.0, 24.0])
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    manifest = write_candidates(
        urdf_path=arguments.urdf,
        proxy_manifest_path=arguments.proxy_manifest,
        output_path=arguments.output,
        grasp_z_mm=arguments.grasp_z_mm,
    )
    print(
        f"wrote {manifest['candidate_count']} candidates to {arguments.output}; "
        f"top={manifest['candidates'][0]['candidate_id']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
