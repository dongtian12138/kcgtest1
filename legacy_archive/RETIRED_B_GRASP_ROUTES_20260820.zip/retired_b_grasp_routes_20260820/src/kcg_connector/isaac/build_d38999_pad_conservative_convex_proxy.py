#!/usr/bin/env python3

"""Build one deterministic conservative analytic-capsule PAD proxy asset."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Sequence


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from kcg_connector.grasp.d38999_pad_conservative_convex_proxy import (  # noqa: E402
    write_proxy_asset,
)


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build the deterministic B V5 conservative convex PAD proxy"
    )
    parser.add_argument("--source-asset-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    manifest = write_proxy_asset(
        Path(arguments.source_asset_dir), Path(arguments.output_dir)
    )
    print(json.dumps(manifest, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

