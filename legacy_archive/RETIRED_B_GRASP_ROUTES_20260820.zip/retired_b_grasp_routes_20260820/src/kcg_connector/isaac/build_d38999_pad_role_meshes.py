#!/usr/bin/env python3

"""Extract the exact author blue PAD_BODY surfaces for the V5 SDF route.

This builder is intentionally offline. It emits immutable source arrays and
post-hoc contact-role maps, but it does not claim that PhysX cooked an SDF or
that the geometry is dynamically usable. The Isaac compatibility smoke owns
those claims.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Sequence

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from kcg_connector.grasp.d38999_pad_contact_roles import (  # noqa: E402
    FINGER_PAD_ROLE_SPECS,
    USER_SEMANTIC_AUTHORITY,
    build_finger_pad_role,
    face_role_records,
    file_sha256,
    repository_root,
)


SCHEMA = "D38999_BLUE_PAD_SDF_SOURCE_ASSET_V1"
LOCAL_POINTS_UNIT = "metre"
COLLISION_ROUTE = "PHYSX_SDF"


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract exact author blue PAD_BODY source meshes for PhysX SDF"
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--repository-root", default=str(repository_root()))
    return parser.parse_args(argv)


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, allow_nan=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _array_sha256(value: np.ndarray, dtype: str) -> str:
    array = np.ascontiguousarray(value, dtype=np.dtype(dtype))
    return hashlib.sha256(array.tobytes()).hexdigest()


def _exact_source_arrays(build: Any) -> dict[str, np.ndarray]:
    points = np.ascontiguousarray(build.pad_component.vertices, dtype="<f8")
    faces = np.ascontiguousarray(build.pad_component.faces, dtype="<i8")
    return {
        "points_local_m": points,
        "face_vertex_counts": np.full(len(faces), 3, dtype="<i4"),
        "face_vertex_indices": faces.reshape(-1).astype("<i4", copy=False),
        "faces": faces,
        "pad_contact_face_ids": np.ascontiguousarray(
            build.pad_contact_face_ids, dtype="<i8"
        ),
        "pad_side_face_ids": np.ascontiguousarray(
            build.pad_side_face_ids, dtype="<i8"
        ),
    }


def _exact_component_arrays(component: Any) -> dict[str, np.ndarray]:
    points = np.ascontiguousarray(component.vertices, dtype="<f8")
    faces = np.ascontiguousarray(component.faces, dtype="<i8")
    return {
        "points_local_m": points,
        "face_vertex_counts": np.full(len(faces), 3, dtype="<i4"),
        "face_vertex_indices": faces.reshape(-1).astype("<i4", copy=False),
        "faces": faces,
    }


def generate_pad_role_assets(output_dir: Path, root: Path) -> dict[str, Any]:
    """Create exact blue PAD inputs in a new evidence directory."""

    output_dir = Path(output_dir).resolve()
    root = Path(root).resolve()
    if output_dir.exists():
        raise FileExistsError(f"refusing to overwrite PAD SDF source output: {output_dir}")
    output_dir.mkdir(parents=True, exist_ok=False)

    links: list[dict[str, Any]] = []
    for spec in FINGER_PAD_ROLE_SPECS:
        source = (
            root
            / "src"
            / "iiwa_description"
            / "meshes"
            / "hand"
            / f"{spec.link_name}.STL"
        )
        build = build_finger_pad_role(spec, source)
        arrays = _exact_source_arrays(build)
        tip_arrays = _exact_component_arrays(build.tip_component)
        mesh_name = f"{spec.link_name}_PAD_BODY_exact_source_local_m.npz"
        mesh_path = output_dir / mesh_name
        np.savez_compressed(mesh_path, **arrays)
        tip_mesh_name = f"{spec.link_name}_TIP_exact_source_local_m.npz"
        tip_mesh_path = output_dir / tip_mesh_name
        np.savez_compressed(tip_mesh_path, **tip_arrays)

        role_map_name = f"{spec.link_name}_contact_role_map.json"
        role_map_path = output_dir / role_map_name
        _write_json(
            role_map_path,
            {
                "schema": SCHEMA,
                "link_name": spec.link_name,
                "finger_number": spec.finger_number,
                "semantic_authority": USER_SEMANTIC_AUTHORITY,
                "source_mesh": str(source.relative_to(root)),
                "source_mesh_sha256": build.source_sha256,
                "online_control_use_allowed": False,
                "posthoc_evaluation_use_allowed": True,
                "faces": face_role_records(build),
            },
        )

        diagnostics = dict(build.diagnostics)
        diagnostics.update(
            {
                "collision_route": COLLISION_ROUTE,
                "exact_author_pad_body_extracted": True,
                "pad_collision_source_mesh_count": 1,
                "physx_sdf_approximation_authored": False,
                "physx_sdf_cooked_verified": False,
                "whole_distal_link_convex_hull_allowed": False,
                "whole_distal_link_convex_hull_runtime_removal_verified": False,
                "coacd_used": False,
                "analytic_convex_proxy_used": False,
                "fixed_convex_piece_limit": None,
                "pad_all_surface_reconstruction_tolerance_m": None,
                "connector_event_50um_reused_as_pad_mesh_gate": False,
                "per_tread_collision_reconstruction_used": False,
                "pad_body_material_binding_scope": "ONE_PAD_FRICTION_MATERIAL",
                "formal_valid_role": "PAD_CONTACT_SURFACE_ONLY",
            }
        )
        links.append(
            {
                "finger_number": spec.finger_number,
                "link_name": spec.link_name,
                "source_mesh": str(source.relative_to(root)),
                "source_mesh_sha256": build.source_sha256,
                "pad_component_rank_by_area_diagnostic_only": int(
                    build.pad_component_rank_by_area
                ),
                "tip_component_rank_by_area_diagnostic_only": int(
                    build.tip_component_rank_by_area
                ),
                "pad_sdf_source_arrays": mesh_name,
                "pad_sdf_source_arrays_sha256": file_sha256(mesh_path),
                "tip_base_collision_source_arrays": tip_mesh_name,
                "tip_base_collision_source_arrays_sha256": file_sha256(
                    tip_mesh_path
                ),
                "points_local_m_sha256": _array_sha256(
                    arrays["points_local_m"], "<f8"
                ),
                "faces_sha256": _array_sha256(arrays["faces"], "<i8"),
                "tip_points_local_m_sha256": _array_sha256(
                    tip_arrays["points_local_m"], "<f8"
                ),
                "tip_faces_sha256": _array_sha256(
                    tip_arrays["faces"], "<i8"
                ),
                "pad_contact_face_ids_sha256": _array_sha256(
                    arrays["pad_contact_face_ids"], "<i8"
                ),
                "contact_role_map": role_map_name,
                "contact_role_map_sha256": file_sha256(role_map_path),
                "diagnostics": diagnostics,
            }
        )

    manifest = {
        "schema": SCHEMA,
        "status": "STATIC_EXACT_BLUE_PAD_SOURCE_EXTRACTED_SDF_COOKING_PENDING",
        "source_authority": "AUTHORED_HAND_STL_GEOMETRY",
        "semantic_authority": USER_SEMANTIC_AUTHORITY,
        "collision_route": COLLISION_ROUTE,
        "local_points_unit": LOCAL_POINTS_UNIT,
        "pad_collision_source_mesh_count_per_finger": 1,
        "visual_geometry_changed": False,
        "robot_mass_or_inertia_changed": False,
        "finger_dimensions_expanded": False,
        "whole_distal_link_convex_hull_allowed": False,
        "whole_distal_link_convex_hull_runtime_removal_verified": False,
        "fixed_convex_piece_limit": None,
        "pad_all_surface_reconstruction_tolerance_m": None,
        "connector_event_50um_reused_as_pad_mesh_gate": False,
        "coacd_used": False,
        "per_tread_collision_reconstruction_used": False,
        "isaac_sdf_cooked_verified": False,
        "dynamic_use_allowed": False,
        "online_control_role_truth_allowed": False,
        "posthoc_role_evaluation_allowed": True,
        "links": links,
    }
    manifest_path = output_dir / "PAD_SDF_SOURCE_ASSET_MANIFEST.json"
    _write_json(manifest_path, manifest)
    return manifest


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    manifest = generate_pad_role_assets(
        Path(arguments.output_dir), Path(arguments.repository_root)
    )
    print(json.dumps(manifest, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
