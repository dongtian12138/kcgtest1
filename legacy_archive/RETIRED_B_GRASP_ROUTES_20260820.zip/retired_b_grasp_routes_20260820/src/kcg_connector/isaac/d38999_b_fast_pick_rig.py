#!/usr/bin/env python3
"""Primitive-only three-finger D38999 tabletop pick baseline.

The runner is intentionally independent from the historical H1--H25 stack.
It imports the real hand joint topology and inertias, removes every mesh
visual/collider from the temporary rig, attaches only the 15 audited blue-PAD
capsules, and lifts a 0.31 kg analytic coupling-nut cylinder with a world-Z
prismatic rig joint.  It is a fast physics baseline, not a formal iiwa B pass.

Online control uses only joint state and measured finger-root effort. Object
pose and contact reports are sampled on a fixed schedule for post-hoc scoring
and never influence the commanded trajectory.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np
import yaml

from kcg_connector.grasp.d38999_b_fast_pick import minimum_jerk


REPOSITORY = Path(__file__).resolve().parents[3]
DEFAULT_CONFIG = REPOSITORY / "src/kcg_connector/config/d38999_b_fast_pick_v1.yaml"
DEFAULT_CANDIDATES = (
    REPOSITORY / "src/kcg_connector/config/d38999_b_fast_pick_candidates_v1.json"
)
DEFAULT_PROXY = (
    REPOSITORY
    / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2"
    / "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
    / "BLUE_PAD_CONSERVATIVE_CONVEX_PROXY_V1"
    / "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json"
)
DEFAULT_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
SCHEMA = "D38999_B_FAST_PICK_RIG_RESULT_V1"
TERMINAL_LINKS = ("f1Link3", "f2Link2", "f3Link3")
HAND_LINKS = (
    "handbase_link",
    "f1Link1",
    "f1Link2",
    "f1Link3",
    "f2Link1",
    "f2Link2",
    "f3Link1",
    "f3Link2",
    "f3Link3",
)
HAND_JOINTS = (
    "f1j1",
    "f1j2",
    "f1j3",
    "f2j1",
    "f2j2",
    "f3j1",
    "f3j2",
    "f3j3",
)
ACTIVE_JOINTS = ("f1j1", "f1j2", "f2j1", "f3j2")
ROOT_TORQUE_JOINTS = ("f1j2", "f2j1", "f3j2")


def _sha256(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--candidates", default=str(DEFAULT_CANDIDATES))
    parser.add_argument("--proxy-manifest", default=str(DEFAULT_PROXY))
    parser.add_argument("--source-urdf", default=str(DEFAULT_URDF))
    parser.add_argument("--candidate-id", default="PAD_Z19")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--kit-portable-root", required=True)
    parser.add_argument("--gui", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args(argv)


def _rpy_matrix(rpy: Sequence[float]) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.asarray(
        [
            [cp * cy, sr * sp * cy - cr * sy, cr * sp * cy + sr * sy],
            [cp * sy, sr * sp * sy + cr * cy, cr * sp * sy - sr * cy],
            [-sp, sr * cp, cr * cp],
        ],
        dtype=np.float64,
    )


def _quat_wxyz_to_matrix(quaternion: Sequence[float]) -> np.ndarray:
    values = np.asarray(quaternion, dtype=np.float64)
    if values.shape != (4,) or not np.all(np.isfinite(values)):
        raise ValueError("quaternion must contain four finite values")
    norm = float(np.linalg.norm(values))
    if norm <= 1.0e-12:
        raise ValueError("quaternion norm must be positive")
    w, x, y, z = values / norm
    return np.asarray(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def _tilt_angle_rad(initial_quaternion: Sequence[float], final_quaternion: Sequence[float]) -> float:
    initial_axis = _quat_wxyz_to_matrix(initial_quaternion)[:, 2]
    final_axis = _quat_wxyz_to_matrix(final_quaternion)[:, 2]
    cosine = float(np.clip(initial_axis @ final_axis, -1.0, 1.0))
    return float(math.acos(cosine))


def _load_inputs(arguments: argparse.Namespace) -> tuple[
    dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]
]:
    config = yaml.safe_load(Path(arguments.config).read_text(encoding="utf-8"))
    candidates = json.loads(Path(arguments.candidates).read_text(encoding="utf-8"))
    proxy = json.loads(Path(arguments.proxy_manifest).read_text(encoding="utf-8"))
    if config.get("schema_version") != "d38999_b_fast_pick_v1":
        raise ValueError("unexpected fast-pick config schema")
    if candidates.get("schema") != "D38999_B_FAST_PICK_CANDIDATES_V1":
        raise ValueError("unexpected candidate manifest schema")
    if proxy.get("collision_route") != "CONSERVATIVE_CONVEX_PAD_PROXY":
        raise ValueError("unexpected PAD proxy route")
    if proxy.get("whole_terminal_convex_hull_count") != 0:
        raise ValueError("old terminal convex hull is not allowed")
    matching = [
        row for row in candidates["candidates"] if row["candidate_id"] == arguments.candidate_id
    ]
    if len(matching) != 1:
        raise ValueError(f"candidate not found or duplicated: {arguments.candidate_id}")
    candidate = matching[0]
    return config, candidates, proxy, candidate


def _inertial_link(name: str, mass: float = 0.001) -> ET.Element:
    link = ET.Element("link", {"name": name})
    inertial = ET.SubElement(link, "inertial")
    ET.SubElement(inertial, "origin", {"xyz": "0 0 0", "rpy": "0 0 0"})
    ET.SubElement(inertial, "mass", {"value": f"{mass:.9g}"})
    ET.SubElement(
        inertial,
        "inertia",
        {
            "ixx": "1e-6",
            "ixy": "0",
            "ixz": "0",
            "iyy": "1e-6",
            "iyz": "0",
            "izz": "1e-6",
        },
    )
    return link


def _element_digest(element: ET.Element) -> str:
    normalized = copy.deepcopy(element)
    for node in normalized.iter():
        node.tail = None
    return hashlib.sha256(ET.tostring(normalized, encoding="utf-8")).hexdigest()


def _build_fast_rig_urdf(
    *,
    source_urdf: Path,
    destination: Path,
    handbase_world_xyz: Sequence[float],
    hand_mount_rpy: Sequence[float],
) -> dict[str, Any]:
    source_root = ET.parse(source_urdf).getroot()
    output_root = ET.Element("robot", {"name": "d38999_b_fast_pick_rig"})
    output_root.append(_inertial_link("rig_base_link"))
    output_root.append(_inertial_link("lift_carriage_link"))
    source_links = {link.get("name"): link for link in source_root.findall("link")}
    source_joints = {joint.get("name"): joint for joint in source_root.findall("joint")}
    inertial_digests: dict[str, str] = {}
    removed_visuals = 0
    removed_collisions = 0
    for name in HAND_LINKS:
        link = source_links.get(name)
        if link is None:
            raise ValueError(f"source URDF missing {name}")
        copied = copy.deepcopy(link)
        inertial = copied.find("inertial")
        if inertial is None:
            raise ValueError(f"source URDF missing inertial on {name}")
        inertial_digests[name] = _element_digest(inertial)
        for visual in list(copied.findall("visual")):
            copied.remove(visual)
            removed_visuals += 1
        for collision in list(copied.findall("collision")):
            copied.remove(collision)
            removed_collisions += 1
        output_root.append(copied)

    lift_joint = ET.SubElement(output_root, "joint", {"name": "lift_z", "type": "prismatic"})
    ET.SubElement(lift_joint, "parent", {"link": "rig_base_link"})
    ET.SubElement(lift_joint, "child", {"link": "lift_carriage_link"})
    ET.SubElement(
        lift_joint,
        "origin",
        {
            "xyz": " ".join(f"{float(v):.12g}" for v in handbase_world_xyz),
            "rpy": "0 0 0",
        },
    )
    ET.SubElement(lift_joint, "axis", {"xyz": "0 0 1"})
    ET.SubElement(
        lift_joint,
        "limit",
        {"lower": "0", "upper": "0.05", "effort": "500", "velocity": "0.10"},
    )
    ET.SubElement(lift_joint, "dynamics", {"damping": "10", "friction": "0"})

    mount = ET.SubElement(output_root, "joint", {"name": "hand_mount", "type": "fixed"})
    ET.SubElement(mount, "parent", {"link": "lift_carriage_link"})
    ET.SubElement(mount, "child", {"link": "handbase_link"})
    ET.SubElement(
        mount,
        "origin",
        {
            "xyz": "0 0 0",
            "rpy": " ".join(f"{float(v):.12g}" for v in hand_mount_rpy),
        },
    )

    for name in HAND_JOINTS:
        joint = source_joints.get(name)
        if joint is None:
            raise ValueError(f"source URDF missing {name}")
        output_root.append(copy.deepcopy(joint))

    tree = ET.ElementTree(output_root)
    ET.indent(tree, space="  ")
    tree.write(destination, encoding="utf-8", xml_declaration=True)
    check = ET.parse(destination).getroot()
    for name in HAND_LINKS:
        link = check.find(f"link[@name='{name}']")
        if link is None or link.findall("visual") or link.findall("collision"):
            raise AssertionError(f"fast rig retained mesh geometry on {name}")
        if _element_digest(link.find("inertial")) != inertial_digests[name]:
            raise AssertionError(f"fast rig changed inertial on {name}")
    return {
        "source_urdf": str(source_urdf),
        "source_urdf_sha256": _sha256(source_urdf),
        "temporary_urdf": str(destination),
        "hand_links": list(HAND_LINKS),
        "hand_joints": list(HAND_JOINTS),
        "removed_visual_count": removed_visuals,
        "removed_collision_count": removed_collisions,
        "all_mesh_collisions_removed": removed_collisions > 0,
        "real_hand_inertials_preserved": True,
        "lift_joint_added": True,
    }


def _candidate_world_geometry(config: Mapping[str, Any], candidate: Mapping[str, Any]) -> dict[str, Any]:
    rpy = np.asarray(config["hand_mount"]["rpy_rad"], dtype=np.float64)
    rotation = _rpy_matrix(rpy)
    object_world = np.asarray(config["object"]["world_center_m"], dtype=np.float64)
    object_hand = np.asarray(
        [
            candidate["object_axis_center_xy_hand_m"][0],
            candidate["object_axis_center_xy_hand_m"][1],
            candidate["object_center_z_hand_m"],
        ],
        dtype=np.float64,
    )
    handbase_world = object_world - rotation @ object_hand
    return {
        "hand_mount_rpy_rad": rpy.tolist(),
        "handbase_world_xyz_m": handbase_world.tolist(),
        "object_world_center_m": object_world.tolist(),
        "object_center_hand_m": object_hand.tolist(),
        "rotation_world_from_hand": rotation.tolist(),
    }


def _dry_run(arguments: argparse.Namespace) -> dict[str, Any]:
    config, candidates, proxy, candidate = _load_inputs(arguments)
    geometry = _candidate_world_geometry(config, candidate)
    output = Path(arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    rig_urdf = output / "d38999_b_fast_pick_rig.urdf"
    urdf_evidence = _build_fast_rig_urdf(
        source_urdf=Path(arguments.source_urdf).resolve(),
        destination=rig_urdf,
        handbase_world_xyz=geometry["handbase_world_xyz_m"],
        hand_mount_rpy=geometry["hand_mount_rpy_rad"],
    )
    report = {
        "schema": SCHEMA,
        "status": "DRY_RUN_PASS",
        "candidate": candidate,
        "candidate_manifest_sha256": _sha256(arguments.candidates),
        "proxy_manifest_sha256": _sha256(arguments.proxy_manifest),
        "config_sha256": _sha256(arguments.config),
        "geometry": geometry,
        "rig_urdf": urdf_evidence,
        "pad_primitive_count": proxy["pad_collision_primitive_count_total"],
        "old_whole_terminal_hull_count": proxy["whole_terminal_convex_hull_count"],
        "formal_b_passed": False,
    }
    _write_json(output / "B_FAST_PICK_DRY_RUN_RESULT.json", report)
    return report


def _run_isaac(arguments: argparse.Namespace) -> dict[str, Any]:
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation, SingleRigidPrim
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    import omni.usd
    from pxr import Gf, PhysicsSchemaTools, PhysxSchema, Sdf, Usd, UsdGeom, UsdPhysics, UsdShade

    config, candidates, proxy, candidate = _load_inputs(arguments)
    output = Path(arguments.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    geometry = _candidate_world_geometry(config, candidate)
    rig_urdf = output / "d38999_b_fast_pick_rig.urdf"
    urdf_evidence = _build_fast_rig_urdf(
        source_urdf=Path(arguments.source_urdf).resolve(),
        destination=rig_urdf,
        handbase_world_xyz=geometry["handbase_world_xyz_m"],
        hand_mount_rpy=geometry["hand_mount_rpy_rad"],
    )
    import_dir = output / "rig_usd"
    import_dir.mkdir()
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=str(rig_urdf),
            usd_path=str(import_dir),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    if not imported_path.exists():
        raise RuntimeError(f"URDF import failed: {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / float(config["simulation"]["physics_rate_hz"]),
        rendering_dt=1.0 / float(config["simulation"]["rendering_rate_hz"]),
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/FastRig")

    articulation_roots = [
        prim for prim in stage.Traverse() if prim.HasAPI(UsdPhysics.ArticulationRootAPI)
    ]
    if len(articulation_roots) != 1:
        raise RuntimeError(f"expected one articulation root, got {len(articulation_roots)}")
    articulation_root = articulation_roots[0]
    imported_collisions = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(articulation_root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if imported_collisions:
        raise RuntimeError(f"mesh-free rig imported collisions: {imported_collisions}")

    physics_scenes = [prim for prim in stage.Traverse() if prim.IsA(UsdPhysics.Scene)]
    if len(physics_scenes) != 1:
        raise RuntimeError("expected one physics scene")
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scenes[0])
    physx_scene.CreateEnableGPUDynamicsAttr().Set(False)
    physx_scene.CreateBroadphaseTypeAttr().Set("MBP")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(-9.81)

    material_scope = "/World/PhysicsMaterials"
    UsdGeom.Scope.Define(stage, material_scope)

    def material(path: str, static: float, dynamic: float) -> Any:
        value = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(value.GetPrim())
        api.CreateStaticFrictionAttr(float(static))
        api.CreateDynamicFrictionAttr(float(dynamic))
        api.CreateRestitutionAttr(0.0)
        return value

    pad_material = material(
        material_scope + "/PAD_FRICTION",
        config["friction"]["nominal_pad_object"],
        config["friction"]["nominal_pad_object"],
    )
    object_material = material(
        material_scope + "/OBJECT_FRICTION",
        config["friction"]["nominal_pad_object"],
        config["friction"]["nominal_pad_object"],
    )
    table_material = material(
        material_scope + "/TABLE_FRICTION",
        config["friction"]["table_static"],
        config["friction"]["table_dynamic"],
    )

    entries = {str(row["link_name"]): row for row in proxy["links"]}
    pad_paths_by_finger: dict[str, set[str]] = {}
    terminal_prims: dict[str, Any] = {}
    for link_name in TERMINAL_LINKS:
        matches = [
            prim
            for prim in stage.Traverse()
            if prim.GetName() == link_name and prim.HasAPI(UsdPhysics.RigidBodyAPI)
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one rigid prim for {link_name}, got {len(matches)}")
        terminal = matches[0]
        if terminal.IsInstanceProxy():
            raise RuntimeError(f"terminal remained instance proxy: {terminal.GetPath()}")
        if terminal.IsInstance():
            terminal.SetInstanceable(False)
            terminal = stage.GetPrimAtPath(terminal.GetPath())
        terminal_prims[link_name] = terminal
        PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
        pad_paths: set[str] = set()
        for capsule in entries[link_name]["capsules"]:
            path = str(terminal.GetPath()) + "/" + str(capsule["prim_name"])
            geometry_prim = UsdGeom.Capsule.Define(stage, path)
            geometry_prim.CreateAxisAttr(UsdGeom.Tokens.z)
            radius = float(capsule["radius_m"])
            height = float(capsule["cylinder_height_m"])
            geometry_prim.CreateRadiusAttr(radius)
            geometry_prim.CreateHeightAttr(height)
            xform = UsdGeom.Xformable(geometry_prim)
            xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
            rotation = Gf.Rotation(
                Gf.Vec3d(0.0, 0.0, 1.0), Gf.Vec3d(*capsule["axis_unit_local"])
            )
            xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
            UsdPhysics.CollisionAPI.Apply(geometry_prim.GetPrim()).CreateCollisionEnabledAttr(True)
            collision = PhysxSchema.PhysxCollisionAPI.Apply(geometry_prim.GetPrim())
            collision.CreateContactOffsetAttr(0.001)
            collision.CreateRestOffsetAttr(0.0)
            UsdShade.MaterialBindingAPI(geometry_prim.GetPrim()).Bind(
                pad_material, materialPurpose="physics"
            )
            geometry_prim.GetPrim().CreateAttribute(
                "kcg:collisionRole", Sdf.ValueTypeNames.Token
            ).Set("PAD_CONTACT_SURFACE_PROXY")
            geometry_prim.GetPrim().CreateAttribute(
                "kcg:finger", Sdf.ValueTypeNames.Token
            ).Set(link_name)
            pad_paths.add(path)
        pad_paths_by_finger[link_name] = pad_paths

    table = UsdGeom.Cube.Define(stage, "/World/Table")
    table.CreateSizeAttr(1.0)
    table_xform = UsdGeom.Xformable(table)
    half_xy = float(config["table"]["half_extent_xy_m"])
    thickness = float(config["table"]["thickness_m"])
    top_z = float(config["table"]["top_z_m"])
    table_xform.AddTranslateOp().Set(Gf.Vec3d(0.0, 0.0, top_z - 0.5 * thickness))
    table_xform.AddScaleOp().Set(Gf.Vec3f(2.0 * half_xy, 2.0 * half_xy, thickness))
    UsdPhysics.CollisionAPI.Apply(table.GetPrim()).CreateCollisionEnabledAttr(True)
    UsdShade.MaterialBindingAPI(table.GetPrim()).Bind(table_material, materialPurpose="physics")

    object_path = "/World/FastConnector"
    obj = UsdGeom.Cylinder.Define(stage, object_path)
    obj.CreateAxisAttr(UsdGeom.Tokens.z)
    obj.CreateRadiusAttr(float(config["object"]["radius_m"]))
    obj.CreateHeightAttr(float(config["object"]["height_m"]))
    obj_xform = UsdGeom.Xformable(obj)
    obj_xform.AddTranslateOp().Set(Gf.Vec3d(*geometry["object_world_center_m"]))
    UsdPhysics.CollisionAPI.Apply(obj.GetPrim()).CreateCollisionEnabledAttr(True)
    UsdPhysics.RigidBodyAPI.Apply(obj.GetPrim()).CreateRigidBodyEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(obj.GetPrim()).CreateMassAttr(float(config["object"]["mass_kg"]))
    obj_collision = PhysxSchema.PhysxCollisionAPI.Apply(obj.GetPrim())
    obj_collision.CreateContactOffsetAttr(0.001)
    obj_collision.CreateRestOffsetAttr(0.0)
    UsdShade.MaterialBindingAPI(obj.GetPrim()).Bind(object_material, materialPurpose="physics")
    PhysxSchema.PhysxContactReportAPI.Apply(obj.GetPrim()).CreateThresholdAttr().Set(0.0)

    robot = world.scene.add(
        SingleArticulation(prim_path=str(articulation_root.GetPath()), name="b_fast_pick_rig")
    )
    object_view = world.scene.add(SingleRigidPrim(prim_path=object_path, name="fast_connector"))

    stage_path = output / "B_FAST_PICK_STAGE.usda"
    trace_path = output / "B_FAST_PICK_TRACE.csv"
    world.reset()
    stage.Export(str(stage_path))

    dof_names = list(robot.dof_names)
    required = ("lift_z",) + ACTIVE_JOINTS + ROOT_TORQUE_JOINTS
    missing = [name for name in required if name not in dof_names]
    if missing:
        raise RuntimeError(f"rig articulation missing DOFs: {missing}; got {dof_names}")
    indices = {name: dof_names.index(name) for name in set(required)}
    controller = robot.get_articulation_controller()
    kps = np.zeros(robot.num_dof, dtype=np.float32)
    kds = np.zeros(robot.num_dof, dtype=np.float32)
    kps[indices["lift_z"]] = float(config["lift_control"]["kp"])
    kds[indices["lift_z"]] = float(config["lift_control"]["kd"])
    for name in ACTIVE_JOINTS:
        kps[indices[name]] = float(config["finger_control"]["kp"])
        kds[indices[name]] = float(config["finger_control"]["kd"])
    controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

    initial_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
    initial_positions[indices["lift_z"]] = 0.0
    initial_positions[indices["f1j1"]] = float(config["finger_control"]["open_preshape_rad"])
    for name in ROOT_TORQUE_JOINTS:
        initial_positions[indices[name]] = float(config["finger_control"]["open_flexion_rad"])
    robot.set_joint_positions(initial_positions)
    robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))

    rate = float(config["simulation"]["physics_rate_hz"])
    candidate_targets = np.asarray(candidate["finger_flexion_targets_rad"], dtype=np.float64)
    preshape_target = float(candidate["preshape_rad"])
    current_targets = {
        "lift_z": 0.0,
        "f1j1": float(config["finger_control"]["open_preshape_rad"]),
        "f1j2": float(config["finger_control"]["open_flexion_rad"]),
        "f2j1": float(config["finger_control"]["open_flexion_rad"]),
        "f3j2": float(config["finger_control"]["open_flexion_rad"]),
    }
    trace: list[dict[str, Any]] = []
    phase_snapshots: list[dict[str, Any]] = []
    interface = get_physx_simulation_interface()
    pad_impulse_by_finger = {name: 0.0 for name in TERMINAL_LINKS}
    table_impulse = 0.0
    initial_object_position_raw, initial_object_orientation_raw = object_view.get_world_pose()
    initial_object_position = np.asarray(initial_object_position_raw, dtype=np.float64)
    initial_object_orientation = np.asarray(initial_object_orientation_raw, dtype=np.float64)
    tare_samples: list[np.ndarray] = []

    def apply_targets() -> None:
        names = tuple(current_targets)
        robot.apply_action(
            ArticulationAction(
                joint_positions=np.asarray([current_targets[name] for name in names], dtype=np.float32),
                joint_indices=np.asarray([indices[name] for name in names], dtype=np.int32),
            )
        )

    def sample_posthoc_contacts() -> tuple[dict[str, float], float]:
        per_finger = {name: 0.0 for name in TERMINAL_LINKS}
        table_value = 0.0
        headers, contacts, _friction = interface.get_full_contact_report()
        for header in headers:
            p0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
            p1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
            pair = {p0, p1}
            start = int(header.contact_data_offset)
            stop = start + int(header.num_contact_data)
            impulse = sum(float(np.linalg.norm(np.asarray(c.impulse, dtype=np.float64))) for c in contacts[start:stop])
            if object_path in pair and "/World/Table" in pair:
                table_value += impulse
            if object_path in pair:
                for finger, paths in pad_paths_by_finger.items():
                    if any(path in pair for path in paths):
                        per_finger[finger] += impulse
        return per_finger, table_value

    def step(phase: str, phase_step: int) -> np.ndarray:
        nonlocal table_impulse
        apply_targets()
        started = time.perf_counter()
        world.step(render=bool(arguments.gui))
        elapsed = time.perf_counter() - started
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
        efforts = np.asarray(
            robot.get_measured_joint_efforts(
                joint_indices=np.asarray([indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32)
            ),
            dtype=np.float64,
        )
        if not (np.all(np.isfinite(positions)) and np.all(np.isfinite(velocities)) and np.all(np.isfinite(efforts))):
            raise RuntimeError("non-finite rig state")
        per_finger, table_value = sample_posthoc_contacts()
        for name, value in per_finger.items():
            pad_impulse_by_finger[name] += value
        table_impulse += table_value
        row = {
            "step": len(trace) + 1,
            "phase": phase,
            "phase_step": phase_step,
            "lift_target_m": current_targets["lift_z"],
            "lift_position_m": float(positions[indices["lift_z"]]),
            "preshape_target_rad": current_targets["f1j1"],
            "f1_target_rad": current_targets["f1j2"],
            "f2_target_rad": current_targets["f2j1"],
            "f3_target_rad": current_targets["f3j2"],
            "f1_position_rad": float(positions[indices["f1j2"]]),
            "f2_position_rad": float(positions[indices["f2j1"]]),
            "f3_position_rad": float(positions[indices["f3j2"]]),
            "f1_effort_nm": float(efforts[0]),
            "f2_effort_nm": float(efforts[1]),
            "f3_effort_nm": float(efforts[2]),
            "f1_pad_impulse_ns": float(per_finger["f1Link3"]),
            "f2_pad_impulse_ns": float(per_finger["f2Link2"]),
            "f3_pad_impulse_ns": float(per_finger["f3Link3"]),
            "table_impulse_ns": float(table_value),
            "step_wall_s": elapsed,
        }
        trace.append(row)
        return efforts

    # Fixed schedule: no object/contact truth affects the commands.
    for index in range(120):
        step("OPEN_SETTLE", index)
        tare_samples.append(
            np.asarray(
                robot.get_measured_joint_efforts(
                    joint_indices=np.asarray([indices[name] for name in ROOT_TORQUE_JOINTS], dtype=np.int32)
                ),
                dtype=np.float64,
            )
        )
    tare = np.mean(np.stack(tare_samples), axis=0)

    for index in range(240):
        blend = minimum_jerk((index + 1) / 240.0)
        current_targets["f1j1"] = float(config["finger_control"]["open_preshape_rad"]) + blend * (
            preshape_target - float(config["finger_control"]["open_preshape_rad"])
        )
        step("PRESHAPE", index)

    open_flex = float(config["finger_control"]["open_flexion_rad"])
    for index in range(480):
        blend = minimum_jerk((index + 1) / 480.0)
        for name, target in zip(ROOT_TORQUE_JOINTS, candidate_targets):
            current_targets[name] = open_flex + blend * (float(target) - open_flex)
        step("PAD_CLOSE", index)

    target_torque = float(config["finger_control"]["target_root_torque_delta_nm"])
    max_extra = float(config["finger_control"]["maximum_extra_closure_rad"])
    build_start = np.asarray([current_targets[name] for name in ROOT_TORQUE_JOINTS])
    for index in range(600):
        efforts = step("FORCE_BUILD", index)
        deltas = np.abs(efforts - tare)
        if np.all(deltas >= target_torque):
            break
        for finger_index, name in enumerate(ROOT_TORQUE_JOINTS):
            if deltas[finger_index] < target_torque:
                current_targets[name] = min(
                    build_start[finger_index] + max_extra,
                    current_targets[name]
                    + float(config["finger_control"]["common_closure_increment_rad"]),
                )

    for index in range(round(float(config["lift_control"]["settle_before_lift_s"]) * rate)):
        step("GRIP_SETTLE", index)
    phase_snapshots.append({"phase": "GRIP_SETTLE", "object_pose": [v.tolist() for v in object_view.get_world_pose()]})

    retained = float(config["finger_control"]["retained_torque_fraction"])
    adaptive_increment = float(config["finger_control"]["adaptive_closure_increment_rad"])
    adaptive_limits = np.asarray([current_targets[name] for name in ROOT_TORQUE_JOINTS]) + max_extra
    lift_targets = list(config["lift_control"]["stage_targets_m"])
    lift_durations = list(config["lift_control"]["stage_duration_s"])
    previous_lift = 0.0
    for stage_index, (lift_target, duration) in enumerate(zip(lift_targets, lift_durations)):
        steps = max(1, round(float(duration) * rate))
        for index in range(steps):
            blend = minimum_jerk((index + 1) / float(steps))
            current_targets["lift_z"] = previous_lift + blend * (float(lift_target) - previous_lift)
            efforts = step(f"LIFT_{float(lift_target)*1000:.1f}MM", index)
            deltas = np.abs(efforts - tare)
            for finger_index, name in enumerate(ROOT_TORQUE_JOINTS):
                if deltas[finger_index] < retained * target_torque:
                    current_targets[name] = min(
                        adaptive_limits[finger_index], current_targets[name] + adaptive_increment
                    )
        previous_lift = float(lift_target)
        phase_snapshots.append(
            {"phase": f"LIFT_{lift_target}", "object_pose": [v.tolist() for v in object_view.get_world_pose()]}
        )

    for index in range(round(float(config["lift_control"]["final_hold_s"]) * rate)):
        step("FINAL_HOLD", index)
    final_position, final_orientation = object_view.get_world_pose()
    final_position = np.asarray(final_position, dtype=np.float64)
    final_orientation = np.asarray(final_orientation, dtype=np.float64)
    lift = float(final_position[2] - initial_object_position[2])
    xy_drift = float(np.linalg.norm(final_position[:2] - initial_object_position[:2]))
    tilt_drift = _tilt_angle_rad(initial_object_orientation, final_orientation)
    final_efforts = np.asarray([trace[-1][f"f{i}_effort_nm"] for i in (1, 2, 3)])
    effort_deltas = np.abs(final_efforts - tare)
    pad_contacts = {name: value > 0.0 for name, value in pad_impulse_by_finger.items()}
    final_hold_steps = max(1, round(float(config["lift_control"]["final_hold_s"]) * rate))
    final_hold_rows = trace[-final_hold_steps:]
    final_hold_pad_force_n = {
        "f1Link3": float(sum(row["f1_pad_impulse_ns"] for row in final_hold_rows) * rate / final_hold_steps),
        "f2Link2": float(sum(row["f2_pad_impulse_ns"] for row in final_hold_rows) * rate / final_hold_steps),
        "f3Link3": float(sum(row["f3_pad_impulse_ns"] for row in final_hold_rows) * rate / final_hold_steps),
    }
    final_hold_table_force_n = float(
        sum(row["table_impulse_ns"] for row in final_hold_rows) * rate / final_hold_steps
    )
    final_hold_contacts = {
        name: value >= float(config["acceptance"]["minimum_final_hold_pad_force_n"])
        for name, value in final_hold_pad_force_n.items()
    }
    passed = (
        all(pad_contacts.values())
        and all(final_hold_contacts.values())
        and final_hold_table_force_n <= float(config["acceptance"]["maximum_final_hold_table_force_n"])
        and lift >= float(config["acceptance"]["minimum_lift_m"])
        and xy_drift <= float(config["acceptance"]["maximum_object_xy_drift_m"])
        and tilt_drift <= float(config["acceptance"]["maximum_object_rotation_drift_rad"])
        and np.all(effort_deltas >= retained * target_torque)
    )

    with trace_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(trace[0]))
        writer.writeheader()
        writer.writerows(trace)

    return {
        "schema": SCHEMA,
        "status": "PASS" if passed else "FAIL",
        "classification": "B_FAST_PICK_RIG_PASS" if passed else "B_FAST_PICK_RIG_FAIL",
        "fast_baseline_passed": passed,
        "formal_b_passed": False,
        "candidate": candidate,
        "geometry": geometry,
        "rig_urdf": urdf_evidence,
        "source_hashes": {
            "config": _sha256(arguments.config),
            "candidates": _sha256(arguments.candidates),
            "proxy_manifest": _sha256(arguments.proxy_manifest),
            "source_urdf": _sha256(arguments.source_urdf),
        },
        "dof_names": dof_names,
        "pad_primitive_count": sum(len(paths) for paths in pad_paths_by_finger.values()),
        "mesh_collision_count": 0,
        "pad_contact_by_finger": pad_contacts,
        "pad_impulse_by_finger_ns": pad_impulse_by_finger,
        "table_impulse_ns": table_impulse,
        "tare_root_efforts_nm": tare.tolist(),
        "final_root_efforts_nm": final_efforts.tolist(),
        "final_root_effort_delta_nm": effort_deltas.tolist(),
        "initial_object_position_m": initial_object_position.tolist(),
        "initial_object_orientation_wxyz": initial_object_orientation.tolist(),
        "final_object_position_m": final_position.tolist(),
        "final_object_orientation_wxyz": final_orientation.tolist(),
        "object_lift_m": lift,
        "object_xy_drift_m": xy_drift,
        "object_tilt_drift_rad": tilt_drift,
        "final_hold_pad_force_n_posthoc": final_hold_pad_force_n,
        "final_hold_pad_contact_pass": final_hold_contacts,
        "final_hold_table_force_n_posthoc": final_hold_table_force_n,
        "phase_snapshots_posthoc_only": phase_snapshots,
        "stage_usda": str(stage_path),
        "trace_csv": str(trace_path),
        "truth_boundary": {
            "online_object_pose_used": False,
            "online_contact_truth_used": False,
            "posthoc_object_pose_used": True,
            "posthoc_contact_report_used": True,
            "object_pose_write_after_physics_start_count": 0,
        },
        "threshold_semantics": config["threshold_semantics"],
        "next_if_pass": "INTEGRATE_SELECTED_PAD_CANDIDATE_INTO_FULL_IIWA_B",
        "next_if_fail": "TRY_NEXT_RANKED_PAD_CANDIDATE",
    }


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    if arguments.dry_run:
        report = _dry_run(arguments)
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
        return 0

    portable = Path(arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    exit_code = 1
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": not bool(arguments.gui),
                "hide_ui": not bool(arguments.gui),
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = _run_isaac(arguments)
        exit_code = 0 if report["fast_baseline_passed"] else 3
    except BaseException as error:
        traceback.print_exc()
        output = Path(arguments.output_dir).resolve()
        output.mkdir(parents=True, exist_ok=True)
        report = {
            "schema": SCHEMA,
            "status": "ERROR",
            "classification": "B_FAST_PICK_RIG_RUNTIME_ERROR",
            "fast_baseline_passed": False,
            "formal_b_passed": False,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
        }
    output = Path(arguments.output_dir).resolve()
    _write_json(output / "B_FAST_PICK_RESULT.json", report)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False, sort_keys=True))
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
