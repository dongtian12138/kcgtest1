#!/usr/bin/env python3

"""Minimal dynamic smoke for the D38999 B V5 conservative PAD capsules.

The controller is a fixed-time minimum-jerk joint trajectory.  Collider paths,
contact points, impulses, and normals are consumed only after each physics step
for post-hoc evidence and never affect the online target.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np

import d38999_pad_sdf_compatibility_smoke as legacy


REPOSITORY = Path(__file__).resolve().parents[3]
TASK_ROOT = (
    REPOSITORY
    / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2"
    / "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
)
DEFAULT_SOURCE_ASSET_DIR = TASK_ROOT / "BLUE_PAD_SDF_SOURCE_ASSET_V2"
DEFAULT_PROXY_ASSET_DIR = TASK_ROOT / "BLUE_PAD_CONSERVATIVE_CONVEX_PROXY_V1"
PROXY_STATIC_RESULT = TASK_ROOT / "PAD_CONSERVATIVE_CONVEX_PROXY_STATIC_RESULT.json"
SDF_DYNAMIC_ANALYSIS = TASK_ROOT / "PAD_SDF_COMPATIBILITY_SMOKE_IFIX03_ANALYSIS.json"
CONTINUOUS_AUTHORIZATION = TASK_ROOT / "CONTINUOUS_AUTONOMOUS_AUTHORIZATION.json"

SCHEMA = "D38999_B_V5_PAD_CONSERVATIVE_CONVEX_COMPATIBILITY_SMOKE_V1"
TASK_ID = "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
HYPOTHESIS_ID = "B-V5-CONSERVATIVE-CONVEX-PAD-PROXY-COMPATIBILITY"
RUN_ID = "B-V5-PAD-CONSERVATIVE-CONVEX-COMPATIBILITY-SMOKE-01"
COLLISION_ROUTE = "CONSERVATIVE_CONVEX_PAD_PROXY"
FIXTURE_PRELOAD_M = 0.00025


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-asset-dir", default=str(DEFAULT_SOURCE_ASSET_DIR))
    parser.add_argument("--proxy-asset-dir", default=str(DEFAULT_PROXY_ASSET_DIR))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--steps", type=int, default=1500)
    parser.add_argument("--run-id", default=RUN_ID)
    parser.add_argument("--kit-portable-root", required=True)
    arguments = parser.parse_args(argv)
    if not 1000 <= arguments.steps <= 2000:
        raise ValueError("--steps must be within the authorized 1000..2000 range")
    if arguments.run_id != RUN_ID:
        raise ValueError(f"only the non-H run id {RUN_ID} is authorized")
    authorization = json.loads(
        CONTINUOUS_AUTHORIZATION.read_text(encoding="utf-8")
    )
    retained = authorization.get("retained_boundaries", {})
    if (
        authorization.get("authority")
        != "USER_CONTINUOUS_AUTONOMOUS_AUTHORIZATION"
        or authorization.get("effective_until") != "USER_EXPLICITLY_SAYS_STOP"
        or authorization.get("scope", {}).get(
            "bounded_non_h_isaac_runs_automatically_authorized"
        )
        is not True
        or retained.get("new_h_number_forbidden") is not True
        or retained.get(
            "online_object_pose_contact_name_normal_event_truth_forbidden"
        )
        is not True
    ):
        raise ValueError("continuous autonomous authorization is absent or invalid")
    return arguments


def _verified_inputs(
    source_asset_dir: Path, proxy_asset_dir: Path
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Path]]:
    source_entry, source_paths = legacy._source_finger_entry(source_asset_dir)
    proxy_manifest_path = (
        proxy_asset_dir / "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json"
    )
    proxy_manifest = json.loads(proxy_manifest_path.read_text(encoding="utf-8"))
    static_result = json.loads(PROXY_STATIC_RESULT.read_text(encoding="utf-8"))
    sdf_analysis = json.loads(SDF_DYNAMIC_ANALYSIS.read_text(encoding="utf-8"))
    if proxy_manifest.get("collision_route") != COLLISION_ROUTE:
        raise ValueError("proxy manifest collision route changed")
    if proxy_manifest.get("whole_terminal_convex_hull_count") != 0:
        raise ValueError("proxy manifest reintroduced the whole terminal hull")
    if proxy_manifest.get("pad_collision_primitive_count_per_finger") != 5:
        raise ValueError("expected five analytically derived PAD capsules per finger")
    if proxy_manifest.get("dynamic_use_allowed") is not False:
        raise ValueError("pre-smoke proxy manifest must not pre-authorize dynamic use")
    if static_result.get("status") != "STATIC_PASS_AWAITING_ISAAC_COMPATIBILITY":
        raise ValueError("conservative proxy static gate is not passed")
    if legacy._sha256(proxy_manifest_path) != static_result.get("manifest_sha256"):
        raise ValueError("conservative proxy manifest hash changed after static pass")
    if (
        sdf_analysis.get("classification")
        != "PHYSX_SDF_RECOGNIZED_BUT_COOKING_DID_NOT_COMPLETE_WITHIN_1500S_TASK_BUDGET"
        or sdf_analysis.get("route_decision", {}).get(
            "convex_fallback_now_authorized"
        )
        is not True
    ):
        raise ValueError("dynamic SDF rejection does not authorize the convex fallback")
    matches = [
        link for link in proxy_manifest["links"] if link["link_name"] == "f2Link2"
    ]
    if len(matches) != 1:
        raise ValueError(f"expected one f2Link2 proxy entry; got {len(matches)}")
    proxy_entry = matches[0]
    if proxy_entry.get("capsule_count") != 5 or len(proxy_entry["capsules"]) != 5:
        raise ValueError("f2Link2 proxy does not contain five capsules")
    if proxy_entry["source_pad_arrays_sha256"] != source_entry[
        "pad_sdf_source_arrays_sha256"
    ]:
        raise ValueError("proxy PAD source lineage differs from exact blue PAD source")
    paths = dict(source_paths)
    paths.update(
        {
            "proxy_manifest": proxy_manifest_path,
            "proxy_static_result": PROXY_STATIC_RESULT,
            "sdf_dynamic_analysis": SDF_DYNAMIC_ANALYSIS,
            "continuous_authorization": CONTINUOUS_AUTHORIZATION,
        }
    )
    return source_entry, proxy_entry, paths


def _derive_proxy_fixture(
    proxy_entry: Mapping[str, Any], tip_arrays: Mapping[str, np.ndarray]
) -> dict[str, Any]:
    capsules = list(proxy_entry["capsules"])
    center_capsule = capsules[len(capsules) // 2]
    center_local = np.asarray(center_capsule["center_local_m"], dtype=np.float64)
    axis_local = np.asarray(center_capsule["axis_unit_local"], dtype=np.float64)
    normal_local = np.asarray(
        proxy_entry["contact_frame_local"]["outward_normal_unit"],
        dtype=np.float64,
    )
    final_transform = legacy._f2_transform(legacy.SOURCE_URDF, legacy.CONTACT_Q_RAD)
    axis_world = final_transform[:3, :3] @ axis_local
    axis_world /= np.linalg.norm(axis_world)
    normal_world = final_transform[:3, :3] @ normal_local
    normal_world -= axis_world * float(normal_world @ axis_world)
    normal_world /= np.linalg.norm(normal_world)
    center_world = final_transform[:3, :3] @ center_local + final_transform[:3, 3]
    capsule_radius = float(center_capsule["radius_m"])
    cylinder_radius = legacy.CYLINDER_RADIUS_M
    line_point = center_world + (
        cylinder_radius + capsule_radius - FIXTURE_PRELOAD_M
    ) * normal_world

    gaps: dict[str, list[float]] = {}
    for label, q_rad in (
        ("initial", legacy.INITIAL_Q_RAD),
        ("final", legacy.CONTACT_Q_RAD),
    ):
        transform = legacy._f2_transform(legacy.SOURCE_URDF, q_rad)
        values: list[float] = []
        for capsule in capsules:
            capsule_center = np.asarray(
                capsule["center_local_m"], dtype=np.float64
            )
            world_center = (
                transform[:3, :3] @ capsule_center + transform[:3, 3]
            )
            relative = world_center - line_point
            axial = axis_world * float(relative @ axis_world)
            radial_distance = float(np.linalg.norm(relative - axial))
            values.append(
                radial_distance
                - cylinder_radius
                - float(capsule["radius_m"])
            )
        gaps[label] = values

    tip_stats = legacy._component_radial_stats(
        np.asarray(tip_arrays["points_local_m"], dtype=np.float64),
        final_transform,
        line_point,
        axis_world,
    )
    tip_radial_clearance = (
        None
        if tip_stats["minimum_radial_distance_m"] is None
        else tip_stats["minimum_radial_distance_m"] - cylinder_radius
    )
    result = {
        "method": "REAL_F2_FK_PLUS_CENTER_CONSERVATIVE_PAD_CAPSULE",
        "contact_q_rad": legacy.CONTACT_Q_RAD,
        "initial_q_rad": legacy.INITIAL_Q_RAD,
        "center_capsule_index": int(center_capsule["index"]),
        "axis_unit_world": axis_world.tolist(),
        "outward_normal_unit_world": normal_world.tolist(),
        "line_point_world_m": line_point.tolist(),
        "cylinder_radius_m": cylinder_radius,
        "cylinder_height_m": legacy.CYLINDER_HEIGHT_M,
        "fixed_geometric_preload_m": FIXTURE_PRELOAD_M,
        "initial_capsule_surface_gaps_m": gaps["initial"],
        "final_capsule_surface_gaps_m": gaps["final"],
        "tip_at_final": tip_stats,
        "tip_minimum_radial_clearance_m": tip_radial_clearance,
        "initial_separation_pass": min(gaps["initial"]) > 0.010,
        "center_capsule_preload_pass": abs(
            gaps["final"][len(capsules) // 2] + FIXTURE_PRELOAD_M
        )
        <= 1.0e-9,
        "adjacent_capsules_not_preloaded": all(
            value > 0.0
            for index, value in enumerate(gaps["final"])
            if index != len(capsules) // 2
        ),
        "tip_radially_clear_pass": bool(
            tip_radial_clearance is not None and tip_radial_clearance > 0.010
        ),
    }
    if not all(
        result[name]
        for name in (
            "initial_separation_pass",
            "center_capsule_preload_pass",
            "adjacent_capsules_not_preloaded",
            "tip_radially_clear_pass",
        )
    ):
        raise ValueError(f"conservative proxy fixture preflight failed: {result}")
    return result


def _run(arguments: argparse.Namespace, application: Any) -> dict[str, Any]:
    import carb.logging
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_cooking_interface, get_physx_simulation_interface
    from omni.physx.scripts.ifaces import get_physx_cooking_private_interface
    import omni.usd
    from pxr import (
        Gf,
        PhysicsSchemaTools,
        PhysxSchema,
        Sdf,
        Usd,
        UsdGeom,
        UsdPhysics,
        UsdShade,
    )

    output = Path(arguments.output_dir).resolve()
    source_dir = Path(arguments.source_asset_dir).resolve()
    proxy_dir = Path(arguments.proxy_asset_dir).resolve()
    source_entry, proxy_entry, input_paths = _verified_inputs(
        source_dir, proxy_dir
    )
    input_hashes_before = {
        name: legacy._sha256(path) for name, path in input_paths.items()
    }
    pad_arrays = legacy._load_arrays(input_paths["pad"])
    tip_arrays = legacy._load_arrays(input_paths["tip"])
    fixture = _derive_proxy_fixture(proxy_entry, tip_arrays)

    minimal_urdf = output / "d38999_pad_convex_smoke_f2.urdf"
    urdf_evidence = legacy._build_minimal_f2_urdf(
        legacy.SOURCE_URDF, minimal_urdf
    )
    import_directory = output / "minimal_f2_usd"
    import_directory.mkdir(parents=False, exist_ok=False)
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=str(minimal_urdf),
            usd_path=str(import_directory),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    for _ in range(10):
        application.update()
    if not imported_path.exists():
        raise RuntimeError(f"minimal URDF import did not create {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    application.update()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / legacy.PHYSICS_RATE_HZ,
        rendering_dt=1.0 / 60.0,
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/Finger")
    for _ in range(10):
        application.update()

    terminal = legacy._find_unique_prim(
        stage,
        lambda prim: prim.GetName() == "f2Link2"
        and prim.HasAPI(UsdPhysics.RigidBodyAPI),
        "f2Link2 rigid link",
    )
    terminal_path = terminal.GetPath()
    terminal_instanceability = {
        "path_before": str(terminal_path),
        "is_instance_before": bool(terminal.IsInstance()),
        "is_instance_proxy_before": bool(terminal.IsInstanceProxy()),
        "is_instanceable_before": bool(terminal.IsInstanceable()),
        "set_instanceable_false_succeeded": False,
    }
    if not terminal.IsInstance() or terminal.IsInstanceProxy():
        raise RuntimeError(
            "expected f2Link2 to be an editable instance root before deinstance: "
            f"{terminal_instanceability}"
        )
    if not terminal.SetInstanceable(False):
        raise RuntimeError("failed to author instanceable=false on f2Link2")
    terminal_instanceability["set_instanceable_false_succeeded"] = True
    for _ in range(2):
        application.update()
    terminal = stage.GetPrimAtPath(terminal_path)
    terminal_instanceability.update(
        {
            "path_after": str(terminal.GetPath()),
            "is_instance_after": bool(terminal.IsInstance()),
            "is_instance_proxy_after": bool(terminal.IsInstanceProxy()),
            "is_instanceable_after": bool(terminal.IsInstanceable()),
            "rigid_body_api_preserved": bool(
                terminal.HasAPI(UsdPhysics.RigidBodyAPI)
            ),
        }
    )
    if (
        not terminal.IsValid()
        or terminal.GetPath() != terminal_path
        or terminal.IsInstance()
        or terminal.IsInstanceProxy()
        or terminal.IsInstanceable()
        or not terminal.HasAPI(UsdPhysics.RigidBodyAPI)
    ):
        raise RuntimeError(
            f"f2Link2 deinstance postcondition failed: {terminal_instanceability}"
        )
    articulation_root = legacy._find_unique_prim(
        stage,
        lambda prim: prim.HasAPI(UsdPhysics.ArticulationRootAPI),
        "minimal f2 articulation root",
    )
    old_terminal_colliders = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(terminal)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if old_terminal_colliders:
        raise RuntimeError(
            f"old terminal collision survived minimal import: {old_terminal_colliders}"
        )

    physics_scene = legacy._find_unique_prim(
        stage,
        lambda prim: prim.IsA(UsdPhysics.Scene),
        "physics scene",
    )
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene)
    physx_scene.CreateEnableGPUDynamicsAttr().Set(True)
    physx_scene.CreateBroadphaseTypeAttr().Set("GPU")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(0.0)

    material_root = "/World/PhysicsMaterials"
    UsdGeom.Scope.Define(stage, material_root)

    def material(path: str, static: float, dynamic: float) -> Any:
        value = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(value.GetPrim())
        api.CreateStaticFrictionAttr(static)
        api.CreateDynamicFrictionAttr(dynamic)
        api.CreateRestitutionAttr(0.0)
        return value

    pad_material = material(
        material_root + "/PAD_FRICTION",
        legacy.PAD_STATIC_FRICTION,
        legacy.PAD_DYNAMIC_FRICTION,
    )
    base_material = material(
        material_root + "/BASE_FRICTION",
        legacy.BASE_STATIC_FRICTION,
        legacy.BASE_DYNAMIC_FRICTION,
    )
    cooking_private = get_physx_cooking_private_interface()
    get_physx_cooking_interface().release_local_mesh_cache()
    cooking_before = legacy._wait_for_cooking(application, cooking_private)

    pad_paths: set[str] = set()
    for capsule in proxy_entry["capsules"]:
        path = str(terminal.GetPath()) + "/" + str(capsule["prim_name"])
        geometry = UsdGeom.Capsule.Define(stage, path)
        geometry.CreateAxisAttr(UsdGeom.Tokens.z)
        radius = float(capsule["radius_m"])
        height = float(capsule["cylinder_height_m"])
        geometry.CreateRadiusAttr(radius)
        geometry.CreateHeightAttr(height)
        half_axis_extent = 0.5 * height + radius
        geometry.CreateExtentAttr(
            [
                Gf.Vec3f(-radius, -radius, -half_axis_extent),
                Gf.Vec3f(radius, radius, half_axis_extent),
            ]
        )
        xform = UsdGeom.Xformable(geometry)
        xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
        rotation = Gf.Rotation(
            Gf.Vec3d(0.0, 0.0, 1.0),
            Gf.Vec3d(*capsule["axis_unit_local"]),
        )
        xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
        UsdPhysics.CollisionAPI.Apply(geometry.GetPrim()).CreateCollisionEnabledAttr(
            True
        )
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(geometry.GetPrim())
        physx_collision.CreateContactOffsetAttr(legacy.CONTACT_OFFSET_M)
        physx_collision.CreateRestOffsetAttr(legacy.REST_OFFSET_M)
        UsdShade.MaterialBindingAPI(geometry.GetPrim()).Bind(
            pad_material, materialPurpose="physics"
        )
        geometry.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set("PAD_CONTACT_SURFACE_PROXY")
        geometry.GetPrim().CreateAttribute(
            "kcg:proxyIndex", Sdf.ValueTypeNames.Int
        ).Set(int(capsule["index"]))
        if geometry.GetPrim().GetParent() != terminal:
            raise RuntimeError(f"PAD capsule is not a direct terminal child: {path}")
        pad_paths.add(path)

    def author_mesh(path: str, arrays: Mapping[str, np.ndarray]) -> Any:
        mesh = UsdGeom.Mesh.Define(stage, path)
        mesh.CreatePointsAttr(
            [
                Gf.Vec3f(*[float(value) for value in point])
                for point in arrays["points_local_m"]
            ]
        )
        mesh.CreateFaceVertexCountsAttr(
            [int(value) for value in arrays["face_vertex_counts"]]
        )
        mesh.CreateFaceVertexIndicesAttr(
            [int(value) for value in arrays["face_vertex_indices"]]
        )
        mesh.CreateSubdivisionSchemeAttr(UsdGeom.Tokens.none)
        UsdPhysics.CollisionAPI.Apply(mesh.GetPrim()).CreateCollisionEnabledAttr(True)
        physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(mesh.GetPrim())
        physx_collision.CreateContactOffsetAttr(legacy.CONTACT_OFFSET_M)
        physx_collision.CreateRestOffsetAttr(legacy.REST_OFFSET_M)
        return mesh

    tip_path = str(terminal.GetPath()) + "/TIP_BASE_COLLISION"
    tip_mesh = author_mesh(tip_path, tip_arrays)
    UsdPhysics.MeshCollisionAPI.Apply(tip_mesh.GetPrim()).CreateApproximationAttr().Set(
        UsdPhysics.Tokens.convexHull
    )
    UsdShade.MaterialBindingAPI(tip_mesh.GetPrim()).Bind(
        base_material, materialPurpose="physics"
    )
    tip_mesh.GetPrim().CreateAttribute(
        "kcg:collisionRole", Sdf.ValueTypeNames.Token
    ).Set("TIP_END_SURFACE")
    cooking_after_authoring = legacy._wait_for_cooking(application, cooking_private)

    cylinder_path = "/World/CouplingNutCurvatureCylinder"
    cylinder = UsdGeom.Cylinder.Define(stage, cylinder_path)
    cylinder.CreateAxisAttr(UsdGeom.Tokens.z)
    cylinder.CreateRadiusAttr(legacy.CYLINDER_RADIUS_M)
    cylinder.CreateHeightAttr(legacy.CYLINDER_HEIGHT_M)
    cylinder.CreateDisplayColorAttr([Gf.Vec3f(0.42, 0.42, 0.46)])
    xform = UsdGeom.Xformable(cylinder)
    xform.AddTranslateOp().Set(Gf.Vec3d(*fixture["line_point_world_m"]))
    rotation = Gf.Rotation(
        Gf.Vec3d(0.0, 0.0, 1.0),
        Gf.Vec3d(*fixture["axis_unit_world"]),
    )
    xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
    UsdPhysics.CollisionAPI.Apply(cylinder.GetPrim()).CreateCollisionEnabledAttr(True)
    physx_collision = PhysxSchema.PhysxCollisionAPI.Apply(cylinder.GetPrim())
    physx_collision.CreateContactOffsetAttr(legacy.CONTACT_OFFSET_M)
    physx_collision.CreateRestOffsetAttr(legacy.REST_OFFSET_M)
    UsdShade.MaterialBindingAPI(cylinder.GetPrim()).Bind(
        base_material, materialPurpose="physics"
    )
    cylinder.GetPrim().CreateAttribute(
        "kcg:collisionRole", Sdf.ValueTypeNames.Token
    ).Set("COUPLING_NUT_CURVATURE")

    PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
    robot = world.scene.add(
        SingleArticulation(
            prim_path=str(articulation_root.GetPath()),
            name="d38999_pad_conservative_convex_smoke_f2",
        )
    )
    stage_path = output / "PAD_CONSERVATIVE_CONVEX_COMPATIBILITY_STAGE.usda"
    stage.Export(str(stage_path))

    relevant_log_rows: list[dict[str, Any]] = []
    logging = carb.logging.acquire_logging()

    def on_log(source: str, level: int, filename: str, line: int, message: str) -> None:
        text = str(message)
        lowered = text.lower()
        if (
            ("physicsusd" in lowered and ("error" in lowered or "failed" in lowered))
            or ("solver" in lowered and ("error" in lowered or "failed" in lowered))
            or (
                "capsule" in lowered
                and any(word in lowered for word in ("error", "failed", "unsupported"))
            )
            or "unsupported approximation" in lowered
        ):
            relevant_log_rows.append(
                {
                    "source": str(source),
                    "level": int(level),
                    "filename": str(filename),
                    "line": int(line),
                    "message": text,
                }
            )

    logger_handle = logging.add_logger(on_log)
    trace: list[dict[str, Any]] = []
    pad_local_points: list[list[float]] = []
    pad_impulses: list[float] = []
    tip_impulse_total = 0.0
    capsule_impulses = {path: 0.0 for path in sorted(pad_paths)}
    radial_normal_alignments: list[float] = []
    maximum_joint_speed = 0.0
    finite_throughout = True
    try:
        world.reset()
        cooking_after_reset = legacy._wait_for_cooking(application, cooking_private)
        dof_names = list(robot.dof_names)
        if "f2j1" not in dof_names or "f2j2" not in dof_names:
            raise RuntimeError(f"real f2 joints missing from articulation: {dof_names}")
        name_to_index = {name: index for index, name in enumerate(dof_names)}
        active_index = name_to_index["f2j1"]
        follower_index = name_to_index["f2j2"]
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        positions[active_index] = legacy.INITIAL_Q_RAD
        positions[follower_index] = legacy.INITIAL_Q_RAD
        robot.set_joint_positions(positions)
        robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
        controller = robot.get_articulation_controller()
        kps = np.zeros(robot.num_dof, dtype=np.float32)
        kds = np.zeros(robot.num_dof, dtype=np.float32)
        kps[active_index] = 12.0
        kds[active_index] = 0.8
        controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

        warmup_steps = 120
        close_steps = min(900, arguments.steps - warmup_steps - 240)
        interface = get_physx_simulation_interface()
        cylinder_axis = np.asarray(fixture["axis_unit_world"], dtype=np.float64)
        cylinder_line = np.asarray(fixture["line_point_world_m"], dtype=np.float64)
        step_wall_times: list[float] = []

        for step in range(arguments.steps):
            if step < warmup_steps:
                target = legacy.INITIAL_Q_RAD
                phase = "OPEN_SETTLE"
            elif step < warmup_steps + close_steps:
                fraction = (step - warmup_steps + 1) / float(close_steps)
                target = legacy.INITIAL_Q_RAD + legacy._minimum_jerk(fraction) * (
                    legacy.CONTACT_Q_RAD - legacy.INITIAL_Q_RAD
                )
                phase = "MINIMUM_JERK_CLOSE"
            else:
                target = legacy.CONTACT_Q_RAD
                phase = "CONTACT_HOLD"
            robot.apply_action(
                ArticulationAction(
                    joint_positions=np.asarray([target], dtype=np.float32),
                    joint_indices=np.asarray([active_index], dtype=np.int32),
                )
            )
            started = time.perf_counter()
            world.step(render=False)
            elapsed = time.perf_counter() - started
            step_wall_times.append(elapsed)
            state_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
            state_velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
            finite = bool(
                np.all(np.isfinite(state_positions))
                and np.all(np.isfinite(state_velocities))
            )
            finite_throughout = finite_throughout and finite
            if not finite:
                break
            maximum_joint_speed = max(
                maximum_joint_speed, float(np.max(np.abs(state_velocities)))
            )

            terminal_matrix = UsdGeom.Xformable(terminal).ComputeLocalToWorldTransform(
                Usd.TimeCode.Default()
            )
            world_to_terminal = terminal_matrix.GetInverse()
            headers, contacts, _friction = interface.get_full_contact_report()
            pad_step_impulse = 0.0
            tip_step_impulse = 0.0
            pad_step_count = 0
            tip_step_count = 0
            active_pad_paths: set[str] = set()
            for header in headers:
                collider0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
                collider1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
                pair = {collider0, collider1}
                matched_pad = next((path for path in pad_paths if path in pair), None)
                is_pad_pair = cylinder_path in pair and matched_pad is not None
                is_tip_pair = cylinder_path in pair and tip_path in pair
                if not is_pad_pair and not is_tip_pair:
                    continue
                start = int(header.contact_data_offset)
                stop = start + int(header.num_contact_data)
                for contact in contacts[start:stop]:
                    impulse = np.asarray(contact.impulse, dtype=np.float64)
                    impulse_norm = float(np.linalg.norm(impulse))
                    position = np.asarray(contact.position, dtype=np.float64)
                    if is_pad_pair and matched_pad is not None:
                        local = world_to_terminal.Transform(Gf.Vec3d(*position))
                        pad_local_points.append([float(local[i]) for i in range(3)])
                        pad_impulses.append(impulse_norm)
                        capsule_impulses[matched_pad] += impulse_norm
                        active_pad_paths.add(matched_pad)
                        pad_step_impulse += impulse_norm
                        pad_step_count += 1
                        relative = position - cylinder_line
                        radial = relative - cylinder_axis * float(
                            relative @ cylinder_axis
                        )
                        radial_norm = float(np.linalg.norm(radial))
                        normal = np.asarray(contact.normal, dtype=np.float64)
                        normal_norm = float(np.linalg.norm(normal))
                        if radial_norm > 1.0e-12 and normal_norm > 1.0e-12:
                            radial_normal_alignments.append(
                                abs(
                                    float(
                                        (radial / radial_norm)
                                        @ (normal / normal_norm)
                                    )
                                )
                            )
                    else:
                        tip_step_impulse += impulse_norm
                        tip_step_count += 1
            tip_impulse_total += tip_step_impulse
            trace.append(
                {
                    "step": step + 1,
                    "phase": phase,
                    "target_f2j1_rad": target,
                    "f2j1_rad": float(state_positions[active_index]),
                    "f2j2_rad": float(state_positions[follower_index]),
                    "f2j1_velocity_rad_s": float(state_velocities[active_index]),
                    "f2j2_velocity_rad_s": float(state_velocities[follower_index]),
                    "pad_contact_count": pad_step_count,
                    "tip_contact_count": tip_step_count,
                    "active_pad_primitive_count": len(active_pad_paths),
                    "pad_contact_force_n": pad_step_impulse * legacy.PHYSICS_RATE_HZ,
                    "tip_contact_force_n": tip_step_impulse * legacy.PHYSICS_RATE_HZ,
                    "step_wall_s": elapsed,
                }
            )
        cooking_final = legacy._wait_for_cooking(application, cooking_private)
    finally:
        logging.remove_logger(logger_handle)

    if not trace:
        raise RuntimeError("smoke executed zero diagnostic actions")
    points_array = np.asarray(pad_local_points, dtype=np.float64).reshape((-1, 3))
    impulses_array = np.asarray(pad_impulses, dtype=np.float64)
    role_audit = legacy._nearest_pad_roles(points_array, impulses_array, pad_arrays)
    pad_impulse_total = float(np.sum(impulses_array))
    all_finger_impulse = pad_impulse_total + tip_impulse_total
    pad_force = np.asarray(
        [row["pad_contact_force_n"] for row in trace], dtype=np.float64
    )
    hold_force = pad_force[-min(240, len(pad_force)) :]
    step_times = np.asarray([row["step_wall_s"] for row in trace], dtype=np.float64)
    final_positions = trace[-1]

    pad_colliders = [
        prim
        for prim in stage.Traverse()
        if prim.HasAPI(UsdPhysics.CollisionAPI)
        and prim.GetAttribute("kcg:collisionRole")
        and str(prim.GetAttribute("kcg:collisionRole").Get())
        == "PAD_CONTACT_SURFACE_PROXY"
    ]
    terminal_collision_inventory = [
        {
            "path": str(prim.GetPath()),
            "type_name": prim.GetTypeName(),
            "approximation": (
                str(UsdPhysics.MeshCollisionAPI(prim).GetApproximationAttr().Get())
                if prim.HasAPI(UsdPhysics.MeshCollisionAPI)
                else "analytic_primitive"
            ),
            "role": (
                str(prim.GetAttribute("kcg:collisionRole").Get())
                if prim.GetAttribute("kcg:collisionRole")
                else None
            ),
        }
        for prim in Usd.PrimRange(terminal)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    analytic_capsules = all(
        prim.IsA(UsdGeom.Capsule)
        and not prim.HasAPI(UsdPhysics.MeshCollisionAPI)
        and float(UsdGeom.Capsule(prim).GetRadiusAttr().Get())
        == float(proxy_entry["capsules"][index]["radius_m"])
        for index, prim in enumerate(sorted(pad_colliders, key=lambda value: str(value.GetPath())))
    )
    physicsusd_errors = [
        row for row in relevant_log_rows if "physicsusd" in row["message"].lower()
    ]
    solver_errors = [
        row for row in relevant_log_rows if "solver" in row["message"].lower()
    ]
    capsule_errors = [
        row
        for row in relevant_log_rows
        if "capsule" in row["message"].lower()
        or "unsupported approximation" in row["message"].lower()
    ]
    median_hold_force = float(np.median(hold_force))
    maximum_force = float(np.max(pad_force))
    mean_step_wall = float(np.mean(step_times))
    tip_share = (
        tip_impulse_total / all_finger_impulse if all_finger_impulse > 0.0 else 1.0
    )
    gates = {
        "authorized_step_count": 1000 <= len(trace) <= 2000,
        "real_f2_articulation_initialized": bool(robot.handles_initialized),
        "joint_state_finite": finite_throughout,
        "real_closure_progress": final_positions["f2j1_rad"]
        - legacy.INITIAL_Q_RAD
        >= 0.35,
        "mimic_follower_tracks": abs(
            final_positions["f2j2_rad"] - final_positions["f2j1_rad"]
        )
        <= 0.05,
        "terminal_deinstanced_for_authoring": (
            terminal_instanceability["is_instance_before"]
            and not terminal_instanceability["is_instance_proxy_before"]
            and terminal_instanceability["set_instanceable_false_succeeded"]
            and not terminal_instanceability["is_instance_after"]
            and not terminal_instanceability["is_instance_proxy_after"]
            and not terminal_instanceability["is_instanceable_after"]
            and terminal_instanceability["rigid_body_api_preserved"]
        ),
        "five_pad_capsules": len(pad_colliders) == 5,
        "pad_colliders_are_analytic_capsules": analytic_capsules,
        "one_independent_tip_collider": sum(
            row["role"] == "TIP_END_SURFACE"
            for row in terminal_collision_inventory
        )
        == 1,
        "old_full_terminal_hull_absent": not any(
            "f2Link2_convex" in row["path"]
            for row in terminal_collision_inventory
        ),
        "pad_contact_established": role_audit["contact_count"] > 0,
        "pad_inner_impulse_share": role_audit[
            "PAD_CONTACT_SURFACE_impulse_share"
        ]
        >= 0.90,
        "tip_not_main_contact": tip_share <= 0.10,
        "contact_normals_radial": bool(radial_normal_alignments)
        and float(np.median(radial_normal_alignments)) >= 0.70,
        "stable_nonzero_hold_force": 0.10 <= median_hold_force <= 30.0,
        "no_single_step_force_explosion": maximum_force
        <= legacy.FORCE_EXPLOSION_THRESHOLD_N,
        "joint_speed_bounded": maximum_joint_speed <= 8.0,
        "physicsusd_error_zero": len(physicsusd_errors) == 0,
        "solver_error_zero": len(solver_errors) == 0,
        "capsule_error_zero": len(capsule_errors) == 0,
        "mean_240hz_step_budget": mean_step_wall
        <= 1.0 / legacy.PHYSICS_RATE_HZ,
        "object_pose_write_after_physics_zero": True,
        "online_contact_truth_control_zero": True,
    }
    passed = all(gates.values())
    trace_path = output / "PAD_CONSERVATIVE_CONVEX_CONTACT_TRACE.csv"
    with trace_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(trace[0]))
        writer.writeheader()
        writer.writerows(trace)
    input_hashes_after = {
        name: legacy._sha256(path) for name, path in input_paths.items()
    }
    simulated_seconds = len(trace) / legacy.PHYSICS_RATE_HZ
    measured_wall_seconds = float(np.sum(step_times))
    return {
        "schema": SCHEMA,
        "task_id": TASK_ID,
        "hypothesis_id": HYPOTHESIS_ID,
        "run_id": arguments.run_id,
        "status": "PASS" if passed else "FAIL",
        "classification": (
            "PAD_CONSERVATIVE_CONVEX_DYNAMIC_COMPATIBILITY_PASS"
            if passed
            else "PAD_CONSERVATIVE_CONVEX_DYNAMIC_COMPATIBILITY_FAIL"
        ),
        "dynamic_compatibility_passed": passed,
        "formal_b_passed": False,
        "collision_route": COLLISION_ROUTE,
        "source_asset": {
            "directory": str(source_dir),
            "entry": source_entry,
        },
        "proxy_asset": {
            "directory": str(proxy_dir),
            "entry": proxy_entry,
        },
        "input_sha256_before": input_hashes_before,
        "input_sha256_after": input_hashes_after,
        "inputs_unchanged": input_hashes_before == input_hashes_after,
        "minimal_real_finger_chain": urdf_evidence,
        "imported_usd": str(imported_path),
        "articulation_root": str(articulation_root.GetPath()),
        "terminal_instanceability": terminal_instanceability,
        "dof_names": list(robot.dof_names),
        "fixture": fixture,
        "pad_collision_body_count": len(pad_colliders),
        "tip_collision_body_count": sum(
            row["role"] == "TIP_END_SURFACE"
            for row in terminal_collision_inventory
        ),
        "terminal_collision_inventory": terminal_collision_inventory,
        "old_whole_distal_hull_runtime_removed": gates[
            "old_full_terminal_hull_absent"
        ],
        "contact_role_audit": role_audit,
        "pad_impulse_total_ns": pad_impulse_total,
        "tip_impulse_total_ns": tip_impulse_total,
        "tip_impulse_share": tip_share,
        "per_capsule_impulse_ns": capsule_impulses,
        "median_radial_normal_alignment": (
            float(np.median(radial_normal_alignments))
            if radial_normal_alignments
            else None
        ),
        "force_stability": {
            "median_last_240_step_pad_force_n": median_hold_force,
            "maximum_single_step_pad_force_n": maximum_force,
            "explosion_threshold_n": legacy.FORCE_EXPLOSION_THRESHOLD_N,
            "working_5_to_8_n_observed": 5.0 <= median_hold_force <= 8.0,
            "working_5_to_8_n_is_formal_smoke_gate": False,
        },
        "articulation_metrics": {
            "final_f2j1_rad": final_positions["f2j1_rad"],
            "final_f2j2_rad": final_positions["f2j2_rad"],
            "maximum_abs_joint_speed_rad_s": maximum_joint_speed,
            "finite_throughout": finite_throughout,
        },
        "performance": {
            "physics_rate_hz": legacy.PHYSICS_RATE_HZ,
            "step_count": len(trace),
            "simulated_seconds": simulated_seconds,
            "measured_step_wall_seconds": measured_wall_seconds,
            "mean_step_wall_s": mean_step_wall,
            "p95_step_wall_s": float(np.percentile(step_times, 95.0)),
            "real_time_factor_excluding_startup": (
                simulated_seconds / measured_wall_seconds
                if measured_wall_seconds > 0.0
                else None
            ),
        },
        "cooking_diagnostics": {
            "before_authoring": cooking_before,
            "after_authoring": cooking_after_authoring,
            "after_reset": cooking_after_reset,
            "final": cooking_final,
        },
        "runtime_log_evidence": {
            "retained_messages": relevant_log_rows,
            "physicsusd_error_count": len(physicsusd_errors),
            "solver_error_count": len(solver_errors),
            "capsule_error_count": len(capsule_errors),
        },
        "gates": gates,
        "control_truth_boundary": {
            "controller_type": "FIXED_TIME_MINIMUM_JERK_JOINT_POSITION",
            "control_reads_object_pose_truth": False,
            "control_reads_contact_names": False,
            "control_reads_contact_normals": False,
            "control_reads_contact_events": False,
            "posthoc_contact_truth_audit": True,
            "object_pose_write_after_physics_start_count": 0,
        },
        "stage_usda": str(stage_path),
        "trace_csv": str(trace_path),
        "runner_sha256": legacy._sha256(Path(__file__)),
        "new_h_number_created": False,
    }


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    output = Path(arguments.output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite convex smoke output: {output}")
    output.mkdir(parents=True, exist_ok=False)
    portable = Path(arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    exit_code = 1
    report: dict[str, Any]
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": True,
                "hide_ui": True,
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = _run(arguments, application)
        exit_code = 0 if report["dynamic_compatibility_passed"] else 3
    except BaseException as error:
        traceback.print_exc()
        report = {
            "schema": SCHEMA,
            "task_id": TASK_ID,
            "hypothesis_id": HYPOTHESIS_ID,
            "run_id": arguments.run_id,
            "status": "ERROR",
            "classification": "PAD_CONSERVATIVE_CONVEX_COMPATIBILITY_RUNTIME_ERROR",
            "dynamic_compatibility_passed": False,
            "formal_b_passed": False,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "object_pose_write_after_physics_start_count": 0,
            "online_contact_truth_control_used": False,
            "new_h_number_created": False,
        }
    legacy._write_json(
        output / "PAD_CONSERVATIVE_CONVEX_COMPATIBILITY_RESULT.json", report
    )
    os.write(
        1,
        (json.dumps(report, allow_nan=False, sort_keys=True) + "\n").encode(),
    )
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
