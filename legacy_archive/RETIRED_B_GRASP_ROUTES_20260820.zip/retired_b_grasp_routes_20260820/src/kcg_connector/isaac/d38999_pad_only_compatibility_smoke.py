#!/usr/bin/env python3

"""PAD-only collision isolation for the D38999 B V5 finger chain.

The temporary URDF keeps the authored f2 link topology, inertials, joints, and
transmission semantics while removing every imported visual and collision.
Exactly five already-approved analytic PAD capsules are then attached to the
real f2Link2 rigid body and closed against one analytic cylinder.  Contact
truth is consumed only after each fixed-time action for post-hoc evidence.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np

import d38999_pad_conservative_convex_compatibility_smoke as full_chain


legacy = full_chain.legacy
REPOSITORY = Path(__file__).resolve().parents[3]
TASK_ROOT = full_chain.TASK_ROOT
DEFAULT_SOURCE_ASSET_DIR = full_chain.DEFAULT_SOURCE_ASSET_DIR
DEFAULT_PROXY_ASSET_DIR = full_chain.DEFAULT_PROXY_ASSET_DIR
FULL_CHAIN_TIMEOUT_RESULT = (
    TASK_ROOT / "PAD_CONSERVATIVE_CONVEX_COMPATIBILITY_SMOKE_01_TIMEOUT_RESULT.json"
)

SCHEMA = "D38999_B_V5_PAD_ONLY_COMPATIBILITY_SMOKE_V1"
TASK_ID = "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
HYPOTHESIS_ID = "B-V5-PAD-ONLY-COLLISION-ISOLATION"
RUN_ID = "B-V5-PAD-ONLY-SMOKE-01"
COLLISION_ROUTE = "CONSERVATIVE_CONVEX_PAD_PROXY"
FIRST_STEP_DEADLINE_S = 60.0


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-asset-dir", default=str(DEFAULT_SOURCE_ASSET_DIR))
    parser.add_argument("--proxy-asset-dir", default=str(DEFAULT_PROXY_ASSET_DIR))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--steps", type=int, default=1500)
    parser.add_argument("--run-id", default=RUN_ID)
    parser.add_argument("--kit-portable-root", required=True)
    arguments = parser.parse_args(argv)
    if arguments.run_id != RUN_ID:
        raise ValueError(f"only the non-H PAD-only run id {RUN_ID} is authorized")
    if not 1000 <= arguments.steps <= 2000:
        raise ValueError("--steps must be within the authorized 1000..2000 range")
    authorization = json.loads(
        full_chain.CONTINUOUS_AUTHORIZATION.read_text(encoding="utf-8")
    )
    retained = authorization.get("retained_boundaries", {})
    if (
        authorization.get("authority")
        != "USER_CONTINUOUS_AUTONOMOUS_AUTHORIZATION"
        or authorization.get("effective_until") != "USER_EXPLICITLY_SAYS_STOP"
        or authorization.get("scope", {}).get(
            "bounded_non_h_isaac_runs_automatically_authorized"
        )
        is not True
        or retained.get("new_h_number_forbidden") is not True
        or retained.get(
            "online_object_pose_contact_name_normal_event_truth_forbidden"
        )
        is not True
    ):
        raise ValueError("continuous autonomous authorization is absent or invalid")
    timeout = json.loads(FULL_CHAIN_TIMEOUT_RESULT.read_text(encoding="utf-8"))
    budget = timeout.get("new_compatibility_process_budget", {})
    if (
        timeout.get("classification")
        != "PREPHYSICS_TIMEOUT_REQUIRES_COLLISION_ISOLATION"
        or timeout.get("first_physics_step_entered") is not False
        or timeout.get("next_run") != RUN_ID
        or budget.get("limit") != 2
        or budget.get("started") != 0
    ):
        raise ValueError("PAD-only branch authorization or process budget changed")
    return arguments


def _element_digest(element: ET.Element) -> str:
    normalized = copy.deepcopy(element)
    for node in normalized.iter():
        node.tail = None
    return hashlib.sha256(ET.tostring(normalized, encoding="utf-8")).hexdigest()


def _build_pad_only_f2_urdf(source: Path, destination: Path) -> dict[str, Any]:
    source = Path(source).resolve()
    destination = Path(destination).resolve()
    source_root = ET.parse(source).getroot()
    output_root = ET.Element("robot", {"name": "d38999_pad_only_smoke_f2"})
    selected_links = ("handbase_link", "f2Link1", "f2Link2")
    selected_joints = ("f2j1", "f2j2")
    removed_visuals: dict[str, int] = {}
    removed_collisions: dict[str, int] = {}
    inertial_digests: dict[str, str] = {}
    joint_digests: dict[str, str] = {}

    for name in selected_links:
        source_link = source_root.find(f"link[@name='{name}']")
        if source_link is None:
            raise ValueError(f"missing source URDF link {name}")
        source_inertials = source_link.findall("inertial")
        if len(source_inertials) != 1:
            raise ValueError(f"expected exactly one source inertial on {name}")
        inertial_digests[name] = _element_digest(source_inertials[0])
        link = copy.deepcopy(source_link)
        visuals = list(link.findall("visual"))
        collisions = list(link.findall("collision"))
        removed_visuals[name] = len(visuals)
        removed_collisions[name] = len(collisions)
        for element in visuals + collisions:
            link.remove(element)
        if len(link.findall("inertial")) != 1:
            raise AssertionError(f"temporary isolation lost inertial on {name}")
        if _element_digest(link.find("inertial")) != inertial_digests[name]:
            raise AssertionError(f"temporary isolation changed inertial on {name}")
        if link.findall("visual") or link.findall("collision"):
            raise AssertionError(f"temporary isolation retained geometry on {name}")
        output_root.append(link)

    for name in selected_joints:
        source_joint = source_root.find(f"joint[@name='{name}']")
        if source_joint is None:
            raise ValueError(f"missing source URDF joint {name}")
        joint_digests[name] = _element_digest(source_joint)
        output_root.append(copy.deepcopy(source_joint))

    if any(count <= 0 for count in removed_collisions.values()):
        raise ValueError(
            f"PAD-only isolation did not remove every original collider: {removed_collisions}"
        )
    tree = ET.ElementTree(output_root)
    ET.indent(tree, space="  ")
    tree.write(destination, encoding="utf-8", xml_declaration=True)

    verification_root = ET.parse(destination).getroot()
    for name in selected_links:
        link = verification_root.find(f"link[@name='{name}']")
        if link is None or link.findall("visual") or link.findall("collision"):
            raise AssertionError(f"PAD-only output geometry gate failed on {name}")
        if _element_digest(link.find("inertial")) != inertial_digests[name]:
            raise AssertionError(f"PAD-only output inertial changed on {name}")
    for name in selected_joints:
        joint = verification_root.find(f"joint[@name='{name}']")
        if joint is None or _element_digest(joint) != joint_digests[name]:
            raise AssertionError(f"PAD-only output joint changed: {name}")

    return {
        "source_urdf": str(source),
        "source_urdf_sha256": legacy._sha256(source),
        "temporary_urdf": str(destination),
        "selected_links": list(selected_links),
        "selected_joints": list(selected_joints),
        "inertial_digests": inertial_digests,
        "joint_digests": joint_digests,
        "removed_visual_elements_by_link": removed_visuals,
        "removed_original_collision_elements_by_link": removed_collisions,
        "removed_original_collision_element_count": sum(
            removed_collisions.values()
        ),
        "output_visual_element_count": 0,
        "output_collision_element_count": 0,
        "real_joint_topology_mass_inertia_preserved": True,
        "source_visual_and_urdf_modified": False,
    }


def _verified_inputs(
    source_asset_dir: Path, proxy_asset_dir: Path
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Path]]:
    source_entry, proxy_entry, paths = full_chain._verified_inputs(
        source_asset_dir, proxy_asset_dir
    )
    timeout = json.loads(FULL_CHAIN_TIMEOUT_RESULT.read_text(encoding="utf-8"))
    if timeout.get("pad_capsule_incompatibility_claimed") is not False:
        raise ValueError("full-chain timeout incorrectly rejected the PAD capsules")
    if timeout.get("true_blocking_collision_prim") is not None:
        raise ValueError("full-chain timeout incorrectly claimed an isolated blocker")
    if timeout.get("tip_rootcause_confirmed") is not False:
        raise ValueError("full-chain timeout incorrectly confirmed the TIP conjecture")
    paths = dict(paths)
    paths["full_chain_timeout_result"] = FULL_CHAIN_TIMEOUT_RESULT
    return source_entry, proxy_entry, paths


def _derive_pad_only_fixture(proxy_entry: Mapping[str, Any]) -> dict[str, Any]:
    capsules = list(proxy_entry["capsules"])
    center_index = len(capsules) // 2
    center = capsules[center_index]
    center_local = np.asarray(center["center_local_m"], dtype=np.float64)
    axis_local = np.asarray(center["axis_unit_local"], dtype=np.float64)
    normal_local = np.asarray(
        proxy_entry["contact_frame_local"]["outward_normal_unit"],
        dtype=np.float64,
    )
    final_transform = legacy._f2_transform(legacy.SOURCE_URDF, legacy.CONTACT_Q_RAD)
    axis_world = final_transform[:3, :3] @ axis_local
    axis_world /= np.linalg.norm(axis_world)
    normal_world = final_transform[:3, :3] @ normal_local
    normal_world -= axis_world * float(normal_world @ axis_world)
    normal_world /= np.linalg.norm(normal_world)
    center_world = final_transform[:3, :3] @ center_local + final_transform[:3, 3]
    line_point = center_world + (
        legacy.CYLINDER_RADIUS_M
        + float(center["radius_m"])
        - full_chain.FIXTURE_PRELOAD_M
    ) * normal_world

    gaps: dict[str, list[float]] = {}
    for label, q_rad in (
        ("initial", legacy.INITIAL_Q_RAD),
        ("final", legacy.CONTACT_Q_RAD),
    ):
        transform = legacy._f2_transform(legacy.SOURCE_URDF, q_rad)
        values: list[float] = []
        for capsule in capsules:
            capsule_center = np.asarray(capsule["center_local_m"], dtype=np.float64)
            world_center = transform[:3, :3] @ capsule_center + transform[:3, 3]
            relative = world_center - line_point
            axial = axis_world * float(relative @ axis_world)
            radial_distance = float(np.linalg.norm(relative - axial))
            values.append(
                radial_distance
                - legacy.CYLINDER_RADIUS_M
                - float(capsule["radius_m"])
            )
        gaps[label] = values

    result = {
        "method": "REAL_F2_FK_PLUS_CENTER_UNCHANGED_PAD_CAPSULE_NO_TIP",
        "contact_q_rad": legacy.CONTACT_Q_RAD,
        "initial_q_rad": legacy.INITIAL_Q_RAD,
        "center_capsule_index": center_index,
        "axis_unit_world": axis_world.tolist(),
        "outward_normal_unit_world": normal_world.tolist(),
        "line_point_world_m": line_point.tolist(),
        "cylinder_radius_m": legacy.CYLINDER_RADIUS_M,
        "cylinder_height_m": legacy.CYLINDER_HEIGHT_M,
        "fixed_geometric_preload_m": full_chain.FIXTURE_PRELOAD_M,
        "initial_capsule_surface_gaps_m": gaps["initial"],
        "final_capsule_surface_gaps_m": gaps["final"],
        "initial_separation_pass": min(gaps["initial"]) > 0.010,
        "center_capsule_preload_pass": abs(
            gaps["final"][center_index] + full_chain.FIXTURE_PRELOAD_M
        )
        <= 1.0e-9,
        "adjacent_capsules_not_preloaded": all(
            value > 0.0
            for index, value in enumerate(gaps["final"])
            if index != center_index
        ),
        "tip_collision_enabled": False,
    }
    if not all(
        result[name]
        for name in (
            "initial_separation_pass",
            "center_capsule_preload_pass",
            "adjacent_capsules_not_preloaded",
        )
    ):
        raise ValueError(f"PAD-only fixture preflight failed: {result}")
    return result


def _emit_milestone(name: str, elapsed_s: float, **values: Any) -> None:
    payload = {
        "kind": "PAD_ONLY_MILESTONE",
        "name": name,
        "elapsed_from_process_start_s": elapsed_s,
        **values,
    }
    os.write(1, (json.dumps(payload, allow_nan=False, sort_keys=True) + "\n").encode())


def _run(
    arguments: argparse.Namespace,
    application: Any,
    process_started: float,
) -> dict[str, Any]:
    import carb.logging
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_simulation_interface
    import omni.usd
    from pxr import (
        Gf,
        PhysicsSchemaTools,
        PhysxSchema,
        Sdf,
        Usd,
        UsdGeom,
        UsdPhysics,
        UsdShade,
    )

    output = Path(arguments.output_dir).resolve()
    source_dir = Path(arguments.source_asset_dir).resolve()
    proxy_dir = Path(arguments.proxy_asset_dir).resolve()
    source_entry, proxy_entry, input_paths = _verified_inputs(source_dir, proxy_dir)
    relevant_inputs = {
        name: path for name, path in input_paths.items() if name != "tip"
    }
    input_hashes_before = {
        name: legacy._sha256(path) for name, path in relevant_inputs.items()
    }
    pad_arrays = legacy._load_arrays(input_paths["pad"])
    fixture = _derive_pad_only_fixture(proxy_entry)

    temporary_urdf = output / "d38999_pad_only_smoke_f2.urdf"
    urdf_evidence = _build_pad_only_f2_urdf(legacy.SOURCE_URDF, temporary_urdf)
    import_directory = output / "pad_only_f2_usd"
    import_directory.mkdir(parents=False, exist_ok=False)
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=str(temporary_urdf),
            usd_path=str(import_directory),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    application.update()
    if not imported_path.exists():
        raise RuntimeError(f"PAD-only URDF import did not create {imported_path}")
    _emit_milestone(
        "URDF_IMPORTED",
        time.perf_counter() - process_started,
        imported_path=str(imported_path),
    )

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    application.update()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / legacy.PHYSICS_RATE_HZ,
        rendering_dt=1.0 / 60.0,
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/Finger")
    application.update()

    terminal = legacy._find_unique_prim(
        stage,
        lambda prim: prim.GetName() == "f2Link2"
        and prim.HasAPI(UsdPhysics.RigidBodyAPI),
        "PAD-only f2Link2 rigid link",
    )
    terminal_path = terminal.GetPath()
    instanceability = {
        "path": str(terminal_path),
        "is_instance_before": bool(terminal.IsInstance()),
        "is_instance_proxy_before": bool(terminal.IsInstanceProxy()),
        "deinstance_required": bool(terminal.IsInstance()),
        "deinstance_succeeded": False,
    }
    if terminal.IsInstanceProxy():
        raise RuntimeError("PAD-only terminal unexpectedly remained an instance proxy")
    if terminal.IsInstance():
        if not terminal.SetInstanceable(False):
            raise RuntimeError("failed to deinstance PAD-only terminal")
        application.update()
        terminal = stage.GetPrimAtPath(terminal_path)
        instanceability["deinstance_succeeded"] = bool(
            terminal.IsValid()
            and not terminal.IsInstance()
            and not terminal.IsInstanceProxy()
            and terminal.HasAPI(UsdPhysics.RigidBodyAPI)
        )
        if not instanceability["deinstance_succeeded"]:
            raise RuntimeError(f"PAD-only deinstance failed: {instanceability}")
    else:
        instanceability["deinstance_succeeded"] = True

    articulation_root = legacy._find_unique_prim(
        stage,
        lambda prim: prim.HasAPI(UsdPhysics.ArticulationRootAPI),
        "PAD-only f2 articulation root",
    )
    imported_collision_paths = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(articulation_root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if imported_collision_paths:
        raise RuntimeError(
            f"PAD-only imported chain retained non-PAD collision: {imported_collision_paths}"
        )

    physics_scene = legacy._find_unique_prim(
        stage,
        lambda prim: prim.IsA(UsdPhysics.Scene),
        "physics scene",
    )
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene)
    physx_scene.CreateEnableGPUDynamicsAttr().Set(True)
    physx_scene.CreateBroadphaseTypeAttr().Set("GPU")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(0.0)

    material_root = "/World/PhysicsMaterials"
    UsdGeom.Scope.Define(stage, material_root)

    def material(path: str, static: float, dynamic: float) -> Any:
        value = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(value.GetPrim())
        api.CreateStaticFrictionAttr(static)
        api.CreateDynamicFrictionAttr(dynamic)
        api.CreateRestitutionAttr(0.0)
        return value

    pad_material = material(
        material_root + "/PAD_FRICTION",
        legacy.PAD_STATIC_FRICTION,
        legacy.PAD_DYNAMIC_FRICTION,
    )
    cylinder_material = material(
        material_root + "/CYLINDER_BASE_FRICTION",
        legacy.BASE_STATIC_FRICTION,
        legacy.BASE_DYNAMIC_FRICTION,
    )

    pad_paths: set[str] = set()
    for capsule in proxy_entry["capsules"]:
        path = str(terminal.GetPath()) + "/" + str(capsule["prim_name"])
        geometry = UsdGeom.Capsule.Define(stage, path)
        geometry.CreateAxisAttr(UsdGeom.Tokens.z)
        radius = float(capsule["radius_m"])
        height = float(capsule["cylinder_height_m"])
        geometry.CreateRadiusAttr(radius)
        geometry.CreateHeightAttr(height)
        half_extent = 0.5 * height + radius
        geometry.CreateExtentAttr(
            [
                Gf.Vec3f(-radius, -radius, -half_extent),
                Gf.Vec3f(radius, radius, half_extent),
            ]
        )
        xform = UsdGeom.Xformable(geometry)
        xform.AddTranslateOp().Set(Gf.Vec3d(*capsule["center_local_m"]))
        rotation = Gf.Rotation(
            Gf.Vec3d(0.0, 0.0, 1.0),
            Gf.Vec3d(*capsule["axis_unit_local"]),
        )
        xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
        UsdPhysics.CollisionAPI.Apply(geometry.GetPrim()).CreateCollisionEnabledAttr(
            True
        )
        collision = PhysxSchema.PhysxCollisionAPI.Apply(geometry.GetPrim())
        collision.CreateContactOffsetAttr(legacy.CONTACT_OFFSET_M)
        collision.CreateRestOffsetAttr(legacy.REST_OFFSET_M)
        UsdShade.MaterialBindingAPI(geometry.GetPrim()).Bind(
            pad_material, materialPurpose="physics"
        )
        geometry.GetPrim().CreateAttribute(
            "kcg:collisionRole", Sdf.ValueTypeNames.Token
        ).Set("PAD_CONTACT_SURFACE_PROXY")
        geometry.GetPrim().CreateAttribute(
            "kcg:proxyIndex", Sdf.ValueTypeNames.Int
        ).Set(int(capsule["index"]))
        pad_paths.add(path)

    cylinder_path = "/World/CouplingNutCurvatureCylinder"
    cylinder = UsdGeom.Cylinder.Define(stage, cylinder_path)
    cylinder.CreateAxisAttr(UsdGeom.Tokens.z)
    cylinder.CreateRadiusAttr(legacy.CYLINDER_RADIUS_M)
    cylinder.CreateHeightAttr(legacy.CYLINDER_HEIGHT_M)
    xform = UsdGeom.Xformable(cylinder)
    xform.AddTranslateOp().Set(Gf.Vec3d(*fixture["line_point_world_m"]))
    rotation = Gf.Rotation(
        Gf.Vec3d(0.0, 0.0, 1.0),
        Gf.Vec3d(*fixture["axis_unit_world"]),
    )
    xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
    UsdPhysics.CollisionAPI.Apply(cylinder.GetPrim()).CreateCollisionEnabledAttr(True)
    cylinder_collision = PhysxSchema.PhysxCollisionAPI.Apply(cylinder.GetPrim())
    cylinder_collision.CreateContactOffsetAttr(legacy.CONTACT_OFFSET_M)
    cylinder_collision.CreateRestOffsetAttr(legacy.REST_OFFSET_M)
    UsdShade.MaterialBindingAPI(cylinder.GetPrim()).Bind(
        cylinder_material, materialPurpose="physics"
    )
    cylinder.GetPrim().CreateAttribute(
        "kcg:collisionRole", Sdf.ValueTypeNames.Token
    ).Set("COUPLING_NUT_CURVATURE")

    chain_collision_paths = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(articulation_root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if set(chain_collision_paths) != pad_paths:
        raise RuntimeError(
            "PAD-only chain must contain exactly the five PAD capsules: "
            f"{chain_collision_paths}"
        )

    PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
    robot = world.scene.add(
        SingleArticulation(
            prim_path=str(articulation_root.GetPath()),
            name="d38999_pad_only_smoke_f2",
        )
    )

    relevant_log_rows: list[dict[str, Any]] = []
    logging = carb.logging.acquire_logging()

    def on_log(source: str, level: int, filename: str, line: int, message: str) -> None:
        value = str(message)
        lowered = value.lower()
        if (
            ("physicsusd" in lowered and ("error" in lowered or "failed" in lowered))
            or ("solver" in lowered and ("error" in lowered or "failed" in lowered))
            or (
                "capsule" in lowered
                and any(word in lowered for word in ("error", "failed", "unsupported"))
            )
        ):
            relevant_log_rows.append(
                {
                    "source": str(source),
                    "level": int(level),
                    "filename": str(filename),
                    "line": int(line),
                    "message": value,
                }
            )

    logger_handle = logging.add_logger(on_log)
    trace: list[dict[str, Any]] = []
    pad_local_points: list[list[float]] = []
    pad_impulses: list[float] = []
    capsule_impulses = {path: 0.0 for path in sorted(pad_paths)}
    radial_normal_alignments: list[float] = []
    maximum_joint_speed = 0.0
    finite_throughout = True
    reset_started_elapsed_s: float | None = None
    reset_completed_elapsed_s: float | None = None
    first_step_elapsed_s: float | None = None
    step_wall_times: list[float] = []
    try:
        reset_started_elapsed_s = time.perf_counter() - process_started
        world.reset()
        reset_completed_elapsed_s = time.perf_counter() - process_started
        _emit_milestone("WORLD_RESET_COMPLETE", reset_completed_elapsed_s)
        dof_names = list(robot.dof_names)
        if "f2j1" not in dof_names or "f2j2" not in dof_names:
            raise RuntimeError(f"real f2 joints missing from articulation: {dof_names}")
        indices = {name: index for index, name in enumerate(dof_names)}
        active_index = indices["f2j1"]
        follower_index = indices["f2j2"]
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        positions[active_index] = legacy.INITIAL_Q_RAD
        positions[follower_index] = legacy.INITIAL_Q_RAD
        robot.set_joint_positions(positions)
        robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
        controller = robot.get_articulation_controller()
        kps = np.zeros(robot.num_dof, dtype=np.float32)
        kds = np.zeros(robot.num_dof, dtype=np.float32)
        kps[active_index] = 12.0
        kds[active_index] = 0.8
        controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

        warmup_steps = 120
        close_steps = min(900, arguments.steps - warmup_steps - 240)
        interface = get_physx_simulation_interface()
        cylinder_axis = np.asarray(fixture["axis_unit_world"], dtype=np.float64)
        cylinder_line = np.asarray(fixture["line_point_world_m"], dtype=np.float64)

        for step in range(arguments.steps):
            if step < warmup_steps:
                target = legacy.INITIAL_Q_RAD
                phase = "OPEN_SETTLE"
            elif step < warmup_steps + close_steps:
                fraction = (step - warmup_steps + 1) / float(close_steps)
                target = legacy.INITIAL_Q_RAD + legacy._minimum_jerk(fraction) * (
                    legacy.CONTACT_Q_RAD - legacy.INITIAL_Q_RAD
                )
                phase = "MINIMUM_JERK_CLOSE"
            else:
                target = legacy.CONTACT_Q_RAD
                phase = "CONTACT_HOLD"
            robot.apply_action(
                ArticulationAction(
                    joint_positions=np.asarray([target], dtype=np.float32),
                    joint_indices=np.asarray([active_index], dtype=np.int32),
                )
            )
            started = time.perf_counter()
            world.step(render=False)
            step_wall_s = time.perf_counter() - started
            step_wall_times.append(step_wall_s)
            if step == 0:
                first_step_elapsed_s = time.perf_counter() - process_started
                _emit_milestone(
                    "FIRST_PHYSICS_STEP_COMPLETE",
                    first_step_elapsed_s,
                    deadline_s=FIRST_STEP_DEADLINE_S,
                    within_deadline=first_step_elapsed_s <= FIRST_STEP_DEADLINE_S,
                )

            state_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
            state_velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
            finite = bool(
                np.all(np.isfinite(state_positions))
                and np.all(np.isfinite(state_velocities))
            )
            finite_throughout = finite_throughout and finite
            if not finite:
                break
            maximum_joint_speed = max(
                maximum_joint_speed, float(np.max(np.abs(state_velocities)))
            )

            terminal_matrix = UsdGeom.Xformable(terminal).ComputeLocalToWorldTransform(
                Usd.TimeCode.Default()
            )
            world_to_terminal = terminal_matrix.GetInverse()
            headers, contacts, _friction = interface.get_full_contact_report()
            pad_step_impulse = 0.0
            pad_step_count = 0
            active_pad_paths: set[str] = set()
            for header in headers:
                collider0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
                collider1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
                pair = {collider0, collider1}
                matched = next((path for path in pad_paths if path in pair), None)
                if cylinder_path not in pair or matched is None:
                    continue
                start = int(header.contact_data_offset)
                stop = start + int(header.num_contact_data)
                for contact in contacts[start:stop]:
                    impulse = np.asarray(contact.impulse, dtype=np.float64)
                    impulse_norm = float(np.linalg.norm(impulse))
                    position = np.asarray(contact.position, dtype=np.float64)
                    local = world_to_terminal.Transform(Gf.Vec3d(*position))
                    pad_local_points.append([float(local[index]) for index in range(3)])
                    pad_impulses.append(impulse_norm)
                    capsule_impulses[matched] += impulse_norm
                    active_pad_paths.add(matched)
                    pad_step_impulse += impulse_norm
                    pad_step_count += 1
                    relative = position - cylinder_line
                    radial = relative - cylinder_axis * float(relative @ cylinder_axis)
                    radial_norm = float(np.linalg.norm(radial))
                    normal = np.asarray(contact.normal, dtype=np.float64)
                    normal_norm = float(np.linalg.norm(normal))
                    if radial_norm > 1.0e-12 and normal_norm > 1.0e-12:
                        radial_normal_alignments.append(
                            abs(float((radial / radial_norm) @ (normal / normal_norm)))
                        )
            trace.append(
                {
                    "step": step + 1,
                    "phase": phase,
                    "target_f2j1_rad": target,
                    "f2j1_rad": float(state_positions[active_index]),
                    "f2j2_rad": float(state_positions[follower_index]),
                    "f2j1_velocity_rad_s": float(state_velocities[active_index]),
                    "f2j2_velocity_rad_s": float(state_velocities[follower_index]),
                    "pad_contact_count": pad_step_count,
                    "active_pad_primitive_count": len(active_pad_paths),
                    "pad_contact_force_n": pad_step_impulse * legacy.PHYSICS_RATE_HZ,
                    "step_wall_s": step_wall_s,
                }
            )
    finally:
        logging.remove_logger(logger_handle)

    if not trace or first_step_elapsed_s is None:
        raise RuntimeError("PAD-only smoke did not execute its first physics step")

    stage_path = output / "PAD_ONLY_COMPATIBILITY_STAGE.usda"
    stage.Export(str(stage_path))
    trace_path = output / "PAD_ONLY_CONTACT_TRACE.csv"
    with trace_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(trace[0]))
        writer.writeheader()
        writer.writerows(trace)

    points_array = np.asarray(pad_local_points, dtype=np.float64).reshape((-1, 3))
    impulses_array = np.asarray(pad_impulses, dtype=np.float64)
    role_audit = legacy._nearest_pad_roles(points_array, impulses_array, pad_arrays)
    pad_force = np.asarray(
        [row["pad_contact_force_n"] for row in trace], dtype=np.float64
    )
    hold_force = pad_force[-min(240, len(pad_force)) :]
    step_times = np.asarray(step_wall_times, dtype=np.float64)
    final = trace[-1]
    pad_colliders = [
        prim
        for prim in stage.Traverse()
        if prim.HasAPI(UsdPhysics.CollisionAPI)
        and prim.GetAttribute("kcg:collisionRole")
        and str(prim.GetAttribute("kcg:collisionRole").Get())
        == "PAD_CONTACT_SURFACE_PROXY"
    ]
    chain_inventory = [
        {
            "path": str(prim.GetPath()),
            "type_name": prim.GetTypeName(),
            "role": (
                str(prim.GetAttribute("kcg:collisionRole").Get())
                if prim.GetAttribute("kcg:collisionRole")
                else None
            ),
        }
        for prim in Usd.PrimRange(articulation_root)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    analytic_capsules = len(pad_colliders) == len(proxy_entry["capsules"]) and all(
        prim.IsA(UsdGeom.Capsule)
        and float(UsdGeom.Capsule(prim).GetRadiusAttr().Get())
        == float(proxy_entry["capsules"][index]["radius_m"])
        and float(UsdGeom.Capsule(prim).GetHeightAttr().Get())
        == float(proxy_entry["capsules"][index]["cylinder_height_m"])
        for index, prim in enumerate(
            sorted(pad_colliders, key=lambda value: str(value.GetPath()))
        )
    )
    physicsusd_errors = [
        row for row in relevant_log_rows if "physicsusd" in row["message"].lower()
    ]
    solver_errors = [
        row for row in relevant_log_rows if "solver" in row["message"].lower()
    ]
    capsule_errors = [
        row for row in relevant_log_rows if "capsule" in row["message"].lower()
    ]
    median_hold_force = float(np.median(hold_force))
    maximum_force = float(np.max(pad_force))
    mean_step_wall = float(np.mean(step_times))
    gates = {
        "first_physics_step_entered": True,
        "world_reset_completed_before_first_step": bool(
            reset_completed_elapsed_s is not None
            and reset_completed_elapsed_s <= first_step_elapsed_s
        ),
        "first_physics_step_within_60_seconds": (
            first_step_elapsed_s <= FIRST_STEP_DEADLINE_S
        ),
        "authorized_step_count": len(trace) == arguments.steps,
        "real_f2_topology_mass_inertia_preserved": urdf_evidence[
            "real_joint_topology_mass_inertia_preserved"
        ],
        "real_f2_articulation_initialized": bool(robot.handles_initialized),
        "all_imported_non_pad_collisions_disabled": not imported_collision_paths,
        "five_unchanged_pad_capsules_only": (
            len(chain_inventory) == 5
            and len(pad_colliders) == 5
            and analytic_capsules
        ),
        "tip_collision_disabled": all(
            row["role"] != "TIP_END_SURFACE" for row in chain_inventory
        ),
        "old_whole_terminal_hull_absent": all(
            "f2Link2_convex" not in row["path"] for row in chain_inventory
        ),
        "joint_state_finite": finite_throughout,
        "real_closure_progress": final["f2j1_rad"] - legacy.INITIAL_Q_RAD >= 0.35,
        "mimic_follower_tracks": abs(final["f2j2_rad"] - final["f2j1_rad"])
        <= 0.05,
        "pad_contact_established": role_audit["contact_count"] > 0,
        "pad_inner_impulse_share": role_audit[
            "PAD_CONTACT_SURFACE_impulse_share"
        ]
        >= 0.90,
        "contact_normals_radial": bool(radial_normal_alignments)
        and float(np.median(radial_normal_alignments)) >= 0.70,
        "stable_nonzero_hold_force": 0.10 <= median_hold_force <= 30.0,
        "no_single_step_force_explosion": maximum_force
        <= legacy.FORCE_EXPLOSION_THRESHOLD_N,
        "joint_speed_bounded": maximum_joint_speed <= 8.0,
        "physicsusd_error_zero": not physicsusd_errors,
        "solver_error_zero": not solver_errors,
        "capsule_error_zero": not capsule_errors,
        "mean_240hz_step_budget": mean_step_wall <= 1.0 / legacy.PHYSICS_RATE_HZ,
        "object_pose_write_after_physics_zero": True,
        "online_contact_truth_control_zero": True,
    }
    passed = all(gates.values())
    input_hashes_after = {
        name: legacy._sha256(path) for name, path in relevant_inputs.items()
    }
    return {
        "schema": SCHEMA,
        "task_id": TASK_ID,
        "hypothesis_id": HYPOTHESIS_ID,
        "run_id": arguments.run_id,
        "status": "PASS" if passed else "FAIL",
        "classification": (
            "PAD_ONLY_SMOKE_PASS"
            if passed
            else "PAD_ONLY_SMOKE_REACHED_PHYSICS_BUT_GATE_FAILED"
        ),
        "pad_only_passed": passed,
        "formal_b_passed": False,
        "collision_route": COLLISION_ROUTE,
        "first_physics_step_entered": True,
        "startup_timing": {
            "deadline_s": FIRST_STEP_DEADLINE_S,
            "world_reset_started_elapsed_s": reset_started_elapsed_s,
            "world_reset_completed_elapsed_s": reset_completed_elapsed_s,
            "first_physics_step_completed_elapsed_s": first_step_elapsed_s,
            "first_step_within_deadline": first_step_elapsed_s
            <= FIRST_STEP_DEADLINE_S,
        },
        "source_asset": {"directory": str(source_dir), "entry": source_entry},
        "proxy_asset": {"directory": str(proxy_dir), "entry": proxy_entry},
        "input_sha256_before": input_hashes_before,
        "input_sha256_after": input_hashes_after,
        "inputs_unchanged": input_hashes_before == input_hashes_after,
        "minimal_real_finger_chain": urdf_evidence,
        "imported_usd": str(imported_path),
        "articulation_root": str(articulation_root.GetPath()),
        "terminal_instanceability": instanceability,
        "dof_names": list(robot.dof_names),
        "fixture": fixture,
        "imported_collision_paths_before_pad_authoring": imported_collision_paths,
        "pad_collision_body_count": len(pad_colliders),
        "tip_collision_body_count": 0,
        "other_chain_collision_body_count": len(chain_inventory) - len(pad_colliders),
        "chain_collision_inventory": chain_inventory,
        "old_whole_distal_hull_runtime_removed": gates[
            "old_whole_terminal_hull_absent"
        ],
        "contact_role_audit": role_audit,
        "pad_impulse_total_ns": float(np.sum(impulses_array)),
        "per_capsule_impulse_ns": capsule_impulses,
        "median_radial_normal_alignment": (
            float(np.median(radial_normal_alignments))
            if radial_normal_alignments
            else None
        ),
        "force_stability": {
            "median_last_240_step_pad_force_n": median_hold_force,
            "maximum_single_step_pad_force_n": maximum_force,
            "explosion_threshold_n": legacy.FORCE_EXPLOSION_THRESHOLD_N,
            "working_5_to_8_n_observed": 5.0 <= median_hold_force <= 8.0,
            "working_5_to_8_n_is_pad_only_gate": False,
        },
        "articulation_metrics": {
            "final_f2j1_rad": final["f2j1_rad"],
            "final_f2j2_rad": final["f2j2_rad"],
            "maximum_abs_joint_speed_rad_s": maximum_joint_speed,
            "finite_throughout": finite_throughout,
        },
        "performance": {
            "physics_rate_hz": legacy.PHYSICS_RATE_HZ,
            "step_count": len(trace),
            "mean_step_wall_s": mean_step_wall,
            "p95_step_wall_s": float(np.percentile(step_times, 95.0)),
        },
        "runtime_log_evidence": {
            "retained_messages": relevant_log_rows,
            "physicsusd_error_count": len(physicsusd_errors),
            "solver_error_count": len(solver_errors),
            "capsule_error_count": len(capsule_errors),
        },
        "gates": gates,
        "control_truth_boundary": {
            "controller_type": "FIXED_TIME_MINIMUM_JERK_JOINT_POSITION",
            "control_reads_object_pose_truth": False,
            "control_reads_contact_names": False,
            "control_reads_contact_normals": False,
            "control_reads_contact_events": False,
            "posthoc_contact_truth_audit": True,
            "object_pose_write_after_physics_start_count": 0,
        },
        "true_blocking_collision_prim": None,
        "tip_rootcause_confirmed": False,
        "stage_exported_after_first_physics_step": True,
        "stage_usda": str(stage_path),
        "trace_csv": str(trace_path),
        "runner_sha256": legacy._sha256(Path(__file__)),
        "new_h_number_created": False,
        "next_run_if_pass": "B-V5-PAD-PLUS-SIMPLE-TIP-SMOKE-01",
    }


def main(argv: Sequence[str] | None = None) -> int:
    process_started = time.perf_counter()
    arguments = _arguments(argv)
    output = Path(arguments.output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite PAD-only output: {output}")
    output.mkdir(parents=True, exist_ok=False)
    portable = Path(arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    exit_code = 1
    report: dict[str, Any]
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": True,
                "hide_ui": True,
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        _emit_milestone("SIMULATION_APP_READY", time.perf_counter() - process_started)
        report = _run(arguments, application, process_started)
        exit_code = 0 if report["pad_only_passed"] else 3
    except BaseException as error:
        traceback.print_exc()
        report = {
            "schema": SCHEMA,
            "task_id": TASK_ID,
            "hypothesis_id": HYPOTHESIS_ID,
            "run_id": arguments.run_id,
            "status": "ERROR",
            "classification": "PAD_ONLY_SMOKE_RUNTIME_ERROR",
            "pad_only_passed": False,
            "formal_b_passed": False,
            "first_physics_step_entered": False,
            "elapsed_from_process_start_s": time.perf_counter() - process_started,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "object_pose_write_after_physics_start_count": 0,
            "online_contact_truth_control_used": False,
            "true_blocking_collision_prim": None,
            "tip_rootcause_confirmed": False,
            "new_h_number_created": False,
        }
    legacy._write_json(output / "PAD_ONLY_COMPATIBILITY_RESULT.json", report)
    os.write(1, (json.dumps(report, allow_nan=False, sort_keys=True) + "\n").encode())
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
