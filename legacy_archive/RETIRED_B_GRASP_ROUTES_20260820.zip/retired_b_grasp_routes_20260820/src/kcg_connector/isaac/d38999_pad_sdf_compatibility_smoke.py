#!/usr/bin/env python3

"""Minimal dynamic compatibility smoke for the D38999 V5 blue PAD SDF.

The controller follows a fixed minimum-jerk finger-closing trajectory. PhysX
contact/collider truth is read only after each action for post-hoc audit and is
never an online controller input.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np


REPOSITORY = Path(__file__).resolve().parents[3]
TASK_ROOT = (
    REPOSITORY
    / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2"
    / "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
)
DEFAULT_ASSET_DIR = TASK_ROOT / "BLUE_PAD_SDF_SOURCE_ASSET_V2"
ADDITIONAL_INTERFACE_AUTHORIZATION = (
    TASK_ROOT / "PAD_SDF_ADDITIONAL_INTERFACE_REPAIR_AUTHORIZATION.json"
)
CONTINUOUS_AUTONOMOUS_AUTHORIZATION = (
    TASK_ROOT / "CONTINUOUS_AUTONOMOUS_AUTHORIZATION.json"
)
SOURCE_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
SCHEMA = "D38999_B_V5_PAD_SDF_COMPATIBILITY_SMOKE_V1"
TASK_ID = "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
HYPOTHESIS_ID = "B-V5-PAD-SDF-ARTICULATION-COMPATIBILITY"
PHYSICS_RATE_HZ = 240.0
INITIAL_Q_RAD = 0.35
CONTACT_Q_RAD = 0.75
CYLINDER_RADIUS_M = 0.024
CYLINDER_HEIGHT_M = 0.020
SDF_RESOLUTION = 256
SDF_SUBGRID_RESOLUTION = 6
CONTACT_OFFSET_M = 0.00025
REST_OFFSET_M = 0.0
PAD_STATIC_FRICTION = 0.50
PAD_DYNAMIC_FRICTION = 0.50
BASE_STATIC_FRICTION = 0.30
BASE_DYNAMIC_FRICTION = 0.30
FORCE_EXPLOSION_THRESHOLD_N = 100.0


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--asset-dir", default=str(DEFAULT_ASSET_DIR))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--steps", type=int, default=1500)
    parser.add_argument("--interface-fix-attempt", type=int, default=0)
    parser.add_argument("--kit-portable-root", required=True)
    arguments = parser.parse_args(argv)
    if not 1000 <= arguments.steps <= 2000:
        raise ValueError("--steps must be within the authorized 1000..2000 range")
    if arguments.interface_fix_attempt not in (0, 1, 2, 3):
        raise ValueError(
            "only SDF interface-fix attempts 0, 1, 2, and authorized 3 exist"
        )
    if arguments.interface_fix_attempt == 2:
        authorization = json.loads(
            ADDITIONAL_INTERFACE_AUTHORIZATION.read_text(encoding="utf-8")
        )
        if (
            authorization.get("authority")
            != "USER_EXPLICIT_ADDITIONAL_INTERFACE_REPAIR_AUTHORIZATION"
            or authorization.get("authorized_run_id")
            != "B-V5-PAD-SDF-COMPATIBILITY-SMOKE-IFIX02"
            or authorization.get("additional_interface_repairs_authorized") != 1
            or authorization.get("additional_smoke_reruns_authorized") != 1
            or authorization.get("new_h_number_created") is not False
            or authorization.get("convex_fallback_authorized") is not False
        ):
            raise ValueError("IFIX02 additional authorization is absent or invalid")
    if arguments.interface_fix_attempt == 3:
        authorization = json.loads(
            CONTINUOUS_AUTONOMOUS_AUTHORIZATION.read_text(encoding="utf-8")
        )
        immediate = authorization.get("immediate_authorization", {})
        retained = authorization.get("retained_boundaries", {})
        if (
            authorization.get("authority")
            != "USER_CONTINUOUS_AUTONOMOUS_AUTHORIZATION"
            or authorization.get("effective_until") != "USER_EXPLICITLY_SAYS_STOP"
            or immediate.get("precision_double_orient_fix_authorized") is not True
            or immediate.get("same_sdf_smoke_rerun_authorized") is not True
            or immediate.get("planned_run_id")
            != "B-V5-PAD-SDF-COMPATIBILITY-SMOKE-IFIX03"
            or retained.get("new_h_number_forbidden") is not True
            or retained.get("online_object_pose_contact_name_normal_event_truth_forbidden")
            is not True
            or retained.get(
                "convex_fallback_requires_dynamic_sdf_incompatibility_evidence"
            )
            is not True
        ):
            raise ValueError("IFIX03 continuous authorization is absent or invalid")
    return arguments


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, allow_nan=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _source_finger_entry(asset_dir: Path) -> tuple[dict[str, Any], dict[str, Path]]:
    manifest_path = asset_dir / "PAD_SDF_SOURCE_ASSET_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("collision_route") != "PHYSX_SDF":
        raise ValueError("PAD source manifest is not the authorized PHYSX_SDF route")
    matches = [row for row in manifest["links"] if row["link_name"] == "f2Link2"]
    if len(matches) != 1:
        raise ValueError(f"expected one f2Link2 PAD source; got {len(matches)}")
    entry = matches[0]
    paths = {
        "manifest": manifest_path,
        "pad": asset_dir / entry["pad_sdf_source_arrays"],
        "tip": asset_dir / entry["tip_base_collision_source_arrays"],
    }
    expected = {
        "pad": entry["pad_sdf_source_arrays_sha256"],
        "tip": entry["tip_base_collision_source_arrays_sha256"],
    }
    for key in ("pad", "tip"):
        actual = _sha256(paths[key])
        if actual != expected[key]:
            raise ValueError(f"{key} source SHA-256 changed: {actual} != {expected[key]}")
    return entry, paths


def _load_arrays(path: Path) -> dict[str, np.ndarray]:
    with np.load(path) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _build_minimal_f2_urdf(source: Path, destination: Path) -> dict[str, Any]:
    source_root = ET.parse(source).getroot()
    root = ET.Element("robot", {"name": "d38999_pad_sdf_smoke_f2"})
    selected_links = ("handbase_link", "f2Link1", "f2Link2")
    selected_joints = ("f2j1", "f2j2")
    removed_terminal_collisions = 0
    for name in selected_links:
        found = source_root.find(f"link[@name='{name}']")
        if found is None:
            raise ValueError(f"missing source URDF link {name}")
        element = copy.deepcopy(found)
        if name == "f2Link2":
            for collision in list(element.findall("collision")):
                element.remove(collision)
                removed_terminal_collisions += 1
        root.append(element)
    for name in selected_joints:
        found = source_root.find(f"joint[@name='{name}']")
        if found is None:
            raise ValueError(f"missing source URDF joint {name}")
        root.append(copy.deepcopy(found))
    if removed_terminal_collisions != 1:
        raise ValueError(
            f"expected to remove one old f2Link2 full hull; got {removed_terminal_collisions}"
        )
    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    tree.write(destination, encoding="utf-8", xml_declaration=True)
    return {
        "source_urdf": str(source),
        "source_urdf_sha256": _sha256(source),
        "selected_links": list(selected_links),
        "selected_joints": list(selected_joints),
        "removed_old_terminal_full_hull_collision_count": removed_terminal_collisions,
        "visual_elements_retained": 3,
        "inertial_elements_retained": 3,
        "joint_origin_axis_limit_dynamics_retained": True,
    }


def _rpy_rotation(rpy: np.ndarray) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.array(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ],
        dtype=np.float64,
    )


def _axis_rotation(axis: np.ndarray, angle: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=np.float64)
    axis /= np.linalg.norm(axis)
    x, y, z = axis
    skew = np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])
    return np.eye(3) + math.sin(angle) * skew + (1.0 - math.cos(angle)) * (
        skew @ skew
    )


def _f2_transform(source_urdf: Path, q_rad: float) -> np.ndarray:
    root = ET.parse(source_urdf).getroot()
    transform = np.eye(4, dtype=np.float64)
    for name in ("f2j1", "f2j2"):
        joint = root.find(f"joint[@name='{name}']")
        if joint is None:
            raise ValueError(f"missing {name}")
        origin = joint.find("origin")
        axis = joint.find("axis")
        xyz = np.fromstring(origin.attrib.get("xyz", "0 0 0"), sep=" ")
        rpy = np.fromstring(origin.attrib.get("rpy", "0 0 0"), sep=" ")
        axis_xyz = np.fromstring(axis.attrib.get("xyz", "0 0 1"), sep=" ")
        step = np.eye(4, dtype=np.float64)
        step[:3, :3] = _rpy_rotation(rpy)
        step[:3, 3] = xyz
        rotation = np.eye(4, dtype=np.float64)
        rotation[:3, :3] = _axis_rotation(axis_xyz, q_rad)
        transform = transform @ step @ rotation
    return transform


def _component_radial_stats(
    vertices: np.ndarray,
    transform: np.ndarray,
    line_point: np.ndarray,
    axis: np.ndarray,
) -> dict[str, Any]:
    world = (transform[:3, :3] @ vertices.T).T + transform[:3, 3]
    relative = world - line_point
    axial = relative @ axis
    radial = np.linalg.norm(relative - axial[:, None] * axis, axis=1)
    overlap = np.abs(axial) <= CYLINDER_HEIGHT_M / 2.0
    return {
        "axial_overlap_vertex_count": int(np.count_nonzero(overlap)),
        "minimum_radial_distance_m": (
            float(np.min(radial[overlap])) if np.any(overlap) else None
        ),
        "maximum_radial_distance_m": (
            float(np.max(radial[overlap])) if np.any(overlap) else None
        ),
        "axial_range_m": [float(np.min(axial)), float(np.max(axial))],
    }


def _derive_cylinder_fixture(
    pad: Mapping[str, np.ndarray], tip: Mapping[str, np.ndarray]
) -> dict[str, Any]:
    points = np.asarray(pad["points_local_m"], dtype=np.float64)
    faces = np.asarray(pad["faces"], dtype=np.int64)
    contact_ids = np.asarray(pad["pad_contact_face_ids"], dtype=np.int64)
    triangles = points[faces[contact_ids]]
    centers_local = np.mean(triangles, axis=1)
    cross = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
    double_area = np.linalg.norm(cross, axis=1)
    normals_local = cross / double_area[:, None]
    areas = 0.5 * double_area
    transform = _f2_transform(SOURCE_URDF, CONTACT_Q_RAD)
    centers = (transform[:3, :3] @ centers_local.T).T + transform[:3, 3]
    normals = (transform[:3, :3] @ normals_local.T).T
    centroid = np.average(centers, axis=0, weights=areas)
    centered = centers - centroid
    covariance = (centered * areas[:, None]).T @ centered / float(np.sum(areas))
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    eigenvectors = eigenvectors[:, np.argsort(eigenvalues)[::-1]]
    axis = eigenvectors[:, 0]
    dominant = int(np.argmax(np.abs(axis)))
    if axis[dominant] < 0.0:
        axis = -axis
    normal = np.average(normals, axis=0, weights=areas)
    normal -= axis * float(normal @ axis)
    normal /= np.linalg.norm(normal)
    line_point = centroid + CYLINDER_RADIUS_M * normal
    initial = _f2_transform(SOURCE_URDF, INITIAL_Q_RAD)
    contact = _f2_transform(SOURCE_URDF, CONTACT_Q_RAD)
    pad_initial = _component_radial_stats(points, initial, line_point, axis)
    pad_contact = _component_radial_stats(points, contact, line_point, axis)
    tip_contact = _component_radial_stats(
        np.asarray(tip["points_local_m"], dtype=np.float64),
        contact,
        line_point,
        axis,
    )
    return {
        "method": "REAL_F2_FK_PLUS_BLUE_PAD_CONTACT_SURFACE_PCA",
        "contact_q_rad": CONTACT_Q_RAD,
        "initial_q_rad": INITIAL_Q_RAD,
        "axis_unit_world": axis.tolist(),
        "line_point_world_m": line_point.tolist(),
        "radius_m": CYLINDER_RADIUS_M,
        "height_m": CYLINDER_HEIGHT_M,
        "pad_initial": pad_initial,
        "pad_contact": pad_contact,
        "tip_contact": tip_contact,
        "tip_outside_cylinder_axial_span_at_contact": (
            tip_contact["axial_overlap_vertex_count"] == 0
        ),
        "expected_pad_contact_at_final_q": bool(
            pad_contact["minimum_radial_distance_m"] is not None
            and pad_contact["minimum_radial_distance_m"]
            <= CYLINDER_RADIUS_M + CONTACT_OFFSET_M
        ),
    }


def _cooking_stats(interface: Any) -> dict[str, int]:
    value = interface.get_cooking_statistics()
    names = (
        "total_scheduled_tasks",
        "total_finished_tasks",
        "total_finished_cache_hit_tasks",
        "total_finished_cache_miss_tasks",
    )
    return {name: int(getattr(value, name)) for name in names}


def _wait_for_cooking(application: Any, interface: Any, max_updates: int = 600) -> dict[str, int]:
    last = _cooking_stats(interface)
    for _ in range(max_updates):
        application.update()
        last = _cooking_stats(interface)
        if last["total_finished_tasks"] >= last["total_scheduled_tasks"]:
            return last
    raise TimeoutError(f"PhysX collision cooking did not finish: {last}")


def _difference(after: Mapping[str, int], before: Mapping[str, int]) -> dict[str, int]:
    return {name: int(after[name]) - int(before[name]) for name in before}


def _find_unique_prim(stage: Any, predicate: Any, description: str) -> Any:
    matches = [prim for prim in stage.Traverse() if predicate(prim)]
    if len(matches) != 1:
        raise RuntimeError(
            f"expected one {description}; got {[str(prim.GetPath()) for prim in matches]}"
        )
    return matches[0]


def _minimum_jerk(value: float) -> float:
    clipped = min(1.0, max(0.0, float(value)))
    return 10.0 * clipped**3 - 15.0 * clipped**4 + 6.0 * clipped**5


def _nearest_pad_roles(
    points_local: np.ndarray,
    impulses: np.ndarray,
    pad_arrays: Mapping[str, np.ndarray],
) -> dict[str, Any]:
    if len(points_local) == 0:
        return {
            "contact_count": 0,
            "PAD_CONTACT_SURFACE_impulse_ns": 0.0,
            "PAD_SIDE_SURFACE_impulse_ns": 0.0,
            "PAD_CONTACT_SURFACE_impulse_share": 0.0,
            "maximum_nearest_surface_distance_m": None,
        }
    import trimesh

    mesh = trimesh.Trimesh(
        vertices=np.asarray(pad_arrays["points_local_m"], dtype=np.float64),
        faces=np.asarray(pad_arrays["faces"], dtype=np.int64),
        process=False,
    )
    _closest, distances, face_ids = trimesh.proximity.closest_point_naive(
        mesh, np.asarray(points_local, dtype=np.float64)
    )
    contact_set = set(
        int(value) for value in np.asarray(pad_arrays["pad_contact_face_ids"])
    )
    contact_mask = np.fromiter(
        (int(face_id) in contact_set for face_id in face_ids),
        dtype=bool,
        count=len(face_ids),
    )
    contact_impulse = float(np.sum(impulses[contact_mask]))
    side_impulse = float(np.sum(impulses[~contact_mask]))
    total = contact_impulse + side_impulse
    return {
        "contact_count": int(len(points_local)),
        "PAD_CONTACT_SURFACE_contact_count": int(np.count_nonzero(contact_mask)),
        "PAD_SIDE_SURFACE_contact_count": int(np.count_nonzero(~contact_mask)),
        "PAD_CONTACT_SURFACE_impulse_ns": contact_impulse,
        "PAD_SIDE_SURFACE_impulse_ns": side_impulse,
        "PAD_CONTACT_SURFACE_impulse_share": (
            contact_impulse / total if total > 0.0 else 0.0
        ),
        "maximum_nearest_surface_distance_m": float(np.max(distances)),
        "median_nearest_surface_distance_m": float(np.median(distances)),
    }


def _run(arguments: argparse.Namespace, application: Any) -> dict[str, Any]:
    import carb.logging
    from isaacsim.asset.importer.urdf import URDFImporter, URDFImporterConfig
    from isaacsim.core.api import World
    from isaacsim.core.prims import SingleArticulation
    from isaacsim.core.utils.stage import add_reference_to_stage, get_current_stage
    from isaacsim.core.utils.types import ArticulationAction
    from omni.physx import get_physx_cooking_interface, get_physx_simulation_interface
    from omni.physx.scripts.ifaces import get_physx_cooking_private_interface
    import omni.usd
    from pxr import Gf, PhysicsSchemaTools, PhysxSchema, Sdf, Usd, UsdGeom, UsdPhysics, UsdShade

    output = Path(arguments.output_dir).resolve()
    asset_dir = Path(arguments.asset_dir).resolve()
    entry, input_paths = _source_finger_entry(asset_dir)
    input_hashes_before = {name: _sha256(path) for name, path in input_paths.items()}
    pad_arrays = _load_arrays(input_paths["pad"])
    tip_arrays = _load_arrays(input_paths["tip"])
    fixture = _derive_cylinder_fixture(pad_arrays, tip_arrays)
    if not fixture["expected_pad_contact_at_final_q"]:
        raise RuntimeError(f"static PAD fixture preflight failed: {fixture}")
    if not fixture["tip_outside_cylinder_axial_span_at_contact"]:
        raise RuntimeError(f"TIP enters cylinder axial span: {fixture}")

    minimal_urdf = output / "d38999_pad_sdf_smoke_f2.urdf"
    urdf_evidence = _build_minimal_f2_urdf(SOURCE_URDF, minimal_urdf)
    import_directory = output / "minimal_f2_usd"
    import_directory.mkdir(parents=False, exist_ok=False)
    importer = URDFImporter(
        URDFImporterConfig(
            urdf_path=str(minimal_urdf),
            usd_path=str(import_directory),
            merge_fixed_joints=False,
            merge_mesh=False,
            collision_from_visuals=False,
            allow_self_collision=False,
            fix_base=True,
        )
    )
    imported_path = Path(str(importer.import_urdf())).resolve()
    for _ in range(10):
        application.update()
    if not imported_path.exists():
        raise RuntimeError(f"minimal URDF import did not create {imported_path}")

    World.clear_instance()
    context = omni.usd.get_context()
    context.new_stage()
    application.update()
    world = World(
        stage_units_in_meters=1.0,
        physics_dt=1.0 / PHYSICS_RATE_HZ,
        rendering_dt=1.0 / 60.0,
        backend="numpy",
        device="cpu",
    )
    stage = get_current_stage()
    add_reference_to_stage(str(imported_path), "/World/Finger")
    for _ in range(10):
        application.update()

    terminal = _find_unique_prim(
        stage,
        lambda prim: prim.GetName() == "f2Link2"
        and prim.HasAPI(UsdPhysics.RigidBodyAPI),
        "f2Link2 rigid link",
    )
    terminal_path = terminal.GetPath()
    terminal_instanceability = {
        "path_before": str(terminal_path),
        "is_instance_before": bool(terminal.IsInstance()),
        "is_instance_proxy_before": bool(terminal.IsInstanceProxy()),
        "is_instanceable_before": bool(terminal.IsInstanceable()),
        "set_instanceable_false_succeeded": False,
    }
    if not terminal.IsInstance() or terminal.IsInstanceProxy():
        raise RuntimeError(
            "authorized deinstance route expected f2Link2 to be an editable instance root; "
            f"got {terminal_instanceability}"
        )
    if not terminal.SetInstanceable(False):
        raise RuntimeError("failed to author instanceable=false on f2Link2 instance root")
    terminal_instanceability["set_instanceable_false_succeeded"] = True
    for _ in range(2):
        application.update()
    terminal = stage.GetPrimAtPath(terminal_path)
    terminal_instanceability.update(
        {
            "path_after": str(terminal.GetPath()),
            "is_instance_after": bool(terminal.IsInstance()),
            "is_instance_proxy_after": bool(terminal.IsInstanceProxy()),
            "is_instanceable_after": bool(terminal.IsInstanceable()),
            "rigid_body_api_preserved": bool(
                terminal.HasAPI(UsdPhysics.RigidBodyAPI)
            ),
        }
    )
    if (
        not terminal.IsValid()
        or terminal.GetPath() != terminal_path
        or terminal.IsInstance()
        or terminal.IsInstanceProxy()
        or terminal.IsInstanceable()
        or not terminal.HasAPI(UsdPhysics.RigidBodyAPI)
    ):
        raise RuntimeError(
            "f2Link2 deinstance postcondition failed: "
            f"{terminal_instanceability}"
        )
    articulation_root = _find_unique_prim(
        stage,
        lambda prim: prim.HasAPI(UsdPhysics.ArticulationRootAPI),
        "minimal f2 articulation root",
    )
    old_terminal_colliders = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(terminal)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    if old_terminal_colliders:
        raise RuntimeError(
            f"old terminal collision survived minimal import: {old_terminal_colliders}"
        )

    physics_scene = _find_unique_prim(
        stage,
        lambda prim: prim.IsA(UsdPhysics.Scene),
        "physics scene",
    )
    physx_scene = PhysxSchema.PhysxSceneAPI.Apply(physics_scene)
    physx_scene.CreateEnableGPUDynamicsAttr().Set(True)
    physx_scene.CreateBroadphaseTypeAttr().Set("GPU")
    physx_scene.CreateSolverTypeAttr().Set("TGS")
    world.get_physics_context().set_gravity(0.0)

    material_root = "/World/PhysicsMaterials"
    UsdGeom.Scope.Define(stage, material_root)

    def material(path: str, static: float, dynamic: float) -> Any:
        value = UsdShade.Material.Define(stage, path)
        api = UsdPhysics.MaterialAPI.Apply(value.GetPrim())
        api.CreateStaticFrictionAttr(static)
        api.CreateDynamicFrictionAttr(dynamic)
        api.CreateRestitutionAttr(0.0)
        return value

    pad_material = material(
        material_root + "/PAD_FRICTION", PAD_STATIC_FRICTION, PAD_DYNAMIC_FRICTION
    )
    base_material = material(
        material_root + "/BASE_FRICTION", BASE_STATIC_FRICTION, BASE_DYNAMIC_FRICTION
    )

    cooking_private = get_physx_cooking_private_interface()
    get_physx_cooking_interface().release_local_mesh_cache()
    cooking_before = _wait_for_cooking(application, cooking_private)

    def author_mesh(path: str, arrays: Mapping[str, np.ndarray]) -> Any:
        mesh = UsdGeom.Mesh.Define(stage, path)
        mesh.CreatePointsAttr(
            [Gf.Vec3f(*[float(value) for value in point]) for point in arrays["points_local_m"]]
        )
        mesh.CreateFaceVertexCountsAttr(
            [int(value) for value in arrays["face_vertex_counts"]]
        )
        mesh.CreateFaceVertexIndicesAttr(
            [int(value) for value in arrays["face_vertex_indices"]]
        )
        mesh.CreateSubdivisionSchemeAttr(UsdGeom.Tokens.none)
        UsdPhysics.CollisionAPI.Apply(mesh.GetPrim()).CreateCollisionEnabledAttr(True)
        PhysxSchema.PhysxCollisionAPI.Apply(mesh.GetPrim()).CreateContactOffsetAttr(
            CONTACT_OFFSET_M
        )
        PhysxSchema.PhysxCollisionAPI(mesh.GetPrim()).CreateRestOffsetAttr(
            REST_OFFSET_M
        )
        return mesh

    pad_path = str(terminal.GetPath()) + "/PAD_BODY_SDF"
    pad_mesh = author_mesh(pad_path, pad_arrays)
    if pad_mesh.GetPrim().GetParent() != terminal:
        raise RuntimeError("PAD_BODY_SDF is not a direct child of the f2Link2 rigid body")
    pad_collision = UsdPhysics.MeshCollisionAPI.Apply(pad_mesh.GetPrim())
    pad_collision.CreateApproximationAttr().Set("sdf")
    sdf_api = PhysxSchema.PhysxSDFMeshCollisionAPI.Apply(pad_mesh.GetPrim())
    sdf_api.CreateSdfResolutionAttr().Set(SDF_RESOLUTION)
    sdf_api.CreateSdfSubgridResolutionAttr().Set(SDF_SUBGRID_RESOLUTION)
    sdf_api.CreateSdfBitsPerSubgridPixelAttr().Set("BitsPerPixel16")
    sdf_api.CreateSdfEnableRemeshingAttr().Set(False)
    sdf_api.CreateSdfTriangleCountReductionFactorAttr().Set(1.0)
    UsdShade.MaterialBindingAPI(pad_mesh.GetPrim()).Bind(
        pad_material, materialPurpose="physics"
    )
    pad_mesh.GetPrim().CreateAttribute(
        "kcg:collisionRole", Sdf.ValueTypeNames.Token
    ).Set("PAD_BODY_SDF")
    cooking_after_pad_authoring = _wait_for_cooking(application, cooking_private)

    tip_path = str(terminal.GetPath()) + "/TIP_BASE_COLLISION"
    tip_mesh = author_mesh(tip_path, tip_arrays)
    if tip_mesh.GetPrim().GetParent() != terminal:
        raise RuntimeError("TIP_BASE_COLLISION is not a direct child of the f2Link2 rigid body")
    UsdPhysics.MeshCollisionAPI.Apply(tip_mesh.GetPrim()).CreateApproximationAttr().Set(
        UsdPhysics.Tokens.convexHull
    )
    UsdShade.MaterialBindingAPI(tip_mesh.GetPrim()).Bind(
        base_material, materialPurpose="physics"
    )
    tip_mesh.GetPrim().CreateAttribute(
        "kcg:collisionRole", Sdf.ValueTypeNames.Token
    ).Set("TIP_END_SURFACE")

    cylinder_path = "/World/CouplingNutCurvatureCylinder"
    cylinder = UsdGeom.Cylinder.Define(stage, cylinder_path)
    cylinder.CreateAxisAttr(UsdGeom.Tokens.z)
    cylinder.CreateRadiusAttr(CYLINDER_RADIUS_M)
    cylinder.CreateHeightAttr(CYLINDER_HEIGHT_M)
    cylinder.CreateDisplayColorAttr([Gf.Vec3f(0.42, 0.42, 0.46)])
    xform = UsdGeom.Xformable(cylinder)
    xform.AddTranslateOp().Set(Gf.Vec3d(*fixture["line_point_world_m"]))
    rotation = Gf.Rotation(
        Gf.Vec3d(0.0, 0.0, 1.0), Gf.Vec3d(*fixture["axis_unit_world"])
    )
    xform.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(rotation.GetQuat())
    UsdPhysics.CollisionAPI.Apply(cylinder.GetPrim()).CreateCollisionEnabledAttr(True)
    PhysxSchema.PhysxCollisionAPI.Apply(cylinder.GetPrim()).CreateContactOffsetAttr(
        CONTACT_OFFSET_M
    )
    PhysxSchema.PhysxCollisionAPI(cylinder.GetPrim()).CreateRestOffsetAttr(REST_OFFSET_M)
    UsdShade.MaterialBindingAPI(cylinder.GetPrim()).Bind(
        base_material, materialPurpose="physics"
    )
    cylinder.GetPrim().CreateAttribute(
        "kcg:collisionRole", Sdf.ValueTypeNames.Token
    ).Set("COUPLING_NUT_CURVATURE")

    PhysxSchema.PhysxContactReportAPI.Apply(terminal).CreateThresholdAttr().Set(0.0)
    robot = world.scene.add(
        SingleArticulation(
            prim_path=str(articulation_root.GetPath()),
            name="d38999_pad_sdf_smoke_f2",
        )
    )
    stage.Export(str(output / "PAD_SDF_COMPATIBILITY_STAGE.usda"))

    relevant_log_rows: list[dict[str, Any]] = []
    logging = carb.logging.acquire_logging()

    def on_log(source: str, level: int, filename: str, line: int, message: str) -> None:
        text = str(message)
        lowered = text.lower()
        if (
            ("physicsusd" in lowered and ("error" in lowered or "failed" in lowered))
            or ("solver" in lowered and ("error" in lowered or "failed" in lowered))
            or ("sdf" in lowered and any(word in lowered for word in ("error", "failed", "fallback")))
            or "unsupported approximation" in lowered
        ):
            relevant_log_rows.append(
                {
                    "source": str(source),
                    "level": int(level),
                    "filename": str(filename),
                    "line": int(line),
                    "message": text,
                }
            )

    logger_handle = logging.add_logger(on_log)
    trace: list[dict[str, Any]] = []
    pad_local_points: list[list[float]] = []
    pad_impulses: list[float] = []
    tip_impulse_total = 0.0
    radial_normal_alignments: list[float] = []
    maximum_joint_speed = 0.0
    finite_throughout = True
    try:
        world.reset()
        cooking_after_reset = _wait_for_cooking(application, cooking_private)
        dof_names = list(robot.dof_names)
        if "f2j1" not in dof_names or "f2j2" not in dof_names:
            raise RuntimeError(f"real f2 joints missing from articulation: {dof_names}")
        name_to_index = {name: index for index, name in enumerate(dof_names)}
        active_index = name_to_index["f2j1"]
        follower_index = name_to_index["f2j2"]
        positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
        positions[active_index] = INITIAL_Q_RAD
        positions[follower_index] = INITIAL_Q_RAD
        robot.set_joint_positions(positions)
        robot.set_joint_velocities(np.zeros(robot.num_dof, dtype=np.float32))
        controller = robot.get_articulation_controller()
        kps = np.zeros(robot.num_dof, dtype=np.float32)
        kds = np.zeros(robot.num_dof, dtype=np.float32)
        kps[active_index] = 12.0
        kds[active_index] = 0.8
        controller.set_gains(kps=kps, kds=kds, save_to_usd=False)

        warmup_steps = 120
        close_steps = min(900, arguments.steps - warmup_steps - 240)
        hold_steps = arguments.steps - warmup_steps - close_steps
        interface = get_physx_simulation_interface()
        axis = np.asarray(fixture["axis_unit_world"], dtype=np.float64)
        line_point = np.asarray(fixture["line_point_world_m"], dtype=np.float64)
        step_wall_times: list[float] = []

        for step in range(arguments.steps):
            if step < warmup_steps:
                target = INITIAL_Q_RAD
                phase = "OPEN_SETTLE"
            elif step < warmup_steps + close_steps:
                fraction = (step - warmup_steps + 1) / float(close_steps)
                target = INITIAL_Q_RAD + _minimum_jerk(fraction) * (
                    CONTACT_Q_RAD - INITIAL_Q_RAD
                )
                phase = "MINIMUM_JERK_CLOSE"
            else:
                target = CONTACT_Q_RAD
                phase = "CONTACT_HOLD"
            robot.apply_action(
                ArticulationAction(
                    joint_positions=np.asarray([target], dtype=np.float32),
                    joint_indices=np.asarray([active_index], dtype=np.int32),
                )
            )
            started = time.perf_counter()
            world.step(render=False)
            elapsed = time.perf_counter() - started
            step_wall_times.append(elapsed)
            state_positions = np.asarray(robot.get_joint_positions(), dtype=np.float64)
            state_velocities = np.asarray(robot.get_joint_velocities(), dtype=np.float64)
            finite = bool(
                np.all(np.isfinite(state_positions))
                and np.all(np.isfinite(state_velocities))
            )
            finite_throughout = finite_throughout and finite
            if not finite:
                break
            maximum_joint_speed = max(
                maximum_joint_speed, float(np.max(np.abs(state_velocities)))
            )

            terminal_matrix = UsdGeom.Xformable(terminal).ComputeLocalToWorldTransform(
                Usd.TimeCode.Default()
            )
            world_to_terminal = terminal_matrix.GetInverse()
            headers, contacts, _friction = interface.get_full_contact_report()
            pad_step_impulse = 0.0
            tip_step_impulse = 0.0
            pad_step_count = 0
            tip_step_count = 0
            for header in headers:
                collider0 = str(PhysicsSchemaTools.intToSdfPath(header.collider0))
                collider1 = str(PhysicsSchemaTools.intToSdfPath(header.collider1))
                pair = {collider0, collider1}
                is_pad_pair = pad_path in pair and cylinder_path in pair
                is_tip_pair = tip_path in pair and cylinder_path in pair
                if not is_pad_pair and not is_tip_pair:
                    continue
                start = int(header.contact_data_offset)
                stop = start + int(header.num_contact_data)
                for contact in contacts[start:stop]:
                    impulse = np.asarray(contact.impulse, dtype=np.float64)
                    impulse_norm = float(np.linalg.norm(impulse))
                    position = np.asarray(contact.position, dtype=np.float64)
                    if is_pad_pair:
                        local = world_to_terminal.Transform(Gf.Vec3d(*position))
                        pad_local_points.append([float(local[i]) for i in range(3)])
                        pad_impulses.append(impulse_norm)
                        pad_step_impulse += impulse_norm
                        pad_step_count += 1
                        relative = position - line_point
                        axial = axis * float(relative @ axis)
                        radial = relative - axial
                        radial_norm = float(np.linalg.norm(radial))
                        normal = np.asarray(contact.normal, dtype=np.float64)
                        normal_norm = float(np.linalg.norm(normal))
                        if radial_norm > 1.0e-12 and normal_norm > 1.0e-12:
                            radial_normal_alignments.append(
                                abs(float((radial / radial_norm) @ (normal / normal_norm)))
                            )
                    else:
                        tip_step_impulse += impulse_norm
                        tip_step_count += 1
            tip_impulse_total += tip_step_impulse
            trace.append(
                {
                    "step": step + 1,
                    "phase": phase,
                    "target_f2j1_rad": target,
                    "f2j1_rad": float(state_positions[active_index]),
                    "f2j2_rad": float(state_positions[follower_index]),
                    "f2j1_velocity_rad_s": float(state_velocities[active_index]),
                    "f2j2_velocity_rad_s": float(state_velocities[follower_index]),
                    "pad_contact_count": pad_step_count,
                    "tip_contact_count": tip_step_count,
                    "pad_contact_force_n": pad_step_impulse * PHYSICS_RATE_HZ,
                    "tip_contact_force_n": tip_step_impulse * PHYSICS_RATE_HZ,
                    "step_wall_s": elapsed,
                }
            )
        cooking_final = _wait_for_cooking(application, cooking_private)
    finally:
        logging.remove_logger(logger_handle)

    if not trace:
        raise RuntimeError("smoke executed zero diagnostic actions")
    points_array = np.asarray(pad_local_points, dtype=np.float64).reshape((-1, 3))
    impulses_array = np.asarray(pad_impulses, dtype=np.float64)
    role_audit = _nearest_pad_roles(points_array, impulses_array, pad_arrays)
    pad_impulse_total = float(np.sum(impulses_array))
    all_finger_impulse = pad_impulse_total + tip_impulse_total
    pad_force = np.asarray([row["pad_contact_force_n"] for row in trace], dtype=np.float64)
    hold_force = pad_force[-min(240, len(pad_force)) :]
    step_times = np.asarray([row["step_wall_s"] for row in trace], dtype=np.float64)
    final_positions = trace[-1]

    pad_prim = stage.GetPrimAtPath(pad_path)
    pad_colliders = [
        str(prim.GetPath())
        for prim in stage.Traverse()
        if prim.HasAPI(UsdPhysics.CollisionAPI)
        and prim.GetAttribute("kcg:collisionRole")
        and str(prim.GetAttribute("kcg:collisionRole").Get()) == "PAD_BODY_SDF"
    ]
    terminal_collision_inventory = [
        {
            "path": str(prim.GetPath()),
            "approximation": (
                str(UsdPhysics.MeshCollisionAPI(prim).GetApproximationAttr().Get())
                if prim.HasAPI(UsdPhysics.MeshCollisionAPI)
                else "primitive"
            ),
            "role": (
                str(prim.GetAttribute("kcg:collisionRole").Get())
                if prim.GetAttribute("kcg:collisionRole")
                else None
            ),
        }
        for prim in Usd.PrimRange(terminal)
        if prim.HasAPI(UsdPhysics.CollisionAPI)
    ]
    sdf_authored = {
        "mesh_collision_approximation": str(
            UsdPhysics.MeshCollisionAPI(pad_prim).GetApproximationAttr().Get()
        ),
        "has_physx_sdf_api": bool(
            pad_prim.HasAPI(PhysxSchema.PhysxSDFMeshCollisionAPI)
        ),
        "has_physx_convex_hull_api": bool(
            pad_prim.HasAPI(PhysxSchema.PhysxConvexHullCollisionAPI)
        ),
        "resolution": int(
            PhysxSchema.PhysxSDFMeshCollisionAPI(pad_prim)
            .GetSdfResolutionAttr()
            .Get()
        ),
        "subgrid_resolution": int(
            PhysxSchema.PhysxSDFMeshCollisionAPI(pad_prim)
            .GetSdfSubgridResolutionAttr()
            .Get()
        ),
        "enable_remeshing": bool(
            PhysxSchema.PhysxSDFMeshCollisionAPI(pad_prim)
            .GetSdfEnableRemeshingAttr()
            .Get()
        ),
        "triangle_count_reduction_factor": float(
            PhysxSchema.PhysxSDFMeshCollisionAPI(pad_prim)
            .GetSdfTriangleCountReductionFactorAttr()
            .Get()
        ),
    }
    cooking = {
        "before_pad_authoring": cooking_before,
        "after_pad_authoring": cooking_after_pad_authoring,
        "after_reset": cooking_after_reset,
        "final": cooking_final,
        "pad_authoring_delta": _difference(cooking_after_pad_authoring, cooking_before),
        "full_run_delta": _difference(cooking_final, cooking_before),
    }
    physicsusd_errors = [
        row for row in relevant_log_rows if "physicsusd" in row["message"].lower()
    ]
    solver_errors = [
        row for row in relevant_log_rows if "solver" in row["message"].lower()
    ]
    sdf_errors = [
        row
        for row in relevant_log_rows
        if "sdf" in row["message"].lower()
        or "unsupported approximation" in row["message"].lower()
    ]
    median_hold_force = float(np.median(hold_force))
    maximum_force = float(np.max(pad_force))
    mean_step_wall = float(np.mean(step_times))
    simulated_seconds = len(trace) / PHYSICS_RATE_HZ
    measured_wall_seconds = float(np.sum(step_times))
    gates = {
        "authorized_step_count": 1000 <= len(trace) <= 2000,
        "real_f2_articulation_initialized": bool(robot.handles_initialized),
        "joint_state_finite": finite_throughout,
        "real_closure_progress": (
            final_positions["f2j1_rad"] - INITIAL_Q_RAD >= 0.35
        ),
        "mimic_follower_tracks": abs(
            final_positions["f2j2_rad"] - final_positions["f2j1_rad"]
        )
        <= 0.05,
        "terminal_deinstanced_for_authoring": (
            terminal_instanceability["is_instance_before"]
            and not terminal_instanceability["is_instance_proxy_before"]
            and terminal_instanceability["set_instanceable_false_succeeded"]
            and not terminal_instanceability["is_instance_after"]
            and not terminal_instanceability["is_instance_proxy_after"]
            and not terminal_instanceability["is_instanceable_after"]
            and terminal_instanceability["rigid_body_api_preserved"]
        ),
        "one_pad_collider": len(pad_colliders) == 1,
        "old_full_terminal_hull_absent": not any(
            "f2Link2_convex" in row["path"]
            for row in terminal_collision_inventory
        ),
        "sdf_authored_not_convex": (
            sdf_authored["mesh_collision_approximation"] == "sdf"
            and sdf_authored["has_physx_sdf_api"]
            and not sdf_authored["has_physx_convex_hull_api"]
        ),
        "sdf_cooking_completed": (
            cooking_final["total_scheduled_tasks"]
            == cooking_final["total_finished_tasks"]
            and cooking["full_run_delta"]["total_finished_tasks"] >= 1
        ),
        "pad_contact_established": role_audit["contact_count"] > 0,
        "pad_inner_impulse_share": (
            role_audit["PAD_CONTACT_SURFACE_impulse_share"] >= 0.90
        ),
        "tip_not_main_contact": (
            tip_impulse_total / all_finger_impulse if all_finger_impulse > 0 else 1.0
        )
        <= 0.10,
        "contact_normals_radial": (
            bool(radial_normal_alignments)
            and float(np.median(radial_normal_alignments)) >= 0.70
        ),
        "stable_nonzero_hold_force": 0.10 <= median_hold_force <= 30.0,
        "no_single_step_force_explosion": maximum_force <= FORCE_EXPLOSION_THRESHOLD_N,
        "joint_speed_bounded": maximum_joint_speed <= 8.0,
        "physicsusd_error_zero": len(physicsusd_errors) == 0,
        "solver_error_zero": len(solver_errors) == 0,
        "sdf_error_or_fallback_zero": len(sdf_errors) == 0,
        "mean_240hz_step_budget": mean_step_wall <= 1.0 / PHYSICS_RATE_HZ,
        "object_pose_write_after_physics_zero": True,
        "online_contact_truth_control_zero": True,
    }
    passed = all(gates.values())

    trace_path = output / "PAD_SDF_CONTACT_TRACE.csv"
    with trace_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(trace[0]))
        writer.writeheader()
        writer.writerows(trace)
    input_hashes_after = {name: _sha256(path) for name, path in input_paths.items()}
    return {
        "schema": SCHEMA,
        "task_id": TASK_ID,
        "hypothesis_id": HYPOTHESIS_ID,
        "status": "PASS" if passed else "FAIL",
        "classification": (
            "PAD_SDF_DYNAMIC_COMPATIBILITY_PASS"
            if passed
            else "PAD_SDF_DYNAMIC_COMPATIBILITY_FAIL"
        ),
        "dynamic_compatibility_passed": passed,
        "formal_b_passed": False,
        "collision_route": "PHYSX_SDF",
        "interface_fix_attempt": int(arguments.interface_fix_attempt),
        "source_asset": {
            "directory": str(asset_dir),
            "entry": entry,
            "input_sha256_before": input_hashes_before,
            "input_sha256_after": input_hashes_after,
            "inputs_unchanged": input_hashes_before == input_hashes_after,
        },
        "minimal_real_finger_chain": urdf_evidence,
        "imported_usd": str(imported_path),
        "articulation_root": str(articulation_root.GetPath()),
        "terminal_instanceability": terminal_instanceability,
        "dof_names": list(robot.dof_names),
        "fixture": fixture,
        "sdf_authored": sdf_authored,
        "sdf_cooking": cooking,
        "pad_collision_body_count": len(pad_colliders),
        "terminal_collision_inventory": terminal_collision_inventory,
        "old_whole_distal_hull_runtime_removed": gates[
            "old_full_terminal_hull_absent"
        ],
        "contact_role_audit": role_audit,
        "pad_impulse_total_ns": pad_impulse_total,
        "tip_impulse_total_ns": tip_impulse_total,
        "tip_impulse_share": (
            tip_impulse_total / all_finger_impulse if all_finger_impulse > 0 else 1.0
        ),
        "median_radial_normal_alignment": (
            float(np.median(radial_normal_alignments))
            if radial_normal_alignments
            else None
        ),
        "force_stability": {
            "median_last_240_step_pad_force_n": median_hold_force,
            "maximum_single_step_pad_force_n": maximum_force,
            "explosion_threshold_n": FORCE_EXPLOSION_THRESHOLD_N,
        },
        "articulation_metrics": {
            "final_f2j1_rad": final_positions["f2j1_rad"],
            "final_f2j2_rad": final_positions["f2j2_rad"],
            "maximum_abs_joint_speed_rad_s": maximum_joint_speed,
            "finite_throughout": finite_throughout,
        },
        "performance": {
            "physics_rate_hz": PHYSICS_RATE_HZ,
            "step_count": len(trace),
            "simulated_seconds": simulated_seconds,
            "measured_step_wall_seconds": measured_wall_seconds,
            "mean_step_wall_s": mean_step_wall,
            "p95_step_wall_s": float(np.percentile(step_times, 95.0)),
            "real_time_factor_excluding_startup": (
                simulated_seconds / measured_wall_seconds
                if measured_wall_seconds > 0.0
                else None
            ),
        },
        "runtime_log_evidence": {
            "retained_messages": relevant_log_rows,
            "physicsusd_error_count": len(physicsusd_errors),
            "solver_error_count": len(solver_errors),
            "sdf_error_or_fallback_count": len(sdf_errors),
        },
        "gates": gates,
        "control_truth_boundary": {
            "controller_type": "FIXED_TIME_MINIMUM_JERK_JOINT_POSITION",
            "control_reads_object_pose_truth": False,
            "control_reads_contact_names": False,
            "control_reads_contact_normals": False,
            "control_reads_contact_events": False,
            "posthoc_contact_truth_audit": True,
            "object_pose_write_after_physics_start_count": 0,
        },
        "trace_csv": str(trace_path),
        "runner_sha256": _sha256(Path(__file__)),
        "new_h_number_created": False,
    }


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _arguments(argv)
    output = Path(arguments.output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite SDF smoke output: {output}")
    output.mkdir(parents=True, exist_ok=False)
    portable = Path(arguments.kit_portable_root).resolve()
    portable.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("WARP_CACHE_PATH", str(portable / "warp-cache"))
    sys.argv = [sys.argv[0], "--portable-root", str(portable)]
    application = None
    exit_code = 1
    report: dict[str, Any]
    try:
        from isaacsim import SimulationApp

        application = SimulationApp(
            {
                "headless": True,
                "hide_ui": True,
                "renderer": "Minimal",
                "multi_gpu": False,
                "fast_shutdown": True,
                "enable_crashreporter": False,
            }
        )
        report = _run(arguments, application)
        exit_code = 0 if report["dynamic_compatibility_passed"] else 3
    except BaseException as error:
        traceback.print_exc()
        report = {
            "schema": SCHEMA,
            "task_id": TASK_ID,
            "hypothesis_id": HYPOTHESIS_ID,
            "status": "ERROR",
            "classification": "PAD_SDF_DYNAMIC_COMPATIBILITY_RUNTIME_ERROR",
            "dynamic_compatibility_passed": False,
            "formal_b_passed": False,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "interface_fix_attempt": int(arguments.interface_fix_attempt),
            "object_pose_write_after_physics_start_count": 0,
            "online_contact_truth_control_used": False,
            "new_h_number_created": False,
        }
    _write_json(output / "PAD_SDF_COMPATIBILITY_RESULT.json", report)
    os.write(
        1,
        (json.dumps(report, allow_nan=False, sort_keys=True) + "\n").encode(),
    )
    if application is not None:
        application.close(exit_code=exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
