#!/usr/bin/env python3
"""Build and independently verify the compact B full-iiwa SCI closeout archive."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import tempfile
from typing import Iterable, Sequence


SCHEMA = "D38999_B_FULL_IIWA_SCI_CLOSEOUT_PACKAGE_V1"
CLOSEOUT_NAME = "B_FULL_IIWA_SCI_CLOSEOUT_20260820T081608Z"
SESSION_NAME = "B_GOAL_MODE_SESSION_20260820T082003Z"
CANDIDATE_SESSION_NAME = "B_GOAL_MODE_SESSION_20260819T213558Z"
VALIDATIONS = tuple(f"FULL_IIWA_TABLE_PICK_VALIDATION_{index:02d}" for index in (1, 2, 3))
TOP3 = (
    "TOP3_DYNAMIC_COMPARISON_BG_P120_Z15",
    "TOP3_DYNAMIC_COMPARISON_BG_P124_Z15",
    "TOP3_DYNAMIC_COMPARISON_BG_P128_Z15",
)
INTEGRATION = tuple(f"FULL_IIWA_INTEGRATION_QUIET_HOLD_{index:02d}" for index in (1, 2, 3))


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_text(path: Path, value: str, *, executable: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")
    if executable:
        path.chmod(0o755)


def write_json(path: Path, value: object) -> None:
    write_text(
        path,
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
    )


def copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_tree(source: Path, destination: Path, *, reject_parts: Iterable[str] = ()) -> None:
    rejected = tuple(reject_parts)
    if not source.is_dir():
        raise FileNotFoundError(source)
    for child in sorted(source.rglob("*")):
        if not child.is_file():
            continue
        relative = child.relative_to(source)
        if any(token in part for part in relative.parts for token in rejected):
            continue
        copy_file(child, destination / relative)


def tail_log(source: Path, destination: Path, line_count: int = 3000) -> None:
    lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
    write_text(destination, "\n".join(lines[-line_count:]) + "\n")


def run_git(repo: Path, *arguments: str) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    return completed.stdout


def copy_experiment(
    source: Path,
    destination: Path,
    *,
    include_stage: bool = False,
) -> None:
    if not source.is_dir():
        raise FileNotFoundError(source)
    for child in sorted(source.iterdir()):
        if not child.is_file():
            continue
        if child.name.endswith(("_STAGE.usd", "_STAGE.usda", "_STAGE.usdc")) and not include_stage:
            continue
        copy_file(child, destination / child.name)


def write_readme(package_root: Path) -> None:
    write_text(
        package_root / "README_FIRST_CN.md",
        (
            "# B_FULL_IIWA_SCI_CLOSEOUT 交付包\n\n"
            "首先阅读：`CLOSEOUT/B_FULL_IIWA_SCI_CLOSEOUT_CN.md`。\n\n"
            "核心结论为仿真范围内的 `B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS`：候选 "
            "`BG_P120_Z15` 在三个独立完整 iiwa 进程中均通过。该结论不是硬件安全认证，"
            "不是 `B_FORMAL_DYNAMIC_PASS` 或 `FULL_CHAIN_DYNAMIC_PASS`，也不授权进入 C/D/E。\n\n"
            "包内包含三次正式 RESULT/TRACE、Top 3 动态比较、12 候选离线证据、"
            "一次 Validation-01 正式 USD、SCI PNG/PDF/SVG 与源 CSV、相关源码/配置/测试、"
            "日志最后 3000 行及工作树状态。其余大 USD、所有 `.portable_*` 缓存、嵌套压缩包"
            "和全部 `REJECTED` 渲染图被有意排除。\n\n"
            "用户指出的“机械臂散架”图已判废。`PUBLICATION/isaac_renders_accepted` 只有一张"
            "连续全臂接近姿态示意；它不是抓取/抬升证据。四张近景同样未通过人工视觉审查。\n\n"
            "在解包后的本目录执行 `bash verify_package.sh` 可逐文件验证 SHA-256。\n"
        ),
    )


def populate(repo: Path, package_root: Path) -> None:
    artifacts = repo / "artifacts/b_goal_mode"
    closeout = artifacts / CLOSEOUT_NAME
    session = artifacts / SESSION_NAME
    candidate_search = (
        artifacts
        / CANDIDATE_SESSION_NAME
        / "experiments/G7_BOUNDED_CANDIDATE_SEARCH_01"
    )
    publication = artifacts / "publication_figures"

    write_readme(package_root)
    copy_tree(closeout, package_root / "CLOSEOUT")
    copy_tree(
        publication,
        package_root / "PUBLICATION",
        reject_parts=("isaac_renders_REJECTED",),
    )

    evidence = package_root / "EVIDENCE"
    experiments = session / "experiments"
    for name in VALIDATIONS:
        copy_experiment(
            experiments / name,
            evidence / "FORMAL_VALIDATIONS" / name,
            include_stage=name == VALIDATIONS[0],
        )
    for name in TOP3:
        copy_experiment(experiments / name, evidence / "TOP3_DYNAMIC" / name)
    for name in INTEGRATION:
        copy_experiment(experiments / name, evidence / "INTEGRATION_HISTORY" / name)
    copy_tree(candidate_search, evidence / "TWELVE_CANDIDATES")

    for name in (
        "CURRENT_GOAL_STATE.json",
        "EXPERIMENT_LEDGER.csv",
        "SESSION_SUMMARY_CN.md",
    ):
        copy_file(session / name, evidence / "SESSION" / name)
    for log in sorted((session / "logs").glob("*.log")):
        tail_log(log, evidence / "LOG_TAILS" / log.name)

    snapshot = package_root / "SOURCE_SNAPSHOT"
    for relative in (
        Path("run_b_goal_mode_supervisor.sh"),
        Path("src/kcg_connector/requirements-isaacsim.txt"),
        Path("src/kcg_connector/isaac/run_isaac_python.sh"),
    ):
        copy_file(repo / relative, snapshot / relative)
    for relative in (
        Path("src/kcg_connector/isaac/b_goal_mode"),
        Path("src/kcg_connector/kcg_connector/grasp/b_goal_mode"),
        Path("src/kcg_connector/config/b_goal_mode"),
    ):
        copy_tree(repo / relative, snapshot / relative, reject_parts=("__pycache__",))
    for name in (
        "d38999_b_minimal_v2.yaml",
        "d38999_b_minimal_v2_candidates.json",
        "d38999_b_minimal_v2_pad_core.json",
    ):
        relative = Path("src/kcg_connector/config") / name
        copy_file(repo / relative, snapshot / relative)
    for test in sorted((repo / "src/kcg_connector/test").glob("test_b_goal_mode_*.py")):
        copy_file(test, snapshot / test.relative_to(repo))

    worktree = package_root / "WORKTREE"
    write_text(
        worktree / "GIT_STATUS.txt",
        run_git(repo, "status", "--short", "--untracked-files=all"),
    )
    write_text(
        worktree / "GIT_DIFF.patch",
        run_git(repo, "diff", "--no-ext-diff", "--binary"),
    )
    write_text(worktree / "GIT_HEAD.txt", run_git(repo, "rev-parse", "HEAD"))

    excluded = {
        "portable_cache_included": False,
        "rejected_render_included": False,
        "nested_archive_included": False,
        "formal_stage_count": 1,
        "formal_stage_role": "VALIDATION_01_FROZEN_STAGE",
    }
    write_json(
        package_root / "PACKAGE_SCOPE.json",
        {
            "schema": SCHEMA,
            "created_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "package_root": package_root.name,
            "closeout_status": "B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS",
            "formal_validation_process_count": 3,
            "top3_dynamic_process_count": 3,
            "offline_candidate_count": 12,
            "exclusions": excluded,
        },
    )
    write_text(
        package_root / "verify_package.sh",
        """#!/usr/bin/env bash\nset -euo pipefail\ncd \"$(dirname \"$0\")\"\nsha256sum -c SHA256SUMS.txt\npython3 - <<'PY'\nimport csv\nfrom pathlib import Path\nrows=list(csv.DictReader(Path('MANIFEST.csv').open(newline='', encoding='utf-8')))\nfor row in rows:\n    path=Path(row['path'])\n    assert path.is_file(), path\n    assert path.stat().st_size == int(row['size_bytes']), path\nprint(f'MANIFEST_OK files={len(rows)}')\nPY\n""",
        executable=True,
    )


def write_manifests(package_root: Path) -> tuple[int, int]:
    files = sorted(
        path
        for path in package_root.rglob("*")
        if path.is_file() and path.name not in {"MANIFEST.csv", "SHA256SUMS.txt"}
    )
    manifest = package_root / "MANIFEST.csv"
    with manifest.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=("path", "size_bytes", "sha256"))
        writer.writeheader()
        for path in files:
            writer.writerow(
                {
                    "path": path.relative_to(package_root).as_posix(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256(path),
                }
            )
    checksummed = [*files, manifest]
    write_text(
        package_root / "SHA256SUMS.txt",
        "".join(
            f"{sha256(path)}  {path.relative_to(package_root).as_posix()}\n"
            for path in checksummed
        ),
    )
    return len(files), sum(path.stat().st_size for path in files)


def verify_archive(archive_path: Path, expected_root: str) -> dict[str, object]:
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts:
                raise RuntimeError(f"unsafe archive member: {member.name}")
            if not path.parts or path.parts[0] != expected_root:
                raise RuntimeError(f"unexpected package root: {member.name}")
        with tempfile.TemporaryDirectory(prefix="b_full_iiwa_sci_verify_") as temporary:
            destination = Path(temporary)
            archive.extractall(destination, filter="data")
            root = destination / expected_root
            completed = subprocess.run(
                ["bash", "verify_package.sh"],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            if completed.returncode != 0:
                raise RuntimeError(f"extracted verification failed:\n{completed.stdout}")
            verification_tail = completed.stdout.splitlines()[-1]
    return {
        "unsafe_path_check": "PASS",
        "tar_read_check": "PASS",
        "extracted_sha256_check": "PASS",
        "extracted_manifest_check": "PASS",
        "member_count": len(members),
        "verification_tail": verification_tail,
    }


def parse_arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default="/home/noob/WorkPlace/kcgtest1")
    parser.add_argument("--output-dir", default=str(Path.home() / "Downloads"))
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = parse_arguments(argv)
    repo = Path(arguments.repo_root).expanduser().resolve()
    output = Path(arguments.output_dir).expanduser().resolve()
    if not (repo / "src/kcg_connector").is_dir():
        raise FileNotFoundError(repo)
    output.mkdir(parents=True, exist_ok=True)
    package_name = f"B_FULL_IIWA_SCI_CLOSEOUT_{utc_stamp()}"
    archive_path = output / f"{package_name}.tar.gz"
    if archive_path.exists():
        raise FileExistsError(archive_path)
    with tempfile.TemporaryDirectory(prefix="b_full_iiwa_sci_package_") as temporary:
        package_root = Path(temporary) / package_name
        package_root.mkdir()
        populate(repo, package_root)
        file_count, uncompressed_bytes = write_manifests(package_root)
        with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
            archive.add(package_root, arcname=package_name, recursive=True)
    archive_digest = sha256(archive_path)
    write_text(
        archive_path.with_suffix(archive_path.suffix + ".sha256"),
        f"{archive_digest}  {archive_path.name}\n",
    )
    verification = verify_archive(archive_path, package_name)
    result = {
        "schema": SCHEMA,
        "archive_path": str(archive_path),
        "archive_size_bytes": archive_path.stat().st_size,
        "archive_sha256": archive_digest,
        "package_file_count": file_count,
        "package_uncompressed_bytes": uncompressed_bytes,
        "verification": verification,
    }
    result_path = output / f"{package_name}_BUILD_RESULT.json"
    write_json(result_path, result)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
