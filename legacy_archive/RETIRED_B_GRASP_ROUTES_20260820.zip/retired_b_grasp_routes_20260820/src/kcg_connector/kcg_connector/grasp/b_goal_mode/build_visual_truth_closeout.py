#!/usr/bin/env python3
"""Build a verified B live-GUI closeout without upgrading proxy-contact claims."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import tempfile
from typing import Any, Iterable, Mapping, Sequence

import numpy as np


SCHEMA = "D38999_B_VISUAL_TRUTH_AND_GUI_CLOSEOUT_V1"
SESSION_NAME = "B_GOAL_MODE_SESSION_20260820T082003Z"
VALIDATIONS = tuple(
    f"FULL_IIWA_TABLE_PICK_VALIDATION_{index:02d}" for index in (1, 2, 3)
)
PROXY_MANIFEST_RELATIVE = Path(
    "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2/"
    "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP/"
    "BLUE_PAD_CONSERVATIVE_CONVEX_PROXY_V1/"
    "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json"
)
PAD_SOURCE_RELATIVE = Path(
    "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2/"
    "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP/"
    "BLUE_PAD_SDF_SOURCE_ASSET_V1"
)
REQUIRED_LIVE_FILES = (
    "FULL_IIWA_RESULT.json",
    "FULL_IIWA_TRACE.csv",
    "B_FULL_IIWA_LIVE_RUN.mp4",
    "CAMERA_PARAMETERS.json",
    "LIVE_CAPTURE_MANIFEST.csv",
    "LIVE_CAPTURE_AUDIT.json",
    "VISUAL_OVERLAY_AUDIT.json",
    "LIVE_01_APPROACH.png",
    "LIVE_02_THREE_PAD_CONTACT.png",
    "LIVE_03_COMPLIANT_GRASP.png",
    "LIVE_04_OFFTABLE_0P5MM.png",
    "LIVE_05_LIFT_40MM.png",
)


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_text(path: Path, value: str, *, executable: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")
    if executable:
        path.chmod(0o755)


def write_json(path: Path, value: object) -> None:
    write_text(
        path,
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
    )


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def run_git(repo: Path, *arguments: str) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    return completed.stdout


def canonical_trace(path: Path) -> tuple[int, int, str]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or "step_wall_s" not in reader.fieldnames:
            raise RuntimeError(f"trace lacks step_wall_s: {path}")
        rows = []
        for source in reader:
            row = dict(source)
            row.pop("step_wall_s")
            rows.append(row)
    encoded = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return len(rows), len(rows[0]) if rows else 0, hashlib.sha256(encoded).hexdigest()


def build_independence_audit(repo: Path) -> dict[str, Any]:
    experiments = repo / "artifacts/b_goal_mode" / SESSION_NAME / "experiments"
    records = []
    for name in VALIDATIONS:
        trace = experiments / name / "FULL_IIWA_TRACE.csv"
        rows, columns, canonical = canonical_trace(trace)
        records.append(
            {
                "validation": name,
                "trace_path": str(trace.relative_to(repo)),
                "trace_sha256": sha256(trace),
                "canonical_sha256_excluding_step_wall_s": canonical,
                "row_count": rows,
                "compared_column_count": columns,
            }
        )
    exact = len({record["canonical_sha256_excluding_step_wall_s"] for record in records}) == 1
    return {
        "schema": "D38999_B_VALIDATION_INDEPENDENCE_AUDIT_V1",
        "created_utc": utc_iso(),
        "validation_process_count": 3,
        "separate_isaac_processes": True,
        "trace_data_exactly_identical_excluding_step_wall_s": exact,
        "same_initial_state": True,
        "same_friction": True,
        "same_noise_configuration": True,
        "same_control_parameters": True,
        "same_time_step": True,
        "classification": "DETERMINISTIC_REPEAT_ONLY_NOT_ROBUSTNESS_STATISTICS",
        "robustness_claim_allowed": False,
        "records": records,
        "future_frozen_small_randomization_plan_not_executed": {
            "initial_xy_m": [-0.0005, 0.0005],
            "initial_yaw_deg": [-1.0, 1.0],
            "friction_values": [0.40, 0.50, 0.60],
            "root_torque_noise": "USE_EXISTING_TARE_STATISTICS",
            "joint_initialization": "SMALL_BOUNDED_PERTURBATION",
            "executed_in_this_closeout": False,
        },
    }


def _surface_heights_at_uv(triangles: np.ndarray, uv: np.ndarray) -> list[float]:
    heights = []
    for triangle in triangles:
        projected = triangle[:, :2]
        basis = np.column_stack(
            (projected[1] - projected[0], projected[2] - projected[0])
        )
        determinant = float(np.linalg.det(basis))
        if abs(determinant) <= 1.0e-16:
            continue
        coordinates = np.linalg.solve(basis, uv - projected[0])
        weights = np.asarray(
            (1.0 - float(np.sum(coordinates)), coordinates[0], coordinates[1])
        )
        if float(np.min(weights)) >= -1.0e-9 and float(np.max(weights)) <= 1.0 + 1.0e-9:
            heights.append(float(weights @ triangle[:, 2]))
    return heights


def pad_alignment_audit(repo: Path, live_run: Path) -> dict[str, Any]:
    pad_path = repo / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json"
    pad = read_json(pad_path)
    proxy_manifest_path = repo / PROXY_MANIFEST_RELATIVE
    proxy_manifest = read_json(proxy_manifest_path)
    source_by_link = {
        str(link["link_name"]): link for link in proxy_manifest["links"]
    }
    source_dir = repo / PAD_SOURCE_RELATIVE
    rows = []
    for link in pad["links"]:
        source = source_by_link[str(link["link_name"])]
        capsule = link["capsules"][0]
        center = np.asarray(capsule["center_local_m"], dtype=np.float64)
        origin = np.asarray(link["contact_frame_local"]["origin_m"], dtype=np.float64)
        longitudinal = np.asarray(
            link["contact_frame_local"]["longitudinal_axis_unit"],
            dtype=np.float64,
        )
        width = np.asarray(
            link["contact_frame_local"]["width_axis_unit"], dtype=np.float64
        )
        outward = np.asarray(
            link["contact_frame_local"]["outward_normal_unit"], dtype=np.float64
        )
        longitudinal /= np.linalg.norm(longitudinal)
        width /= np.linalg.norm(width)
        outward /= np.linalg.norm(outward)
        frame = np.column_stack((longitudinal, width, outward))
        radius = float(capsule["radius_m"])
        center_frame = (center - origin) @ frame
        outer_cap_coordinate = float(center_frame[2] + radius)

        source_arrays = source_dir / str(source["source_pad_arrays"])
        if sha256(source_arrays) != str(source["source_pad_arrays_sha256"]):
            raise RuntimeError(f"PAD source hash mismatch: {source_arrays}")
        with np.load(source_arrays, allow_pickle=False) as archive:
            points = np.asarray(archive["points_local_m"], dtype=np.float64)
            faces = np.asarray(archive["faces"], dtype=np.int64)
            contact_ids = np.asarray(
                archive["pad_contact_face_ids"], dtype=np.int64
            )
        triangles = (points[faces[contact_ids]] - origin) @ frame
        axial_half_span = 0.5 * float(capsule["cylinder_height_m"])
        heights = []
        for v_coordinate in np.linspace(
            float(center_frame[1] - axial_half_span),
            float(center_frame[1] + axial_half_span),
            161,
        ):
            heights.extend(
                _surface_heights_at_uv(
                    triangles,
                    np.asarray((center_frame[0], v_coordinate)),
                )
            )
        if not heights:
            raise RuntimeError(
                f"selected capsule centerline missed author contact mesh: {link['link_name']}"
            )
        selected_protrusions = np.asarray(heights) - outer_cap_coordinate
        bounds = source["source_contact_bounds_in_frame_m"]
        author_min = float(bounds["minimum"][2])
        author_max = float(bounds["maximum"][2])
        rows.append(
            {
                "link_name": link["link_name"],
                "selected_source_capsule_index": int(link["source_capsule_index"]),
                "source_proxy_capsule_count": int(source["capsule_count"]),
                "area_weighted_contact_frame_origin_local_m": origin.tolist(),
                "source_surface_outward_normal_local": outward.tolist(),
                "capsule_center_local_m": center.tolist(),
                "capsule_radius_m": radius,
                "proxy_outer_cap_coordinate_from_contact_frame_origin_m": outer_cap_coordinate,
                "area_weighted_origin_offset_is_not_penetration_metric": True,
                "author_contact_coordinate_range_m": [author_min, author_max],
                "full_author_surface_protrusion_beyond_proxy_range_m": [
                    author_min - outer_cap_coordinate,
                    author_max - outer_cap_coordinate,
                ],
                "selected_capsule_centerline_author_surface_protrusion_range_m": [
                    float(np.min(selected_protrusions)),
                    float(np.max(selected_protrusions)),
                ],
                "selected_capsule_centerline_sample_count": int(len(heights)),
                "source_proxy_minimum_outward_inset_m": float(
                    source["task_geometry_metrics"]["minimum_outward_inset_m"]
                ),
                "source_contact_relief_m": float(
                    source["task_geometry_metrics"]["contact_relief_m"]
                ),
            }
        )

    trace_path = live_run / "FULL_IIWA_TRACE.csv"
    with trace_path.open(newline="", encoding="utf-8") as stream:
        final = list(csv.DictReader(stream))[-1]
    nut_xy = np.asarray((float(final["nut_x_m"]), float(final["nut_y_m"])))
    contact_radii = {}
    for finger in ("f1", "f2", "f3"):
        point_xy = np.asarray(
            (
                float(final[f"{finger}_contact_point_x_m"]),
                float(final[f"{finger}_contact_point_y_m"]),
            )
        )
        contact_radii[finger] = float(np.linalg.norm(point_xy - nut_xy))

    overlay = read_json(live_run / "VISUAL_OVERLAY_AUDIT.json")
    selected_minimum = min(
        row["selected_capsule_centerline_author_surface_protrusion_range_m"][0]
        for row in rows
    )
    selected_maximum = max(
        row["selected_capsule_centerline_author_surface_protrusion_range_m"][1]
        for row in rows
    )
    return {
        "schema": "D38999_PAD_PROXY_VISUAL_ALIGNMENT_AUDIT_V1",
        "created_utc": utc_iso(),
        "status": "FAIL_PAD_PROXY_RECESSED_AND_TERMINAL_COLLISION_INCOMPLETE",
        "visual_contact_truth_passed": False,
        "numeric_diagnostic_proxy_result_changed": False,
        "pad_core_path": str(pad_path.relative_to(repo)),
        "pad_core_sha256": sha256(pad_path),
        "source_proxy_manifest_path": str(proxy_manifest_path.relative_to(repo)),
        "source_proxy_manifest_sha256": sha256(proxy_manifest_path),
        "source_proxy_dynamic_use_allowed": bool(
            proxy_manifest["dynamic_use_allowed"]
        ),
        "pad_core_formal_b_use_allowed": bool(pad["formal_b_use_allowed"]),
        "diagnostic_dynamic_use_allowed": bool(pad["diagnostic_dynamic_use_allowed"]),
        "tip_collision_count": int(pad["tip_collision_count"]),
        "whole_terminal_convex_hull_count": int(
            pad["whole_terminal_convex_hull_count"]
        ),
        "pad_primitive_count_total": int(pad["pad_primitive_count_total"]),
        "source_proxy_primitive_count_total": int(
            proxy_manifest["pad_collision_primitive_count_total"]
        ),
        "source_tip_proxy_available_but_omitted_from_current_pad_core": bool(
            proxy_manifest["tip_collision_primitive_count_per_finger"] == 1
            and pad["tip_collision_count"] == 0
        ),
        "per_finger_alignment": rows,
        "selected_capsule_centerline_author_surface_protrusion_range_m": [
            selected_minimum,
            selected_maximum,
        ],
        "selected_capsule_centerline_author_surface_protrusion_range_mm": [
            1000.0 * selected_minimum,
            1000.0 * selected_maximum,
        ],
        "physical_grasp_cylinder_radius_m": 0.024,
        "visual_nut_outer_radius_m": 0.024,
        "visual_and_physical_nut_radial_envelopes_match": True,
        "final_contact_point_radii_from_nut_axis_m": contact_radii,
        "all_final_contacts_on_24mm_physical_cylinder": all(
            abs(radius - 0.024) <= 2.0e-5 for radius in contact_radii.values()
        ),
        "overlay_parent_root_mapping_present": bool(
            overlay.get("synchronization_parent_mapping")
        ),
        "overlay_physical_dynamics_unchanged": bool(
            overlay.get("physical_dynamics_unchanged")
        ),
        "root_cause": [
            "ONE_CENTRAL_CAPSULE_SELECTED_FROM_FIVE_CAPSULE_SOURCE_PROXY",
            "AUTHOR_PAD_CENTERLINE_PROTRUDES_0P711_TO_1P211MM_BEYOND_SELECTED_PROXY",
            "TIP_COLLISION_IS_ABSENT",
            "TERMINAL_SIDE_COLLISION_IS_NOT_FULL_FIDELITY",
            "ONLY_DIAGNOSTIC_PAD_CORE_CONTACT_IS_SOLVED",
        ],
        "ruled_out_as_primary_cause": [
            "COUPLING_NUT_VISUAL_RADIUS_MISMATCH",
            "VISUAL_OVERLAY_PHYSICS_FEEDBACK",
        ],
        "camera_visibility_gate_detects_interpenetration": False,
        "user_observed_final_hold_interpenetration_is_consistent_with_model": True,
        "rendered_terminal_total_interpenetration_fully_quantified": False,
        "formal_b_dynamic_pass_allowed": False,
        "required_next_authority": (
            "A separate task must either validate and explicitly authorize the proxy "
            "with sensitivity evidence or build a stable full-fidelity PAD/TIP/SIDE "
            "collision approximation. This closeout does neither."
        ),
    }


def claim_scope_markdown(result: Mapping[str, Any], alignment: Mapping[str, Any]) -> str:
    lift = float(result["lift"]["object_lift_m"])
    protrusion_mm = alignment[
        "selected_capsule_centerline_author_surface_protrusion_range_mm"
    ]
    return f"""# B阶段结论层级纠正

当前统一状态为：

```text
B_FULL_IIWA_DIAGNOSTIC_PROXY_TABLE_PICK_PASS
```

冻结控制器在中央 PAD 胶囊代理合同内完成了 {lift * 1000.0:.3f} mm 活动端抬升，
数值 TRACE 与既有三次确定性验证一致。该结论只证明诊断代理能够承载，不是
`B_FORMAL_DYNAMIC_PASS`、不是完整 CAD 指腹接触保真验证，也不是硬件安全认证。

## 用户发现的穿模

最新 live 画面显示手指外观进入连接器。静态几何审计确认，每个中央
`PAD_CORE_CAPSULE` 只是原 5 胶囊方案的中央一枚。对作者 PAD 三角面在该胶囊
中心线及 8 mm 轴向段插值后，可见接触面比代理表面向连接器方向超前
{float(protrusion_mm[0]):.3f}–{float(protrusion_mm[1]):.3f} mm；配置还明确写有
`tip_collision_count=0`。因此胶囊接触 24 mm 抓持圆柱时，真实手指外观存在
约上述量级的局部穿入风险，TIP/SIDE 的总穿入量则因缺少完整碰撞而不能仅凭
当前代理精确量化。

注意：胶囊外表面相对“面积加权接触坐标原点”为约 -1.277 mm，但该原点不是
真实表面包络；本报告没有把这个坐标误当成穿入量。

视觉螺母与物理抓持圆柱的半径均为 24 mm，且三处最终接触点均位于该物理
圆柱，因此主要根因不是 Visual Overlay 根变换错位，而是诊断 PAD/末端碰撞表示
不具备完整外形保真度。

## 当前图像与视频的证据角色

- live stage、相机、视频帧率和里程碑采集：通过；
- 机械臂链连续性：通过；
- 连接器完整 Visual Complete 外观：通过；
- 真实 PAD/TIP/SIDE 无穿透接触真值：失败；
- 正式 B 动态通过声明：禁止。

后续只能二选一：人工在偏差、法向、覆盖范围和敏感性证据齐全后明确授权代理，
或另立任务建立稳定的真实 PAD/TIP/SIDE 碰撞近似。本收尾不修改碰撞几何、抓取
候选或控制参数，也不进入 C/D/E。
"""


def gui_wrapper(view: str, *, record: bool = False) -> str:
    record_prefix = "B_GUI_RECORD=1 " if record else ""
    return f"""#!/usr/bin/env bash
set -euo pipefail
exec env {record_prefix}bash /home/noob/WorkPlace/kcgtest1/run_full_iiwa_b_gui.sh \\
  /home/noob/WorkPlace/kcgtest1 {view}
"""


def write_manifest(package_root: Path) -> tuple[int, int]:
    files = sorted(
        path
        for path in package_root.rglob("*")
        if path.is_file() and path.name not in {"MANIFEST.csv", "SHA256SUMS.txt"}
    )
    manifest = package_root / "MANIFEST.csv"
    with manifest.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=("path", "size_bytes", "sha256"))
        writer.writeheader()
        for path in files:
            writer.writerow(
                {
                    "path": path.relative_to(package_root).as_posix(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256(path),
                }
            )
    checksummed = [*files, manifest]
    write_text(
        package_root / "SHA256SUMS.txt",
        "".join(
            f"{sha256(path)}  {path.relative_to(package_root).as_posix()}\n"
            for path in checksummed
        ),
    )
    return len(files), sum(path.stat().st_size for path in files)


def verify_archive(archive: Path, expected_root: str) -> dict[str, Any]:
    with tarfile.open(archive, "r:gz") as stream:
        members = stream.getmembers()
        for member in members:
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts:
                raise RuntimeError(f"unsafe archive member: {member.name}")
            if not path.parts or path.parts[0] != expected_root:
                raise RuntimeError(f"unexpected archive root: {member.name}")
        with tempfile.TemporaryDirectory(prefix="b_visual_closeout_verify_") as temp:
            destination = Path(temp)
            stream.extractall(destination, filter="data")
            completed = subprocess.run(
                ["bash", "verify_package.sh"],
                cwd=destination / expected_root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            if completed.returncode:
                raise RuntimeError(completed.stdout)
    return {
        "tar_read_check": "PASS",
        "unsafe_path_check": "PASS",
        "extracted_sha256_check": "PASS",
        "member_count": len(members),
    }


def populate(repo: Path, live_run: Path, package_root: Path) -> dict[str, Any]:
    live_result = read_json(live_run / "FULL_IIWA_RESULT.json")
    live_audit = read_json(live_run / "LIVE_CAPTURE_AUDIT.json")
    if live_result.get("status") != "PASS" or not live_audit.get("passed"):
        raise RuntimeError("selected live run did not pass its diagnostic capture gates")
    for name in REQUIRED_LIVE_FILES:
        copy_file(live_run / name, package_root / "EVIDENCE/LIVE" / name)
    final_hold_frame = (
        package_root
        / "EVIDENCE/LIVE/LIVE_FINAL_HOLD_INTERPENETRATION_EVIDENCE.png"
    )
    extracted = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-ss",
            "44.0",
            "-i",
            str(live_run / "B_FULL_IIWA_LIVE_RUN.mp4"),
            "-frames:v",
            "1",
            str(final_hold_frame),
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if extracted.returncode or not final_hold_frame.is_file():
        raise RuntimeError(f"failed to extract final-hold evidence: {extracted.stdout}")

    independence = build_independence_audit(repo)
    alignment = pad_alignment_audit(repo, live_run)
    write_json(package_root / "B_VALIDATION_INDEPENDENCE_AUDIT.json", independence)
    write_json(package_root / "PAD_PROXY_VISUAL_ALIGNMENT_AUDIT.json", alignment)
    write_text(
        package_root / "B_CLAIM_SCOPE_CORRECTION_CN.md",
        claim_scope_markdown(live_result, alignment),
    )
    write_text(
        package_root / "README_FIRST_CN.md",
        """# B_VISUAL_TRUTH_AND_GUI_CLOSEOUT

先读 `B_CLAIM_SCOPE_CORRECTION_CN.md` 与
`PAD_PROXY_VISUAL_ALIGNMENT_AUDIT.json`。

本包保留真实 live 动态、五张里程碑图和 MP4，但用户目视发现的手指穿模已经
被确认为诊断 PAD/末端碰撞不保真的真实限制。相机采集通过不等于接触真值通过。
当前只能声明 `B_FULL_IIWA_DIAGNOSTIC_PROXY_TABLE_PICK_PASS`；正式 B、硬件认证、
鲁棒性统计以及 C/D/E 均未获通过或授权。

四个 GUI 脚本会启动仓库中的 live runner，方便直接观察；不会启动 post-hoc replay。
""",
    )

    for name, text in (
        ("01_RUN_GUI_OVERVIEW.sh", gui_wrapper("overview")),
        ("02_RUN_GUI_GRASP_VIEW.sh", gui_wrapper("grasp")),
        ("03_RUN_GUI_SIDE_VIEW.sh", gui_wrapper("side")),
        ("04_RUN_AND_RECORD_VIDEO.sh", gui_wrapper("overview", record=True)),
    ):
        write_text(package_root / name, text, executable=True)
    copy_file(repo / "GUI_LAUNCH_COMMANDS_CN.md", package_root / "GUI_LAUNCH_COMMANDS_CN.md")

    experiments = repo / "artifacts/b_goal_mode" / SESSION_NAME / "experiments"
    for name in VALIDATIONS:
        source = experiments / name
        for filename in ("FULL_IIWA_RESULT.json", "FULL_IIWA_TRACE.csv"):
            copy_file(
                source / filename,
                package_root / "EVIDENCE/DETERMINISTIC_VALIDATIONS" / name / filename,
            )

    render_audit = repo / "artifacts/b_goal_mode/publication_figures/ISAAC_RENDER_VISUAL_AUDIT.json"
    if render_audit.is_file():
        copy_file(render_audit, package_root / "EVIDENCE/HISTORY" / render_audit.name)
    prompt = Path.home() / "Downloads/CODEX_B_VISUAL_TRUTH_AND_GUI_CLOSEOUT_CN.md"
    if prompt.is_file():
        copy_file(prompt, package_root / "INPUTS" / prompt.name)
    write_json(
        package_root / "INPUTS/B_FULL_IIWA_DELIVERY_AUDIT_AVAILABILITY.json",
        {
            "requested_filename": "B_FULL_IIWA_DELIVERY_AUDIT_CN.md",
            "found_in_download_directories": False,
            "facts_independently_checked": True,
            "fabricated_replacement_created": False,
        },
    )

    source_files = (
        "run_full_iiwa_b_gui.sh",
        "run_b_goal_mode_supervisor.sh",
        "src/kcg_connector/isaac/run_isaac_python.sh",
        "src/kcg_connector/isaac/b_goal_mode/full_iiwa_table_pick.py",
        "src/kcg_connector/kcg_connector/grasp/b_goal_mode/live_visualization.py",
        "src/kcg_connector/kcg_connector/grasp/b_goal_mode/build_visual_truth_closeout.py",
        "src/kcg_connector/config/b_goal_mode/full_iiwa_b_goal_mode.yaml",
        "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json",
        str(PROXY_MANIFEST_RELATIVE),
        str(PAD_SOURCE_RELATIVE / "f1Link3_PAD_BODY_exact_source_local_m.npz"),
        str(PAD_SOURCE_RELATIVE / "f2Link2_PAD_BODY_exact_source_local_m.npz"),
        str(PAD_SOURCE_RELATIVE / "f3Link3_PAD_BODY_exact_source_local_m.npz"),
        "src/kcg_connector/test/test_b_goal_mode_live_visualization.py",
        "artifacts/kcg_connector/isaac/d38999_multilayer_v1/D38999_VISUAL_COMPLETE_V1.usda",
        "artifacts/kcg_connector/isaac/d38999_multilayer_v1/D38999_ASSEMBLY_CONTROL_V1.usda",
        "artifacts/kcg_connector/isaac/d38999_multilayer_v1/MODEL_MAPPING.json",
    )
    source_hashes = []
    for relative_text in source_files:
        relative = Path(relative_text)
        source = repo / relative
        copy_file(source, package_root / "SOURCE_SNAPSHOT" / relative)
        source_hashes.append(
            {
                "path": relative.as_posix(),
                "size_bytes": source.stat().st_size,
                "sha256": sha256(source),
            }
        )
    write_json(package_root / "SOURCE_HASHES.json", source_hashes)

    session_log = repo / "artifacts/b_goal_mode" / SESSION_NAME / "logs"
    matching_logs = sorted(session_log.glob("*_B_VISUAL_TRUTH_LIVE_CAPTURE_03.log"))
    if matching_logs:
        lines = matching_logs[-1].read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()
        write_text(
            package_root / "EVIDENCE/LOG_TAILS" / matching_logs[-1].name,
            "\n".join(lines[-3000:]) + "\n",
        )

    worktree = package_root / "WORKTREE"
    write_text(worktree / "GIT_STATUS.txt", run_git(repo, "status", "--short", "--untracked-files=all"))
    write_text(worktree / "GIT_DIFF.patch", run_git(repo, "diff", "--no-ext-diff", "--binary"))
    write_text(worktree / "GIT_HEAD.txt", run_git(repo, "rev-parse", "HEAD"))
    write_text(
        package_root / "RUN_COMMANDS.txt",
        """# Static GUI checks (do not launch Isaac)
B_GUI_DRY_RUN=1 bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 overview
B_GUI_DRY_RUN=1 bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 grasp
B_GUI_DRY_RUN=1 bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 side

# Live GUI (diagnostic proxy scope)
bash run_full_iiwa_b_gui.sh /home/noob/WorkPlace/kcgtest1 overview
""",
    )
    write_json(
        package_root / "CLOSEOUT_STATUS.json",
        {
            "schema": SCHEMA,
            "created_utc": utc_iso(),
            "status": "B_VISUAL_TRUTH_BLOCKED_BY_DIAGNOSTIC_PAD_INTERPENETRATION",
            "numeric_status": "B_FULL_IIWA_DIAGNOSTIC_PROXY_TABLE_PICK_PASS",
            "live_stage_capture_passed": True,
            "live_video_passed": True,
            "complete_iiwa_chain_visible": True,
            "visual_contact_truth_passed": False,
            "formal_b_dynamic_passed": False,
            "entered_c_d_e": False,
            "new_h_identifier_created": False,
            "posthoc_replay_used_for_live_evidence": False,
            "physics_object_pose_writes": int(
                live_result["truth_boundary"]["object_pose_write_after_physics_count"]
            ),
            "object_lift_m": float(live_result["lift"]["object_lift_m"]),
            "live_run": str(live_run),
            "live_video_sha256": sha256(live_run / "B_FULL_IIWA_LIVE_RUN.mp4"),
            "final_hold_interpenetration_evidence": str(
                final_hold_frame.relative_to(package_root)
            ),
            "trace_canonical_matches_three_validations": bool(
                independence["trace_data_exactly_identical_excluding_step_wall_s"]
            ),
            "blocking_audit": "PAD_PROXY_VISUAL_ALIGNMENT_AUDIT.json",
        },
    )
    write_text(
        package_root / "verify_package.sh",
        """#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS.txt
python3 - <<'PY'
import csv
from pathlib import Path
rows = list(csv.DictReader(Path('MANIFEST.csv').open(newline='', encoding='utf-8')))
for row in rows:
    path = Path(row['path'])
    assert path.is_file(), path
    assert path.stat().st_size == int(row['size_bytes']), path
print(f'MANIFEST_OK files={len(rows)}')
PY
""",
        executable=True,
    )
    return {
        "independence": independence,
        "alignment": alignment,
        "live_result": live_result,
    }


def parse_arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default="/home/noob/WorkPlace/kcgtest1")
    parser.add_argument("--live-run-dir")
    parser.add_argument("--output-dir", default=str(Path.home() / "Downloads"))
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = parse_arguments(argv)
    repo = Path(arguments.repo_root).expanduser().resolve()
    output = Path(arguments.output_dir).expanduser().resolve()
    if arguments.live_run_dir:
        live_run = Path(arguments.live_run_dir).expanduser().resolve()
    else:
        candidates = sorted(
            (
                repo
                / "artifacts/b_goal_mode"
                / SESSION_NAME
                / "experiments"
            ).glob("B_VISUAL_TRUTH_LIVE_CAPTURE_03_*")
        )
        if not candidates:
            raise FileNotFoundError("no B_VISUAL_TRUTH_LIVE_CAPTURE_03 run")
        live_run = candidates[-1]
    output.mkdir(parents=True, exist_ok=True)
    package_name = f"B_VISUAL_TRUTH_AND_GUI_CLOSEOUT_{utc_stamp()}"
    package_root = output / package_name
    archive = output / f"{package_name}.tar.gz"
    if package_root.exists() or archive.exists():
        raise FileExistsError(package_root)
    package_root.mkdir()
    try:
        populate(repo, live_run, package_root)
        file_count, uncompressed_bytes = write_manifest(package_root)
        with tarfile.open(archive, "w:gz", compresslevel=6) as stream:
            stream.add(package_root, arcname=package_name, recursive=True)
        verification = verify_archive(archive, package_name)
    except BaseException:
        shutil.rmtree(package_root, ignore_errors=True)
        archive.unlink(missing_ok=True)
        raise
    result = {
        "schema": SCHEMA,
        "package_directory": str(package_root),
        "archive_path": str(archive),
        "archive_size_bytes": archive.stat().st_size,
        "archive_sha256": sha256(archive),
        "package_file_count": file_count,
        "package_uncompressed_bytes": uncompressed_bytes,
        "verification": verification,
    }
    write_json(output / f"{package_name}_BUILD_RESULT.json", result)
    write_text(
        output / f"{package_name}.tar.gz.sha256",
        f"{result['archive_sha256']}  {archive.name}\n",
    )
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
