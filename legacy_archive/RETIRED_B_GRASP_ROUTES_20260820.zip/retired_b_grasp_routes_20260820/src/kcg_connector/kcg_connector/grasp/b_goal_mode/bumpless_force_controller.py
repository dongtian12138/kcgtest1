"""Bounded common/differential position-admittance force controller for G4+."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np


@dataclass(frozen=True)
class ForceControlOutput:
    target_positions_rad: tuple[float, float, float]
    estimated_force_n: tuple[float, float, float]
    desired_force_n: tuple[float, float, float]
    force_error_n: tuple[float, float, float]
    common_error_n: float
    differential_error_n: tuple[float, float, float]
    cumulative_offset_rad: tuple[float, float, float]
    raw_offset_rate_rad_s: tuple[float, float, float]
    limited_offset_rate_rad_s: tuple[float, float, float]
    first_step_integrator_frozen: bool
    rate_limit_active: bool
    cumulative_limit_active: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            name: list(value) if isinstance(value, tuple) else value
            for name, value in self.__dict__.items()
        }


class BumplessThreeFingerForceController:
    def __init__(
        self,
        *,
        equilibrium_target_positions_rad: Sequence[float],
        common_rate_gain_rad_s_per_n: float,
        differential_rate_gain_rad_s_per_n: float,
        maximum_offset_rate_rad_s: float,
        maximum_target_step_rad: float,
        minimum_cumulative_offset_rad: float,
        maximum_cumulative_offset_rad: float,
    ) -> None:
        equilibrium = np.asarray(equilibrium_target_positions_rad, dtype=np.float64)
        if equilibrium.shape != (3,) or not np.all(np.isfinite(equilibrium)):
            raise ValueError("force controller needs three finite equilibrium targets")
        positives = (
            common_rate_gain_rad_s_per_n,
            differential_rate_gain_rad_s_per_n,
            maximum_offset_rate_rad_s,
            maximum_target_step_rad,
        )
        if not all(float(value) > 0.0 for value in positives):
            raise ValueError("force controller gains and limits must be positive")
        if minimum_cumulative_offset_rad >= maximum_cumulative_offset_rad:
            raise ValueError("cumulative offset bounds are inverted")
        self.equilibrium = equilibrium
        self.common_gain = float(common_rate_gain_rad_s_per_n)
        self.differential_gain = float(differential_rate_gain_rad_s_per_n)
        self.maximum_rate = float(maximum_offset_rate_rad_s)
        self.maximum_step = float(maximum_target_step_rad)
        self.minimum_offset = float(minimum_cumulative_offset_rad)
        self.maximum_offset = float(maximum_cumulative_offset_rad)
        self.offset = np.zeros(3, dtype=np.float64)
        self.last_target = equilibrium.copy()
        self.just_switched = True
        self.anti_windup_event_count = 0
        self.maximum_observed_target_step_rad = 0.0

    def update(
        self,
        *,
        desired_force_n: Sequence[float],
        estimated_force_n: Sequence[float],
        dt_s: float,
    ) -> ForceControlOutput:
        desired = np.asarray(desired_force_n, dtype=np.float64)
        estimated = np.asarray(estimated_force_n, dtype=np.float64)
        if desired.shape != (3,) or estimated.shape != (3,):
            raise ValueError("force controller needs three desired and estimated forces")
        if not np.all(np.isfinite(desired)) or not np.all(np.isfinite(estimated)):
            raise ValueError("force controller forces must be finite")
        if dt_s <= 0.0:
            raise ValueError("dt_s must be positive")
        error = desired - estimated
        common = float(np.mean(error))
        differential = error - common
        raw_rate = self.common_gain * common + self.differential_gain * differential
        frozen = self.just_switched
        previous_target = self.last_target.copy()
        rate_limited = False
        cumulative_limited = False
        if frozen:
            limited_rate = np.zeros(3, dtype=np.float64)
            self.just_switched = False
        else:
            limited_rate = np.clip(raw_rate, -self.maximum_rate, self.maximum_rate)
            rate_limited = not np.allclose(limited_rate, raw_rate, atol=0.0, rtol=0.0)
            proposed_offset = self.offset + limited_rate * float(dt_s)
            bounded_offset = np.clip(
                proposed_offset, self.minimum_offset, self.maximum_offset
            )
            cumulative_limited = not np.allclose(
                bounded_offset, proposed_offset, atol=0.0, rtol=0.0
            )
            proposed_target = self.equilibrium + bounded_offset
            target_delta = np.clip(
                proposed_target - self.last_target,
                -self.maximum_step,
                self.maximum_step,
            )
            if not np.allclose(
                target_delta,
                proposed_target - self.last_target,
                atol=0.0,
                rtol=0.0,
            ):
                rate_limited = True
            actual_target = self.last_target + target_delta
            # Back-calculate the integral state from the emitted bounded target.
            # This is the anti-windup path for both rate and cumulative limits.
            self.offset = actual_target - self.equilibrium
            self.last_target = actual_target
            if rate_limited or cumulative_limited:
                self.anti_windup_event_count += 1
        target_step = float(np.max(np.abs(self.last_target - previous_target)))
        self.maximum_observed_target_step_rad = max(
            self.maximum_observed_target_step_rad, target_step
        )
        return ForceControlOutput(
            target_positions_rad=tuple(float(value) for value in self.last_target),
            estimated_force_n=tuple(float(value) for value in estimated),
            desired_force_n=tuple(float(value) for value in desired),
            force_error_n=tuple(float(value) for value in error),
            common_error_n=common,
            differential_error_n=tuple(float(value) for value in differential),
            cumulative_offset_rad=tuple(float(value) for value in self.offset),
            raw_offset_rate_rad_s=tuple(float(value) for value in raw_rate),
            limited_offset_rate_rad_s=tuple(float(value) for value in limited_rate),
            first_step_integrator_frozen=frozen,
            rate_limit_active=rate_limited,
            cumulative_limit_active=cumulative_limited,
        )

    def state(self) -> dict[str, Any]:
        return {
            "equilibrium_target_positions_rad": self.equilibrium.tolist(),
            "cumulative_offset_rad": self.offset.tolist(),
            "last_target_positions_rad": self.last_target.tolist(),
            "anti_windup_event_count": self.anti_windup_event_count,
            "maximum_observed_target_step_rad": self.maximum_observed_target_step_rad,
            "common_and_differential_are_orthogonal": True,
        }
