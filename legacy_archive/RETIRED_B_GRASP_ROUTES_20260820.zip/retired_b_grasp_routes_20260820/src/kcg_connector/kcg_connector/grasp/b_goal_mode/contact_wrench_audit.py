#!/usr/bin/env python3
"""Offline contact-wrench math and the immutable R2 baseline audit."""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np


@dataclass(frozen=True)
class ContactWrenchSample:
    normal_force_n: float
    tangential_force_n: float
    friction_utilization: float
    contact_normal: tuple[float, float, float]
    contact_point_m: tuple[float, float, float]
    normal_impulse_ns: float
    tangential_impulse_ns: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ContactWrenchAggregate:
    normal_force_n: float
    tangential_force_n: float
    friction_utilization: float
    contact_normal: tuple[float, float, float]
    contact_point_m: tuple[float, float, float]
    normal_impulse_ns: float
    tangential_impulse_ns: float
    contact_total_impulse_norm_ns: float
    contact_count: int
    friction_anchor_count: int
    tangential_source: str
    maximum_normal_unit_error: float
    maximum_impulse_reconstruction_error_ns: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _unit(vector: Sequence[float], *, name: str) -> np.ndarray:
    value = np.asarray(vector, dtype=np.float64)
    if value.shape != (3,) or not np.all(np.isfinite(value)):
        raise ValueError(f"{name} must be one finite 3-vector")
    norm = float(np.linalg.norm(value))
    if norm <= 1.0e-12:
        raise ValueError(f"{name} has zero length")
    return value / norm


def decompose_contact_impulse(
    *,
    contact_impulse_ns: Sequence[float],
    contact_normal: Sequence[float],
    contact_point_m: Sequence[float],
    dt_s: float,
    friction_coefficient: float,
    epsilon_n: float = 1.0e-9,
) -> ContactWrenchSample:
    """Project one reported total impulse onto its actual contact normal."""

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")
    if friction_coefficient < 0.0:
        raise ValueError("friction_coefficient cannot be negative")
    impulse = np.asarray(contact_impulse_ns, dtype=np.float64)
    point = np.asarray(contact_point_m, dtype=np.float64)
    if impulse.shape != (3,) or point.shape != (3,):
        raise ValueError("contact impulse and point must be 3-vectors")
    if not np.all(np.isfinite(impulse)) or not np.all(np.isfinite(point)):
        raise ValueError("contact impulse and point must be finite")
    normal = _unit(contact_normal, name="contact_normal")
    signed_normal_impulse = float(np.dot(impulse, normal))
    normal_impulse = abs(signed_normal_impulse)
    tangential_vector = impulse - signed_normal_impulse * normal
    tangential_impulse = float(np.linalg.norm(tangential_vector))
    normal_force = normal_impulse / float(dt_s)
    tangential_force = tangential_impulse / float(dt_s)
    utilization = tangential_force / (
        float(friction_coefficient) * normal_force + float(epsilon_n)
    )
    return ContactWrenchSample(
        normal_force_n=normal_force,
        tangential_force_n=tangential_force,
        friction_utilization=utilization,
        contact_normal=tuple(float(value) for value in normal),
        contact_point_m=tuple(float(value) for value in point),
        normal_impulse_ns=normal_impulse,
        tangential_impulse_ns=tangential_impulse,
    )


def aggregate_contact_wrench(
    *,
    contact_impulses_ns: Sequence[Sequence[float]],
    contact_normals: Sequence[Sequence[float]],
    contact_points_m: Sequence[Sequence[float]],
    friction_anchor_impulses_ns: Sequence[Sequence[float]],
    dt_s: float,
    friction_coefficient: float,
    orient_normals_toward_point_m: Sequence[float] | None = None,
    epsilon_n: float = 1.0e-9,
) -> ContactWrenchAggregate:
    """Aggregate one collider pair without treating total impulse as normal force.

    PhysX contact vectors are projected onto each reported contact normal.  If
    friction-anchor impulses are present they define the tangential channel;
    otherwise only the tangential residual of the contact vectors is used.
    The optional orientation point changes normal sign for reporting only and
    cannot affect the sign-independent force magnitude.
    """

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")
    if friction_coefficient < 0.0:
        raise ValueError("friction_coefficient cannot be negative")
    count = len(contact_impulses_ns)
    if count == 0:
        raise ValueError("at least one contact record is required")
    if len(contact_normals) != count or len(contact_points_m) != count:
        raise ValueError("contact impulse, normal and point counts must match")

    orientation_point = None
    if orient_normals_toward_point_m is not None:
        orientation_point = np.asarray(orient_normals_toward_point_m, dtype=np.float64)
        if orientation_point.shape != (3,) or not np.all(np.isfinite(orientation_point)):
            raise ValueError("orient_normals_toward_point_m must be one finite 3-vector")

    normal_impulses: list[float] = []
    oriented_normals: list[np.ndarray] = []
    points: list[np.ndarray] = []
    fallback_tangential_impulse = 0.0
    total_impulse_norm = 0.0
    maximum_unit_error = 0.0
    maximum_reconstruction_error = 0.0
    for impulse_raw, normal_raw, point_raw in zip(
        contact_impulses_ns, contact_normals, contact_points_m
    ):
        impulse = np.asarray(impulse_raw, dtype=np.float64)
        raw_normal = np.asarray(normal_raw, dtype=np.float64)
        point = np.asarray(point_raw, dtype=np.float64)
        if impulse.shape != (3,) or raw_normal.shape != (3,) or point.shape != (3,):
            raise ValueError("each contact impulse, normal and point must be a 3-vector")
        if not (
            np.all(np.isfinite(impulse))
            and np.all(np.isfinite(raw_normal))
            and np.all(np.isfinite(point))
        ):
            raise ValueError("contact records must be finite")
        raw_norm = float(np.linalg.norm(raw_normal))
        if raw_norm <= 1.0e-12:
            raise ValueError("contact_normal has zero length")
        maximum_unit_error = max(maximum_unit_error, abs(raw_norm - 1.0))
        normal = raw_normal / raw_norm
        if orientation_point is not None and float(normal @ (orientation_point - point)) < 0.0:
            normal = -normal
        signed_normal = float(impulse @ normal)
        parallel = signed_normal * normal
        tangential = impulse - parallel
        reconstruction = parallel + tangential
        maximum_reconstruction_error = max(
            maximum_reconstruction_error,
            float(np.linalg.norm(impulse - reconstruction)),
        )
        normal_impulses.append(abs(signed_normal))
        oriented_normals.append(normal)
        points.append(point)
        fallback_tangential_impulse += float(np.linalg.norm(tangential))
        total_impulse_norm += float(np.linalg.norm(impulse))

    weights = np.asarray(normal_impulses, dtype=np.float64)
    weight_sum = float(np.sum(weights))
    if weight_sum > 1.0e-15:
        aggregate_normal = np.sum(
            np.asarray(oriented_normals, dtype=np.float64) * weights[:, None], axis=0
        )
        aggregate_point = np.sum(
            np.asarray(points, dtype=np.float64) * weights[:, None], axis=0
        ) / weight_sum
    else:
        aggregate_normal = np.sum(np.asarray(oriented_normals, dtype=np.float64), axis=0)
        aggregate_point = np.mean(np.asarray(points, dtype=np.float64), axis=0)
    aggregate_normal_norm = float(np.linalg.norm(aggregate_normal))
    if aggregate_normal_norm <= 1.0e-12:
        aggregate_normal = oriented_normals[0]
    else:
        aggregate_normal = aggregate_normal / aggregate_normal_norm

    friction_tangential_impulse = 0.0
    for raw in friction_anchor_impulses_ns:
        anchor = np.asarray(raw, dtype=np.float64)
        if anchor.shape != (3,) or not np.all(np.isfinite(anchor)):
            raise ValueError("friction anchor impulse must be one finite 3-vector")
        tangent = anchor - float(anchor @ aggregate_normal) * aggregate_normal
        friction_tangential_impulse += float(np.linalg.norm(tangent))
    if friction_anchor_impulses_ns:
        tangential_impulse = friction_tangential_impulse
        tangential_source = "PHYSX_FRICTION_ANCHOR_IMPULSE"
    else:
        tangential_impulse = fallback_tangential_impulse
        tangential_source = "CONTACT_VECTOR_TANGENTIAL_RESIDUAL"

    normal_force = weight_sum / float(dt_s)
    tangential_force = tangential_impulse / float(dt_s)
    return ContactWrenchAggregate(
        normal_force_n=normal_force,
        tangential_force_n=tangential_force,
        friction_utilization=tangential_force
        / (float(friction_coefficient) * normal_force + float(epsilon_n)),
        contact_normal=tuple(float(value) for value in aggregate_normal),
        contact_point_m=tuple(float(value) for value in aggregate_point),
        normal_impulse_ns=weight_sum,
        tangential_impulse_ns=tangential_impulse,
        contact_total_impulse_norm_ns=total_impulse_norm,
        contact_count=count,
        friction_anchor_count=len(friction_anchor_impulses_ns),
        tangential_source=tangential_source,
        maximum_normal_unit_error=maximum_unit_error,
        maximum_impulse_reconstruction_error_ns=maximum_reconstruction_error,
    )
def normal_axis_angle_deg(normal: Sequence[float], axis: Sequence[float]) -> float:
    unit_normal = _unit(normal, name="normal")
    unit_axis = _unit(axis, name="axis")
    cosine = float(np.clip(abs(np.dot(unit_normal, unit_axis)), 0.0, 1.0))
    return math.degrees(math.acos(cosine))


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_trace(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _candidate_from_dry_result(r2_root: Path, candidate_id: str) -> dict[str, Any]:
    direct = r2_root / f"DRY_{candidate_id}.json"
    payload = _read_json(direct)
    candidate = payload.get("candidate")
    if not isinstance(candidate, dict):
        nested = r2_root / f"DRY_{candidate_id}" / "B_MINIMAL_V2_DRY_RUN_RESULT.json"
        candidate = _read_json(nested).get("candidate")
    if not isinstance(candidate, dict):
        raise ValueError(f"R2 dry result lacks candidate geometry: {candidate_id}")
    return candidate


def audit_r2_baseline(
    *, r2_root: Path, r2_runner: Path, output_path: Path
) -> dict[str, Any]:
    source = r2_runner.read_text(encoding="utf-8")
    norm_expression_present = (
        "np.linalg.norm(np.asarray(contact.impulse" in source
        and 'row["f1_pad_force_n"]' not in source
    )
    # The second expression is recorded directly because R2 gives the scalar
    # channel its final force units by multiplying pair impulse by rate.
    impulse_times_rate_present = 'row["f1_pad_force_n"]' not in source and "* rate" in source
    candidates: list[dict[str, Any]] = []
    for candidate_id in ("PAD_CORE_Z12", "PAD_CORE_Z14", "PAD_CORE_Z18"):
        directory = r2_root / f"offtable_grasp_{candidate_id}"
        calibration = _read_json(directory / "B_MINIMAL_V2_R2_PRELOAD_CALIBRATION.json")
        trace = _read_trace(directory / "B_MINIMAL_V2_TRACE.csv")
        result = _read_json(directory / "B_MINIMAL_V2_RESULT.json")
        lift_rows = [row for row in trace if row["phase"] == "LIFT_2.0MM"]
        lift_positions = [float(row["lift_position_m"]) for row in lift_rows]
        object_initial_z = float(trace[0]["object_z_m"])
        object_final_z = float(trace[-1]["object_z_m"])
        geometry = _candidate_from_dry_result(r2_root, candidate_id)
        normals = geometry["predicted_contact_normals_hand"]
        candidates.append(
            {
                "candidate_id": candidate_id,
                "pre_release_legacy_pad_force_n": calibration["achieved_pad_force_n"],
                "legacy_channel_all_near_4p9_n": all(
                    4.7 <= float(value) <= 5.1
                    for value in calibration["achieved_pad_force_n"]
                ),
                "commanded_lift_target_m": max(float(row["lift_target_m"]) for row in lift_rows),
                "actual_lift_axis_range_during_lift_m": max(lift_positions) - min(lift_positions),
                "actual_lift_axis_peak_m": max(lift_positions),
                "object_final_displacement_m": object_final_z - object_initial_z,
                "result_status": result.get("status"),
                "result_classification": result.get("classification"),
                "predicted_contact_normal_axis_components": [float(normal[2]) for normal in normals],
                "maximum_absolute_predicted_axis_component": max(abs(float(normal[2])) for normal in normals),
            }
        )

    facts = {
        "three_candidates_reached_about_4p9_legacy_pad_force": all(
            row["legacy_channel_all_near_4p9_n"] for row in candidates
        ),
        "object_slid_down_after_support_release": all(
            row["object_final_displacement_m"] < 0.0 for row in candidates
        ),
        "lift_target_2mm_but_actual_axis_motion_micrometre_scale": all(
            row["commanded_lift_target_m"] >= 0.002
            and row["actual_lift_axis_range_during_lift_m"] < 0.0001
            for row in candidates
        ),
        "legacy_pad_force_is_total_impulse_norm_times_rate": bool(
            "np.linalg.norm(np.asarray(contact.impulse" in source and "* rate" in source
        ),
        "mu_times_sum_legacy_pad_force_is_not_valid_normal_capacity": True,
        "predicted_normals_have_significant_connector_axis_component": all(
            row["maximum_absolute_predicted_axis_component"] > 0.5 for row in candidates
        ),
        "per_finger_first_contact_lock_not_implemented": not all(
            token in source for token in ("CONTACT_LOCKED", "first_contact_step")
        ),
    }
    if not all(facts.values()):
        raise AssertionError(f"R2 baseline facts were not all reproduced: {facts}")
    report = {
        "schema": "D38999_B_GOAL_MODE_R2_BASELINE_AUDIT_V1",
        "status": "PASS",
        "source_runner": str(r2_runner.resolve()),
        "r2_evidence_root": str(r2_root.resolve()),
        "facts": facts,
        "candidates": candidates,
        "semantic_correction": {
            "legacy_pad_force_channel_accepted_as_normal_force": False,
            "required_channels": [
                "normal_force",
                "tangential_force",
                "friction_utilization",
                "contact_normal",
                "contact_point",
            ],
        },
        "unused_internal_checks": {
            "norm_expression_present": norm_expression_present,
            "impulse_times_rate_present": impulse_times_rate_present,
        },
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r2-root", required=True)
    parser.add_argument("--r2-runner", required=True)
    parser.add_argument("--output", required=True)
    arguments = parser.parse_args(argv)
    report = audit_r2_baseline(
        r2_root=Path(arguments.r2_root).resolve(),
        r2_runner=Path(arguments.r2_runner).resolve(),
        output_path=Path(arguments.output).resolve(),
    )
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
