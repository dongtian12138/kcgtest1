"""Pure planning contract for the diagnostic full-iiwa B_GOAL_MODE bridge.

This module performs no USD authoring and imports no Isaac API.  It locks the
already validated BG_P120_Z15 diagnostic grasp to the canonical multilayer
tabletop scene, recomputes the full-iiwa fixed-q7 IK family, and fails closed
when any frozen dependency or truth boundary changes.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import yaml

from kcg_connector.d38999_physical_insertion import solve_fixed_q7_tcp_pose
from kcg_connector.d38999_tabletop_pick import iiwa14_grasp_tcp_transform
from kcg_connector.d38999_tabletop_scene import (
    D38999_TABLETOP_SCHEMA_VERSION_MULTILAYER_GRASP,
    load_d38999_tabletop_scene,
    verify_d38999_tabletop_asset,
)
from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    candidate_world_geometry,
    load_seed_geometry,
    select_candidate,
    selected_pad_capsules,
)
from kcg_connector.grasp.b_goal_mode.root_torque_force_calibration import (
    fit_g1_trace,
    serialize_fits,
)


SCHEMA_VERSION = "d38999_full_iiwa_b_goal_mode_v2"
MODE = "FULL_IIWA_B_GOAL_MODE"
CLAIM_SCOPE = "DIAGNOSTIC_INTEGRATION_ONLY_NOT_B_FORMAL_DYNAMIC_PASS"
DEFAULT_CONFIG = (
    Path(__file__).resolve().parents[3]
    / "config/b_goal_mode/full_iiwa_b_goal_mode.yaml"
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _exact_keys(value: Mapping[str, Any], expected: Sequence[str], label: str) -> None:
    actual = set(value)
    wanted = set(expected)
    if actual != wanted:
        raise ValueError(
            f"{label} keys differ: missing={sorted(wanted - actual)}, "
            f"extra={sorted(actual - wanted)}"
        )


def _finite_vector(value: Any, length: int, label: str) -> np.ndarray:
    result = np.asarray(value, dtype=np.float64)
    if result.shape != (length,) or not np.all(np.isfinite(result)):
        raise ValueError(f"{label} must be one finite {length}-vector")
    return result


def _dependency_paths(
    document: Mapping[str, Any], repository_root: Path
) -> dict[str, Path]:
    dependencies = document.get("dependencies")
    if not isinstance(dependencies, Mapping):
        raise ValueError("dependencies must be a mapping")
    required = (
        "robot_asset",
        "tabletop_config",
        "connector_asset",
        "selected_goal_config",
        "candidate_bundle",
        "pad_core",
        "source_hand_urdf",
        "g1_trace",
    )
    _exact_keys(dependencies, required, "dependencies")
    paths: dict[str, Path] = {}
    for name in required:
        entry = dependencies[name]
        if not isinstance(entry, Mapping):
            raise ValueError(f"dependencies.{name} must be a mapping")
        _exact_keys(entry, ("path", "sha256"), f"dependencies.{name}")
        relative = Path(str(entry["path"]))
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"dependencies.{name}.path must be repository-relative")
        path = (repository_root / relative).resolve()
        try:
            path.relative_to(repository_root)
        except ValueError as error:
            raise ValueError(f"dependencies.{name} escapes the repository") from error
        if not path.is_file():
            raise FileNotFoundError(f"dependency is missing: {path}")
        actual = file_sha256(path)
        if actual != str(entry["sha256"]):
            raise ValueError(
                f"dependency digest changed: {name}: expected={entry['sha256']} actual={actual}"
            )
        paths[name] = path
    return paths


def load_full_iiwa_config(
    config_path: Path | str = DEFAULT_CONFIG,
    *,
    repository_root: Path | str,
) -> tuple[dict[str, Any], dict[str, Path]]:
    repository = Path(repository_root).expanduser().resolve()
    path = Path(config_path).expanduser().resolve()
    document = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(document, Mapping):
        raise ValueError("full-iiwa configuration must be a mapping")
    _exact_keys(
        document,
        (
            "schema_version",
            "mode",
            "claim_scope",
            "dependencies",
            "scene",
            "robot",
            "motion",
            "force_quiet_hold",
            "safety",
            "threshold_roles",
            "frozen_boundaries",
        ),
        "root",
    )
    if document["schema_version"] != SCHEMA_VERSION or document["mode"] != MODE:
        raise ValueError("full-iiwa schema or mode changed")
    if document["claim_scope"] != CLAIM_SCOPE:
        raise ValueError("diagnostic-only claim scope changed")
    quiet_hold = document["force_quiet_hold"]
    expected_quiet_hold = {
        "entry_consecutive_force_steps": 48,
        "hold_steps": 120,
        "tare_baseline_steps": 120,
        "locked_baseline_steps": 48,
        "position_baseline_multiplier": 5.0,
        "qdot_fd_baseline_multiplier": 12.0,
        "maximum_position_peak_to_peak_rad": 2.0e-5,
        "maximum_qdot_fd_rms_rad_s": 2.0e-3,
        "raw_to_fd_diagnostic_ratio": 10.0,
    }
    _exact_keys(quiet_hold, expected_quiet_hold, "force_quiet_hold")
    for name, expected in expected_quiet_hold.items():
        if float(quiet_hold[name]) != expected:
            raise ValueError(f"force_quiet_hold changed: {name}")
    expected_roles = {
        "raw_generalized_velocity_0p03_rad_s": "SLIP_MONITOR_ONLY",
        "normal_unit_error_1e_6": "DIAGNOSTIC_ONLY",
        "impulse_reconstruction_error_1e_9_ns": "DIAGNOSTIC_ONLY",
        "bumpless_target_tolerance_1e_9_rad": "DIAGNOSTIC_ONLY",
        "rho_0p70": "DEMOTE_SOFT",
        "tcp_error_0p05_mm": "DIAGNOSTIC_ONLY",
        "wrist_moment_0p30_nm": "DEMOTE_SOFT",
        "wrist_moment_0p60_nm": "KEEP_TASK_RECOVERY",
        "wrist_moment_1p00_nm": "KEEP_HARD_SIMULATION_ONLY",
    }
    if dict(document["threshold_roles"]) != expected_roles:
        raise ValueError("threshold role classification changed")
    safety = document["safety"]
    if float(safety.get("sustained_rho_failure_threshold", math.nan)) != 1.0:
        raise ValueError("sustained rho failure threshold changed")
    if int(safety.get("sustained_rho_failure_steps", -1)) != 12:
        raise ValueError("sustained rho failure duration changed")
    frozen = document["frozen_boundaries"]
    expected_numeric = {
        "object_mass_kg": 0.310,
        "pad_object_friction": 0.50,
        "first_grip_force_n_per_finger": 8.0,
        "nominal_assembly_force_n_per_finger": 10.0,
        "adaptive_force_ceiling_n_per_finger": 12.0,
        "absolute_force_ceiling_n_per_finger": 15.0,
    }
    if frozen.get("candidate_id") != "BG_P120_Z15":
        raise ValueError("selected candidate changed")
    for name, expected in expected_numeric.items():
        if float(frozen.get(name, math.nan)) != expected:
            raise ValueError(f"frozen boundary changed: {name}")
    for name in (
        "sdf_allowed",
        "coacd_allowed",
        "whole_terminal_convex_hull_allowed",
        "object_pose_write_after_physics_allowed",
        "online_object_pose_control_allowed",
        "online_contact_truth_control_allowed",
    ):
        if frozen.get(name) is not False:
            raise ValueError(f"forbidden route was enabled: {name}")
    paths = _dependency_paths(document, repository)
    return dict(document), paths


def _tcp_matrix(joints: Sequence[float]) -> np.ndarray:
    return np.asarray(
        iiwa14_grasp_tcp_transform(tuple(float(value) for value in joints)),
        dtype=np.float64,
    )


def _rotation_error_rad(first: np.ndarray, second: np.ndarray) -> float:
    relative = first @ second.T
    cosine = float(np.clip((np.trace(relative) - 1.0) / 2.0, -1.0, 1.0))
    return math.acos(cosine)


def compute_proprioceptive_load_transfer_compensation(
    plan: Mapping[str, Any],
    *,
    target_offset_m: float,
    achieved_tcp_offset_m: float,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Compensate the one-time support-load tracking bias along the frozen IK path.

    The caller supplies only a TCP offset reconstructed from robot joint positions.
    The correction is the measured Z shortfall projected onto a secant of the
    already-authorized fixed-q7 IK family; no object pose or contact truth enters
    this calculation and no stored IK waypoint is changed.
    """

    target = float(target_offset_m)
    achieved = float(achieved_tcp_offset_m)
    if not math.isfinite(target) or target <= 0.0:
        raise ValueError("target_offset_m must be finite and positive")
    if not math.isfinite(achieved):
        raise ValueError("achieved_tcp_offset_m must be finite")
    shortfall = target - achieved
    if shortfall <= 0.0 or shortfall >= target:
        raise ValueError("load-transfer shortfall must lie strictly inside the target")

    ik = plan.get("ik")
    if not isinstance(ik, Mapping) or not isinstance(ik.get("solutions"), Mapping):
        raise ValueError("plan must contain an IK solution family")
    family: list[tuple[float, np.ndarray]] = []
    for label, record in ik["solutions"].items():
        if not isinstance(record, Mapping):
            raise ValueError(f"invalid IK record: {label}")
        offset = float(record.get("offset_m", math.nan))
        if not math.isfinite(offset):
            raise ValueError(f"invalid IK offset: {label}")
        family.append((offset, _finite_vector(record.get("arm_rad"), 7, label)))
    family.sort(key=lambda item: item[0])
    target_matches = [item for item in family if abs(item[0] - target) <= 1.0e-12]
    lower = [item for item in family if item[0] < target - 1.0e-12]
    upper = [item for item in family if item[0] > target + 1.0e-12]
    if len(target_matches) != 1 or not lower or not upper:
        raise ValueError("target must be one interior waypoint of the frozen IK family")

    lower_offset, lower_joints = lower[-1]
    upper_offset, upper_joints = upper[0]
    target_joints = target_matches[0][1]
    tangent = (upper_joints - lower_joints) / (upper_offset - lower_offset)
    joint_delta = tangent * shortfall
    corrected_joints = target_joints + joint_delta

    target_tcp = _tcp_matrix(target_joints)
    corrected_tcp = _tcp_matrix(corrected_joints)
    tcp_delta = corrected_tcp[:3, 3] - target_tcp[:3, 3]
    report = {
        "source": "ROBOT_JOINT_POSITION_FK_ONLY",
        "online_object_truth_used": False,
        "online_contact_truth_used": False,
        "stored_ik_waypoints_modified": False,
        "target_offset_m": target,
        "achieved_tcp_offset_before_compensation_m": achieved,
        "measured_tcp_shortfall_m": shortfall,
        "secant_offsets_m": [lower_offset, upper_offset],
        "joint_target_delta_rad": joint_delta.tolist(),
        "maximum_joint_target_delta_rad": float(np.max(np.abs(joint_delta))),
        "predicted_tcp_delta_m": tcp_delta.tolist(),
        "predicted_tcp_z_correction_m": float(tcp_delta[2]),
        "predicted_tcp_lateral_correction_m": float(np.linalg.norm(tcp_delta[:2])),
        "predicted_tcp_rotation_delta_rad": _rotation_error_rad(
            corrected_tcp[:3, :3], target_tcp[:3, :3]
        ),
        "fixed_q7_delta_rad": float(joint_delta[6]),
    }
    return corrected_joints, report


def _solve_waypoint(
    *,
    seed: Sequence[float],
    target_position_m: Sequence[float],
    target_rotation: np.ndarray,
    fixed_q7_rad: float,
) -> tuple[np.ndarray, dict[str, float]]:
    joints = np.asarray(
        solve_fixed_q7_tcp_pose(
            tuple(float(value) for value in seed),
            tuple(float(value) for value in target_position_m),
            target_rotation=target_rotation,
            maximum_iterations=50,
        ),
        dtype=np.float64,
    )
    if abs(float(joints[6]) - float(fixed_q7_rad)) > 1.0e-12:
        raise ValueError("fixed q7 changed during local IK")
    realized = _tcp_matrix(joints)
    return joints, {
        "position_error_m": float(
            np.linalg.norm(realized[:3, 3] - np.asarray(target_position_m))
        ),
        "rotation_error_rad": _rotation_error_rad(
            realized[:3, :3], target_rotation
        ),
    }


def advance_closure_target(
    current_rad: float,
    limit_rad: float,
    direction: float,
    increment_rad: float,
) -> float:
    """Advance one joint in its candidate-defined physical closing direction."""

    direction_value = float(direction)
    increment = float(increment_rad)
    if direction_value not in (-1.0, 1.0):
        raise ValueError("closure direction must be -1 or +1")
    if not math.isfinite(increment) or increment <= 0.0:
        raise ValueError("closure increment must be finite and positive")
    proposed = float(current_rad) + direction_value * increment
    return (
        min(proposed, float(limit_rad))
        if direction_value > 0.0
        else max(proposed, float(limit_rad))
    )


def map_force_controller_targets(
    equilibrium_targets_rad: Sequence[float],
    canonical_targets_rad: Sequence[float],
    closure_direction: Sequence[float],
) -> np.ndarray:
    """Map positive controller closure coordinates onto physical joint signs."""

    equilibrium = _finite_vector(
        equilibrium_targets_rad, 3, "force equilibrium targets"
    )
    canonical = _finite_vector(
        canonical_targets_rad, 3, "canonical force-controller targets"
    )
    direction = _finite_vector(closure_direction, 3, "closure direction")
    if not np.all(np.isin(direction, (-1.0, 1.0))):
        raise ValueError("closure directions must contain only -1 or +1")
    return equilibrium + direction * (canonical - equilibrium)


def _real_cad_candidates(config: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    motion = config["motion"]
    if motion.get("real_cad_candidate_seed_id") != "BG_P120_Z12":
        raise ValueError("real-CAD candidate seed changed")
    records = motion.get("real_cad_grasp_candidates")
    if not isinstance(records, list) or len(records) != 3:
        raise ValueError("exactly three real-CAD candidates are required")
    candidates: dict[str, dict[str, Any]] = {}
    for expected_rank, raw in enumerate(records, start=1):
        if not isinstance(raw, Mapping):
            raise ValueError("real-CAD candidate must be a mapping")
        record = dict(raw)
        candidate_id = str(record.get("candidate_id", ""))
        if not candidate_id.startswith("CAD_") or candidate_id in candidates:
            raise ValueError("real-CAD candidate IDs must be unique CAD_ names")
        if int(record.get("rank", -1)) != expected_rank:
            raise ValueError("real-CAD candidate rank changed")
        approach = _finite_vector(
            record.get("approach_flexion_rad"), 3, "approach flexion"
        )
        target = _finite_vector(
            record.get("finger_flexion_targets_rad"), 3, "target flexion"
        )
        direction = _finite_vector(
            record.get("closure_direction"), 3, "closure direction"
        )
        if not np.all(np.isin(direction, (-1.0, 1.0))):
            raise ValueError("real-CAD closure directions must contain only -1 or +1")
        if not np.all(direction * (target - approach) > 0.0):
            raise ValueError("real-CAD approach must remain outside the target grasp")
        if not np.all(
            (target > 0.0)
            & (target < 1.3963)
            & (approach > 0.0)
            & (approach < 1.3963)
        ):
            raise ValueError("real-CAD flexion left the source joint limits")
        closure_travel = direction * (target - approach)
        if float(np.max(closure_travel)) > 0.08:
            raise ValueError("real-CAD precontact closure travel exceeds 0.08 rad")
        closure_start_offset = float(
            record.get("closure_start_offset_m", math.nan)
        )
        if (
            not math.isfinite(closure_start_offset)
            or closure_start_offset <= 0.0
            or closure_start_offset
            >= float(motion["candidate_pregrasp_offset_m"])
        ):
            raise ValueError("real-CAD closure start must be above the target grasp")
        if float(record.get("minimum_table_clearance_m", 0.0)) < 0.001:
            raise ValueError("real-CAD table clearance is below 1 mm")
        if max(abs(value) for value in _finite_vector(
            record.get("target_gaps_m"), 3, "target gaps"
        )) > 0.0002:
            raise ValueError("real-CAD target gap exceeds 0.2 mm")
        if min(_finite_vector(
            record.get("approach_gaps_m"), 3, "approach gaps"
        )) < 0.0015:
            raise ValueError("real-CAD precontact gap is below 1.5 mm")
        if record.get("force_closure") is not True:
            raise ValueError("real-CAD candidate lost force closure")
        if float(record.get("minimum_abs_normal_alignment", 0.0)) < 0.90:
            raise ValueError("real-CAD contact normal alignment changed")
        if float(record.get("minimum_8n_lift_safety_factor", 0.0)) < 1.5:
            raise ValueError("real-CAD 8 N lift margin changed")
        if float(record.get("minimum_12n_other_task_safety_factor", 0.0)) < 1.0:
            raise ValueError("real-CAD task-wrench margin changed")
        if float(record.get("maximum_required_peak_normal_force_n", math.inf)) > 12.0:
            raise ValueError("real-CAD candidate exceeds the 12 N task limit")
        axis_xy = _finite_vector(
            record.get("object_axis_center_xy_hand_m"),
            2,
            "real-CAD object axis center",
        )
        if float(np.max(np.abs(axis_xy))) > 0.05:
            raise ValueError("real-CAD object axis center left the bounded hand region")
        object_center_z = float(record.get("object_center_z_hand_m", math.nan))
        if not math.isfinite(object_center_z) or not 0.35 < object_center_z < 0.50:
            raise ValueError("real-CAD object center Z left the bounded hand region")
        wrist_offset = _finite_vector(
            record.get("wrist_rpy_offset_rad"), 3, "real-CAD wrist offset"
        )
        if float(np.max(np.abs(wrist_offset))) > 0.12:
            raise ValueError("real-CAD wrist offset exceeds the bounded screen")
        tcp_z_offset = float(record.get("tcp_z_offset_m", math.nan))
        if not math.isfinite(tcp_z_offset) or abs(tcp_z_offset) > 0.030:
            raise ValueError("real-CAD TCP Z offset left its bounded calibration range")
        candidates[candidate_id] = record
    return candidates


def build_full_iiwa_plan(
    config_path: Path | str = DEFAULT_CONFIG,
    *,
    repository_root: Path | str,
    candidate_id: str | None = None,
) -> dict[str, Any]:
    repository = Path(repository_root).expanduser().resolve()
    config, paths = load_full_iiwa_config(
        config_path, repository_root=repository
    )
    selected_config = yaml.safe_load(
        paths["selected_goal_config"].read_text(encoding="utf-8")
    )
    frozen = config["frozen_boundaries"]
    selected_frozen = selected_config["frozen_boundaries"]
    for name in (
        "object_mass_kg",
        "pad_object_friction",
        "first_grip_force_n_per_finger",
        "nominal_assembly_force_n_per_finger",
        "adaptive_force_ceiling_n_per_finger",
        "absolute_force_ceiling_n_per_finger",
    ):
        if float(selected_frozen[name]) != float(frozen[name]):
            raise ValueError(f"selected goal config differs at {name}")
    for section in ("g1_contact_wrench", "g2_independent_contact", "g4_compliant_force_control"):
        if selected_config[section]["seed_candidate_id"] != frozen["candidate_id"]:
            raise ValueError(f"selected goal config candidate differs in {section}")
    if selected_config["g7_candidate_search"].get("active_candidate_id") != frozen["candidate_id"]:
        raise ValueError("selected goal config active candidate differs")

    candidates, pad_core = load_seed_geometry(
        candidates_path=paths["candidate_bundle"],
        pad_core_path=paths["pad_core"],
        source_urdf=paths["source_hand_urdf"],
    )
    selected_candidate_id = (
        str(frozen["candidate_id"])
        if candidate_id is None
        else str(candidate_id)
    )
    real_cad_candidates = _real_cad_candidates(config)
    real_cad_candidate = real_cad_candidates.get(selected_candidate_id)
    seed_candidate_id = (
        str(config["motion"]["real_cad_candidate_seed_id"])
        if real_cad_candidate is not None
        else selected_candidate_id
    )
    seed_candidate = select_candidate(candidates, seed_candidate_id)
    if seed_candidate.get("static_pass") is not True:
        raise ValueError("selected candidate no longer has static_pass")
    gates = seed_candidate.get("screening_gates", {})
    if not gates or not all(value is True for value in gates.values()):
        raise ValueError("selected candidate screening gates changed")
    if int(seed_candidate.get("sweep_metrics", {}).get("sample_count", 0)) != 303:
        raise ValueError("selected candidate lost its 303-sample sweep")
    candidate = dict(seed_candidate)
    if real_cad_candidate is not None:
        candidate.update(real_cad_candidate)
        candidate["candidate_id"] = selected_candidate_id
        candidate["seed_candidate_id"] = seed_candidate_id
        candidate["candidate_generation"] = (
            "REAL_CAD_COMPLETE_COLLISION_RESCREEN"
        )
        candidate["static_pass"] = True
    capsules = selected_pad_capsules(pad_core)

    tabletop = load_d38999_tabletop_scene(paths["tabletop_config"])
    if tabletop.schema_version != D38999_TABLETOP_SCHEMA_VERSION_MULTILAYER_GRASP:
        raise ValueError("full-iiwa bridge requires the multilayer grasp scene")
    connector_asset = verify_d38999_tabletop_asset(tabletop, repository)
    if connector_asset != paths["connector_asset"]:
        raise ValueError("scene resolved a different connector asset")
    if abs(tabletop.asset_profile.body_mass_kg + tabletop.asset_profile.nut_mass_kg - 0.310) > 1.0e-12:
        raise ValueError("multilayer moved mass changed")

    local_grip_center = _finite_vector(
        config["scene"]["authorized_grip_local_center_m"], 3, "authorized grip center"
    )
    loose_rotation = np.diag((1.0, -1.0, -1.0))
    nominal_loose_origin = np.asarray(tabletop.loose_settled_origin_m, dtype=np.float64)
    nominal_grip_center = nominal_loose_origin + loose_rotation @ local_grip_center
    geometry = candidate_world_geometry(
        hand_mount_rpy_rad=selected_config["grasp_geometry"]["hand_mount_rpy_rad"],
        object_world_center_m=nominal_grip_center,
        candidate=candidate,
    )
    hand_rotation = np.asarray(geometry["rotation_world_from_hand"], dtype=np.float64)
    handbase = np.asarray(geometry["handbase_world_m"], dtype=np.float64)
    tcp_z_offset = float(candidate.get("tcp_z_offset_m", 0.0))
    handbase = handbase + np.asarray((0.0, 0.0, tcp_z_offset))
    geometry = dict(geometry)
    geometry["handbase_world_m"] = handbase.tolist()
    geometry["object_center_hand_m"] = (
        hand_rotation.T @ (nominal_grip_center - handbase)
    ).tolist()
    geometry["real_cad_tcp_z_offset_m"] = tcp_z_offset
    grasp_tcp_position = handbase + hand_rotation @ np.asarray((0.0, 0.0, 0.4))

    robot = config["robot"]
    fixed_q7 = float(robot["fixed_q7_rad"])
    grasp_joints, grasp_residual = _solve_waypoint(
        seed=robot["ik_seed_arm_rad"],
        target_position_m=grasp_tcp_position,
        target_rotation=hand_rotation,
        fixed_q7_rad=fixed_q7,
    )
    targets = [0.0] + [float(value) for value in config["motion"]["lift_targets_m"]]
    closure_start_offset = float(candidate.get("closure_start_offset_m", 0.0))
    offsets = sorted(
        set(
            targets
            + [
                closure_start_offset,
                float(config["motion"]["candidate_pregrasp_offset_m"]),
                float(config["motion"]["candidate_high_offset_m"]),
            ]
        )
    )
    solutions: dict[float, tuple[np.ndarray, dict[str, float]]] = {
        0.0: (grasp_joints, grasp_residual)
    }
    seed = grasp_joints
    for offset in offsets:
        if offset == 0.0:
            continue
        solution = _solve_waypoint(
            seed=seed,
            target_position_m=grasp_tcp_position + np.asarray((0.0, 0.0, offset)),
            target_rotation=hand_rotation,
            fixed_q7_rad=fixed_q7,
        )
        solutions[offset] = solution
        seed = solution[0]

    lower = _finite_vector(robot["arm_lower_limits_rad"], 7, "arm lower limits")
    upper = _finite_vector(robot["arm_upper_limits_rad"], 7, "arm upper limits")
    all_joints = np.stack([solutions[offset][0] for offset in offsets])
    margins = np.minimum(all_joints - lower[None, :], upper[None, :] - all_joints)
    if float(np.min(margins)) < 0.02:
        raise ValueError("full-iiwa IK family lacks 0.02 rad hard-limit margin")
    if max(
        max(record[1].values()) for record in solutions.values()
    ) > 1.0e-7:
        raise ValueError("full-iiwa IK residual exceeds 1e-7")

    fits = fit_g1_trace(paths["g1_trace"])
    dependency_evidence = {
        name: {"path": str(path.relative_to(repository)), "sha256": file_sha256(path)}
        for name, path in paths.items()
    }
    return {
        "schema": "D38999_FULL_IIWA_B_GOAL_MODE_PLAN_V1",
        "status": "STATIC_PASS",
        "mode": MODE,
        "claim_scope": CLAIM_SCOPE,
        "candidate_id": candidate["candidate_id"],
        "candidate_selection": (
            "FROZEN_DEFAULT"
            if candidate_id is None
            else (
                "REAL_CAD_COMPLETE_COLLISION_RESCREEN_TOP3"
                if real_cad_candidate is not None
                else "EXISTING_BOUNDED_12_POSE_OVERRIDE"
            )
        ),
        "dependencies": dependency_evidence,
        "scene": {
            "tabletop": tabletop.as_dict(),
            "nominal_loose_origin_m": nominal_loose_origin.tolist(),
            "authorized_grip_local_center_m": local_grip_center.tolist(),
            "nominal_authorized_grip_center_world_m": nominal_grip_center.tolist(),
            "authorized_grip_collider_path": tabletop.asset.nut_prim_path
            + "/CouplingNutGraspCollision",
            "moved_mass_kg": 0.310,
        },
        "candidate": candidate,
        "pad_capsules": capsules,
        "pad_contract": {
            "legacy_candidate_seed_primitive_count": len(capsules),
            "runtime_pad_collision_count": int(
                config["scene"]["expected_pad_collider_count"]
            ),
            "runtime_tip_collision_count": int(
                config["scene"]["expected_tip_collider_count"]
            ),
            "runtime_side_collision_count": int(
                config["scene"]["expected_side_collider_count"]
            ),
            "maximum_convex_hulls_per_terminal": int(
                config["scene"]["terminal_collision"][
                    "pad_maximum_convex_hulls"
                ]
                + config["scene"]["terminal_collision"][
                    "tip_maximum_convex_hulls"
                ]
                + config["scene"]["terminal_collision"][
                    "side_maximum_convex_hulls"
                ]
            ),
            "runtime_collision_route": config["scene"]["terminal_collision"][
                "route"
            ],
            "whole_terminal_convex_hull_count": int(
                pad_core["whole_terminal_convex_hull_count"]
            ),
            "formal_b_passed": False,
        },
        "geometry": geometry,
        "ik": {
            "target_tcp_rotation_world": hand_rotation.tolist(),
            "grasp_tcp_position_world_m": grasp_tcp_position.tolist(),
            "fixed_q7_rad": fixed_q7,
            "minimum_hard_joint_margin_rad": float(np.min(margins)),
            "solutions": {
                f"z_offset_{offset:.4f}_m": {
                    "offset_m": offset,
                    "arm_rad": solutions[offset][0].tolist(),
                    **solutions[offset][1],
                }
                for offset in offsets
            },
        },
        "root_torque_force_proxy": serialize_fits(fits),
        "truth_boundary": {
            "online_object_pose_control": False,
            "online_contact_truth_control": False,
            "object_pose_write_after_physics_count": 0,
            "physx_contact_role": "POST_STEP_DIAGNOSTIC_ONLY",
            "raw_generalized_velocity_0p03_rad_s_role": "SLIP_MONITOR_ONLY",
            "force_quiet_hold_acceptance": "POSITION_AND_FINITE_DIFFERENCE_VELOCITY",
        },
        "formal_b_passed": False,
    }


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(plan, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


__all__ = [
    "CLAIM_SCOPE",
    "DEFAULT_CONFIG",
    "MODE",
    "SCHEMA_VERSION",
    "advance_closure_target",
    "build_full_iiwa_plan",
    "compute_proprioceptive_load_transfer_compensation",
    "file_sha256",
    "load_full_iiwa_config",
    "map_force_controller_targets",
    "write_plan",
]
