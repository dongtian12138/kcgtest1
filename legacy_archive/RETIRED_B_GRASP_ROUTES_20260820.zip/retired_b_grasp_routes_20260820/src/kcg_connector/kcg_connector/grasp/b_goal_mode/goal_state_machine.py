#!/usr/bin/env python3
"""Evidence-gated progression for B_GOAL_MODE."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence


GATE_ORDER = (
    "G0_LIFT_AXIS_TRACKING",
    "G1_CONTACT_WRENCH_MEASUREMENT",
    "G2_INDEPENDENT_CONTACT_ACQUISITION",
    "G3_TASK_FORCE_CLOSURE",
    "G4_BUMPLESS_COMPLIANT_FORCE_CONTROL",
    "G5_UNSUPPORTED_HOLD",
    "G6_REAL_LIFT",
    "G7_THREE_PROCESS_VALIDATION",
)


def _write_json_atomic(path: Path, payload: Mapping[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def advance_gate(
    *, state_path: Path, completed_gate: str, result_path: Path
) -> dict[str, Any]:
    if completed_gate not in GATE_ORDER:
        raise ValueError(f"unknown B_GOAL_MODE gate: {completed_gate}")
    state = json.loads(state_path.read_text(encoding="utf-8"))
    result = json.loads(result_path.read_text(encoding="utf-8"))
    if state.get("current_goal_gate") != completed_gate:
        raise ValueError(
            f"cannot complete {completed_gate}; current gate is "
            f"{state.get('current_goal_gate')}"
        )
    if result.get("status") != "PASS" or result.get("goal_id") != completed_gate:
        raise ValueError(
            f"result does not pass {completed_gate}: "
            f"status={result.get('status')} goal_id={result.get('goal_id')}"
        )
    index = GATE_ORDER.index(completed_gate)
    next_gate = GATE_ORDER[index + 1] if index + 1 < len(GATE_ORDER) else None
    state["completed_gates"] = [
        gate
        for gate in GATE_ORDER
        if gate in set(state.get("completed_gates", ())) | {completed_gate}
    ]
    state["best_result"] = f"{completed_gate}:PASS:{result_path.resolve()}"
    if next_gate is None:
        state["current_goal_gate"] = completed_gate
        state["status"] = "B_GOAL_MODE_DYNAMIC_PASS"
        state["next_recommended_action"] = "停止B阶段实验并保存正式结果。"
    else:
        state["current_goal_gate"] = next_gate
        state["status"] = "READY"
        state["next_recommended_action"] = f"执行并验证 {next_gate}。"
    _write_json_atomic(state_path, state)
    return state


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True)
    parser.add_argument("--completed-gate", required=True)
    parser.add_argument("--result", required=True)
    arguments = parser.parse_args(argv)
    state = advance_gate(
        state_path=Path(arguments.state).resolve(),
        completed_gate=arguments.completed_gate,
        result_path=Path(arguments.result).resolve(),
    )
    print(json.dumps(state, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
