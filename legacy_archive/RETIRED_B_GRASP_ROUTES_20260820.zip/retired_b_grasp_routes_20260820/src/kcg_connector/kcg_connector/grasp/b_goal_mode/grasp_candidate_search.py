"""Validated seed candidates and bounded goal-mode grasp search.

The three R2 candidates are accepted only as immutable seed geometry.  This
module owns no R2 controller behavior and later expands the seed variables for
the bounded G7 search.  The search keeps the audited three analytic PAD-core
capsules and the 303-sample collision sweep, but varies preshape, connector
depth, grasp height, first-contact locations, and small wrist roll/pitch.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from kcg_connector.grasp import d38999_b_minimal_v2 as diagnostic_geometry
from kcg_connector.grasp.b_goal_mode.task_force_closure import (
    build_friction_pyramid,
    circular_contact_metrics,
    evaluate_task_suite,
    radial_alignment_metrics,
    signed_basis_force_closure,
)


ACTIVE_PAD_LINKS = ("f1Link3", "f2Link2", "f3Link3")
ROOT_TORQUE_JOINTS = ("f1j2", "f2j1", "f3j2")
BOUNDED_CANDIDATE_SCHEMA = "D38999_B_GOAL_MODE_BOUNDED_CANDIDATES_V1"
ACCEPTED_CANDIDATE_SCHEMAS = (
    "D38999_B_MINIMAL_V2_CANDIDATES",
    BOUNDED_CANDIDATE_SCHEMA,
)


@dataclass(frozen=True)
class AnalyticContact:
    link_name: str
    capsule_axis_point_world_m: np.ndarray
    object_contact_point_world_m: np.ndarray
    contact_normal_world: np.ndarray
    capsule_axis_fraction: float
    signed_gap_m: float


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rpy_matrix(rpy: Sequence[float]) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.asarray(
        (
            (cp * cy, sr * sp * cy - cr * sy, cr * sp * cy + sr * sy),
            (cp * sy, sr * sp * sy + cr * cy, cr * sp * sy - sr * cy),
            (-sp, sr * cp, cr * cp),
        ),
        dtype=np.float64,
    )


def load_seed_geometry(
    *, candidates_path: Path, pad_core_path: Path, source_urdf: Path
) -> tuple[dict[str, Any], dict[str, Any]]:
    candidates = json.loads(candidates_path.read_text(encoding="utf-8"))
    pad_core = json.loads(pad_core_path.read_text(encoding="utf-8"))
    if candidates.get("schema") not in ACCEPTED_CANDIDATE_SCHEMAS:
        raise ValueError("unexpected diagnostic seed candidate schema")
    if pad_core.get("schema") != "D38999_B_MINIMAL_V2_PAD_CORE_V1":
        raise ValueError("unexpected PAD core schema")
    if candidates.get("diagnostic_pad_core_dynamic_use_allowed") is not True:
        raise ValueError("diagnostic seed geometry is not authorized")
    if candidates.get("formal_b_pass_claimed") is not False:
        raise ValueError("seed geometry cannot claim formal B pass")
    if pad_core.get("diagnostic_dynamic_use_allowed") is not True:
        raise ValueError("PAD core diagnostic dynamic use is not authorized")
    if pad_core.get("formal_b_use_allowed") is not False:
        raise ValueError("PAD core must remain diagnostic-only")
    if pad_core.get("whole_terminal_convex_hull_count") != 0:
        raise ValueError("old whole-terminal convex hull is forbidden")
    if pad_core.get("tip_collision_count") != 0:
        raise ValueError("G1 diagnostic must not enable TIP collision")
    if pad_core.get("pad_primitive_count_total") != 3:
        raise ValueError("G1 expects one central PAD capsule per finger")
    if file_sha256(source_urdf) != candidates.get("source_urdf_sha256"):
        raise ValueError("source hand URDF differs from candidate evidence")
    if file_sha256(pad_core_path) != candidates.get("source_proxy_manifest_sha256"):
        raise ValueError("PAD core differs from candidate evidence")
    return candidates, pad_core


def select_candidate(bundle: Mapping[str, Any], candidate_id: str) -> dict[str, Any]:
    matches = [
        row for row in bundle.get("candidates", ()) if row.get("candidate_id") == candidate_id
    ]
    if len(matches) != 1:
        raise ValueError(f"seed candidate missing or duplicated: {candidate_id}")
    return dict(matches[0])


def selected_pad_capsules(pad_core: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    links = {str(row["link_name"]): row for row in pad_core["links"]}
    selected: dict[str, dict[str, Any]] = {}
    for link_name in ACTIVE_PAD_LINKS:
        entry = links.get(link_name)
        capsules = None if entry is None else entry.get("capsules")
        if entry is None or not isinstance(capsules, list) or len(capsules) != 1:
            raise ValueError(f"expected one PAD core capsule for {link_name}")
        selected[link_name] = dict(capsules[0])
    return selected


def candidate_world_geometry(
    *,
    hand_mount_rpy_rad: Sequence[float],
    object_world_center_m: Sequence[float],
    candidate: Mapping[str, Any],
) -> dict[str, Any]:
    base_rpy = np.asarray(hand_mount_rpy_rad, dtype=np.float64)
    candidate_offset = np.asarray(
        candidate.get("wrist_rpy_offset_rad", (0.0, 0.0, 0.0)),
        dtype=np.float64,
    )
    if base_rpy.shape != (3,) or candidate_offset.shape != (3,):
        raise ValueError("hand mount and candidate wrist offsets must be three-vectors")
    effective_rpy = base_rpy + candidate_offset
    rotation = rpy_matrix(effective_rpy)
    object_world = np.asarray(object_world_center_m, dtype=np.float64)
    object_hand = np.asarray(
        (
            candidate["object_axis_center_xy_hand_m"][0],
            candidate["object_axis_center_xy_hand_m"][1],
            candidate["object_center_z_hand_m"],
        ),
        dtype=np.float64,
    )
    handbase_world = object_world - rotation @ object_hand
    world_up_in_joint = rotation.T @ np.asarray((0.0, 0.0, 1.0), dtype=np.float64)
    world_up_in_joint /= np.linalg.norm(world_up_in_joint)
    return {
        "rotation_world_from_hand": rotation.tolist(),
        "base_hand_mount_rpy_rad": base_rpy.tolist(),
        "candidate_wrist_rpy_offset_rad": candidate_offset.tolist(),
        "hand_mount_rpy_rad": effective_rpy.tolist(),
        "handbase_world_m": handbase_world.tolist(),
        "lift_axis_in_joint_frame": world_up_in_joint.tolist(),
        "object_world_center_m": object_world.tolist(),
        "object_center_hand_m": object_hand.tolist(),
    }


def _cached_hand_model(
    source_urdf: Path,
) -> tuple[dict[str, Any], dict[str, str], dict[str, str], dict[str, tuple[float, float]]]:
    # This is read-only FK math from the retired diagnostic generator.  No old
    # candidate, controller, or dynamic result is reused.
    return diagnostic_geometry._load_urdf(source_urdf)


def _hand_link_transforms(
    *,
    model: tuple[
        dict[str, Any],
        dict[str, str],
        dict[str, str],
        dict[str, tuple[float, float]],
    ],
    preshape_rad: float,
    flexion_rad: Sequence[float],
) -> dict[str, np.ndarray]:
    joints, parents, children, _limits = model
    flexion = np.asarray(flexion_rad, dtype=np.float64)
    values = {
        "f1j1": float(preshape_rad),
        "f1j2": float(flexion[0]),
        "f1j3": float(flexion[0]),
        "f2j1": float(flexion[1]),
        "f2j2": float(flexion[1]),
        "f3j1": float(preshape_rad),
        "f3j2": float(flexion[2]),
        "f3j3": float(flexion[2]),
    }
    transforms: dict[str, np.ndarray] = {"handbase_link": np.eye(4, dtype=np.float64)}
    for name in diagnostic_geometry.HAND_JOINT_ORDER:
        transforms[children[name]] = transforms[parents[name]] @ diagnostic_geometry._joint_transform(
            joints[name], values[name]
        )
    return transforms


def _capsules_in_hand(
    *,
    model: tuple[
        dict[str, Any],
        dict[str, str],
        dict[str, str],
        dict[str, tuple[float, float]],
    ],
    pad_capsules: Mapping[str, Mapping[str, Any]],
    preshape_rad: float,
    flexion_rad: Sequence[float],
) -> list[dict[str, Any]]:
    transforms = _hand_link_transforms(
        model=model,
        preshape_rad=preshape_rad,
        flexion_rad=flexion_rad,
    )
    result: list[dict[str, Any]] = []
    for link_name in ACTIVE_PAD_LINKS:
        capsule = pad_capsules[link_name]
        transform = transforms[link_name]
        center_local = np.asarray(capsule["center_local_m"], dtype=np.float64)
        axis_local = np.asarray(capsule["axis_unit_local"], dtype=np.float64)
        center = transform[:3, :3] @ center_local + transform[:3, 3]
        axis = transform[:3, :3] @ axis_local
        axis /= np.linalg.norm(axis)
        half_length = 0.5 * float(capsule["cylinder_height_m"])
        result.append(
            {
                "link_name": link_name,
                "center_hand_m": center,
                "endpoint_a_hand_m": center - half_length * axis,
                "endpoint_b_hand_m": center + half_length * axis,
                "radius_m": float(capsule["radius_m"]),
            }
        )
    return result


def _analytic_contacts(
    *,
    model: tuple[
        dict[str, Any],
        dict[str, str],
        dict[str, str],
        dict[str, tuple[float, float]],
    ],
    pad_capsules: Mapping[str, Mapping[str, Any]],
    base_hand_mount_rpy_rad: Sequence[float],
    object_world_center_m: Sequence[float],
    object_radius_m: float,
    grasp_local_z_mm: float,
    preshape_rad: float,
    flexion_rad: Sequence[float],
    object_axis_center_xy_hand_m: Sequence[float],
    wrist_roll_pitch_offset_rad: Sequence[float],
) -> tuple[list[AnalyticContact], np.ndarray, float, list[dict[str, Any]]]:
    capsules = _capsules_in_hand(
        model=model,
        pad_capsules=pad_capsules,
        preshape_rad=preshape_rad,
        flexion_rad=flexion_rad,
    )
    base_rpy = np.asarray(base_hand_mount_rpy_rad, dtype=np.float64)
    offsets = np.asarray(wrist_roll_pitch_offset_rad, dtype=np.float64)
    effective_rpy = base_rpy + np.asarray((offsets[0], offsets[1], 0.0))
    rotation = rpy_matrix(effective_rpy)
    object_world = np.asarray(object_world_center_m, dtype=np.float64)
    axis_xy = np.asarray(object_axis_center_xy_hand_m, dtype=np.float64)
    mean_center_z = float(np.mean([row["center_hand_m"][2] for row in capsules]))
    object_center_z_hand = mean_center_z - (float(grasp_local_z_mm) - 19.0) / 1000.0
    object_hand = np.asarray((axis_xy[0], axis_xy[1], object_center_z_hand))
    handbase_world = object_world - rotation @ object_hand
    contacts: list[AnalyticContact] = []
    for row in capsules:
        endpoint_a = handbase_world + rotation @ row["endpoint_a_hand_m"]
        endpoint_b = handbase_world + rotation @ row["endpoint_b_hand_m"]
        segment = endpoint_b - endpoint_a
        projected_norm_sq = float(segment[:2] @ segment[:2])
        if projected_norm_sq <= 1.0e-15:
            fraction = 0.5
        else:
            fraction = float(
                np.clip(
                    -float(
                        (endpoint_a[:2] - object_world[:2]) @ segment[:2]
                    )
                    / projected_norm_sq,
                    0.0,
                    1.0,
                )
            )
        axis_point = endpoint_a + fraction * segment
        radial = axis_point[:2] - object_world[:2]
        radial_distance = float(np.linalg.norm(radial))
        if radial_distance <= 1.0e-12:
            raise ValueError("capsule axis intersects connector axis")
        outward = radial / radial_distance
        contact_point = np.asarray(
            (
                object_world[0] + float(object_radius_m) * outward[0],
                object_world[1] + float(object_radius_m) * outward[1],
                axis_point[2],
            ),
            dtype=np.float64,
        )
        contacts.append(
            AnalyticContact(
                link_name=str(row["link_name"]),
                capsule_axis_point_world_m=axis_point,
                object_contact_point_world_m=contact_point,
                contact_normal_world=np.asarray((-outward[0], -outward[1], 0.0)),
                capsule_axis_fraction=fraction,
                signed_gap_m=(
                    radial_distance
                    - float(object_radius_m)
                    - float(row["radius_m"])
                ),
            )
        )
    return contacts, effective_rpy, object_center_z_hand, capsules


def _solve_candidate_pose(
    *,
    source_urdf: Path,
    pad_capsules: Mapping[str, Mapping[str, Any]],
    base_hand_mount_rpy_rad: Sequence[float],
    object_world_center_m: Sequence[float],
    object_radius_m: float,
    target_preload_m: float,
    preshape_rad: float,
    grasp_local_z_mm: float,
    maximum_wrist_offset_rad: float,
) -> tuple[dict[str, Any], tuple[Any, ...]]:
    try:
        from scipy.optimize import least_squares
    except Exception as exc:  # pragma: no cover - environment dependent
        raise RuntimeError("SciPy is required for bounded candidate generation") from exc

    model = _cached_hand_model(source_urdf)
    limits = model[3]
    for joint_name in ("f1j1", "f3j1"):
        lower, upper = limits[joint_name]
        if not lower < preshape_rad < upper:
            raise ValueError(f"preshape is outside {joint_name} limits")

    representative_radius = float(next(iter(pad_capsules.values()))["radius_m"])
    target_center_radius = object_radius_m + representative_radius - target_preload_m

    def center_residual(vector: np.ndarray) -> np.ndarray:
        flexion = vector[:3]
        axis_xy = vector[3:5]
        capsules = _capsules_in_hand(
            model=model,
            pad_capsules=pad_capsules,
            preshape_rad=preshape_rad,
            flexion_rad=flexion,
        )
        return np.asarray(
            [
                (
                    np.linalg.norm(axis_xy - row["center_hand_m"][:2])
                    - target_center_radius
                )
                / 0.0002
                for row in capsules
            ],
            dtype=np.float64,
        )

    lower_flexion = [limits[name][0] for name in ROOT_TORQUE_JOINTS]
    upper_flexion = [limits[name][1] for name in ROOT_TORQUE_JOINTS]
    center_solution = least_squares(
        center_residual,
        np.asarray((0.75, 0.65, 0.75, -0.009, 0.005)),
        bounds=(
            np.asarray((*lower_flexion, -0.03, -0.03)),
            np.asarray((*upper_flexion, 0.03, 0.03)),
        ),
        max_nfev=3000,
        xtol=1.0e-13,
        ftol=1.0e-13,
        gtol=1.0e-13,
    )

    def contact_residual(vector: np.ndarray) -> np.ndarray:
        contacts, _rpy, _center_z, _capsules = _analytic_contacts(
            model=model,
            pad_capsules=pad_capsules,
            base_hand_mount_rpy_rad=base_hand_mount_rpy_rad,
            object_world_center_m=object_world_center_m,
            object_radius_m=object_radius_m,
            grasp_local_z_mm=grasp_local_z_mm,
            preshape_rad=preshape_rad,
            flexion_rad=vector[:3],
            object_axis_center_xy_hand_m=vector[3:5],
            wrist_roll_pitch_offset_rad=vector[5:7],
        )
        heights = np.asarray(
            [row.capsule_axis_point_world_m[2] for row in contacts],
            dtype=np.float64,
        )
        return np.concatenate(
            (
                (
                    np.asarray([row.signed_gap_m for row in contacts])
                    + target_preload_m
                )
                / 0.0001,
                (heights - float(np.mean(heights))) / 0.001,
                np.asarray(
                    [(row.capsule_axis_fraction - 0.5) / 2.0 for row in contacts]
                ),
                vector[5:7] / 0.20,
            )
        )

    lower = np.asarray(
        (
            *lower_flexion,
            -0.03,
            -0.03,
            -maximum_wrist_offset_rad,
            -maximum_wrist_offset_rad,
        )
    )
    upper = np.asarray(
        (
            *upper_flexion,
            0.03,
            0.03,
            maximum_wrist_offset_rad,
            maximum_wrist_offset_rad,
        )
    )
    solution = least_squares(
        contact_residual,
        np.concatenate((center_solution.x, np.zeros(2))),
        bounds=(lower, upper),
        max_nfev=3000,
        xtol=1.0e-13,
        ftol=1.0e-13,
        gtol=1.0e-13,
    )
    contacts, effective_rpy, object_center_z_hand, capsules = _analytic_contacts(
        model=model,
        pad_capsules=pad_capsules,
        base_hand_mount_rpy_rad=base_hand_mount_rpy_rad,
        object_world_center_m=object_world_center_m,
        object_radius_m=object_radius_m,
        grasp_local_z_mm=grasp_local_z_mm,
        preshape_rad=preshape_rad,
        flexion_rad=solution.x[:3],
        object_axis_center_xy_hand_m=solution.x[3:5],
        wrist_roll_pitch_offset_rad=solution.x[5:7],
    )
    margins = [
        min(float(value) - limits[name][0], limits[name][1] - float(value))
        for name, value in zip(ROOT_TORQUE_JOINTS, solution.x[:3])
    ]
    for name in ("f1j1", "f3j1"):
        margins.append(
            min(preshape_rad - limits[name][0], limits[name][1] - preshape_rad)
        )
    return (
        {
            "solver_success": bool(solution.success),
            "solver_message": str(solution.message),
            "optimization_residual_norm": float(np.linalg.norm(solution.fun)),
            "preshape_rad": float(preshape_rad),
            "finger_flexion_targets_rad": solution.x[:3].tolist(),
            "object_axis_center_xy_hand_m": solution.x[3:5].tolist(),
            "wrist_rpy_offset_rad": [
                float(solution.x[5]),
                float(solution.x[6]),
                0.0,
            ],
            "effective_hand_mount_rpy_rad": effective_rpy.tolist(),
            "object_center_z_hand_m": float(object_center_z_hand),
            "minimum_joint_margin_rad": float(min(margins)),
            "contacts": contacts,
            "capsules": capsules,
        },
        model,
    )


def _evaluate_scene_capsules(
    capsules: Sequence[Any],
    *,
    object_center_m: Sequence[float],
    object_radius_m: float,
    object_height_m: float,
    table_top_z_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    object_gaps = np.asarray(
        [
            diagnostic_geometry.capsule_cylinder_gap_m(
                capsule,
                object_center_m=object_center_m,
                object_radius_m=object_radius_m,
                object_height_m=object_height_m,
            )
            for capsule in capsules
        ]
    )
    table_gaps = np.asarray(
        [
            diagnostic_geometry.capsule_table_gap_m(
                capsule, table_top_z_m=table_top_z_m
            )
            for capsule in capsules
        ]
    )
    pair_gaps = np.asarray(
        [
            diagnostic_geometry.capsule_capsule_gap_m(capsules[first], capsules[second])
            for first in range(len(capsules))
            for second in range(first + 1, len(capsules))
        ]
    )
    return object_gaps, table_gaps, pair_gaps


def _bounded_static_sweep(
    *,
    source_urdf: Path,
    pad_core_path: Path,
    pose: Mapping[str, Any],
    base_hand_mount_rpy_rad: Sequence[float],
    grasp_local_z_mm: float,
    preclose_fraction: float,
    samples_per_phase: int,
    object_radius_m: float,
    object_height_m: float,
    table_top_z_m: float,
    minimum_table_clearance_m: float,
    minimum_precontact_object_clearance_m: float,
    maximum_final_penetration_m: float,
    minimum_interfinger_clearance_m: float,
) -> tuple[dict[str, Any], dict[str, Any]]:
    manifest = diagnostic_geometry._load_proxy_manifest(pad_core_path)
    selected = diagnostic_geometry.selected_central_capsules(manifest)
    closed_preshape = float(pose["preshape_rad"])
    closed_flexion = np.asarray(pose["finger_flexion_targets_rad"])
    axis_xy = np.asarray(pose["object_axis_center_xy_hand_m"])
    object_center_z_hand = float(pose["object_center_z_hand_m"])
    effective_rpy = np.asarray(base_hand_mount_rpy_rad) + np.asarray(
        pose["wrist_rpy_offset_rad"]
    )
    table_object_center = np.asarray(
        (0.0, 0.0, table_top_z_m + 0.5 * object_height_m), dtype=np.float64
    )

    def posed_capsules(pose_fraction: float, lift_m: float) -> list[Any]:
        return diagnostic_geometry._pose_capsules(
            urdf_path=source_urdf,
            selected=selected,
            preshape_rad=diagnostic_geometry._interpolate(
                diagnostic_geometry.DEFAULT_OPEN_PRESHAPE_RAD,
                closed_preshape,
                pose_fraction,
            ),
            flexion_rad=[
                diagnostic_geometry._interpolate(
                    diagnostic_geometry.DEFAULT_OPEN_FLEXION_RAD,
                    value,
                    pose_fraction,
                )
                for value in closed_flexion
            ],
            axis_xy_hand_m=axis_xy,
            object_center_z_hand_m=object_center_z_hand,
            lift_m=lift_m,
            hand_mount_rpy_rad=effective_rpy,
            object_world_center_m=table_object_center,
        )

    zero_lift_table_minimum = float("inf")
    for fraction in np.linspace(0.0, preclose_fraction, samples_per_phase):
        _object, table, _pairs = _evaluate_scene_capsules(
            posed_capsules(float(fraction), 0.0),
            object_center_m=table_object_center,
            object_radius_m=object_radius_m,
            object_height_m=object_height_m,
            table_top_z_m=table_top_z_m,
        )
        zero_lift_table_minimum = min(
            zero_lift_table_minimum, float(np.min(table))
        )
    approach_lift = max(
        0.0, minimum_table_clearance_m - zero_lift_table_minimum
    )

    minimum_table = float("inf")
    minimum_precontact_object = float("inf")
    minimum_pair = float("inf")
    maximum_final_penetration = 0.0
    final_object_gaps = np.full(3, np.inf)
    rows: list[dict[str, Any]] = []
    phases = (
        (
            "RAISED_PRECLOSE",
            lambda fraction: preclose_fraction * fraction,
            lambda _fraction: approach_lift,
        ),
        (
            "DESCEND",
            lambda _fraction: preclose_fraction,
            lambda fraction: approach_lift * (1.0 - fraction),
        ),
        (
            "FINAL_CLOSE",
            lambda fraction: diagnostic_geometry._interpolate(
                preclose_fraction, 1.0, fraction
            ),
            lambda _fraction: 0.0,
        ),
    )
    for phase, pose_function, lift_function in phases:
        for phase_fraction in np.linspace(0.0, 1.0, samples_per_phase):
            pose_fraction = float(pose_function(float(phase_fraction)))
            lift_m = float(lift_function(float(phase_fraction)))
            object_gaps, table_gaps, pair_gaps = _evaluate_scene_capsules(
                posed_capsules(pose_fraction, lift_m),
                object_center_m=table_object_center,
                object_radius_m=object_radius_m,
                object_height_m=object_height_m,
                table_top_z_m=table_top_z_m,
            )
            minimum_table = min(minimum_table, float(np.min(table_gaps)))
            minimum_pair = min(minimum_pair, float(np.min(pair_gaps)))
            if phase == "FINAL_CLOSE":
                maximum_final_penetration = max(
                    maximum_final_penetration,
                    max(0.0, -float(np.min(object_gaps))),
                )
                final_object_gaps = object_gaps
            else:
                minimum_precontact_object = min(
                    minimum_precontact_object, float(np.min(object_gaps))
                )
            rows.append(
                {
                    "phase": phase,
                    "phase_fraction": float(phase_fraction),
                    "pose_fraction": pose_fraction,
                    "lift_m": lift_m,
                    "minimum_object_gap_m": float(np.min(object_gaps)),
                    "minimum_table_gap_m": float(np.min(table_gaps)),
                    "minimum_interfinger_gap_m": float(np.min(pair_gaps)),
                }
            )
    metrics = {
        "minimum_table_clearance_m": minimum_table,
        "minimum_precontact_object_clearance_m": minimum_precontact_object,
        "maximum_final_object_penetration_m": maximum_final_penetration,
        "minimum_interfinger_clearance_m": minimum_pair,
        "closed_object_gaps_m": final_object_gaps.tolist(),
        "approach_lift_m": approach_lift,
        "preclose_fraction": preclose_fraction,
        "sample_count": len(rows),
    }
    checks = {
        "table_sweep_clearance": minimum_table
        >= minimum_table_clearance_m - 1.0e-12,
        "precontact_object_clearance": minimum_precontact_object
        >= minimum_precontact_object_clearance_m - 1.0e-12,
        "final_penetration": maximum_final_penetration
        <= maximum_final_penetration_m + 1.0e-12,
        "all_three_final_contacts": all(
            -maximum_final_penetration_m <= gap <= 0.0002
            for gap in final_object_gaps
        ),
        "interfinger_clearance": minimum_pair
        >= minimum_interfinger_clearance_m,
        "approach_lift_within_joint_range": approach_lift <= 0.020,
        "sample_count_303": len(rows) == 303,
    }
    return metrics, {"checks": checks, "samples": rows}


def _task_wrenches(config: Mapping[str, Any]) -> dict[str, list[float]]:
    task = config["g3_task_force_closure"]
    mass = float(config["grasp_geometry"]["object_mass_kg"])
    gravity = float(config["simulation"]["gravity_m_s2"])
    weight = mass * gravity
    lift_load = mass * (gravity + float(task["lift_acceleration_m_s2"]))
    axial = float(task["downstream_axial_force_n"])
    lateral = float(task["lateral_disturbance_n"])
    tilt = float(task["finite_tilt_moment_nm"])
    torsion = float(task["finite_torsion_moment_nm"])
    result = {
        "gravity": [0.0, 0.0, -weight, 0.0, 0.0, 0.0],
        "b_lift_acceleration": [0.0, 0.0, -lift_load, 0.0, 0.0, 0.0],
        "downstream_axial_compression": [
            0.0,
            0.0,
            -(weight + axial),
            0.0,
            0.0,
            0.0,
        ],
        "downstream_axial_pull": [0.0, 0.0, axial - weight, 0.0, 0.0, 0.0],
    }
    for axis, label in ((0, "x"), (1, "y")):
        for sign, suffix in ((-1.0, "negative"), (1.0, "positive")):
            wrench = [0.0, 0.0, -weight, 0.0, 0.0, 0.0]
            wrench[axis] = sign * lateral
            result[f"lateral_{label}_{suffix}"] = wrench
            wrench = [0.0, 0.0, -weight, 0.0, 0.0, 0.0]
            wrench[3 + axis] = sign * tilt
            result[f"tilt_{label}_{suffix}"] = wrench
    for sign, suffix in ((-1.0, "negative"), (1.0, "positive")):
        result[f"torsion_z_{suffix}"] = [
            0.0,
            0.0,
            -weight,
            0.0,
            0.0,
            sign * torsion,
        ]
    return result


def build_bounded_candidate_bundle(
    *,
    config: Mapping[str, Any],
    source_urdf: Path,
    seed_candidates_path: Path,
    pad_core_path: Path,
) -> dict[str, Any]:
    search = config["g7_candidate_search"]
    preshapes = [float(value) for value in search["preshape_values_rad"]]
    grasp_z_values = [float(value) for value in search["grasp_z_values_mm"]]
    if len(preshapes) * len(grasp_z_values) > int(search["maximum_candidates"]):
        raise ValueError("bounded candidate grid exceeds maximum_candidates")
    if int(search["samples_per_phase"]) != 101:
        raise ValueError("the frozen sweep must remain 101 samples x 3 phases")
    if any(not 9.0 <= value <= 29.0 for value in grasp_z_values):
        raise ValueError("grasp z is outside the authorized 9..29 mm band")
    seed_bundle, pad_core = load_seed_geometry(
        candidates_path=seed_candidates_path,
        pad_core_path=pad_core_path,
        source_urdf=source_urdf,
    )
    pad_capsules = selected_pad_capsules(pad_core)
    geometry = config["grasp_geometry"]
    object_world_center = geometry["object_offtable_world_center_m"]
    object_radius = float(geometry["object_radius_m"])
    object_height = float(geometry["object_height_m"])
    coefficient = float(geometry["pad_object_friction"])
    base_rpy = geometry["hand_mount_rpy_rad"]
    task_config = config["g3_task_force_closure"]
    task_wrenches = _task_wrenches(config)
    candidates: list[dict[str, Any]] = []
    sweep_evidence: dict[str, Any] = {}
    for preshape in preshapes:
        for grasp_z in grasp_z_values:
            candidate_id = f"BG_P{int(round(preshape * 100)):03d}_Z{int(round(grasp_z)):02d}"
            pose, _model = _solve_candidate_pose(
                source_urdf=source_urdf,
                pad_capsules=pad_capsules,
                base_hand_mount_rpy_rad=base_rpy,
                object_world_center_m=object_world_center,
                object_radius_m=object_radius,
                target_preload_m=float(search["target_preload_m"]),
                preshape_rad=preshape,
                grasp_local_z_mm=grasp_z,
                maximum_wrist_offset_rad=float(search["maximum_wrist_offset_rad"]),
            )
            sweep_metrics, sweep = _bounded_static_sweep(
                source_urdf=source_urdf,
                pad_core_path=pad_core_path,
                pose=pose,
                base_hand_mount_rpy_rad=base_rpy,
                grasp_local_z_mm=grasp_z,
                preclose_fraction=float(search["preclose_fraction"]),
                samples_per_phase=int(search["samples_per_phase"]),
                object_radius_m=object_radius,
                object_height_m=object_height,
                table_top_z_m=float(search["table_top_z_m"]),
                minimum_table_clearance_m=float(
                    search["minimum_table_clearance_m"]
                ),
                minimum_precontact_object_clearance_m=float(
                    search["minimum_precontact_object_clearance_m"]
                ),
                maximum_final_penetration_m=float(
                    search["maximum_final_penetration_m"]
                ),
                minimum_interfinger_clearance_m=float(
                    search["minimum_interfinger_clearance_m"]
                ),
            )
            contacts: list[AnalyticContact] = pose["contacts"]
            points = [row.object_contact_point_world_m.tolist() for row in contacts]
            normals = [row.contact_normal_world.tolist() for row in contacts]
            pyramid = build_friction_pyramid(
                contact_points_m=points,
                contact_normals=normals,
                center_of_mass_m=object_world_center,
                friction_coefficient=coefficient,
                edges_per_contact=int(task_config["friction_cone_edges"]),
            )
            circular = circular_contact_metrics(points, object_world_center)
            radial = radial_alignment_metrics(
                contact_points_m=points,
                contact_normals=normals,
                connector_axis_center_xy_m=object_world_center[:2],
            )
            force_closure = signed_basis_force_closure(
                pyramid,
                characteristic_length_m=object_radius,
                normal_force_cap_n_per_finger=float(
                    task_config["maximum_task_evaluation_cap_n"]
                ),
            )
            task_results = evaluate_task_suite(
                pyramid,
                task_wrenches=task_wrenches,
                normal_force_caps_n=task_config["normal_force_caps_n_per_finger"],
            )
            maximum_required = max(
                float(result["minimum_peak_normal_force"]["minimum_peak_normal_force_n"])
                for result in task_results.values()
                if result["minimum_peak_normal_force"]["solver_success"]
            )
            maximum_cap_key = f"{float(task_config['maximum_task_evaluation_cap_n']):g}N"
            other_tasks = [
                name
                for name in task_results
                if name not in {"gravity", "b_lift_acceleration"}
            ]
            minimum_other_sf = min(
                float(
                    task_results[name]["safety_factor_by_normal_cap"][maximum_cap_key][
                        "maximum_scale"
                    ]
                )
                for name in other_tasks
            )
            gravity_key = f"{float(task_config['gravity_safety_evaluation_cap_n']):g}N"
            lift_key = f"{float(task_config['lift_safety_evaluation_cap_n']):g}N"
            gravity_sf = float(
                task_results["gravity"]["safety_factor_by_normal_cap"][gravity_key][
                    "maximum_scale"
                ]
            )
            lift_sf = float(
                task_results["b_lift_acceleration"]["safety_factor_by_normal_cap"][
                    lift_key
                ]["maximum_scale"]
            )
            axis_fractions = [row.capsule_axis_fraction for row in contacts]
            contact_heights = [row.object_contact_point_world_m[2] for row in contacts]
            gates = {
                **sweep["checks"],
                "solver_success": bool(pose["solver_success"]),
                "three_pad_contacts": len(contacts) == 3,
                "contact_on_pad_middle": all(
                    float(search["minimum_contact_axis_fraction"])
                    <= fraction
                    <= float(search["maximum_contact_axis_fraction"])
                    for fraction in axis_fractions
                ),
                "joint_margin": float(pose["minimum_joint_margin_rad"])
                >= float(search["minimum_joint_margin_rad"]),
                "circular_distribution": circular["maximum_gap_deg"]
                < float(search["maximum_circular_gap_deg"]),
                "radial_contact_normal": radial["minimum_radial_alignment"]
                >= float(search["minimum_radial_alignment"]),
                "task_force_closure": bool(force_closure["force_closure"]),
                "gravity_safety_factor": gravity_sf
                >= float(task_config["minimum_gravity_safety_factor"]),
                "lift_safety_factor": lift_sf
                >= float(task_config["minimum_lift_safety_factor"]),
                "bounded_other_tasks": minimum_other_sf
                >= float(task_config["minimum_other_task_safety_factor"]),
                "predicted_single_finger_force": maximum_required
                <= float(search["maximum_predicted_single_finger_force_n"]),
                "wrist_offset_bounded": max(
                    abs(float(value)) for value in pose["wrist_rpy_offset_rad"][:2]
                )
                <= float(search["maximum_wrist_offset_rad"]) + 1.0e-12,
                "authorized_grasp_band": 9.0 <= grasp_z <= 29.0,
                "vision_and_insertion_compatible": bool(
                    search["vision_and_insertion_compatible"]
                ),
            }
            score = (
                40.0 * minimum_other_sf
                + 4.0 * gravity_sf
                + float(force_closure["minimum_normalized_signed_basis_scale"])
                - 4.0 * maximum_required
                - 0.03 * float(circular["maximum_gap_deg"])
                + 3.0 * float(pose["minimum_joint_margin_rad"])
                - 0.02
                * sum(
                    abs(math.degrees(float(value)))
                    for value in pose["wrist_rpy_offset_rad"][:2]
                )
                - 0.02 * abs(grasp_z - 15.0)
            )
            preclose_fraction = float(search["preclose_fraction"])
            rotation = rpy_matrix(pose["effective_hand_mount_rpy_rad"])
            predicted_normals_hand = [
                (rotation.T @ row.contact_normal_world).tolist() for row in contacts
            ]
            candidate = {
                "candidate_id": candidate_id,
                "rank": 0,
                "dynamic_rank": None,
                "grasp_local_z_mm": grasp_z,
                "preshape_rad": preshape,
                "finger_flexion_targets_rad": pose[
                    "finger_flexion_targets_rad"
                ],
                "object_axis_center_xy_hand_m": pose[
                    "object_axis_center_xy_hand_m"
                ],
                "object_center_z_hand_m": pose["object_center_z_hand_m"],
                "wrist_rpy_offset_rad": pose["wrist_rpy_offset_rad"],
                "open_preshape_rad": diagnostic_geometry.DEFAULT_OPEN_PRESHAPE_RAD,
                "open_flexion_rad": diagnostic_geometry.DEFAULT_OPEN_FLEXION_RAD,
                "preclose_preshape_rad": diagnostic_geometry._interpolate(
                    diagnostic_geometry.DEFAULT_OPEN_PRESHAPE_RAD,
                    preshape,
                    preclose_fraction,
                ),
                "preclose_flexion_rad": [
                    diagnostic_geometry._interpolate(
                        diagnostic_geometry.DEFAULT_OPEN_FLEXION_RAD,
                        value,
                        preclose_fraction,
                    )
                    for value in pose["finger_flexion_targets_rad"]
                ],
                "approach_lift_m": sweep_metrics["approach_lift_m"],
                "central_capsule_index_per_finger": [
                    int(pad_capsules[name]["index"]) for name in ACTIVE_PAD_LINKS
                ],
                "predicted_contact_centers_hand_m": [
                    row["center_hand_m"].tolist() for row in pose["capsules"]
                ],
                "predicted_contact_points_world_m": points,
                "predicted_contact_normals_world": normals,
                "predicted_contact_normals_hand": predicted_normals_hand,
                "predicted_closed_object_gaps_m": sweep_metrics[
                    "closed_object_gaps_m"
                ],
                "predicted_contact_z_spread_m": float(np.ptp(contact_heights)),
                "predicted_contact_axis_fraction": axis_fractions,
                "minimum_joint_margin_rad": pose["minimum_joint_margin_rad"],
                "optimization_residual_norm": pose[
                    "optimization_residual_norm"
                ],
                "sweep_metrics": sweep_metrics,
                "task_metrics": {
                    "circular_contact_metrics": circular,
                    "radial_alignment_metrics": radial,
                    "force_closure": force_closure,
                    "gravity_safety_factor_at_8n": gravity_sf,
                    "lift_safety_factor_at_8n": lift_sf,
                    "minimum_other_task_safety_factor_at_12n": minimum_other_sf,
                    "maximum_required_peak_normal_force_n": maximum_required,
                },
                "screening_gates": gates,
                "geometry_score": float(score),
            }
            candidate["static_pass"] = bool(all(gates.values()))
            candidates.append(candidate)
            sweep_evidence[candidate_id] = sweep

    passing = sorted(
        (row for row in candidates if row["static_pass"]),
        key=lambda row: (-float(row["geometry_score"]), row["candidate_id"]),
    )
    selected: list[dict[str, Any]] = []
    minimum_separation = float(search["minimum_dynamic_preshape_separation_rad"])
    for row in passing:
        if all(
            abs(float(row["preshape_rad"]) - float(other["preshape_rad"]))
            >= minimum_separation - 1.0e-12
            for other in selected
        ):
            selected.append(row)
            if len(selected) == int(search["dynamic_candidate_count"]):
                break
    if len(selected) != int(search["dynamic_candidate_count"]):
        raise RuntimeError("fewer than three diverse candidates passed static screening")
    selected_ids = [row["candidate_id"] for row in selected]
    remainder = [row for row in passing if row["candidate_id"] not in selected_ids]
    rejected = sorted(
        (row for row in candidates if not row["static_pass"]),
        key=lambda row: row["candidate_id"],
    )
    ranked = selected + remainder + rejected
    for rank, row in enumerate(ranked, start=1):
        row["rank"] = rank
        if row["candidate_id"] in selected_ids:
            row["dynamic_rank"] = selected_ids.index(row["candidate_id"]) + 1

    return {
        "schema": BOUNDED_CANDIDATE_SCHEMA,
        "status": "STATIC_SWEEP_PASS_AWAITING_ISAAC",
        "source_urdf_name": source_urdf.name,
        "source_urdf_sha256": file_sha256(source_urdf),
        "source_proxy_manifest_name": pad_core_path.name,
        "source_proxy_manifest_sha256": file_sha256(pad_core_path),
        "source_seed_candidates": str(seed_candidates_path),
        "source_seed_candidates_sha256": file_sha256(seed_candidates_path),
        "source_proxy_dynamic_use_allowed": bool(
            seed_bundle.get("source_proxy_dynamic_use_allowed", False)
        ),
        "diagnostic_pad_core_dynamic_use_allowed": True,
        "minimal_v2_collision_subset": {
            "kind": "ONE_CENTRAL_ANALYTIC_PAD_CAPSULE_PER_FINGER",
            "pad_primitive_count_total": 3,
            "whole_terminal_convex_hull_count": 0,
            "tip_collision_count": 0,
            "formal_b_pass_claimed": False,
        },
        "candidate_count": len(ranked),
        "dynamic_candidate_count": len(selected_ids),
        "selected_dynamic_candidate_ids": selected_ids,
        "selection_policy": (
            "TASK_SCORE_THEN_DISTINCT_PRESHAPE_AT_LEAST_"
            f"{minimum_separation:.3f}_RAD"
        ),
        "candidates": ranked,
        "sweep_evidence": sweep_evidence,
        "online_truth_use_allowed": False,
        "formal_b_pass_claimed": False,
    }


__all__ = [
    "ACTIVE_PAD_LINKS",
    "ROOT_TORQUE_JOINTS",
    "BOUNDED_CANDIDATE_SCHEMA",
    "build_bounded_candidate_bundle",
    "candidate_world_geometry",
    "file_sha256",
    "load_seed_geometry",
    "rpy_matrix",
    "select_candidate",
    "selected_pad_capsules",
]
