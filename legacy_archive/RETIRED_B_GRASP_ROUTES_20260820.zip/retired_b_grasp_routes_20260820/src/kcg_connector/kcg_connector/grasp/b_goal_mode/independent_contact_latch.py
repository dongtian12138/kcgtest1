"""Torque-only per-finger contact acquisition for B_GOAL_MODE G2."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Sequence

import numpy as np


@dataclass(frozen=True)
class TareStatistics:
    mean_effort_nm: float
    residual_mean_abs_nm: float
    residual_sigma_nm: float
    contact_threshold_nm: float
    sample_count: int

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def compute_tare_statistics(
    samples_nm: Sequence[float],
    *,
    minimum_threshold_nm: float,
    sigma_multiplier: float,
) -> TareStatistics:
    samples = np.asarray(samples_nm, dtype=np.float64)
    if samples.ndim != 1 or samples.size < 24 or not np.all(np.isfinite(samples)):
        raise ValueError("tare requires at least 24 finite scalar effort samples")
    if minimum_threshold_nm <= 0.0 or sigma_multiplier <= 0.0:
        raise ValueError("tare threshold parameters must be positive")
    mean = float(np.mean(samples))
    residual = np.abs(samples - mean)
    residual_mean = float(np.mean(residual))
    sigma = float(np.std(residual, ddof=1))
    threshold = max(
        float(minimum_threshold_nm), residual_mean + float(sigma_multiplier) * sigma
    )
    return TareStatistics(
        mean_effort_nm=mean,
        residual_mean_abs_nm=residual_mean,
        residual_sigma_nm=sigma,
        contact_threshold_nm=threshold,
        sample_count=int(samples.size),
    )


@dataclass
class IndependentContactLatch:
    tare: TareStatistics
    confirmation_steps: int
    loss_threshold_fraction: float
    loss_confirmation_steps: int
    state: str = "SEARCHING"
    above_threshold_steps: int = 0
    below_release_steps: int = 0
    locked_stable_steps: int = 0
    lock_target_rad: float | None = None
    first_contact_step: int | None = None
    first_contact_position_rad: float | None = None
    first_contact_effort_delta_nm: float | None = None
    lock_count: int = 0
    recovery_count: int = 0

    def __post_init__(self) -> None:
        if self.confirmation_steps <= 0 or self.loss_confirmation_steps <= 0:
            raise ValueError("confirmation step counts must be positive")
        if not 0.0 < self.loss_threshold_fraction < 1.0:
            raise ValueError("loss threshold fraction must be between zero and one")

    @property
    def locked(self) -> bool:
        return self.state == "CONTACT_LOCKED"

    def effort_delta_nm(self, effort_nm: float) -> float:
        return abs(float(effort_nm) - self.tare.mean_effort_nm)

    def update(
        self,
        *,
        effort_nm: float,
        current_target_rad: float,
        actual_position_rad: float,
        physics_step: int,
    ) -> str | None:
        """Update from proprioception only and return a state-transition event."""

        values = (effort_nm, current_target_rad, actual_position_rad)
        if not all(np.isfinite(float(value)) for value in values):
            raise ValueError("contact latch inputs must be finite")
        delta = self.effort_delta_nm(effort_nm)
        if not self.locked:
            self.above_threshold_steps = (
                self.above_threshold_steps + 1
                if delta > self.tare.contact_threshold_nm
                else 0
            )
            if self.above_threshold_steps < self.confirmation_steps:
                return None
            self.state = "CONTACT_LOCKED"
            self.lock_target_rad = float(current_target_rad)
            self.locked_stable_steps = 0
            self.below_release_steps = 0
            self.lock_count += 1
            if self.first_contact_step is None:
                self.first_contact_step = int(physics_step)
                self.first_contact_position_rad = float(actual_position_rad)
                self.first_contact_effort_delta_nm = delta
            return "CONTACT_LOCKED"

        release_threshold = (
            self.loss_threshold_fraction * self.tare.contact_threshold_nm
        )
        self.below_release_steps = (
            self.below_release_steps + 1 if delta < release_threshold else 0
        )
        if self.below_release_steps >= self.loss_confirmation_steps:
            self.state = "SEARCHING"
            self.above_threshold_steps = 0
            self.below_release_steps = 0
            self.locked_stable_steps = 0
            self.lock_target_rad = None
            self.recovery_count += 1
            return "CONTACT_LOST_RESUME_SEARCH"
        self.locked_stable_steps += 1
        return None

    def as_dict(self) -> dict[str, Any]:
        return {
            "tare": self.tare.as_dict(),
            "state": self.state,
            "above_threshold_steps": self.above_threshold_steps,
            "below_release_steps": self.below_release_steps,
            "locked_stable_steps": self.locked_stable_steps,
            "lock_target_rad": self.lock_target_rad,
            "first_contact_step": self.first_contact_step,
            "first_contact_position_rad": self.first_contact_position_rad,
            "first_contact_effort_delta_nm": self.first_contact_effort_delta_nm,
            "lock_count": self.lock_count,
            "recovery_count": self.recovery_count,
        }
