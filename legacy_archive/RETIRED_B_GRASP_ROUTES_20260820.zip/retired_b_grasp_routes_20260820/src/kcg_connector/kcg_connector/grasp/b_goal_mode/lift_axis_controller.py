"""Mass-derived lift-axis design and minimum-jerk trajectories."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Sequence


@dataclass(frozen=True)
class LiftAxisDesign:
    moved_mass_kg: float
    gravity_m_s2: float
    weight_n: float
    smallest_target_m: float
    acceptance_tracking_ratio: float
    acceptance_absolute_error_m: float
    design_error_budget_m: float
    stiffness_margin: float
    kp_n_per_m: float
    damping_ratio: float
    kd_n_s_per_m: float
    drive_force_multiplier: float
    maximum_drive_force_n: float
    drive_force_to_weight_ratio: float
    predicted_static_error_m: float

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


def design_lift_axis(
    *,
    moved_mass_kg: float,
    targets_m: Sequence[float],
    gravity_m_s2: float,
    minimum_tracking_ratio: float,
    maximum_absolute_error_m: float,
    stiffness_margin: float,
    damping_ratio: float,
    drive_force_multiplier: float,
) -> LiftAxisDesign:
    if moved_mass_kg <= 0.0:
        raise ValueError("moved_mass_kg must be positive")
    if not targets_m or min(targets_m) <= 0.0:
        raise ValueError("lift targets must be positive")
    if not 0.0 < minimum_tracking_ratio <= 1.0:
        raise ValueError("minimum_tracking_ratio must be in (0, 1]")
    if drive_force_multiplier < 3.0:
        raise ValueError("drive force must be at least three times moved weight")
    smallest_target = min(float(value) for value in targets_m)
    ratio_error_budget = smallest_target * (1.0 - minimum_tracking_ratio)
    design_error_budget = min(float(maximum_absolute_error_m), ratio_error_budget)
    if design_error_budget <= 0.0:
        raise ValueError("tracking requirements produce a zero error budget")
    weight = float(moved_mass_kg) * float(gravity_m_s2)
    kp = float(stiffness_margin) * weight / design_error_budget
    kd = 2.0 * float(damping_ratio) * math.sqrt(kp * float(moved_mass_kg))
    maximum_force = float(drive_force_multiplier) * weight
    return LiftAxisDesign(
        moved_mass_kg=float(moved_mass_kg),
        gravity_m_s2=float(gravity_m_s2),
        weight_n=weight,
        smallest_target_m=smallest_target,
        acceptance_tracking_ratio=float(minimum_tracking_ratio),
        acceptance_absolute_error_m=float(maximum_absolute_error_m),
        design_error_budget_m=design_error_budget,
        stiffness_margin=float(stiffness_margin),
        kp_n_per_m=kp,
        damping_ratio=float(damping_ratio),
        kd_n_s_per_m=kd,
        drive_force_multiplier=float(drive_force_multiplier),
        maximum_drive_force_n=maximum_force,
        drive_force_to_weight_ratio=maximum_force / weight,
        predicted_static_error_m=weight / kp,
    )


def minimum_jerk(start: float, target: float, step_index: int, total_steps: int) -> float:
    if total_steps <= 0:
        raise ValueError("total_steps must be positive")
    fraction = min(1.0, max(0.0, (int(step_index) + 1) / float(total_steps)))
    blend = 10.0 * fraction**3 - 15.0 * fraction**4 + 6.0 * fraction**5
    return float(start) + blend * (float(target) - float(start))
