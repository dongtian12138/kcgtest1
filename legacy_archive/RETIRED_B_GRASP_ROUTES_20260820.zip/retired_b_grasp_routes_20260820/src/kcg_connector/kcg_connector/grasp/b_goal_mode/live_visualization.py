"""Live-only visual overlay and camera evidence for the full-iiwa B diagnostic.

The physical controller never imports rendered observations from this module.
The only authored transforms are below ``/World/BFullIiwaVisualOverlay`` and
therefore have the evidence role ``VISUAL_OVERLAY_WRITE_ONLY``.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import subprocess
from typing import Any, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np


SCHEMA = "D38999_B_FULL_IIWA_LIVE_VISUALIZATION_V1"
OVERLAY_ROOT = "/World/BFullIiwaVisualOverlay"
VISUAL_PAIR_SOURCE_PRIM = (
    "/World/D38999MultilayerV1/D38999_VISUAL_COMPLETE_V1/D38999Pair"
)
VISUAL_METADATA_PRIM = (
    "/World/D38999MultilayerV1/D38999_VISUAL_COMPLETE_V1"
)
LIVE_CAMERA_PATH = "/World/BFullIiwaLiveCamera"
LIVE_RESOLUTION = (1280, 720)
VIDEO_FPS = 20
VISUAL_MODES = ("clean", "collision_debug")
COLLISION_DEBUG_TRACE = "LIVE_COLLISION_DEBUG_TRACE.csv"
# A deliberately wide opening view.  The milestone camera search still moves in
# for contact evidence, while this view keeps the complete iiwa, tabletop, and
# connector in frame so the live video cannot be confused with a cropped or
# post-hoc replay view.
FULL_ASSEMBLY_OVERVIEW_EYE_M = (3.80, -4.10, 2.80)
FULL_ASSEMBLY_OVERVIEW_TARGET_M = (0.25, -0.05, 0.68)
MILESTONE_FILES = {
    "APPROACH": "LIVE_01_APPROACH.png",
    "THREE_PAD_CONTACT": "LIVE_02_THREE_PAD_CONTACT.png",
    "COMPLIANT_GRASP": "LIVE_03_COMPLIANT_GRASP.png",
    "OFFTABLE_0P5MM": "LIVE_04_OFFTABLE_0P5MM.png",
    "LIFT_40MM": "LIVE_05_LIFT_40MM.png",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def _unit(vector: Sequence[float], fallback: Sequence[float]) -> np.ndarray:
    value = np.asarray(vector, dtype=np.float64)
    magnitude = float(np.linalg.norm(value))
    if magnitude <= 1.0e-12:
        value = np.asarray(fallback, dtype=np.float64)
        magnitude = float(np.linalg.norm(value))
    return value / magnitude


@dataclass(frozen=True)
class CameraCandidate:
    candidate_id: str
    eye_m: tuple[float, float, float]
    target_m: tuple[float, float, float]
    azimuth_deg: float
    elevation_deg: float
    distance_m: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "eye_m": list(self.eye_m),
            "target_m": list(self.target_m),
            "azimuth_deg": self.azimuth_deg,
            "elevation_deg": self.elevation_deg,
            "distance_m": self.distance_m,
        }


def generate_camera_candidates(
    target_m: Sequence[float],
    hand_direction_world: Sequence[float],
) -> tuple[CameraCandidate, ...]:
    """Return eight bounded views with two elevations and two distances."""

    target = np.asarray(target_m, dtype=np.float64)
    hand = _unit(hand_direction_world, (0.0, -1.0, 0.0))
    horizontal = _unit((hand[0], hand[1], 0.0), (0.0, -1.0, 0.0))
    base_azimuth = math.atan2(float(horizontal[1]), float(horizontal[0]))
    azimuth_offsets_deg = (-70.0, -25.0, 25.0, 70.0, 110.0, 155.0, 205.0, 250.0)
    results: list[CameraCandidate] = []
    for index, offset_deg in enumerate(azimuth_offsets_deg):
        elevation_deg = 18.0 if index % 2 == 0 else 32.0
        distance_m = 0.36 if (index // 2) % 2 == 0 else 0.48
        azimuth = base_azimuth + math.radians(offset_deg)
        elevation = math.radians(elevation_deg)
        radial = distance_m * math.cos(elevation)
        eye = target + np.asarray(
            (
                radial * math.cos(azimuth),
                radial * math.sin(azimuth),
                distance_m * math.sin(elevation),
            ),
            dtype=np.float64,
        )
        results.append(
            CameraCandidate(
                candidate_id=f"CAM_{index + 1:02d}",
                eye_m=tuple(float(value) for value in eye),
                target_m=tuple(float(value) for value in target),
                azimuth_deg=math.degrees(azimuth),
                elevation_deg=elevation_deg,
                distance_m=distance_m,
            )
        )
    return tuple(results)


def aabb_corners(minimum: Sequence[float], maximum: Sequence[float]) -> np.ndarray:
    low = np.asarray(minimum, dtype=np.float64)
    high = np.asarray(maximum, dtype=np.float64)
    return np.asarray(
        [
            (x, y, z)
            for x in (low[0], high[0])
            for y in (low[1], high[1])
            for z in (low[2], high[2])
        ],
        dtype=np.float64,
    )


def project_world_points(
    points_world_m: Sequence[Sequence[float]],
    *,
    eye_m: Sequence[float],
    target_m: Sequence[float],
    resolution_px: tuple[int, int] = LIVE_RESOLUTION,
    focal_length_mm: float = 32.0,
    horizontal_aperture_mm: float = 20.955,
) -> tuple[np.ndarray, np.ndarray]:
    """Project world points using the same pinhole model as the USD camera."""

    points = np.asarray(points_world_m, dtype=np.float64).reshape((-1, 3))
    eye = np.asarray(eye_m, dtype=np.float64)
    forward = _unit(np.asarray(target_m, dtype=np.float64) - eye, (0.0, 0.0, -1.0))
    right = _unit(np.cross(forward, (0.0, 0.0, 1.0)), (1.0, 0.0, 0.0))
    up = _unit(np.cross(right, forward), (0.0, 0.0, 1.0))
    relative = points - eye
    depth = relative @ forward
    horizontal = relative @ right
    vertical = relative @ up
    width, height = resolution_px
    vertical_aperture_mm = horizontal_aperture_mm * float(height) / float(width)
    half_width = depth * horizontal_aperture_mm / (2.0 * focal_length_mm)
    half_height = depth * vertical_aperture_mm / (2.0 * focal_length_mm)
    with np.errstate(divide="ignore", invalid="ignore"):
        u = 0.5 + horizontal / (2.0 * half_width)
        v = 0.5 - vertical / (2.0 * half_height)
    return np.stack((u, v), axis=1), depth


def _sample_depth(depth: np.ndarray, uv: Sequence[float]) -> float | None:
    height, width = depth.shape
    u, v = float(uv[0]), float(uv[1])
    if not (0.0 <= u <= 1.0 and 0.0 <= v <= 1.0):
        return None
    x = int(round(u * float(width - 1)))
    y = int(round(v * float(height - 1)))
    patch = depth[max(0, y - 2) : min(height, y + 3), max(0, x - 2) : min(width, x + 3)]
    valid = patch[np.isfinite(patch) & (patch > 0.0)]
    if valid.size == 0:
        return None
    return float(np.median(valid))


def score_camera_observation(
    *,
    rgb: np.ndarray,
    depth_m: np.ndarray,
    candidate: CameraCandidate,
    object_aabb_min_m: Sequence[float],
    object_aabb_max_m: Sequence[float],
    pad_centers_world_m: Sequence[Sequence[float]],
    contact_center_world_m: Sequence[float],
) -> dict[str, Any]:
    """Score visibility without feeding image or contact truth into control."""

    maximum_rgb = np.max(rgb[:, :, :3], axis=2)
    near_black = float(np.mean(maximum_rgb <= 2))
    valid_depth = np.isfinite(depth_m) & (depth_m > 0.0)
    valid_depth_fraction = float(np.mean(valid_depth))
    corners = aabb_corners(object_aabb_min_m, object_aabb_max_m)
    corner_uv, corner_depth = project_world_points(
        corners,
        eye_m=candidate.eye_m,
        target_m=candidate.target_m,
        resolution_px=(rgb.shape[1], rgb.shape[0]),
    )
    object_complete = bool(
        np.all(corner_depth > 0.0)
        and np.all(corner_uv[:, 0] >= 0.03)
        and np.all(corner_uv[:, 0] <= 0.97)
        and np.all(corner_uv[:, 1] >= 0.03)
        and np.all(corner_uv[:, 1] <= 0.97)
    )
    u_min = float(np.min(corner_uv[:, 0]))
    u_max = float(np.max(corner_uv[:, 0]))
    v_min = float(np.min(corner_uv[:, 1]))
    v_max = float(np.max(corner_uv[:, 1]))
    projection_area = max(0.0, min(1.0, u_max) - max(0.0, u_min)) * max(
        0.0, min(1.0, v_max) - max(0.0, v_min)
    )

    pad_uv, pad_depth = project_world_points(
        pad_centers_world_m,
        eye_m=candidate.eye_m,
        target_m=candidate.target_m,
        resolution_px=(rgb.shape[1], rgb.shape[0]),
    )
    pad_visibility: list[dict[str, Any]] = []
    for uv, expected_depth in zip(pad_uv, pad_depth):
        rendered_depth = _sample_depth(depth_m, uv)
        visible = bool(
            expected_depth > 0.0
            and rendered_depth is not None
            and abs(rendered_depth - float(expected_depth)) <= 0.020
        )
        pad_visibility.append(
            {
                "uv": [float(value) for value in uv],
                "expected_depth_m": float(expected_depth),
                "rendered_depth_m": rendered_depth,
                "visible": visible,
            }
        )
    visible_pad_count = sum(int(item["visible"]) for item in pad_visibility)

    contact_uv, contact_depth = project_world_points(
        [contact_center_world_m],
        eye_m=candidate.eye_m,
        target_m=candidate.target_m,
        resolution_px=(rgb.shape[1], rgb.shape[0]),
    )
    contact_sample = _sample_depth(depth_m, contact_uv[0])
    contact_in_safe_zone = bool(
        contact_depth[0] > 0.0
        and 0.15 <= contact_uv[0, 0] <= 0.85
        and 0.15 <= contact_uv[0, 1] <= 0.85
    )
    contact_not_fully_occluded = bool(
        contact_in_safe_zone
        and contact_sample is not None
        and abs(contact_sample - float(contact_depth[0])) <= 0.035
    )

    center = 0.5 * (
        np.asarray(object_aabb_min_m, dtype=np.float64)
        + np.asarray(object_aabb_max_m, dtype=np.float64)
    )
    half_extent = 0.5 * float(
        np.linalg.norm(
            np.asarray(object_aabb_max_m, dtype=np.float64)
            - np.asarray(object_aabb_min_m, dtype=np.float64)
        )
    )
    center_uv, center_depth = project_world_points(
        [center],
        eye_m=candidate.eye_m,
        target_m=candidate.target_m,
        resolution_px=(rgb.shape[1], rgb.shape[0]),
    )
    sample_hits = 0
    sample_total = 0
    for u in np.linspace(max(0.02, u_min), min(0.98, u_max), 7):
        for v in np.linspace(max(0.02, v_min), min(0.98, v_max), 7):
            measured = _sample_depth(depth_m, (u, v))
            if measured is None:
                continue
            sample_total += 1
            if abs(measured - float(center_depth[0])) <= half_extent + 0.012:
                sample_hits += 1
    visible_object_fraction = 0.0 if sample_total == 0 else sample_hits / sample_total
    robot_occlusion_ratio = 1.0 - visible_object_fraction
    passed = bool(
        near_black < 0.35
        and object_complete
        and visible_pad_count >= 2
        and contact_not_fully_occluded
    )
    score = (
        4.0 * float(passed)
        + 1.7 * (1.0 - near_black)
        + 1.0 * valid_depth_fraction
        + 5.0 * min(projection_area, 0.12)
        + 0.55 * visible_pad_count
        + 0.8 * float(contact_not_fully_occluded)
        + 0.8 * (1.0 - robot_occlusion_ratio)
    )
    return {
        **candidate.as_dict(),
        "near_black_fraction": near_black,
        "valid_depth_fraction": valid_depth_fraction,
        "object_aabb_projection_area_fraction": projection_area,
        "object_complete_in_frame": object_complete,
        "visible_pad_count": visible_pad_count,
        "pad_visibility": pad_visibility,
        "contact_center_uv": [float(value) for value in contact_uv[0]],
        "contact_center_expected_depth_m": float(contact_depth[0]),
        "contact_center_rendered_depth_m": contact_sample,
        "contact_center_in_safe_zone": contact_in_safe_zone,
        "contact_region_not_fully_occluded": contact_not_fully_occluded,
        "robot_occlusion_ratio": robot_occlusion_ratio,
        "passed": passed,
        "score": float(score),
    }


def _rpy_rotation(rpy: Sequence[float]) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.asarray(
        (
            (cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr),
            (sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr),
            (-sp, cp * sr, cp * cr),
        ),
        dtype=np.float64,
    )


def _axis_rotation(axis: Sequence[float], angle_rad: float) -> np.ndarray:
    unit = _unit(axis, (0.0, 0.0, 1.0))
    x, y, z = (float(value) for value in unit)
    skew = np.asarray(
        ((0.0, -z, y), (z, 0.0, -x), (-y, x, 0.0)),
        dtype=np.float64,
    )
    return (
        np.eye(3, dtype=np.float64)
        + math.sin(angle_rad) * skew
        + (1.0 - math.cos(angle_rad)) * (skew @ skew)
    )


def _pose_matrix(
    position_m: Sequence[float], orientation_wxyz: Sequence[float]
) -> np.ndarray:
    w, x, y, z = (float(value) for value in orientation_wxyz)
    magnitude = math.sqrt(w * w + x * x + y * y + z * z)
    if magnitude <= 1.0e-12:
        raise ValueError("object quaternion is degenerate")
    w, x, y, z = (value / magnitude for value in (w, x, y, z))
    rotation = np.asarray(
        (
            (1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)),
            (2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)),
            (2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)),
        ),
        dtype=np.float64,
    )
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = rotation
    result[:3, 3] = np.asarray(position_m, dtype=np.float64)
    return result


def _finite_oriented_cylinder_sdf(
    points_world_m: np.ndarray,
    *,
    center_world_m: np.ndarray,
    axis_world: np.ndarray,
    radius_m: float,
    height_m: float,
) -> np.ndarray:
    points = np.asarray(points_world_m, dtype=np.float64).reshape((-1, 3))
    axis = _unit(axis_world, (0.0, 0.0, 1.0))
    relative = points - np.asarray(center_world_m, dtype=np.float64)[None, :]
    axial_coordinate = relative @ axis
    radial_vector = relative - axial_coordinate[:, None] * axis[None, :]
    radial = np.linalg.norm(radial_vector, axis=1) - float(radius_m)
    axial = np.abs(axial_coordinate) - 0.5 * float(height_m)
    outside = np.linalg.norm(
        np.stack((np.maximum(radial, 0.0), np.maximum(axial, 0.0)), axis=1),
        axis=1,
    )
    inside = np.minimum(np.maximum(radial, axial), 0.0)
    return outside + inside


def _axis_aligned_box_sdf(
    points_world_m: np.ndarray,
    *,
    center_world_m: Sequence[float],
    size_m: Sequence[float],
) -> np.ndarray:
    points = np.asarray(points_world_m, dtype=np.float64).reshape((-1, 3))
    center = np.asarray(center_world_m, dtype=np.float64)
    half_size = 0.5 * np.asarray(size_m, dtype=np.float64)
    offset = np.abs(points - center[None, :]) - half_size[None, :]
    outside = np.linalg.norm(np.maximum(offset, 0.0), axis=1)
    inside = np.minimum(np.max(offset, axis=1), 0.0)
    return outside + inside


class _FullRobotCadMonitor:
    """Post-step geometry audit driven only by measured robot/object state."""

    def __init__(
        self,
        *,
        repository: Path,
        urdf_path: Path,
        table_center_m: Sequence[float],
        table_size_m: Sequence[float],
        grip_center_local_m: Sequence[float],
        grip_radius_m: float,
        grip_height_m: float,
        connector_visual_local_bounds_m: Mapping[
            str, Mapping[str, Sequence[float]]
        ],
    ) -> None:
        import trimesh

        from kcg_connector.grasp.d38999_pad_contact_roles import (
            FINGER_PAD_ROLE_SPECS,
            build_finger_pad_role,
        )

        self.repository = repository.resolve()
        self.urdf_path = urdf_path.resolve()
        self.table_center_m = np.asarray(table_center_m, dtype=np.float64)
        self.table_size_m = np.asarray(table_size_m, dtype=np.float64)
        self.grip_center_local_m = np.asarray(
            grip_center_local_m, dtype=np.float64
        )
        self.grip_radius_m = float(grip_radius_m)
        self.grip_height_m = float(grip_height_m)
        required_connector_components = {"body_assembly", "coupling_nut"}
        if set(connector_visual_local_bounds_m) != required_connector_components:
            raise ValueError("connector visual bounds must contain body and nut")
        self._connector_visual_obb_points: dict[str, np.ndarray] = {}
        for component, bounds in connector_visual_local_bounds_m.items():
            if set(bounds) != {"minimum_m", "maximum_m"}:
                raise ValueError(f"invalid visual bounds for {component}")
            minimum = np.asarray(bounds["minimum_m"], dtype=np.float64)
            maximum = np.asarray(bounds["maximum_m"], dtype=np.float64)
            if (
                minimum.shape != (3,)
                or maximum.shape != (3,)
                or not np.all(np.isfinite(minimum))
                or not np.all(np.isfinite(maximum))
                or not np.all(maximum > minimum)
            ):
                raise ValueError(f"non-finite visual bounds for {component}")
            self._connector_visual_obb_points[component] = aabb_corners(
                minimum, maximum
            )
        root = ET.parse(self.urdf_path).getroot()
        self._joints: list[dict[str, Any]] = []
        for joint in root.findall("joint"):
            origin = joint.find("origin")
            axis = joint.find("axis")
            transform = np.eye(4, dtype=np.float64)
            transform[:3, :3] = _rpy_rotation(
                np.fromstring(
                    "0 0 0" if origin is None else origin.get("rpy", "0 0 0"),
                    sep=" ",
                )
            )
            transform[:3, 3] = np.fromstring(
                "0 0 0" if origin is None else origin.get("xyz", "0 0 0"),
                sep=" ",
            )
            self._joints.append(
                {
                    "name": str(joint.get("name")),
                    "type": str(joint.get("type", "fixed")),
                    "parent": str(joint.find("parent").get("link")),
                    "child": str(joint.find("child").get("link")),
                    "origin": transform,
                    "axis": np.fromstring(
                        "0 0 1" if axis is None else axis.get("xyz", "0 0 1"),
                        sep=" ",
                    ),
                }
            )

        self._visual_hulls: dict[str, np.ndarray] = {}
        for link in root.findall("link"):
            link_name = str(link.get("name"))
            points_for_link: list[np.ndarray] = []
            for visual in link.findall("visual"):
                mesh_node = visual.find("geometry/mesh")
                if mesh_node is None:
                    continue
                mesh_path = Path(str(mesh_node.get("filename"))).expanduser()
                if not mesh_path.is_absolute():
                    mesh_path = self.repository / mesh_path
                mesh = trimesh.load_mesh(mesh_path.resolve(), process=False)
                if isinstance(mesh, trimesh.Scene):
                    mesh = mesh.dump(concatenate=True)
                if not isinstance(mesh, trimesh.Trimesh):
                    raise TypeError(f"robot visual is not a triangle mesh: {mesh_path}")
                points = np.asarray(mesh.vertices, dtype=np.float64)
                scale_text = mesh_node.get("scale")
                if scale_text:
                    points = points * np.fromstring(scale_text, sep=" ")[None, :]
                visual_origin = visual.find("origin")
                visual_transform = np.eye(4, dtype=np.float64)
                visual_transform[:3, :3] = _rpy_rotation(
                    np.fromstring(
                        "0 0 0"
                        if visual_origin is None
                        else visual_origin.get("rpy", "0 0 0"),
                        sep=" ",
                    )
                )
                visual_transform[:3, 3] = np.fromstring(
                    "0 0 0"
                    if visual_origin is None
                    else visual_origin.get("xyz", "0 0 0"),
                    sep=" ",
                )
                points_for_link.append(
                    points @ visual_transform[:3, :3].T
                    + visual_transform[:3, 3][None, :]
                )
            if points_for_link:
                all_points = np.concatenate(points_for_link, axis=0)
                hull = trimesh.Trimesh(vertices=all_points, process=False).convex_hull
                self._visual_hulls[link_name] = np.asarray(
                    hull.vertices, dtype=np.float64
                )

        self._terminal_role_points: dict[tuple[str, str], np.ndarray] = {}
        for spec in FINGER_PAD_ROLE_SPECS:
            build = build_finger_pad_role(spec)
            side_components = [
                component
                for rank, component in enumerate(build.components_by_area)
                if rank
                not in {
                    build.pad_component_rank_by_area,
                    build.tip_component_rank_by_area,
                }
            ]
            self._terminal_role_points[(spec.link_name, "PAD")] = np.asarray(
                build.pad_component.vertices, dtype=np.float64
            )
            self._terminal_role_points[(spec.link_name, "TIP")] = np.asarray(
                build.tip_component.vertices, dtype=np.float64
            )
            self._terminal_role_points[(spec.link_name, "SIDE")] = np.unique(
                np.concatenate(
                    [np.asarray(component.vertices, dtype=np.float64) for component in side_components],
                    axis=0,
                ),
                axis=0,
            )

    def _link_transforms(
        self, joint_positions_rad: Mapping[str, float]
    ) -> dict[str, np.ndarray]:
        transforms: dict[str, np.ndarray] = {"world": np.eye(4, dtype=np.float64)}
        pending = list(self._joints)
        while pending:
            progress = False
            remaining: list[dict[str, Any]] = []
            for joint in pending:
                parent = joint["parent"]
                if parent not in transforms:
                    remaining.append(joint)
                    continue
                motion = np.eye(4, dtype=np.float64)
                if joint["type"] in {"revolute", "continuous"}:
                    if joint["name"] not in joint_positions_rad:
                        raise KeyError(f"missing measured joint {joint['name']}")
                    motion[:3, :3] = _axis_rotation(
                        joint["axis"], float(joint_positions_rad[joint["name"]])
                    )
                transforms[joint["child"]] = (
                    transforms[parent] @ joint["origin"] @ motion
                )
                progress = True
            if not progress:
                unresolved = [joint["name"] for joint in remaining]
                raise RuntimeError(f"URDF transform tree is unresolved: {unresolved}")
            pending = remaining
        return transforms

    def measure(
        self,
        *,
        joint_positions_rad: Mapping[str, float],
        body_position_m: Sequence[float],
        body_orientation_wxyz: Sequence[float],
        nut_position_m: Sequence[float],
        nut_orientation_wxyz: Sequence[float],
        contacts: Mapping[str, Any],
    ) -> dict[str, Any]:
        transforms = self._link_transforms(joint_positions_rad)
        table_minimum = math.inf
        table_minimum_link = ""
        for link_name, points in self._visual_hulls.items():
            transform = transforms.get(link_name)
            if transform is None:
                continue
            world_points = points @ transform[:3, :3].T + transform[:3, 3]
            minimum = float(
                np.min(
                    _axis_aligned_box_sdf(
                        world_points,
                        center_world_m=self.table_center_m,
                        size_m=self.table_size_m,
                    )
                )
            )
            if minimum < table_minimum:
                table_minimum = minimum
                table_minimum_link = link_name

        connector_poses = {
            "body_assembly": _pose_matrix(
                body_position_m, body_orientation_wxyz
            ),
            "coupling_nut": _pose_matrix(
                nut_position_m, nut_orientation_wxyz
            ),
        }
        connector_table_gaps: dict[str, float] = {}
        for component, local_points in self._connector_visual_obb_points.items():
            pose = connector_poses[component]
            world_points = local_points @ pose[:3, :3].T + pose[:3, 3]
            connector_table_gaps[component] = float(
                np.min(
                    _axis_aligned_box_sdf(
                        world_points,
                        center_world_m=self.table_center_m,
                        size_m=self.table_size_m,
                    )
                )
            )
        minimum_connector_component = min(
            connector_table_gaps, key=connector_table_gaps.__getitem__
        )
        minimum_connector_table = connector_table_gaps[
            minimum_connector_component
        ]

        nut_pose = _pose_matrix(nut_position_m, nut_orientation_wxyz)
        grip_center_world = (
            nut_pose[:3, :3] @ self.grip_center_local_m + nut_pose[:3, 3]
        )
        grip_axis_world = nut_pose[:3, 2]
        role_gaps: dict[str, dict[str, float]] = {}
        for (link_name, role), points in self._terminal_role_points.items():
            transform = transforms[link_name]
            world_points = points @ transform[:3, :3].T + transform[:3, 3]
            gap = float(
                np.min(
                    _finite_oriented_cylinder_sdf(
                        world_points,
                        center_world_m=grip_center_world,
                        axis_world=grip_axis_world,
                        radius_m=self.grip_radius_m,
                        height_m=self.grip_height_m,
                    )
                )
            )
            role_gaps.setdefault(link_name, {})[role] = gap

        pad_gaps = {
            link: values["PAD"] for link, values in role_gaps.items()
        }
        blocker_gaps = [
            values[role]
            for values in role_gaps.values()
            for role in ("TIP", "SIDE")
        ]
        unauthorized_penetration = 0.0
        for manifold in contacts.get("unauthorized_manifolds", ()):
            for point in manifold.get("contact_points", ()):
                unauthorized_penetration = max(
                    unauthorized_penetration,
                    max(0.0, -float(point.get("separation_m", 0.0))),
                )
        return {
            "minimum_full_robot_visual_cad_table_clearance_m": table_minimum,
            "minimum_table_clearance_link": table_minimum_link,
            "connector_visual_cad_table_clearance_m": connector_table_gaps,
            "minimum_connector_visual_cad_table_clearance_m": (
                minimum_connector_table
            ),
            "minimum_connector_table_clearance_component": (
                minimum_connector_component
            ),
            "maximum_connector_visual_cad_table_penetration_m": max(
                0.0, -minimum_connector_table
            ),
            "pad_authorized_grip_sampled_sdf_m": pad_gaps,
            "maximum_authorized_pad_cad_penetration_m": max(
                0.0, -min(pad_gaps.values())
            ),
            "minimum_tip_side_authorized_grip_sampled_sdf_m": min(blocker_gaps),
            "maximum_tip_side_authorized_grip_cad_penetration_m": max(
                0.0, -min(blocker_gaps)
            ),
            "maximum_unauthorized_physx_penetration_m": unauthorized_penetration,
            "unauthorized_contact_count": int(
                contacts.get("unauthorized_count", 0)
            ),
            "metric_role": (
                "POST_STEP_MEASURED_STATE_FULL_ROBOT_VISUAL_CAD_"
                "CONNECTOR_VISUAL_CAD_OBB_AND_LIVE_PHYSX"
            ),
        }


class FullIiwaLiveVisualizer:
    """Own a nonphysical complete-appearance overlay and live render evidence."""

    def __init__(
        self,
        *,
        repository: Path,
        output: Path,
        stage: Any,
        application: Any,
        visual_asset: Path,
        physical_asset: Path,
        physical_fixed_path: str,
        physical_body_path: str,
        physical_nut_path: str,
        pad_paths: Mapping[str, str],
        tip_paths: Mapping[str, str],
        side_paths: Mapping[str, str],
        visual_mode: str,
        source_robot_urdf: Path,
        table_center_m: Sequence[float],
        table_size_m: Sequence[float],
        authorized_grip_local_center_m: Sequence[float],
        authorized_grip_radius_m: float,
        authorized_grip_height_m: float,
        sim_rate_hz: int,
        record_live_video: bool,
        video_output: Path,
        Gf: Any,
        Usd: Any,
        UsdGeom: Any,
        UsdLux: Any,
        UsdPhysics: Any,
    ) -> None:
        self.repository = repository.resolve()
        self.output = output.resolve()
        self.stage = stage
        self.application = application
        self.visual_asset = visual_asset.resolve()
        self.physical_asset = physical_asset.resolve()
        self.physical_paths = {
            "fixed_receptacle": physical_fixed_path,
            "body_assembly": physical_body_path,
            "coupling_nut": physical_nut_path,
        }
        self.pad_paths = dict(pad_paths)
        self.tip_paths = dict(tip_paths)
        self.side_paths = dict(side_paths)
        if visual_mode not in VISUAL_MODES:
            raise ValueError(f"unknown live visual mode: {visual_mode}")
        self.visual_mode = visual_mode
        self.source_robot_urdf = source_robot_urdf.resolve()
        self.table_center_m = np.asarray(table_center_m, dtype=np.float64)
        self.table_size_m = np.asarray(table_size_m, dtype=np.float64)
        self.authorized_grip_local_center_m = np.asarray(
            authorized_grip_local_center_m, dtype=np.float64
        )
        self.authorized_grip_radius_m = float(authorized_grip_radius_m)
        self.authorized_grip_height_m = float(authorized_grip_height_m)
        self.sim_rate_hz = int(sim_rate_hz)
        self.record_live_video = bool(record_live_video)
        self.video_output = video_output.resolve()
        self.Gf = Gf
        self.Usd = Usd
        self.UsdGeom = UsdGeom
        self.UsdLux = UsdLux
        self.UsdPhysics = UsdPhysics
        self.overlay_component_paths = {
            "fixed_receptacle": OVERLAY_ROOT + "/FixedReceptacle",
            "body_assembly": OVERLAY_ROOT + "/LoosePlug/BodyAssembly",
            "coupling_nut": OVERLAY_ROOT + "/LoosePlug/CouplingNut",
        }
        self._sync_ops: dict[str, Any] = {}
        self._overlay_write_count = 0
        self._rep: Any | None = None
        self._camera: Any | None = None
        self._render_product: Any | None = None
        self._annotators: list[Any] = []
        self._rgb_annotator: Any | None = None
        self._depth_annotator: Any | None = None
        self._video_process: subprocess.Popen[bytes] | None = None
        self._video_frame_count = 0
        self._first_video_sim_time_s: float | None = None
        self._last_video_sim_time_s: float | None = None
        self._video_error: str | None = None
        self._camera_records: list[dict[str, Any]] = []
        self._milestones: dict[str, dict[str, Any]] = {}
        self._capture_initialized = False
        self._finalized = False
        self._timeline: Any | None = None
        self._timeline_resume_count = 0
        self._debug_monitor: _FullRobotCadMonitor | None = None
        self._debug_rows: list[dict[str, Any]] = []
        self._latest_debug_metrics: dict[str, Any] | None = None
        self._debug_contact_ops: list[tuple[Any, Any, Any, Any]] = []
        self._debug_grip_op: Any | None = None
        self._physical_signature_before = self._physical_dynamics_signature()
        self.overlay_audit = self._author_overlay()
        if self.visual_mode == "collision_debug":
            connector_visual_bounds = self._visual_component_local_bounds()
            self._debug_monitor = _FullRobotCadMonitor(
                repository=self.repository,
                urdf_path=self.source_robot_urdf,
                table_center_m=self.table_center_m,
                table_size_m=self.table_size_m,
                grip_center_local_m=self.authorized_grip_local_center_m,
                grip_radius_m=self.authorized_grip_radius_m,
                grip_height_m=self.authorized_grip_height_m,
                connector_visual_local_bounds_m=connector_visual_bounds,
            )
            self._author_collision_debug_overlay()
            self.overlay_audit["connector_visual_local_bounds_m"] = (
                connector_visual_bounds
            )
            self.overlay_audit["collision_debug_geometry_role"] = (
                "RENDER_ONLY_SOURCE_COLLISION_MESHES_AND_CONTACT_GLYPHS"
            )
            self.overlay_audit["collision_debug_monitor_role"] = (
                "POST_STEP_MEASURED_STATE_DIAGNOSTIC_ONLY"
            )
            _write_json(self.output / "VISUAL_OVERLAY_AUDIT.json", self.overlay_audit)

    def _visual_component_local_bounds(self) -> dict[str, dict[str, list[float]]]:
        cache = self.UsdGeom.BBoxCache(
            self.Usd.TimeCode.Default(),
            [self.UsdGeom.Tokens.default_, self.UsdGeom.Tokens.render],
            useExtentsHint=True,
        )
        bounds: dict[str, dict[str, list[float]]] = {}
        for component in ("body_assembly", "coupling_nut"):
            prim = self.stage.GetPrimAtPath(self.overlay_component_paths[component])
            if not prim.IsValid():
                raise RuntimeError(f"visual component missing: {component}")
            box = cache.ComputeLocalBound(prim).ComputeAlignedBox()
            minimum = np.asarray(box.GetMin(), dtype=np.float64)
            maximum = np.asarray(box.GetMax(), dtype=np.float64)
            if (
                minimum.shape != (3,)
                or maximum.shape != (3,)
                or not np.all(np.isfinite(minimum))
                or not np.all(np.isfinite(maximum))
                or not np.all(maximum > minimum)
            ):
                raise RuntimeError(f"invalid visual component bounds: {component}")
            bounds[component] = {
                "minimum_m": [float(value) for value in minimum],
                "maximum_m": [float(value) for value in maximum],
            }
        return bounds

    def _physical_dynamics_signature(self) -> dict[str, Any]:
        rows: list[dict[str, Any]] = []
        for owner, root_path in self.physical_paths.items():
            root = self.stage.GetPrimAtPath(root_path)
            if not root.IsValid():
                raise RuntimeError(f"physical connector root is missing: {root_path}")
            for prim in self.Usd.PrimRange(root):
                row: dict[str, Any] = {"owner": owner, "path": str(prim.GetPath())}
                relevant = False
                if prim.HasAPI(self.UsdPhysics.CollisionAPI):
                    relevant = True
                    row["collision_enabled"] = self.UsdPhysics.CollisionAPI(
                        prim
                    ).GetCollisionEnabledAttr().Get()
                if prim.HasAPI(self.UsdPhysics.RigidBodyAPI):
                    relevant = True
                    row["rigid_body_enabled"] = self.UsdPhysics.RigidBodyAPI(
                        prim
                    ).GetRigidBodyEnabledAttr().Get()
                if prim.HasAPI(self.UsdPhysics.MassAPI):
                    relevant = True
                    row["mass_kg"] = self.UsdPhysics.MassAPI(prim).GetMassAttr().Get()
                if relevant:
                    rows.append(row)
        encoded = json.dumps(rows, sort_keys=True, default=str).encode("utf-8")
        return {
            "row_count": len(rows),
            "sha256": hashlib.sha256(encoded).hexdigest(),
        }

    def _read_visual_metadata(self) -> dict[str, Any]:
        visual_stage = self.Usd.Stage.Open(str(self.visual_asset))
        if visual_stage is None:
            raise RuntimeError("failed to open D38999_VISUAL_COMPLETE_V1")
        prim = visual_stage.GetPrimAtPath(VISUAL_METADATA_PRIM)
        if not prim.IsValid():
            raise RuntimeError("visual metadata prim is missing")
        names = (
            "kcg:representationId",
            "kcg:referenceSourcePath",
            "kcg:referenceSourceSha256",
            "kcg:visibleGeometryPreserved",
            "kcg:visiblePinCount",
            "kcg:visibleSocketCount",
            "kcg:visibleThreadPreserved",
            "kcg:visibleDetentTeethPreserved",
            "kcg:visibleSealsPreserved",
            "kcg:readOnlyReference",
            "kcg:completeRobotAssemblyMainlineAllowed",
        )
        return {
            name: prim.GetAttribute(name).Get()
            for name in names
            if prim.HasAttribute(name)
        }

    def _author_overlay(self) -> dict[str, Any]:
        if not self.visual_asset.is_file() or not self.physical_asset.is_file():
            raise FileNotFoundError("visual or physical connector asset is missing")
        metadata = self._read_visual_metadata()
        source_relative = str(metadata["kcg:referenceSourcePath"])
        reference_source = (self.repository / source_relative).resolve()
        if _sha256(reference_source) != str(metadata["kcg:referenceSourceSha256"]):
            raise RuntimeError("visual reference source SHA-256 changed")

        overlay = self.UsdGeom.Xform.Define(self.stage, OVERLAY_ROOT).GetPrim()
        overlay.GetReferences().AddReference(
            str(self.visual_asset), VISUAL_PAIR_SOURCE_PRIM
        )
        component_validity = {}
        for name, path in self.overlay_component_paths.items():
            prim = self.stage.GetPrimAtPath(path)
            component_validity[name] = prim.IsValid()
            if not prim.IsValid():
                raise RuntimeError(f"visual overlay component missing: {path}")
            xform = self.UsdGeom.Xformable(prim)
            xform.SetResetXformStack(True)
            self._sync_ops[name] = xform.AddTransformOp(
                precision=self.UsdGeom.XformOp.PrecisionDouble,
                opSuffix="visualSync",
            )

        raw_counts = {"collision": 0, "rigid_body": 0, "mass": 0, "joint": 0}
        disabled_counts = {"collision": 0, "rigid_body": 0, "mass": 0, "joint": 0}
        for prim in self.Usd.PrimRange(overlay):
            if prim.HasAPI(self.UsdPhysics.CollisionAPI):
                raw_counts["collision"] += 1
                self.UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(
                    False
                ).Set(False)
                prim.RemoveAPI(self.UsdPhysics.CollisionAPI)
                disabled_counts["collision"] += 1
            if prim.HasAPI(self.UsdPhysics.RigidBodyAPI):
                raw_counts["rigid_body"] += 1
                self.UsdPhysics.RigidBodyAPI(prim).CreateRigidBodyEnabledAttr(
                    False
                ).Set(False)
                prim.RemoveAPI(self.UsdPhysics.RigidBodyAPI)
                disabled_counts["rigid_body"] += 1
            if prim.HasAPI(self.UsdPhysics.MassAPI):
                raw_counts["mass"] += 1
                prim.RemoveAPI(self.UsdPhysics.MassAPI)
                disabled_counts["mass"] += 1
            if prim.IsA(self.UsdPhysics.Joint):
                raw_counts["joint"] += 1
                self.UsdPhysics.Joint(prim).CreateJointEnabledAttr(False).Set(False)
                disabled_counts["joint"] += 1

        remaining_counts = {"collision": 0, "rigid_body": 0, "mass": 0}
        enabled_joint_count = 0
        for prim in self.Usd.PrimRange(overlay):
            remaining_counts["collision"] += int(
                prim.HasAPI(self.UsdPhysics.CollisionAPI)
            )
            remaining_counts["rigid_body"] += int(
                prim.HasAPI(self.UsdPhysics.RigidBodyAPI)
            )
            remaining_counts["mass"] += int(prim.HasAPI(self.UsdPhysics.MassAPI))
            if prim.IsA(self.UsdPhysics.Joint):
                enabled_joint_count += int(
                    self.UsdPhysics.Joint(prim).GetJointEnabledAttr().Get() is not False
                )
        if any(remaining_counts.values()) or enabled_joint_count:
            raise RuntimeError(
                "visual overlay retained active physics schemas: "
                f"{remaining_counts}, joints={enabled_joint_count}"
            )

        hidden_physical_paths = []
        for root_path in self.physical_paths.values():
            imageable = self.UsdGeom.Imageable(self.stage.GetPrimAtPath(root_path))
            imageable.MakeInvisible()
            hidden_physical_paths.append(root_path)
        terminal_collision_render_paths: dict[str, list[str]] = {}
        role_paths = {
            "PAD": self.pad_paths,
            "TIP": self.tip_paths,
            "SIDE": self.side_paths,
        }
        role_colors = {
            "PAD": self.Gf.Vec3f(0.0, 0.447, 0.698),
            "TIP": self.Gf.Vec3f(0.835, 0.369, 0.0),
            "SIDE": self.Gf.Vec3f(0.902, 0.624, 0.0),
        }
        for role, paths in role_paths.items():
            terminal_collision_render_paths[role] = []
            for path in paths.values():
                prim = self.stage.GetPrimAtPath(path)
                imageable = self.UsdGeom.Imageable(prim)
                if self.visual_mode == "collision_debug":
                    imageable.MakeVisible()
                    gprim = self.UsdGeom.Gprim(prim)
                    gprim.CreateDisplayColorAttr([role_colors[role]])
                    gprim.CreateDisplayOpacityAttr([0.48])
                else:
                    imageable.MakeInvisible()
                terminal_collision_render_paths[role].append(path)

        semantic_label_status = "APPLIED"
        try:
            from pxr import UsdSemantics

            for path, label in (
                (self.overlay_component_paths["body_assembly"], "connector_body"),
                (self.overlay_component_paths["coupling_nut"], "connector_nut"),
            ):
                labels = UsdSemantics.LabelsAPI.Apply(
                    self.stage.GetPrimAtPath(path), "class"
                )
                labels.CreateLabelsAttr().Set([label])
        except Exception as error:
            semantic_label_status = f"UNAVAILABLE_{type(error).__name__}: {error}"

        physical_after = self._physical_dynamics_signature()
        physical_unchanged = physical_after == self._physical_signature_before
        if not physical_unchanged:
            raise RuntimeError("visual overlay changed the physical connector signature")

        visible_counts = {
            "complete_plug_shell_root": int(
                self.stage.GetPrimAtPath(
                    self.overlay_component_paths["body_assembly"] + "/MatingShell"
                ).IsValid()
            ),
            "coupling_nut_root": int(component_validity["coupling_nut"]),
            "pin_visual_structures": int(metadata["kcg:visiblePinCount"]),
            "socket_visual_structures": int(metadata["kcg:visibleSocketCount"]),
            "thread_visual_preserved": bool(metadata["kcg:visibleThreadPreserved"]),
            "detent_visual_preserved": bool(
                metadata["kcg:visibleDetentTeethPreserved"]
            ),
            "seal_visual_preserved": bool(metadata["kcg:visibleSealsPreserved"]),
            "polarizing_key_root": int(
                any(
                    "PolarizingKeys" in str(prim.GetPath())
                    for prim in self.Usd.PrimRange(overlay)
                )
            ),
        }
        audit = {
            "schema": SCHEMA,
            "status": "VISUAL_OVERLAY_STATIC_PASS",
            "scope": "LIVE_RENDER_ONLY_NOT_PHYSICAL_CONTROL",
            "visual_asset": str(self.visual_asset),
            "visual_asset_sha256": _sha256(self.visual_asset),
            "visual_reference_source": str(reference_source),
            "visual_reference_source_sha256": _sha256(reference_source),
            "physical_asset": str(self.physical_asset),
            "physical_asset_sha256": _sha256(self.physical_asset),
            "visual_metadata": metadata,
            "visual_component_validity": component_validity,
            "visual_physics_api_count_before_disable": raw_counts,
            "visual_physics_api_disabled_count": disabled_counts,
            "visual_collision_api_count_after_disable": remaining_counts[
                "collision"
            ],
            "visual_rigid_body_api_count_after_disable": remaining_counts[
                "rigid_body"
            ],
            "visual_mass_api_count_after_disable": remaining_counts["mass"],
            "visual_enabled_joint_count_after_disable": enabled_joint_count,
            "visible_component_counts": visible_counts,
            "synchronization_parent_mapping": {
                self.overlay_component_paths[name]: physical_path
                for name, physical_path in self.physical_paths.items()
            },
            "synchronization_granularity": "THREE_PARENT_ROOTS_ONLY",
            "overlay_write_role": "VISUAL_OVERLAY_WRITE_ONLY",
            "physical_dynamics_signature_before": self._physical_signature_before,
            "physical_dynamics_signature_after": physical_after,
            "physical_dynamics_unchanged": physical_unchanged,
            "physical_connector_hidden_from_render_only": hidden_physical_paths,
            "terminal_collision_render_paths": terminal_collision_render_paths,
            "terminal_collision_sources_visible_in_debug": (
                self.visual_mode == "collision_debug"
            ),
            "visual_mode": self.visual_mode,
            "semantic_label_status": semantic_label_status,
            "online_controller_observation_changed": False,
            "physical_object_pose_write_count_changed": False,
            "visual_overlay_write_count": 0,
        }
        _write_json(self.output / "VISUAL_OVERLAY_AUDIT.json", audit)
        return audit

    def _author_collision_debug_overlay(self) -> None:
        debug_root = OVERLAY_ROOT + "/CollisionDebug"
        self.UsdGeom.Xform.Define(self.stage, debug_root)

        table = self.UsdGeom.Cube.Define(
            self.stage, debug_root + "/TableCollisionVolume"
        )
        table.CreateSizeAttr(1.0)
        table.CreateDisplayColorAttr([self.Gf.Vec3f(0.0, 0.62, 0.28)])
        table.CreateDisplayOpacityAttr([0.16])
        table_xform = self.UsdGeom.Xformable(table.GetPrim())
        table_xform.AddTranslateOp().Set(
            self.Gf.Vec3d(*[float(value) for value in self.table_center_m])
        )
        table_xform.AddScaleOp().Set(
            self.Gf.Vec3f(*[float(value) for value in self.table_size_m])
        )

        grip = self.UsdGeom.Cylinder.Define(
            self.stage, debug_root + "/AuthorizedGripCollision"
        )
        grip.CreateAxisAttr(self.UsdGeom.Tokens.z)
        grip.CreateRadiusAttr(self.authorized_grip_radius_m)
        grip.CreateHeightAttr(self.authorized_grip_height_m)
        grip.CreateDisplayColorAttr([self.Gf.Vec3f(0.58, 0.20, 0.82)])
        grip.CreateDisplayOpacityAttr([0.28])
        self._debug_grip_op = self.UsdGeom.Xformable(grip.GetPrim()).AddTransformOp(
            precision=self.UsdGeom.XformOp.PrecisionDouble,
            opSuffix="visualDebugSync",
        )

        for index in range(3):
            sphere = self.UsdGeom.Sphere.Define(
                self.stage, f"{debug_root}/Contact_{index + 1}/Point"
            )
            sphere.CreateRadiusAttr(0.0015)
            sphere.CreateDisplayColorAttr([self.Gf.Vec3f(0.92, 0.0, 0.72)])
            sphere.CreateDisplayOpacityAttr([0.95])
            sphere_imageable = self.UsdGeom.Imageable(sphere.GetPrim())
            sphere_imageable.MakeInvisible()
            sphere_op = self.UsdGeom.Xformable(sphere.GetPrim()).AddTransformOp(
                precision=self.UsdGeom.XformOp.PrecisionDouble,
                opSuffix="contactSync",
            )

            arrow = self.UsdGeom.Cylinder.Define(
                self.stage, f"{debug_root}/Contact_{index + 1}/Normal"
            )
            arrow.CreateAxisAttr(self.UsdGeom.Tokens.z)
            arrow.CreateRadiusAttr(0.00055)
            arrow.CreateHeightAttr(0.018)
            arrow.CreateDisplayColorAttr([self.Gf.Vec3f(0.92, 0.0, 0.72)])
            arrow.CreateDisplayOpacityAttr([0.9])
            arrow_imageable = self.UsdGeom.Imageable(arrow.GetPrim())
            arrow_imageable.MakeInvisible()
            arrow_op = self.UsdGeom.Xformable(arrow.GetPrim()).AddTransformOp(
                precision=self.UsdGeom.XformOp.PrecisionDouble,
                opSuffix="normalSync",
            )
            self._debug_contact_ops.append(
                (sphere_op, arrow_op, sphere_imageable, arrow_imageable)
            )

    def _update_contact_debug(self, contacts: Mapping[str, Any]) -> None:
        contact_rows = [
            contacts.get("pad", {}).get(name, {})
            for name in sorted(self.pad_paths)
        ]
        for index, (sphere_op, arrow_op, sphere_imageable, arrow_imageable) in enumerate(
            self._debug_contact_ops
        ):
            record = contact_rows[index] if index < len(contact_rows) else {}
            point = record.get("contact_point_m")
            normal = record.get("contact_normal")
            if point is None or normal is None:
                sphere_imageable.MakeInvisible()
                arrow_imageable.MakeInvisible()
                continue
            point_array = np.asarray(point, dtype=np.float64)
            normal_array = _unit(normal, (0.0, 0.0, 1.0))
            sphere_matrix = self.Gf.Matrix4d(1.0)
            sphere_matrix.SetTranslateOnly(
                self.Gf.Vec3d(*[float(value) for value in point_array])
            )
            sphere_op.Set(sphere_matrix)
            arrow_matrix = self.Gf.Matrix4d(1.0)
            arrow_matrix.SetRotate(
                self.Gf.Rotation(
                    self.Gf.Vec3d(0.0, 0.0, 1.0),
                    self.Gf.Vec3d(*[float(value) for value in normal_array]),
                ).GetQuat()
            )
            arrow_center = point_array + 0.009 * normal_array
            arrow_matrix.SetTranslateOnly(
                self.Gf.Vec3d(*[float(value) for value in arrow_center])
            )
            arrow_op.Set(arrow_matrix)
            sphere_imageable.MakeVisible()
            arrow_imageable.MakeVisible()

    def _pose_matrix(
        self, position_m: Sequence[float], orientation_wxyz: Sequence[float]
    ) -> Any:
        position = np.asarray(position_m, dtype=np.float64)
        quaternion = np.asarray(orientation_wxyz, dtype=np.float64)
        matrix = self.Gf.Matrix4d(1.0)
        matrix.SetRotate(
            self.Gf.Quatd(
                float(quaternion[0]),
                self.Gf.Vec3d(
                    float(quaternion[1]),
                    float(quaternion[2]),
                    float(quaternion[3]),
                ),
            )
        )
        matrix.SetTranslateOnly(
            self.Gf.Vec3d(
                float(position[0]), float(position[1]), float(position[2])
            )
        )
        return matrix

    def sync(
        self,
        *,
        body_position_m: Sequence[float],
        body_orientation_wxyz: Sequence[float],
        nut_position_m: Sequence[float],
        nut_orientation_wxyz: Sequence[float],
    ) -> None:
        cache = self.UsdGeom.XformCache(self.Usd.TimeCode.Default())
        fixed_matrix = cache.GetLocalToWorldTransform(
            self.stage.GetPrimAtPath(self.physical_paths["fixed_receptacle"])
        )
        matrices = {
            "fixed_receptacle": fixed_matrix,
            "body_assembly": self._pose_matrix(
                body_position_m, body_orientation_wxyz
            ),
            "coupling_nut": self._pose_matrix(
                nut_position_m, nut_orientation_wxyz
            ),
        }
        for name, matrix in matrices.items():
            path = self.overlay_component_paths[name]
            if not path.startswith(OVERLAY_ROOT + "/"):
                raise RuntimeError("refusing non-overlay transform write")
            self._sync_ops[name].Set(matrix)
            self._overlay_write_count += 1
        if self._debug_grip_op is not None:
            nut_pose = _pose_matrix(nut_position_m, nut_orientation_wxyz)
            center_world = (
                nut_pose[:3, :3] @ self.authorized_grip_local_center_m
                + nut_pose[:3, 3]
            )
            self._debug_grip_op.Set(
                self._pose_matrix(center_world, nut_orientation_wxyz)
            )

    def initialize_capture(self) -> None:
        dome = self.UsdLux.DomeLight.Define(
            self.stage, "/World/BFullIiwaLiveFill"
        )
        dome.CreateIntensityAttr(850.0)
        dome.CreateColorAttr(self.Gf.Vec3f(0.94, 0.97, 1.0))
        key = self.UsdLux.DistantLight.Define(
            self.stage, "/World/BFullIiwaLiveKey"
        )
        key.CreateIntensityAttr(1700.0)
        key.CreateColorAttr(self.Gf.Vec3f(1.0, 0.91, 0.82))
        self.UsdGeom.Xformable(key).AddRotateXYZOp().Set(
            self.Gf.Vec3f(-38.0, 28.0, 32.0)
        )
        if not self.record_live_video:
            self._capture_initialized = True
            return

        import omni.replicator.core as rep
        import omni.timeline

        self._rep = rep
        self._timeline = omni.timeline.get_timeline_interface()
        self._camera = self.UsdGeom.Camera.Define(self.stage, LIVE_CAMERA_PATH)
        self._camera.CreateFocalLengthAttr(32.0)
        self._camera.CreateHorizontalApertureAttr(20.955)
        self._camera.CreateVerticalApertureAttr(
            20.955 * LIVE_RESOLUTION[1] / LIVE_RESOLUTION[0]
        )
        self._camera.CreateClippingRangeAttr(self.Gf.Vec2f(0.02, 8.0))
        self._render_product = rep.create.render_product(
            self._camera.GetPrim(),
            LIVE_RESOLUTION,
            name="BFullIiwaLiveRenderProduct",
        )
        self._rgb_annotator = rep.AnnotatorRegistry.get_annotator("rgb")
        self._depth_annotator = rep.AnnotatorRegistry.get_annotator(
            "distance_to_image_plane"
        )
        self._annotators = [self._rgb_annotator, self._depth_annotator]
        for annotator in self._annotators:
            annotator.attach([self._render_product.path])
        self._set_camera(
            eye_m=FULL_ASSEMBLY_OVERVIEW_EYE_M,
            target_m=FULL_ASSEMBLY_OVERVIEW_TARGET_M,
        )
        for _ in range(2):
            self._render_once()
        self._start_video_encoder()
        self._capture_initialized = True

    def _set_camera(
        self, *, eye_m: Sequence[float], target_m: Sequence[float]
    ) -> None:
        from isaacsim.core.rendering_manager import ViewportManager

        ViewportManager.set_camera_view(
            camera=self._camera,
            eye=np.asarray(eye_m, dtype=np.float64),
            target=np.asarray(target_m, dtype=np.float64),
        )

    def _render_once(self) -> tuple[np.ndarray, np.ndarray]:
        if self._rep is None:
            raise RuntimeError("live Replicator capture was not initialized")
        self._rep.orchestrator.step(
            rt_subframes=1,
            delta_time=0.0,
            pause_timeline=True,
        )
        rgba = np.asarray(self._rgb_annotator.get_data())
        depth = np.asarray(self._depth_annotator.get_data(), dtype=np.float64)
        if rgba.ndim != 3 or rgba.shape[:2] != LIVE_RESOLUTION[::-1] or rgba.shape[2] < 3:
            raise RuntimeError(f"invalid live RGB frame: {rgba.shape}")
        depth = np.squeeze(depth)
        if depth.shape != LIVE_RESOLUTION[::-1]:
            raise RuntimeError(f"invalid live depth frame: {depth.shape}")
        if self._timeline is not None and not self._timeline.is_playing():
            self._timeline.play()
            self._timeline_resume_count += 1
        return np.asarray(rgba[:, :, :3], dtype=np.uint8), depth

    def _start_video_encoder(self) -> None:
        self.video_output.parent.mkdir(parents=True, exist_ok=True)
        command = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "rawvideo",
            "-pix_fmt",
            "rgb24",
            "-s",
            f"{LIVE_RESOLUTION[0]}x{LIVE_RESOLUTION[1]}",
            "-r",
            str(VIDEO_FPS),
            "-i",
            "-",
            "-an",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "21",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(self.video_output),
        ]
        self._video_process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

    def _annotate_frame(
        self, rgb: np.ndarray, phase: str, sim_time_s: float
    ) -> np.ndarray:
        if self.visual_mode == "clean":
            return np.asarray(rgb, dtype=np.uint8)
        from PIL import Image, ImageDraw, ImageFont

        image = Image.fromarray(rgb, "RGB")
        draw = ImageDraw.Draw(image, "RGBA")
        metrics = self._latest_debug_metrics or {}
        table_gap = metrics.get("minimum_full_robot_visual_cad_table_clearance_m")
        connector_table_gap = metrics.get(
            "minimum_connector_visual_cad_table_clearance_m"
        )
        connector_penetration = metrics.get(
            "maximum_authorized_pad_cad_penetration_m"
        )
        unauthorized = metrics.get("unauthorized_contact_count", 0)
        text_rows = [
            f"LIVE PHYSICS / COLLISION DEBUG | {phase} | sim {sim_time_s:07.3f} s",
            "Robot CAD -> table min: "
            + ("n/a" if table_gap is None else f"{1000.0 * float(table_gap):+.3f} mm"),
            "Connector CAD -> table min: "
            + (
                "n/a"
                if connector_table_gap is None
                else f"{1000.0 * float(connector_table_gap):+.3f} mm"
            ),
            "Authorized PAD -> connector max penetration: "
            + (
                "n/a"
                if connector_penetration is None
                else f"{1000.0 * float(connector_penetration):.3f} mm"
            )
            + f" | unauthorized contacts: {int(unauthorized)}",
        ]
        try:
            font = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 22
            )
        except OSError:
            font = ImageFont.load_default()
        line_boxes = [draw.textbbox((0, 0), row, font=font) for row in text_rows]
        width = max(box[2] for box in line_boxes)
        line_height = max(box[3] - box[1] for box in line_boxes) + 7
        draw.rounded_rectangle(
            (18, 16, 42 + width, 31 + line_height * len(text_rows)),
            radius=8,
            fill=(0, 0, 0, 175),
        )
        for index, row in enumerate(text_rows):
            draw.text(
                (28, 23 + index * line_height),
                row,
                fill=(255, 255, 255, 255),
                font=font,
            )
        return np.asarray(image, dtype=np.uint8)

    def maybe_record_frame(
        self,
        *,
        phase: str,
        physics_step: int,
        sim_time_s: float,
        joint_positions_rad: Mapping[str, float],
        body_position_m: Sequence[float],
        body_orientation_wxyz: Sequence[float],
        nut_position_m: Sequence[float],
        nut_orientation_wxyz: Sequence[float],
        contacts: Mapping[str, Any],
    ) -> None:
        if not self._capture_initialized:
            return
        if self._debug_monitor is not None:
            self._update_contact_debug(contacts)
            metrics = self._debug_monitor.measure(
                joint_positions_rad=joint_positions_rad,
                body_position_m=body_position_m,
                body_orientation_wxyz=body_orientation_wxyz,
                nut_position_m=nut_position_m,
                nut_orientation_wxyz=nut_orientation_wxyz,
                contacts=contacts,
            )
            self._latest_debug_metrics = metrics
            pad_gaps = metrics["pad_authorized_grip_sampled_sdf_m"]
            self._debug_rows.append(
                {
                    "step": int(physics_step),
                    "phase": phase,
                    "sim_time_s": float(sim_time_s),
                    "minimum_full_robot_visual_cad_table_clearance_m": metrics[
                        "minimum_full_robot_visual_cad_table_clearance_m"
                    ],
                    "minimum_table_clearance_link": metrics[
                        "minimum_table_clearance_link"
                    ],
                    "body_assembly_visual_cad_table_clearance_m": metrics[
                        "connector_visual_cad_table_clearance_m"
                    ]["body_assembly"],
                    "coupling_nut_visual_cad_table_clearance_m": metrics[
                        "connector_visual_cad_table_clearance_m"
                    ]["coupling_nut"],
                    "minimum_connector_visual_cad_table_clearance_m": metrics[
                        "minimum_connector_visual_cad_table_clearance_m"
                    ],
                    "minimum_connector_table_clearance_component": metrics[
                        "minimum_connector_table_clearance_component"
                    ],
                    "maximum_connector_visual_cad_table_penetration_m": metrics[
                        "maximum_connector_visual_cad_table_penetration_m"
                    ],
                    "f1_pad_authorized_grip_sampled_sdf_m": pad_gaps[
                        "f1Link3"
                    ],
                    "f2_pad_authorized_grip_sampled_sdf_m": pad_gaps[
                        "f2Link2"
                    ],
                    "f3_pad_authorized_grip_sampled_sdf_m": pad_gaps[
                        "f3Link3"
                    ],
                    "maximum_authorized_pad_cad_penetration_m": metrics[
                        "maximum_authorized_pad_cad_penetration_m"
                    ],
                    "minimum_tip_side_authorized_grip_sampled_sdf_m": metrics[
                        "minimum_tip_side_authorized_grip_sampled_sdf_m"
                    ],
                    "maximum_tip_side_authorized_grip_cad_penetration_m": metrics[
                        "maximum_tip_side_authorized_grip_cad_penetration_m"
                    ],
                    "maximum_unauthorized_physx_penetration_m": metrics[
                        "maximum_unauthorized_physx_penetration_m"
                    ],
                    "unauthorized_contact_count": metrics[
                        "unauthorized_contact_count"
                    ],
                }
            )
        if not self.record_live_video:
            return
        stride = self.sim_rate_hz // VIDEO_FPS
        if self.sim_rate_hz % VIDEO_FPS != 0:
            raise RuntimeError("simulation rate must be divisible by video FPS")
        if (physics_step - 1) % stride != 0:
            return
        try:
            rgb, _depth = self._render_once()
            frame = self._annotate_frame(rgb, phase, sim_time_s)
            if self._video_process is None or self._video_process.stdin is None:
                raise RuntimeError("video encoder stdin is unavailable")
            self._video_process.stdin.write(np.ascontiguousarray(frame).tobytes())
            self._video_frame_count += 1
            if self._first_video_sim_time_s is None:
                self._first_video_sim_time_s = sim_time_s
            self._last_video_sim_time_s = sim_time_s
        except Exception as error:
            self._video_error = f"{type(error).__name__}: {error}"

    def _object_aabb(self) -> tuple[np.ndarray, np.ndarray]:
        purposes = [self.UsdGeom.Tokens.default_, self.UsdGeom.Tokens.render]
        cache = self.UsdGeom.BBoxCache(self.Usd.TimeCode.Default(), purposes)
        ranges = []
        for name in ("body_assembly", "coupling_nut"):
            prim = self.stage.GetPrimAtPath(self.overlay_component_paths[name])
            ranges.append(cache.ComputeWorldBound(prim).ComputeAlignedRange())
        minimum = np.min(
            np.asarray(
                [[float(value) for value in item.GetMin()] for item in ranges],
                dtype=np.float64,
            ),
            axis=0,
        )
        maximum = np.max(
            np.asarray(
                [[float(value) for value in item.GetMax()] for item in ranges],
                dtype=np.float64,
            ),
            axis=0,
        )
        if not np.all(np.isfinite(minimum)) or not np.all(np.isfinite(maximum)):
            raise RuntimeError("visual object AABB is non-finite")
        return minimum, maximum

    def _pad_centers(self) -> list[list[float]]:
        cache = self.UsdGeom.XformCache(self.Usd.TimeCode.Default())
        centers = []
        for name in sorted(self.pad_paths):
            matrix = cache.GetLocalToWorldTransform(
                self.stage.GetPrimAtPath(self.pad_paths[name])
            )
            centers.append(
                [float(value) for value in matrix.ExtractTranslation()]
            )
        return centers

    def capture_milestone(
        self,
        milestone: str,
        *,
        source_phase: str,
        physics_step: int,
        sim_time_s: float,
        contacts: Mapping[str, Any],
        tcp_position_world_m: Sequence[float],
    ) -> None:
        if not self.record_live_video or milestone in self._milestones:
            return
        if milestone not in MILESTONE_FILES:
            raise ValueError(f"unknown live milestone: {milestone}")
        minimum, maximum = self._object_aabb()
        object_center = 0.5 * (minimum + maximum)
        contact_points = [
            contacts["pad"][name]["contact_point_m"]
            for name in sorted(contacts["pad"])
            if contacts["pad"][name]["contact_point_m"] is not None
        ]
        contact_center = (
            np.mean(np.asarray(contact_points, dtype=np.float64), axis=0)
            if contact_points
            else object_center
        )
        tcp = np.asarray(tcp_position_world_m, dtype=np.float64)
        hand_direction = contact_center - tcp
        pad_centers = self._pad_centers()
        candidates = generate_camera_candidates(contact_center, hand_direction)
        candidate_reports = []
        for candidate in candidates:
            self._set_camera(eye_m=candidate.eye_m, target_m=candidate.target_m)
            rgb, depth = self._render_once()
            candidate_reports.append(
                score_camera_observation(
                    rgb=rgb,
                    depth_m=depth,
                    candidate=candidate,
                    object_aabb_min_m=minimum,
                    object_aabb_max_m=maximum,
                    pad_centers_world_m=pad_centers,
                    contact_center_world_m=contact_center,
                )
            )
        passing = [row for row in candidate_reports if row["passed"]]
        record: dict[str, Any] = {
            "milestone": milestone,
            "source_phase": source_phase,
            "physics_step": physics_step,
            "sim_time_s": sim_time_s,
            "object_aabb_min_m": minimum.tolist(),
            "object_aabb_max_m": maximum.tolist(),
            "contact_center_world_m": contact_center.tolist(),
            "pad_centers_world_m": pad_centers,
            "camera_candidate_count": len(candidate_reports),
            "camera_candidates": candidate_reports,
            "capture_role": "LIVE_CURRENT_STAGE_NO_POSE_REPLAY",
            "contact_truth_role": "VISUAL_CAMERA_AUDIT_ONLY_NOT_CONTROL",
            "passed": False,
            "output_png": None,
        }
        if passing:
            selected = max(passing, key=lambda item: float(item["score"]))
            self._set_camera(
                eye_m=selected["eye_m"], target_m=selected["target_m"]
            )
            rgb, depth = self._render_once()
            selected_candidate = CameraCandidate(
                candidate_id=str(selected["candidate_id"]),
                eye_m=tuple(float(value) for value in selected["eye_m"]),
                target_m=tuple(float(value) for value in selected["target_m"]),
                azimuth_deg=float(selected["azimuth_deg"]),
                elevation_deg=float(selected["elevation_deg"]),
                distance_m=float(selected["distance_m"]),
            )
            final_score = score_camera_observation(
                rgb=rgb,
                depth_m=depth,
                candidate=selected_candidate,
                object_aabb_min_m=minimum,
                object_aabb_max_m=maximum,
                pad_centers_world_m=pad_centers,
                contact_center_world_m=contact_center,
            )
            if final_score["passed"]:
                from PIL import Image

                annotated = self._annotate_frame(rgb, source_phase, sim_time_s)
                image_path = self.output / MILESTONE_FILES[milestone]
                Image.fromarray(annotated, "RGB").save(image_path, dpi=(300, 300))
                record.update(
                    {
                        "passed": True,
                        "output_png": image_path.name,
                        "output_sha256": _sha256(image_path),
                        "selected_camera": final_score,
                    }
                )
        self._milestones[milestone] = record
        self._camera_records.append(record)

    def _finish_video(self) -> dict[str, Any]:
        if self._video_process is not None:
            try:
                if self._video_process.stdin is not None:
                    self._video_process.stdin.close()
                stderr = b""
                if self._video_process.stderr is not None:
                    stderr = self._video_process.stderr.read()
                return_code = self._video_process.wait(timeout=30.0)
                if return_code != 0:
                    self._video_error = (
                        f"ffmpeg exit {return_code}: "
                        + stderr.decode("utf-8", errors="replace")[-2000:]
                    )
            except Exception as error:
                self._video_error = f"{type(error).__name__}: {error}"
                self._video_process.kill()
        probe: dict[str, Any] = {
            "path": str(self.video_output),
            "frame_count_written": self._video_frame_count,
            "encoder_error": self._video_error,
            "exists": self.video_output.is_file(),
        }
        if self.video_output.is_file():
            completed = subprocess.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-select_streams",
                    "v:0",
                    "-show_entries",
                    "stream=width,height,r_frame_rate,avg_frame_rate,nb_frames,duration",
                    "-of",
                    "json",
                    str(self.video_output),
                ],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            try:
                probe["ffprobe"] = json.loads(completed.stdout)
            except json.JSONDecodeError:
                probe["ffprobe_raw"] = completed.stdout
            streams = probe.get("ffprobe", {}).get("streams", [])
            if streams:
                rate_text = str(streams[0].get("avg_frame_rate", "0/1"))
                numerator, denominator = rate_text.split("/", 1)
                probe["reported_fps"] = float(numerator) / float(denominator)
            probe["sha256"] = _sha256(self.video_output)
            probe["size_bytes"] = self.video_output.stat().st_size
        probe["first_frame_sim_time_s"] = self._first_video_sim_time_s
        probe["last_frame_sim_time_s"] = self._last_video_sim_time_s
        probe["sim_time_span_s"] = (
            None
            if self._first_video_sim_time_s is None
            or self._last_video_sim_time_s is None
            else self._last_video_sim_time_s - self._first_video_sim_time_s
        )
        probe["encoded_duration_from_frame_count_s"] = (
            self._video_frame_count / float(VIDEO_FPS)
        )
        return probe

    def _finish_collision_debug_trace(self) -> dict[str, Any] | None:
        if self.visual_mode != "collision_debug":
            return None
        trace_path = self.output / COLLISION_DEBUG_TRACE
        fieldnames = tuple(self._debug_rows[0]) if self._debug_rows else (
            "step",
            "phase",
            "sim_time_s",
        )
        with trace_path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(self._debug_rows)
        if not self._debug_rows:
            summary = {
                "schema": SCHEMA,
                "status": "B_COLLISION_DEBUG_GEOMETRY_FAIL",
                "passed": False,
                "reason": "NO_POST_STEP_GEOMETRY_ROWS",
                "trace_csv": str(trace_path),
            }
        else:
            minimum_table = min(
                float(row["minimum_full_robot_visual_cad_table_clearance_m"])
                for row in self._debug_rows
            )
            minimum_connector_table = min(
                float(row["minimum_connector_visual_cad_table_clearance_m"])
                for row in self._debug_rows
            )
            maximum_pad_penetration = max(
                float(row["maximum_authorized_pad_cad_penetration_m"])
                for row in self._debug_rows
            )
            maximum_tip_side_penetration = max(
                float(row["maximum_tip_side_authorized_grip_cad_penetration_m"])
                for row in self._debug_rows
            )
            maximum_unauthorized_penetration = max(
                float(row["maximum_unauthorized_physx_penetration_m"])
                for row in self._debug_rows
            )
            unauthorized_rows = sum(
                int(row["unauthorized_contact_count"]) > 0
                for row in self._debug_rows
            )
            passed = bool(
                minimum_table >= -0.0001
                and minimum_connector_table >= -0.0001
                and maximum_pad_penetration <= 0.0002
                and maximum_tip_side_penetration <= 0.0002
                and maximum_unauthorized_penetration <= 0.0001
                and unauthorized_rows == 0
            )
            minimum_row = min(
                self._debug_rows,
                key=lambda row: float(
                    row["minimum_full_robot_visual_cad_table_clearance_m"]
                ),
            )
            minimum_connector_row = min(
                self._debug_rows,
                key=lambda row: float(
                    row["minimum_connector_visual_cad_table_clearance_m"]
                ),
            )
            summary = {
                "schema": SCHEMA,
                "status": "B_COLLISION_DEBUG_GEOMETRY_PASS"
                if passed
                else "B_COLLISION_DEBUG_GEOMETRY_FAIL",
                "passed": passed,
                "trace_csv": str(trace_path),
                "trace_sha256": _sha256(trace_path),
                "post_step_row_count": len(self._debug_rows),
                "minimum_full_robot_visual_cad_table_clearance_m": minimum_table,
                "minimum_table_clearance_link": minimum_row[
                    "minimum_table_clearance_link"
                ],
                "minimum_table_clearance_step": int(minimum_row["step"]),
                "minimum_connector_visual_cad_table_clearance_m": (
                    minimum_connector_table
                ),
                "minimum_connector_table_clearance_component": (
                    minimum_connector_row[
                        "minimum_connector_table_clearance_component"
                    ]
                ),
                "minimum_connector_table_clearance_step": int(
                    minimum_connector_row["step"]
                ),
                "maximum_connector_visual_cad_table_penetration_m": max(
                    0.0, -minimum_connector_table
                ),
                "maximum_authorized_pad_cad_penetration_m": maximum_pad_penetration,
                "maximum_tip_side_authorized_grip_cad_penetration_m": maximum_tip_side_penetration,
                "maximum_unauthorized_physx_penetration_m": maximum_unauthorized_penetration,
                "unauthorized_contact_row_count": unauthorized_rows,
                "thresholds_m": {
                    "maximum_robot_table_penetration": 0.0001,
                    "maximum_connector_table_penetration": 0.0001,
                    "maximum_authorized_pad_connector_penetration": 0.0002,
                    "maximum_tip_side_connector_penetration": 0.0002,
                    "maximum_other_unauthorized_penetration": 0.0001,
                },
                "geometry_metric_role": (
                    "FULL_ROBOT_VISUAL_CAD_TO_FINITE_TABLE_BOX_SAMPLED_SDF_AND_"
                    "FULL_CONNECTOR_VISUAL_CAD_LOCAL_OBB_TO_FINITE_TABLE_BOX_SDF_"
                    "AND_TERMINAL_CAD_SAMPLED_AUTHORIZED_CYLINDER_SDF"
                ),
                "physx_metric_role": (
                    "LIVE_POST_STEP_UNAUTHORIZED_CONTACT_MANIFOLD_SEPARATION"
                ),
                "online_controller_observation_changed": False,
                "object_pose_changes_commands": False,
            }
        _write_json(self.output / "LIVE_COLLISION_TRUTH_SUMMARY.json", summary)
        return summary

    def finalize(self) -> dict[str, Any]:
        if self._finalized:
            return json.loads(
                (self.output / "LIVE_CAPTURE_AUDIT.json").read_text(
                    encoding="utf-8"
                )
            ) if (self.output / "LIVE_CAPTURE_AUDIT.json").is_file() else {}
        self._finalized = True
        collision_debug = self._finish_collision_debug_trace()
        video = self._finish_video() if self.record_live_video else {
            "recording_requested": False
        }
        if self._render_product is not None:
            try:
                for annotator in self._annotators:
                    annotator.detach([self._render_product.path])
            finally:
                self._render_product.destroy()

        self.overlay_audit["visual_overlay_write_count"] = self._overlay_write_count
        self.overlay_audit["visual_overlay_write_role"] = "VISUAL_OVERLAY_WRITE_ONLY"
        self.overlay_audit["render_pause_timeline_resume_count"] = (
            self._timeline_resume_count
        )
        self.overlay_audit["physical_object_pose_write_after_physics_count"] = 0
        if collision_debug is not None:
            self.overlay_audit["collision_debug"] = collision_debug
        _write_json(self.output / "VISUAL_OVERLAY_AUDIT.json", self.overlay_audit)
        if not self.record_live_video:
            return self.overlay_audit

        expected = tuple(MILESTONE_FILES)
        all_milestones = all(
            name in self._milestones and bool(self._milestones[name]["passed"])
            for name in expected
        )
        video_passed = bool(
            video.get("exists")
            and self._video_frame_count > 0
            and self._video_error is None
            and float(video.get("reported_fps", 0.0)) >= float(VIDEO_FPS)
        )
        geometry_passed = bool(
            self.visual_mode != "collision_debug"
            or (collision_debug is not None and collision_debug.get("passed"))
        )
        audit = {
            "schema": SCHEMA,
            "status": "B_FULL_IIWA_LIVE_CAPTURE_PASS"
            if all_milestones and video_passed and geometry_passed
            else "B_FULL_IIWA_LIVE_CAPTURE_FAIL",
            "passed": bool(all_milestones and video_passed and geometry_passed),
            "scope": "VISUALIZATION_ONLY_REPLAY_OF_SAME_CONTROLLER",
            "source": "FULL_IIWA_TABLE_PICK_LIVE_CURRENT_STAGE",
            "visual_mode": self.visual_mode,
            "posthoc_pose_replay_used": False,
            "physical_controller_changed": False,
            "physical_object_pose_write_after_physics_count": 0,
            "overlay_write_role": "VISUAL_OVERLAY_WRITE_ONLY",
            "overlay_write_count": self._overlay_write_count,
            "render_pause_timeline_resume_count": self._timeline_resume_count,
            "render_resolution_px": list(LIVE_RESOLUTION),
            "video_output_fps": VIDEO_FPS,
            "video": video,
            "collision_debug": collision_debug,
            "milestones": [
                self._milestones.get(
                    name,
                    {
                        "milestone": name,
                        "passed": False,
                        "reason": "MILESTONE_NOT_REACHED",
                    },
                )
                for name in expected
            ],
            "camera_gate": {
                "minimum_candidate_count": 8,
                "near_black_fraction_maximum": 0.35,
                "object_complete_required": True,
                "minimum_visible_pad_count": 2,
                "contact_region_not_fully_occluded_required": True,
            },
        }
        _write_json(self.output / "CAMERA_PARAMETERS.json", {
            "schema": SCHEMA,
            "camera_prim_path": LIVE_CAMERA_PATH,
            "resolution_px": list(LIVE_RESOLUTION),
            "focal_length_mm": 32.0,
            "horizontal_aperture_mm": 20.955,
            "views": self._camera_records,
        })
        manifest_path = self.output / "LIVE_CAPTURE_MANIFEST.csv"
        with manifest_path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=(
                    "milestone",
                    "filename",
                    "sha256",
                    "source_phase",
                    "physics_step",
                    "sim_time_s",
                    "camera_id",
                    "passed",
                    "evidence_role",
                ),
            )
            writer.writeheader()
            for name in expected:
                record = self._milestones.get(name, {})
                selected = record.get("selected_camera", {})
                writer.writerow(
                    {
                        "milestone": name,
                        "filename": record.get("output_png", ""),
                        "sha256": record.get("output_sha256", ""),
                        "source_phase": record.get("source_phase", ""),
                        "physics_step": record.get("physics_step", ""),
                        "sim_time_s": record.get("sim_time_s", ""),
                        "camera_id": selected.get("candidate_id", ""),
                        "passed": record.get("passed", False),
                        "evidence_role": "LIVE_CURRENT_STAGE_NO_POSE_REPLAY",
                    }
                )
        _write_json(self.output / "LIVE_CAPTURE_AUDIT.json", audit)
        return audit
