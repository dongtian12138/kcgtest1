"""Build the collision-free real-inertia hand rig used by G0."""

from __future__ import annotations

import copy
import hashlib
from pathlib import Path
from typing import Any, Sequence
import xml.etree.ElementTree as ET


HAND_LINKS = (
    "handbase_link",
    "f1Link1",
    "f1Link2",
    "f1Link3",
    "f2Link1",
    "f2Link2",
    "f3Link1",
    "f3Link2",
    "f3Link3",
)
HAND_JOINTS = (
    "f1j1",
    "f2j1",
    "f3j1",
    "f1j2",
    "f1j3",
    "f2j2",
    "f3j2",
    "f3j3",
)


def _digest(element: ET.Element) -> str:
    # ``ElementTree.indent`` only changes formatting whitespace.  Normalize
    # that whitespace so the audit compares inertial structure and numeric
    # attributes rather than serialization layout.
    normalized = copy.deepcopy(element)
    for node in normalized.iter():
        if node.text is not None and not node.text.strip():
            node.text = None
        if node.tail is not None and not node.tail.strip():
            node.tail = None
    return hashlib.sha256(ET.tostring(normalized, encoding="utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _fixed_base_link() -> ET.Element:
    link = ET.Element("link", {"name": "rig_base_link"})
    inertial = ET.SubElement(link, "inertial")
    ET.SubElement(inertial, "origin", {"xyz": "0 0 0", "rpy": "0 0 0"})
    ET.SubElement(inertial, "mass", {"value": "1"})
    ET.SubElement(
        inertial,
        "inertia",
        {
            "ixx": "1e-6",
            "ixy": "0",
            "ixz": "0",
            "iyy": "1e-6",
            "iyz": "0",
            "izz": "1e-6",
        },
    )
    return link


def build_collision_free_hand_urdf(
    *,
    source_urdf: Path,
    destination: Path,
    lift_effort_limit_n: float,
    handbase_origin_xyz_m: Sequence[float] = (0.0, 0.0, 0.0),
    handbase_origin_rpy_rad: Sequence[float] = (0.0, 0.0, 0.0),
    lift_axis_in_joint_frame: Sequence[float] = (0.0, 0.0, 1.0),
) -> dict[str, Any]:
    """Copy real hand topology/inertias and add one world-Z prismatic joint."""

    source_root = ET.parse(source_urdf).getroot()
    source_links = {str(link.get("name")): link for link in source_root.findall("link")}
    source_joints = {str(joint.get("name")): joint for joint in source_root.findall("joint")}
    output = ET.Element("robot", {"name": "d38999_b_goal_mode_g0"})
    output.append(_fixed_base_link())
    inertial_hashes: dict[str, str] = {}
    masses: dict[str, float] = {}
    removed_visual_count = 0
    removed_collision_count = 0

    for name in HAND_LINKS:
        source = source_links.get(name)
        if source is None:
            raise ValueError(f"source URDF missing hand link: {name}")
        copied = copy.deepcopy(source)
        inertial = copied.find("inertial")
        mass = copied.find("./inertial/mass")
        if inertial is None or mass is None:
            raise ValueError(f"source URDF missing real inertial or mass: {name}")
        inertial_hashes[name] = _digest(inertial)
        masses[name] = float(mass.get("value"))
        for visual in list(copied.findall("visual")):
            copied.remove(visual)
            removed_visual_count += 1
        for collision in list(copied.findall("collision")):
            copied.remove(collision)
            removed_collision_count += 1
        output.append(copied)

    lift = ET.SubElement(output, "joint", {"name": "lift_z", "type": "prismatic"})
    ET.SubElement(lift, "parent", {"link": "rig_base_link"})
    ET.SubElement(lift, "child", {"link": "handbase_link"})
    for name, vector in (
        ("handbase_origin_xyz_m", handbase_origin_xyz_m),
        ("handbase_origin_rpy_rad", handbase_origin_rpy_rad),
        ("lift_axis_in_joint_frame", lift_axis_in_joint_frame),
    ):
        if len(tuple(vector)) != 3:
            raise ValueError(f"{name} must have three entries")
    origin_xyz = tuple(float(value) for value in handbase_origin_xyz_m)
    origin_rpy = tuple(float(value) for value in handbase_origin_rpy_rad)
    lift_axis = tuple(float(value) for value in lift_axis_in_joint_frame)
    ET.SubElement(
        lift,
        "origin",
        {
            "xyz": " ".join(f"{value:.12g}" for value in origin_xyz),
            "rpy": " ".join(f"{value:.12g}" for value in origin_rpy),
        },
    )
    ET.SubElement(
        lift,
        "axis",
        {"xyz": " ".join(f"{value:.12g}" for value in lift_axis)},
    )
    ET.SubElement(
        lift,
        "limit",
        {
            "lower": "0",
            "upper": "0.060",
            "effort": f"{float(lift_effort_limit_n):.12g}",
            "velocity": "0.10",
        },
    )
    ET.SubElement(lift, "dynamics", {"damping": "0", "friction": "0"})

    for name in HAND_JOINTS:
        source = source_joints.get(name)
        if source is None:
            raise ValueError(f"source URDF missing hand joint: {name}")
        output.append(copy.deepcopy(source))

    destination.parent.mkdir(parents=True, exist_ok=True)
    tree = ET.ElementTree(output)
    ET.indent(tree, space="  ")
    tree.write(destination, encoding="utf-8", xml_declaration=True)

    check = ET.parse(destination).getroot()
    parented = {str(joint.find("child").get("link")) for joint in check.findall("joint")}
    roots = [str(link.get("name")) for link in check.findall("link") if link.get("name") not in parented]
    if roots != ["rig_base_link"]:
        raise AssertionError(f"G0 rig must have one root, got {roots}")
    for name in HAND_LINKS:
        copied = check.find(f"link[@name='{name}']")
        if copied is None or copied.findall("visual") or copied.findall("collision"):
            raise AssertionError(f"G0 rig retained geometry on {name}")
        inertial = copied.find("inertial")
        if inertial is None or _digest(inertial) != inertial_hashes[name]:
            raise AssertionError(f"G0 rig changed the real inertial on {name}")

    moved_mass = sum(masses.values())
    return {
        "schema": "D38999_B_GOAL_MODE_MINIMAL_HAND_RIG_V1",
        "source_urdf": str(source_urdf.resolve()),
        "source_urdf_sha256": file_sha256(source_urdf),
        "temporary_urdf": str(destination.resolve()),
        "root_links": roots,
        "moved_link_masses_kg": masses,
        "moved_mass_kg": moved_mass,
        "real_hand_inertials_preserved": True,
        "removed_visual_count": removed_visual_count,
        "removed_collision_count": removed_collision_count,
        "collision_count": 0,
        "lift_joint_count": 1,
        "lift_effort_limit_n": float(lift_effort_limit_n),
        "handbase_origin_xyz_m": list(origin_xyz),
        "handbase_origin_rpy_rad": list(origin_rpy),
        "lift_axis_in_joint_frame": list(lift_axis),
    }
