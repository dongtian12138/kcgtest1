"""Data-driven stability assessment for the frozen-target force quiet hold."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np


def _three_channel_matrix(
    values: Sequence[Sequence[float]], *, name: str, minimum_rows: int = 2
) -> np.ndarray:
    matrix = np.asarray(values, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[1] != 3 or matrix.shape[0] < minimum_rows:
        raise ValueError(
            f"{name} must contain at least {minimum_rows} rows and three channels"
        )
    if not np.all(np.isfinite(matrix)):
        raise ValueError(f"{name} must be finite")
    return matrix


def finite_difference_velocity(
    positions_rad: Sequence[Sequence[float]], *, dt_s: float
) -> np.ndarray:
    """Return adjacent-sample velocity without using generalized velocity."""

    positions = _three_channel_matrix(positions_rad, name="positions_rad")
    if not np.isfinite(dt_s) or dt_s <= 0.0:
        raise ValueError("dt_s must be finite and positive")
    return np.diff(positions, axis=0) / float(dt_s)


def _position_metrics(positions: np.ndarray, *, dt_s: float) -> dict[str, np.ndarray]:
    qdot_fd = np.diff(positions, axis=0) / float(dt_s)
    return {
        "position_peak_to_peak_rad": np.ptp(positions, axis=0),
        "position_end_minus_start_rad": positions[-1] - positions[0],
        "qdot_fd_rms_rad_s": np.sqrt(np.mean(np.square(qdot_fd), axis=0)),
    }


@dataclass(frozen=True)
class QuietHoldAssessment:
    passed: bool
    metrics: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {"passed": self.passed, **self.metrics}


def assess_force_quiet_hold(
    *,
    tare_positions_rad: Sequence[Sequence[float]],
    locked_positions_rad: Sequence[Sequence[float]],
    hold_positions_rad: Sequence[Sequence[float]],
    hold_raw_generalized_velocity_rad_s: Sequence[Sequence[float]],
    hold_target_positions_rad: Sequence[Sequence[float]],
    hold_estimated_force_n: Sequence[Sequence[float]],
    dt_s: float,
    target_force_n: float,
    force_tolerance_n: float,
    position_baseline_multiplier: float,
    qdot_fd_baseline_multiplier: float,
    maximum_position_peak_to_peak_rad: float,
    maximum_qdot_fd_rms_rad_s: float,
    raw_to_fd_diagnostic_ratio: float,
) -> QuietHoldAssessment:
    """Assess frozen-target stability from measured positions and their differences.

    Raw generalized velocity is deliberately reported but cannot change ``passed``.
    The acceptance thresholds are frozen before runtime and are the smaller of an
    absolute task bound and a multiple of same-run tare/locked baseline noise.
    """

    tare = _three_channel_matrix(tare_positions_rad, name="tare_positions_rad")
    locked = _three_channel_matrix(
        locked_positions_rad, name="locked_positions_rad"
    )
    hold = _three_channel_matrix(hold_positions_rad, name="hold_positions_rad")
    raw = _three_channel_matrix(
        hold_raw_generalized_velocity_rad_s,
        name="hold_raw_generalized_velocity_rad_s",
    )
    targets = _three_channel_matrix(
        hold_target_positions_rad, name="hold_target_positions_rad"
    )
    estimated = _three_channel_matrix(
        hold_estimated_force_n, name="hold_estimated_force_n"
    )
    if not (hold.shape == raw.shape == targets.shape == estimated.shape):
        raise ValueError("quiet-hold sample matrices must have the same shape")
    positive = (
        dt_s,
        force_tolerance_n,
        position_baseline_multiplier,
        qdot_fd_baseline_multiplier,
        maximum_position_peak_to_peak_rad,
        maximum_qdot_fd_rms_rad_s,
        raw_to_fd_diagnostic_ratio,
    )
    if not all(np.isfinite(value) and float(value) > 0.0 for value in positive):
        raise ValueError("quiet-hold bounds and multipliers must be positive")

    tare_metrics = _position_metrics(tare, dt_s=dt_s)
    locked_metrics = _position_metrics(locked, dt_s=dt_s)
    hold_metrics = _position_metrics(hold, dt_s=dt_s)
    baseline_position = np.maximum(
        tare_metrics["position_peak_to_peak_rad"],
        locked_metrics["position_peak_to_peak_rad"],
    )
    baseline_qdot_fd = np.maximum(
        tare_metrics["qdot_fd_rms_rad_s"],
        locked_metrics["qdot_fd_rms_rad_s"],
    )
    position_threshold = np.minimum(
        float(maximum_position_peak_to_peak_rad),
        baseline_position * float(position_baseline_multiplier),
    )
    qdot_fd_threshold = np.minimum(
        float(maximum_qdot_fd_rms_rad_s),
        baseline_qdot_fd * float(qdot_fd_baseline_multiplier),
    )
    # An exactly zero baseline represents quantized stationary data. Preserve a
    # one-ULP numerical floor without turning numerical precision into a gate.
    position_threshold = np.maximum(position_threshold, np.finfo(np.float32).eps)
    qdot_fd_threshold = np.maximum(
        qdot_fd_threshold, np.finfo(np.float32).eps / float(dt_s)
    )

    target_peak_to_peak = np.ptp(targets, axis=0)
    target_positions_exactly_frozen = bool(np.all(target_peak_to_peak == 0.0))
    force_error = estimated - float(target_force_n)
    force_within_band = bool(
        np.all(np.abs(force_error) <= float(force_tolerance_n))
    )
    position_within_bound = bool(
        np.all(
            hold_metrics["position_peak_to_peak_rad"] <= position_threshold
        )
    )
    qdot_fd_within_bound = bool(
        np.all(hold_metrics["qdot_fd_rms_rad_s"] <= qdot_fd_threshold)
    )
    no_monotonic_drift = bool(
        np.all(
            np.abs(hold_metrics["position_end_minus_start_rad"])
            <= position_threshold
        )
    )
    raw_rms = np.sqrt(np.mean(np.square(raw), axis=0))
    fd_rms = hold_metrics["qdot_fd_rms_rad_s"]
    raw_to_fd_ratio = raw_rms / np.maximum(fd_rms, np.finfo(np.float64).eps)
    mismatch_channels = [
        index
        for index, ratio in enumerate(raw_to_fd_ratio)
        if ratio > float(raw_to_fd_diagnostic_ratio)
    ]
    passed = bool(
        target_positions_exactly_frozen
        and force_within_band
        and position_within_bound
        and qdot_fd_within_bound
        and no_monotonic_drift
    )
    return QuietHoldAssessment(
        passed=passed,
        metrics={
            "acceptance_inputs": [
                "joint_position",
                "finite_difference_joint_position",
                "estimated_normal_force_proxy",
            ],
            "raw_generalized_velocity_role": "DIAGNOSTIC_AND_8_RAD_S_SAFETY_ONLY",
            "tare_baseline": {
                key: value.tolist() for key, value in tare_metrics.items()
            },
            "locked_baseline": {
                key: value.tolist() for key, value in locked_metrics.items()
            },
            "position_peak_to_peak_threshold_rad": position_threshold.tolist(),
            "qdot_fd_rms_threshold_rad_s": qdot_fd_threshold.tolist(),
            "hold_position_peak_to_peak_rad": hold_metrics[
                "position_peak_to_peak_rad"
            ].tolist(),
            "hold_position_end_minus_start_rad": hold_metrics[
                "position_end_minus_start_rad"
            ].tolist(),
            "hold_qdot_fd_rms_rad_s": fd_rms.tolist(),
            "hold_raw_generalized_velocity_rms_rad_s": raw_rms.tolist(),
            "raw_to_fd_rms_ratio": raw_to_fd_ratio.tolist(),
            "diagnostic_flags": (
                ["RAW_GENERALIZED_VELOCITY_NOT_USED_FOR_SETTLE"]
                if mismatch_channels
                else []
            ),
            "raw_velocity_mismatch_channels": mismatch_channels,
            "target_position_peak_to_peak_rad": target_peak_to_peak.tolist(),
            "target_positions_exactly_frozen": target_positions_exactly_frozen,
            "estimated_force_mean_n": np.mean(estimated, axis=0).tolist(),
            "estimated_force_std_n": np.std(estimated, axis=0).tolist(),
            "estimated_force_min_n": np.min(estimated, axis=0).tolist(),
            "estimated_force_max_n": np.max(estimated, axis=0).tolist(),
            "force_within_target_band": force_within_band,
            "position_peak_to_peak_within_bound": position_within_bound,
            "qdot_fd_rms_within_bound": qdot_fd_within_bound,
            "no_monotonic_position_drift": no_monotonic_drift,
        },
    )
