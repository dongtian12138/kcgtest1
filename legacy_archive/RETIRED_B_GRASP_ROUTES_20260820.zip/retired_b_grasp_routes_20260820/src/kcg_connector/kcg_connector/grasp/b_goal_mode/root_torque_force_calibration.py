"""Fit a simulation-only root-torque to PAD-normal-force proxy from G1."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np


CHANNELS = {
    "f1Link3": ("f1j2_effort_delta_nm", "f1_normal_force_n"),
    "f2Link2": ("f2j1_effort_delta_nm", "f2_normal_force_n"),
    "f3Link3": ("f3j2_effort_delta_nm", "f3_normal_force_n"),
}


@dataclass(frozen=True)
class RootTorqueForceFit:
    finger: str
    normal_force_per_root_torque_n_per_nm: float
    sample_count: int
    force_rmse_n: float
    force_max_abs_error_n: float
    force_r_squared: float
    minimum_torque_delta_nm: float
    maximum_torque_delta_nm: float
    minimum_normal_force_n: float
    maximum_normal_force_n: float
    role: str = "SIMULATION_ONLY_POSTHOC_G1_PROXY_NOT_HARDWARE_CALIBRATION"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    def estimate_normal_force_n(self, torque_delta_nm: float) -> float:
        return max(
            0.0,
            float(self.normal_force_per_root_torque_n_per_nm)
            * abs(float(torque_delta_nm)),
        )


def fit_g1_trace(
    trace_path: Path,
    *,
    phase: str = "DIAGNOSTIC_HOLD",
    minimum_torque_delta_nm: float = 0.02,
    minimum_normal_force_n: float = 0.05,
) -> dict[str, RootTorqueForceFit]:
    with trace_path.open(newline="", encoding="utf-8") as stream:
        rows = [row for row in csv.DictReader(stream) if row["phase"] == phase]
    fits: dict[str, RootTorqueForceFit] = {}
    for finger, (torque_field, force_field) in CHANNELS.items():
        pairs = [
            (float(row[torque_field]), float(row[force_field]))
            for row in rows
            if row[torque_field] != "" and row[force_field] != ""
        ]
        pairs = [
            pair
            for pair in pairs
            if pair[0] >= float(minimum_torque_delta_nm)
            and pair[1] >= float(minimum_normal_force_n)
            and np.all(np.isfinite(pair))
        ]
        if len(pairs) < 48:
            raise ValueError(f"G1 trace lacks calibration samples for {finger}")
        torque = np.asarray([pair[0] for pair in pairs], dtype=np.float64)
        force = np.asarray([pair[1] for pair in pairs], dtype=np.float64)
        denominator = float(torque @ torque)
        if denominator <= 1.0e-12:
            raise ValueError(f"G1 trace torque excitation is degenerate for {finger}")
        slope = float(torque @ force) / denominator
        predicted = slope * torque
        residual = force - predicted
        total = float(np.sum((force - float(np.mean(force))) ** 2))
        r_squared = 1.0 - float(residual @ residual) / max(total, 1.0e-12)
        fits[finger] = RootTorqueForceFit(
            finger=finger,
            normal_force_per_root_torque_n_per_nm=slope,
            sample_count=len(pairs),
            force_rmse_n=float(np.sqrt(np.mean(residual**2))),
            force_max_abs_error_n=float(np.max(np.abs(residual))),
            force_r_squared=r_squared,
            minimum_torque_delta_nm=float(np.min(torque)),
            maximum_torque_delta_nm=float(np.max(torque)),
            minimum_normal_force_n=float(np.min(force)),
            maximum_normal_force_n=float(np.max(force)),
        )
    return fits


def serialize_fits(fits: Mapping[str, RootTorqueForceFit]) -> dict[str, Any]:
    return {
        "schema": "D38999_B_GOAL_MODE_ROOT_TORQUE_FORCE_PROXY_V1",
        "role": "SIMULATION_ONLY_POSTHOC_G1_PROXY_NOT_HARDWARE_CALIBRATION",
        "online_physx_contact_truth_used": False,
        "fits": {name: fit.as_dict() for name, fit in fits.items()},
    }
