"""Build the evidence-backed B_FULL_IIWA_SCI_CLOSEOUT publication bundle.

The builder never runs physics and never feeds post-hoc contact/object truth back
to a controller.  It reads frozen offline candidates plus completed Isaac
RESULT/TRACE files, verifies the three full-iiwa validation gates, and produces
tables, source CSV files, vector/raster figures, captions, and the aggregate
simulation-only B-stage pass record.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from collections import Counter
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.lines import Line2D
import numpy as np


SCHEMA = "D38999_B_FULL_IIWA_SCI_CLOSEOUT_PUBLICATION_V1"
FINGER_COLORS = ("#0072B2", "#E69F00", "#009E73")
TOP3 = ("BG_P120_Z15", "BG_P124_Z15", "BG_P128_Z15")
SELECTED = "BG_P120_Z15"
PHYSICS_HZ = 240.0


def _json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise TypeError(f"expected JSON object: {path}")
    return value


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _number(value: Any, default: float = math.nan) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result


def _bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _write_csv(path: Path, fieldnames: Sequence[str], rows: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _configure_plotting() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8.5,
            "axes.titlesize": 9.5,
            "axes.labelsize": 9,
            "legend.fontsize": 7.5,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 7.5,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.grid": True,
            "grid.alpha": 0.22,
            "grid.linewidth": 0.55,
            "savefig.facecolor": "white",
            "savefig.bbox": "tight",
        }
    )


def _save_figure(fig: Any, output: Path, stem: str) -> dict[str, str]:
    output.mkdir(parents=True, exist_ok=True)
    png = output / f"{stem}.png"
    pdf = output / f"{stem}.pdf"
    svg = output / f"{stem}.svg"
    fig.savefig(png, dpi=360)
    fig.savefig(pdf)
    fig.savefig(svg)
    plt.close(fig)
    return {"png": png.name, "pdf": pdf.name, "svg": svg.name}


def _time(rows: Sequence[Mapping[str, str]]) -> np.ndarray:
    return np.asarray([_number(row.get("step"), index + 1) / PHYSICS_HZ for index, row in enumerate(rows)])


def _column(rows: Sequence[Mapping[str, str]], name: str) -> np.ndarray:
    return np.asarray([_number(row.get(name)) for row in rows], dtype=np.float64)


def _first_phase_index(rows: Sequence[Mapping[str, str]], phase: str) -> int:
    for index, row in enumerate(rows):
        if row.get("phase") == phase:
            return index
    raise KeyError(f"missing phase {phase}")


def _candidate_sources(candidate_bundle: Mapping[str, Any]) -> list[dict[str, Any]]:
    candidates = list(candidate_bundle["candidates"])
    if len(candidates) != 12:
        raise ValueError(f"expected exactly 12 candidates, got {len(candidates)}")
    if any(not bool(candidate["static_pass"]) for candidate in candidates):
        raise ValueError("all 12 frozen candidates must retain static_pass")
    return candidates


def _candidate_table(candidates: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for candidate in candidates:
        task = candidate["task_metrics"]
        sweep = candidate["sweep_metrics"]
        circular = task["circular_contact_metrics"]
        radial = task["radial_alignment_metrics"]
        result.append(
            {
                "rank": candidate["rank"],
                "dynamic_rank": candidate.get("dynamic_rank", ""),
                "candidate_id": candidate["candidate_id"],
                "evidence_level": (
                    "TOP3_SINGLE_DYNAMIC_COMPARISON" if candidate["candidate_id"] in TOP3
                    else "OFFLINE_ONLY"
                ),
                "preshape_rad": candidate["preshape_rad"],
                "grasp_z_mm": candidate["grasp_local_z_mm"],
                "palm_depth_object_center_z_hand_m": candidate["object_center_z_hand_m"],
                "wrist_roll_rad": candidate["wrist_rpy_offset_rad"][0],
                "wrist_pitch_rad": candidate["wrist_rpy_offset_rad"][1],
                "wrist_yaw_rad": candidate["wrist_rpy_offset_rad"][2],
                "contact_points_world_m": json.dumps(candidate["predicted_contact_points_world_m"]),
                "contact_normals_world": json.dumps(candidate["predicted_contact_normals_world"]),
                "maximum_circular_gap_deg": circular["maximum_gap_deg"],
                "minimum_radial_alignment": radial["minimum_radial_alignment"],
                "minimum_joint_margin_rad": candidate["minimum_joint_margin_rad"],
                "sweep_minimum_table_clearance_m": sweep["minimum_table_clearance_m"],
                "sweep_minimum_precontact_object_clearance_m": sweep[
                    "minimum_precontact_object_clearance_m"
                ],
                "sweep_minimum_interfinger_clearance_m": sweep[
                    "minimum_interfinger_clearance_m"
                ],
                "sweep_sample_count": sweep["sample_count"],
                "gravity_safety_factor_at_8n": task["gravity_safety_factor_at_8n"],
                "lift_safety_factor_at_8n": task["lift_safety_factor_at_8n"],
                "bounded_task_safety_factor_at_12n": task[
                    "minimum_other_task_safety_factor_at_12n"
                ],
                "predicted_peak_single_finger_force_n": task[
                    "maximum_required_peak_normal_force_n"
                ],
                "force_closure": task["force_closure"]["force_closure"],
                "force_closure_signed_basis_scale": task["force_closure"][
                    "minimum_normalized_signed_basis_scale"
                ],
                "geometry_score": candidate["geometry_score"],
                "selected_final": candidate["candidate_id"] == SELECTED,
            }
        )
    return result


def _top3_table(results: Mapping[str, Mapping[str, Any]], candidates: Mapping[str, Mapping[str, Any]]) -> list[dict[str, Any]]:
    table = []
    for candidate_id in TOP3:
        result = results[candidate_id]
        candidate = candidates[candidate_id]
        g5 = result["g5_evidence"]
        g6 = result["g6_evidence"]
        peak_estimated = result["maximum_estimated_force_n"]
        peak_posthoc = result["maximum_diagnostic_force_n"]
        table.append(
            {
                "candidate_id": candidate_id,
                "offline_rank": candidate["rank"],
                "status": result["status"],
                "physics_steps": result["physics_steps"],
                "unsupported_hold_max_slip_um": 1e6 * g5["maximum_axial_slip_m"],
                "unsupported_hold_max_rotation_deg": math.degrees(g5["maximum_relative_rotation_rad"]),
                "full_sequence_max_slip_um": 1e6 * result["maximum_axial_slip_m"],
                "full_sequence_max_rotation_deg": math.degrees(result["maximum_relative_rotation_rad"]),
                "final_object_lift_mm": 1e3 * g6["object_lift_m"],
                "final_hold_max_rho": max(g5["final_window_maximum_rho"]),
                "maximum_consecutive_rho_gt_1_steps": max(
                    result["maximum_consecutive_rho_above_one_steps"]
                ),
                "peak_estimated_force_n": max(peak_estimated),
                "peak_posthoc_force_n": max(peak_posthoc),
                "peak_force_imbalance_n": max(peak_estimated) - min(peak_estimated),
                "adaptive_events": len(result["adaptive_events"]),
                "tws_safety_factor": candidate["task_metrics"][
                    "minimum_other_task_safety_factor_at_12n"
                ],
                "selected_final": candidate_id == SELECTED,
                "truth_role": "POSTHOC_AUDIT_ONLY_NOT_ONLINE_CONTROL",
            }
        )
    return table


def _validation_checks(result: Mapping[str, Any], index: int) -> dict[str, bool]:
    lift = result["lift"]
    stages = lift["stage_results"]
    return {
        "validation_index": result.get("validation_index") == index,
        "status": result.get("status") == "PASS",
        "classification": result.get("classification")
        == "FULL_IIWA_TABLE_PICK_VALIDATION_PASS",
        "candidate": result.get("candidate_id") == SELECTED,
        "physics_started": bool(result.get("physics_started"))
        and int(result.get("physics_steps", 0)) > 0,
        "four_lift_targets": [row["target_m"] for row in stages]
        == [0.0005, 0.002, 0.01, 0.04]
        and all(bool(row["passed"]) for row in stages),
        "final_object_lift": float(lift["object_lift_m"]) >= 0.039,
        "final_hold": int(lift["final_hold_steps"]) >= 480,
        "pad_contact": bool(lift["three_pad_contact_maintained"])
        and all(float(value) >= 0.90 for value in result["pad_normal_impulse_share"].values()),
        "tip_not_bearing": not bool(result["red_tip_main_bearing"]),
        "old_hull_removed": not bool(result["old_terminal_hull_in_contact_chain"]),
        "slip": float(lift["relative_axial_slip_m"]) <= 0.0005,
        "tilt": float(lift["object_rotation_rad"]) <= math.radians(5.0),
        "force": max(float(value) for value in result["maximum_estimated_force_n"]) <= 15.0
        and max(float(value) for value in result["maximum_posthoc_normal_force_n"]) <= 15.0,
        "rho": max(int(value) for value in result["maximum_consecutive_rho_above_one_steps"]) < 12,
        "pose_write": int(result["truth_boundary"]["object_pose_write_after_physics_count"]) == 0,
        "online_truth": not bool(result["truth_boundary"]["physx_contact_changes_commands"])
        and not bool(result["truth_boundary"]["object_pose_changes_commands"]),
        "unauthorized_contact": not bool(result["unauthorized_contact_pairs"]),
        "wrist_emergency": not bool(result["wrist"]["simulation_emergency_triggered"])
        and float(result["wrist"]["recovery_gate_exceed_duration_s"]) == 0.0,
        "table_unloaded": float(lift["final_table_normal_force_n"]) == 0.0,
    }


def _validation_table(results: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, bool]]]:
    table: list[dict[str, Any]] = []
    check_rows = []
    for index, result in enumerate(results, start=1):
        checks = _validation_checks(result, index)
        check_rows.append(checks)
        lift = result["lift"]
        stages = lift["stage_results"]
        table.append(
            {
                "validation_index": index,
                "status": result["status"],
                "classification": result["classification"],
                "physics_steps": result["physics_steps"],
                "tcp_lift_0p5_mm": 1e3 * stages[0]["achieved_tcp_lift_m"],
                "tcp_lift_2_mm": 1e3 * stages[1]["achieved_tcp_lift_m"],
                "tcp_lift_10_mm": 1e3 * stages[2]["achieved_tcp_lift_m"],
                "tcp_lift_40_mm": 1e3 * stages[3]["achieved_tcp_lift_m"],
                "object_lift_0p5_mm": 1e3 * stages[0]["achieved_object_lift_m"],
                "object_lift_2_mm": 1e3 * stages[1]["achieved_object_lift_m"],
                "object_lift_10_mm": 1e3 * stages[2]["achieved_object_lift_m"],
                "object_lift_40_mm": 1e3 * stages[3]["achieved_object_lift_m"],
                "final_object_lift_mm": 1e3 * lift["object_lift_m"],
                "relative_axial_slip_um": 1e6 * lift["relative_axial_slip_m"],
                "lateral_drift_um": 1e6 * lift["object_lateral_drift_m"],
                "tilt_deg": math.degrees(lift["object_rotation_rad"]),
                "peak_estimated_force_n": max(result["maximum_estimated_force_n"]),
                "peak_posthoc_force_n": max(result["maximum_posthoc_normal_force_n"]),
                "pad_share_min": min(result["pad_normal_impulse_share"].values()),
                "tip_main_bearing": result["red_tip_main_bearing"],
                "rho_gt_1_max_consecutive_steps": max(
                    result["maximum_consecutive_rho_above_one_steps"]
                ),
                "wrist_raw_force_peak_n": result["wrist"]["raw_force_peak_n"],
                "wrist_raw_moment_peak_nm": result["wrist"]["raw_moment_peak_nm"],
                "wrist_tare_force_peak_n": result["wrist"]["tare_compensated_force_peak_n"],
                "wrist_tare_moment_peak_nm": result["wrist"]["tare_compensated_moment_peak_nm"],
                "wrist_soft_0p30_exceed_s": result["wrist"]["soft_target_exceed_duration_s"],
                "wrist_recovery_0p60_exceed_s": result["wrist"]["recovery_gate_exceed_duration_s"],
                "wrist_emergency_triggered": result["wrist"]["simulation_emergency_triggered"],
                "object_pose_writes": result["truth_boundary"]["object_pose_write_after_physics_count"],
                "all_formal_checks": all(checks.values()),
            }
        )
    return table, check_rows


def _draw_cylinder_top(ax: Any, radius_mm: float = 24.0) -> None:
    circle = patches.Circle((0.0, 0.0), radius_mm, fill=False, lw=1.25, color="#4D4D4D")
    ax.add_patch(circle)
    ax.axhline(0.0, color="#999999", lw=0.55, ls="--")
    ax.axvline(0.0, color="#999999", lw=0.55, ls="--")


def _figure1(output: Path, repo: Path, figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    mesh_dir = repo / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2/DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP/BLUE_PAD_SDF_SOURCE_ASSET_V2"
    pad = np.load(mesh_dir / "f1Link3_PAD_BODY_exact_source_local_m.npz")
    tip = np.load(mesh_dir / "f1Link3_TIP_exact_source_local_m.npz")
    pad_points = np.asarray(pad["points_local_m"]) * 1e3
    tip_points = np.asarray(tip["points_local_m"]) * 1e3
    contact_vertices = np.unique(np.asarray(pad["faces"])[np.asarray(pad["pad_contact_face_ids"])].ravel())
    contact_mask = np.zeros(len(pad_points), dtype=bool)
    contact_mask[contact_vertices] = True
    pad_core = _json(repo / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json")
    link = pad_core["links"][0]
    capsule = link["capsules"][0]
    center = np.asarray(capsule["center_local_m"]) * 1e3
    axis = np.asarray(capsule["axis_unit_local"], dtype=float)
    half_span = 0.5 * float(capsule["total_axis_span_m"]) * 1e3
    endpoints = np.stack((center - axis * half_span, center + axis * half_span))
    origin = np.asarray(link["contact_frame_local"]["origin_m"]) * 1e3
    normal = np.asarray(link["contact_frame_local"]["outward_normal_unit"], dtype=float)
    width_axis = np.asarray(link["contact_frame_local"]["width_axis_unit"], dtype=float)
    connector_center = origin + normal * 24.0

    source_rows: list[dict[str, Any]] = []
    for role, points in (
        ("PAD_CONTACT_SURFACE", pad_points[contact_mask]),
        ("PAD_SIDE_SURFACE", pad_points[~contact_mask]),
        ("TIP", tip_points),
        ("PAD_CAPSULE_ENDPOINT", endpoints),
        ("CONTACT_POINT", origin.reshape(1, 3)),
        ("CONNECTOR_AXIS_POINT", connector_center.reshape(1, 3)),
    ):
        for point in points:
            source_rows.append({"role": role, "x_mm": point[0], "y_mm": point[1], "z_mm": point[2]})
    figure_rows["FIGURE_01_SOURCE.csv"] = source_rows

    fig = plt.figure(figsize=(10.6, 7.4))
    projections = ((0, 1, "Top view", "X (mm)", "Y (mm)"), (0, 2, "Side view", "X (mm)", "Z (mm)"), (1, 2, "End view", "Y (mm)", "Z (mm)"))
    for index, (a, b, title, xlabel, ylabel) in enumerate(projections, start=1):
        ax = fig.add_subplot(2, 2, index)
        ax.scatter(pad_points[~contact_mask, a], pad_points[~contact_mask, b], s=2, color="#87CEEB", alpha=0.32, rasterized=True)
        ax.scatter(pad_points[contact_mask, a], pad_points[contact_mask, b], s=3, color="#0072B2", alpha=0.75, rasterized=True)
        ax.scatter(tip_points[:, a], tip_points[:, b], s=2, color="#D55E00", alpha=0.55, rasterized=True)
        ax.plot(endpoints[:, a], endpoints[:, b], color="#009E73", lw=6, alpha=0.8, solid_capstyle="round")
        ax.scatter(origin[a], origin[b], marker="x", s=48, color="black", zorder=5)
        ax.arrow(origin[a], origin[b], normal[a] * 8.0, normal[b] * 8.0, width=0.12, head_width=1.4, color="black", length_includes_head=True)
        if (a, b) == (0, 1):
            ax.add_patch(patches.Circle((connector_center[a], connector_center[b]), 24.0, fill=False, lw=1.2, ls="--", color="#4D4D4D"))
        else:
            axis_projection = np.asarray((width_axis[a], width_axis[b]))
            if np.linalg.norm(axis_projection) > 1e-9:
                axis_projection /= np.linalg.norm(axis_projection)
                tangent = np.asarray((-axis_projection[1], axis_projection[0]))
                c2 = connector_center[[a, b]]
                corners = np.asarray([c2 - axis_projection * 16 - tangent * 24, c2 + axis_projection * 16 - tangent * 24, c2 + axis_projection * 16 + tangent * 24, c2 - axis_projection * 16 + tangent * 24])
                ax.add_patch(patches.Polygon(corners, fill=False, lw=1.2, ls="--", color="#4D4D4D"))
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_aspect("equal", adjustable="datalim")
    ax3 = fig.add_subplot(2, 2, 4, projection="3d")
    sample = slice(None, None, 4)
    ax3.scatter(*pad_points[contact_mask][sample].T, s=3, color="#0072B2", alpha=0.75)
    ax3.scatter(*pad_points[~contact_mask][sample].T, s=2, color="#87CEEB", alpha=0.28)
    ax3.scatter(*tip_points[::3].T, s=2, color="#D55E00", alpha=0.55)
    ax3.plot(*endpoints.T, color="#009E73", lw=7, solid_capstyle="round")
    ax3.quiver(*origin, *(normal * 9.0), color="black", arrow_length_ratio=0.18)
    ax3.set_title("Oblique view")
    ax3.set_xlabel("X (mm)")
    ax3.set_ylabel("Y (mm)")
    ax3.set_zlabel("Z (mm)")
    handles = [
        Line2D([0], [0], marker="o", lw=0, color="#0072B2", label="Blue PAD contact surface"),
        Line2D([0], [0], marker="o", lw=0, color="#87CEEB", label="PAD side/back"),
        Line2D([0], [0], marker="o", lw=0, color="#D55E00", label="Red TIP"),
        Line2D([0], [0], lw=6, color="#009E73", label="Analytic PAD capsule"),
        Line2D([0], [0], lw=1.2, ls="--", color="#4D4D4D", label="Connector cylinder"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False)
    fig.suptitle("Audited fingertip semantics and task-specific PAD collision proxy")
    fig.subplots_adjust(bottom=0.12, wspace=0.28, hspace=0.28)
    return _save_figure(fig, output, "FIGURE_01_PAD_GEOMETRY")


def _plot_candidate_top(ax: Any, candidate: Mapping[str, Any], compact: bool = False) -> None:
    _draw_cylinder_top(ax)
    points = np.asarray(candidate["predicted_contact_points_world_m"])[:, :2] * 1e3
    normals = np.asarray(candidate["predicted_contact_normals_world"])[:, :2]
    for finger, (point, normal) in enumerate(zip(points, normals)):
        ax.scatter(*point, s=32 if compact else 48, color=FINGER_COLORS[finger], edgecolor="white", linewidth=0.6, zorder=4)
        ax.arrow(point[0], point[1], normal[0] * 7.0, normal[1] * 7.0, width=0.12, head_width=1.25, color=FINGER_COLORS[finger], length_includes_head=True)
    ax.scatter(0, 0, marker="+", s=52, color="black", zorder=5)
    ax.set_xlim(-32, 32)
    ax.set_ylim(-32, 32)
    ax.set_aspect("equal")


def _figure2(output: Path, candidates: Sequence[Mapping[str, Any]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    rows = []
    fig, axes = plt.subplots(3, 4, figsize=(11.3, 8.5), sharex=True, sharey=True)
    for ax, candidate in zip(axes.flat, candidates):
        _plot_candidate_top(ax, candidate, compact=True)
        task = candidate["task_metrics"]
        ax.set_title(
            f"{candidate['candidate_id']} | q={candidate['preshape_rad']:.2f} rad\n"
            f"z={candidate['grasp_local_z_mm']:.0f} mm | gap={task['circular_contact_metrics']['maximum_gap_deg']:.1f} deg\n"
            f"TWS={task['minimum_other_task_safety_factor_at_12n']:.2f} | Fpred={task['maximum_required_peak_normal_force_n']:.2f} N",
            fontsize=7.5,
        )
        for finger, (point, normal) in enumerate(zip(candidate["predicted_contact_points_world_m"], candidate["predicted_contact_normals_world"])):
            rows.append(
                {
                    "candidate_id": candidate["candidate_id"],
                    "finger": finger + 1,
                    "preshape_rad": candidate["preshape_rad"],
                    "grasp_z_mm": candidate["grasp_local_z_mm"],
                    "contact_x_m": point[0],
                    "contact_y_m": point[1],
                    "contact_z_m": point[2],
                    "normal_x": normal[0],
                    "normal_y": normal[1],
                    "normal_z": normal[2],
                    "maximum_gap_deg": task["circular_contact_metrics"]["maximum_gap_deg"],
                    "tws_safety_factor": task["minimum_other_task_safety_factor_at_12n"],
                    "predicted_force_n": task["maximum_required_peak_normal_force_n"],
                }
            )
    for ax in axes[-1]:
        ax.set_xlabel("X (mm)")
    for ax in axes[:, 0]:
        ax.set_ylabel("Y (mm)")
    fig.suptitle("Twelve bounded offline grasp candidates (only Top 3 were dynamically compared)")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    figure_rows["FIGURE_02_SOURCE.csv"] = rows
    return _save_figure(fig, output, "FIGURE_02_TWELVE_CANDIDATES")


def _figure3(output: Path, candidate_table: Sequence[Mapping[str, Any]], top3_table: Sequence[Mapping[str, Any]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.6))
    ids = [row["candidate_id"] for row in candidate_table]
    top3 = set(TOP3)
    colors = {
        cid: "#0072B2" if cid == SELECTED else "#E69F00" if cid == "BG_P124_Z15" else "#CC79A7" if cid == "BG_P128_Z15" else "#9E9E9E"
        for cid in ids
    }

    def paired_scatter(ax: Any, x_values: np.ndarray, y_values: np.ndarray) -> None:
        # Z12 and Z15 have intentionally identical planar grasp metrics.  Draw
        # the Z12 sample as an open ring and the Z15 sample as a filled point at
        # the same coordinates so no artificial jitter is introduced.
        for candidate_id, x_value, y_value in zip(ids, x_values, y_values):
            if candidate_id.endswith("_Z12"):
                ax.scatter(
                    [x_value],
                    [y_value],
                    facecolors="none",
                    edgecolors="#4D4D4D",
                    linewidths=1.0,
                    s=68,
                    zorder=2,
                )
            else:
                ax.scatter(
                    [x_value],
                    [y_value],
                    c=[colors[candidate_id]],
                    edgecolors="white",
                    linewidths=0.45,
                    s=43,
                    zorder=3,
                )
        grouped: dict[str, tuple[float, float]] = {}
        for candidate_id, x_value, y_value in zip(ids, x_values, y_values):
            grouped.setdefault(candidate_id.rsplit("_Z", 1)[0], (float(x_value), float(y_value)))
        for group_id, (x_value, y_value) in grouped.items():
            ax.annotate(
                f"{group_id.replace('BG_', '')} Z12/Z15",
                (x_value, y_value),
                xytext=(4, 3),
                textcoords="offset points",
                fontsize=6.2,
            )

    x = np.asarray([row["maximum_circular_gap_deg"] for row in candidate_table])
    y = np.asarray([row["bounded_task_safety_factor_at_12n"] for row in candidate_table])
    paired_scatter(axes[0], x, y)
    axes[0].set_xlabel("Maximum circular gap (deg)")
    axes[0].set_ylabel("Bounded TWS safety factor (-)")
    axes[0].set_title("Task margin vs contact distribution")
    x2 = np.asarray([row["minimum_joint_margin_rad"] for row in candidate_table])
    y2 = np.asarray([row["predicted_peak_single_finger_force_n"] for row in candidate_table])
    paired_scatter(axes[1], x2, y2)
    axes[1].set_xlabel("Minimum joint margin (rad)")
    axes[1].set_ylabel("Predicted peak finger force (N)")
    axes[1].set_title("Force demand vs joint margin")
    pair_legend = [
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#9E9E9E", markeredgecolor="white", markersize=5.5, label="Z15 filled"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="none", markeredgecolor="#4D4D4D", markersize=6.5, label="Z12 open ring"),
    ]
    axes[0].legend(handles=pair_legend, frameon=False, loc="lower left", fontsize=6.2)
    slip = np.asarray([row["full_sequence_max_slip_um"] for row in top3_table])
    rho = np.asarray([row["final_hold_max_rho"] for row in top3_table])
    axes[2].scatter(slip, rho, c=["#0072B2", "#E69F00", "#CC79A7"], s=56)
    for row, xv, yv in zip(top3_table, slip, rho):
        axes[2].annotate(row["candidate_id"].replace("BG_", ""), (xv, yv), xytext=(4, 3), textcoords="offset points", fontsize=7)
    axes[2].axhline(0.70, color="#D55E00", ls="--", lw=1, label="rho=0.70 soft metric")
    axes[2].set_xlabel("Dynamic axial slip (um)")
    axes[2].set_ylabel("Final-hold max rho (-)")
    axes[2].set_title("Top 3 dynamic comparison")
    axes[2].legend(frameon=False, loc="best")
    axes[2].text(
        0.04,
        0.95,
        "Legacy H25\nFAIL before 2 mm\nslip/rho unavailable",
        transform=axes[2].transAxes,
        ha="left",
        va="top",
        fontsize=6.4,
        color="#D55E00",
        bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "edgecolor": "#D55E00", "alpha": 0.9},
    )
    fig.tight_layout()
    source = []
    for row in candidate_table:
        source.append(
            {
                "candidate_id": row["candidate_id"],
                "evidence_level": row["evidence_level"],
                "maximum_circular_gap_deg": row["maximum_circular_gap_deg"],
                "bounded_task_safety_factor": row["bounded_task_safety_factor_at_12n"],
                "minimum_joint_margin_rad": row["minimum_joint_margin_rad"],
                "predicted_peak_force_n": row["predicted_peak_single_finger_force_n"],
                "dynamic_slip_um": "",
                "final_hold_max_rho": "",
                "comparison_outcome": "OFFLINE_ONLY" if row["candidate_id"] not in top3 else "TOP3_DYNAMIC_PASS",
            }
        )
    dynamic_lookup = {row["candidate_id"]: row for row in top3_table}
    for row in source:
        if row["candidate_id"] in dynamic_lookup:
            dynamic = dynamic_lookup[row["candidate_id"]]
            row["dynamic_slip_um"] = dynamic["full_sequence_max_slip_um"]
            row["final_hold_max_rho"] = dynamic["final_hold_max_rho"]
    source.append(
        {
            "candidate_id": "LEGACY_H25",
            "evidence_level": "DYNAMIC_LEGACY_FAILURE",
            "maximum_circular_gap_deg": "",
            "bounded_task_safety_factor": "",
            "minimum_joint_margin_rad": "",
            "predicted_peak_force_n": "",
            "dynamic_slip_um": "UNAVAILABLE",
            "final_hold_max_rho": "UNAVAILABLE",
            "comparison_outcome": "FAIL_BEFORE_2MM",
        }
    )
    figure_rows["FIGURE_03_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_03_RANKING_PARETO")


def _project(points: np.ndarray, view: str) -> tuple[np.ndarray, tuple[str, str]]:
    if view == "front":
        return points[:, (0, 2)], ("X (mm)", "Z (mm)")
    if view == "top":
        return points[:, (0, 1)], ("X (mm)", "Y (mm)")
    if view == "side":
        return points[:, (1, 2)], ("Y (mm)", "Z (mm)")
    matrix = np.asarray(((0.82, -0.42, 0.18), (0.18, 0.58, 0.80)))
    return points @ matrix.T, ("Oblique u (mm)", "Oblique v (mm)")


def _figure4(output: Path, candidates: Mapping[str, Mapping[str, Any]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    views = ("front", "top", "side", "oblique")
    fig, axes = plt.subplots(3, 4, figsize=(11.4, 8.0))
    source = []
    for row_index, candidate_id in enumerate(TOP3):
        candidate = candidates[candidate_id]
        points = np.asarray(candidate["predicted_contact_points_world_m"], dtype=float) * 1e3
        normals = np.asarray(candidate["predicted_contact_normals_world"], dtype=float)
        center = np.asarray((0.0, 0.0, 100.0))
        com = center.copy()
        for col_index, view in enumerate(views):
            ax = axes[row_index, col_index]
            projected, labels = _project(points, view)
            normal_end, _ = _project(points + normals * 0.008 * 1e3, view)
            center_projected, _ = _project(center.reshape(1, 3), view)
            com_projected, _ = _project(com.reshape(1, 3), view)
            for finger in range(3):
                ax.scatter(*projected[finger], s=46, color=FINGER_COLORS[finger], edgecolor="white", linewidth=0.6, zorder=4)
                delta = normal_end[finger] - projected[finger]
                ax.arrow(*projected[finger], *delta, width=0.10, head_width=1.1, color=FINGER_COLORS[finger], length_includes_head=True)
                # A rounded blue stroke conveys the local PAD tangent without inventing a mesh collider.
                tangent = np.asarray((-delta[1], delta[0]))
                if np.linalg.norm(tangent) > 1e-9:
                    tangent = tangent / np.linalg.norm(tangent) * 5.0
                    ax.plot([projected[finger, 0] - tangent[0], projected[finger, 0] + tangent[0]], [projected[finger, 1] - tangent[1], projected[finger, 1] + tangent[1]], color="#56B4E9", lw=5, solid_capstyle="round", alpha=0.65)
                source.append(
                    {
                        "candidate_id": candidate_id,
                        "view": view,
                        "finger": finger + 1,
                        "projected_contact_u_mm": projected[finger, 0],
                        "projected_contact_v_mm": projected[finger, 1],
                        "projected_normal_end_u_mm": normal_end[finger, 0],
                        "projected_normal_end_v_mm": normal_end[finger, 1],
                        "com_u_mm": com_projected[0, 0],
                        "com_v_mm": com_projected[0, 1],
                    }
                )
            ax.scatter(*center_projected[0], marker="+", color="#4D4D4D", s=54, label="Axis")
            ax.scatter(*com_projected[0], marker="*", color="black", s=45, label="CoM")
            if view == "top":
                _draw_cylinder_top(ax)
                ax.set_xlim(-32, 32)
                ax.set_ylim(-32, 32)
            ax.set_aspect("equal", adjustable="datalim")
            ax.set_xlabel(labels[0])
            ax.set_ylabel(labels[1])
            if row_index == 0:
                ax.set_title(view.capitalize())
            if col_index == 0:
                ax.text(0.02, 0.96, candidate_id, transform=ax.transAxes, va="top", fontweight="bold")
    fig.suptitle("Top 3 grasp poses: contact points, inward normals, connector axis, and object CoM")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    figure_rows["FIGURE_04_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_04_TOP3_POSES")


def _trace_slice(rows: Sequence[dict[str, str]], start_phase: str, end_phase: str) -> list[dict[str, str]]:
    start = _first_phase_index(rows, start_phase)
    end_start = _first_phase_index(rows, end_phase)
    end = end_start
    while end + 1 < len(rows) and rows[end + 1].get("phase") == end_phase:
        end += 1
    return list(rows[start : end + 1])


def _figure5(output: Path, trace: Sequence[dict[str, str]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    rows = _trace_slice(trace, "PRECONTACT_TARE", "CONTACT_LOCKED_SETTLE")
    time = (_column(rows, "step") - _number(rows[0]["step"])) / PHYSICS_HZ
    fig, axes = plt.subplots(3, 1, figsize=(10.4, 7.0), sharex=True)
    source = []
    first_contacts = []
    for finger, (prefix, joint) in enumerate((("f1", "f1j2"), ("f2", "f2j1"), ("f3", "f3j2"))):
        target = _column(rows, f"{joint}_target_rad")
        actual = _column(rows, f"{joint}_position_rad")
        effort = _column(rows, f"{joint}_effort_delta_nm")
        state = np.asarray([1.0 if row[f"{prefix}_contact_state"] == "CONTACT_LOCKED" else 0.0 for row in rows])
        axes[0].plot(time, target, color=FINGER_COLORS[finger], ls="--", lw=1.1, label=f"F{finger+1} target")
        axes[0].plot(time, actual, color=FINGER_COLORS[finger], lw=1.4, label=f"F{finger+1} actual")
        axes[1].plot(time, effort, color=FINGER_COLORS[finger], lw=1.3, label=f"F{finger+1}")
        axes[2].step(time, state + finger * 1.2, where="post", color=FINGER_COLORS[finger], lw=1.4, label=f"F{finger+1}")
        locked = np.where(state > 0.5)[0]
        if len(locked):
            first_time = float(time[locked[0]])
            first_contacts.append(first_time)
            for ax in axes:
                ax.axvline(first_time, color=FINGER_COLORS[finger], lw=0.85, alpha=0.7)
        for index, row in enumerate(rows):
            source.append(
                {
                    "time_s": time[index],
                    "finger": finger + 1,
                    "target_position_rad": target[index],
                    "actual_position_rad": actual[index],
                    "root_effort_delta_nm": effort[index],
                    "contact_locked": int(state[index]),
                }
            )
    axes[0].set_ylabel("Joint position (rad)")
    axes[1].set_ylabel("Root effort delta (N m)")
    axes[2].set_ylabel("Contact state (offset)")
    axes[2].set_xlabel("Time from precontact tare (s)")
    axes[0].legend(ncol=3, frameon=False)
    axes[1].legend(ncol=3, frameon=False)
    axes[2].set_yticks((0, 1.2, 2.4), ("F1", "F2", "F3"))
    fig.suptitle("Independent per-finger position approach and contact-triggered locking")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    figure_rows["FIGURE_05_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_05_CONTACT_STOP_TIMING")


def _figure6(output: Path, candidate_table: Sequence[Mapping[str, Any]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    labels = [row["candidate_id"].replace("BG_", "") for row in candidate_table]
    x = np.arange(len(labels), dtype=float)
    width = 0.25
    fig, axes = plt.subplots(2, 1, figsize=(11.2, 6.4), sharex=True)
    gravity = np.asarray([row["gravity_safety_factor_at_8n"] for row in candidate_table])
    lift = np.asarray([row["lift_safety_factor_at_8n"] for row in candidate_table])
    tws = np.asarray([row["bounded_task_safety_factor_at_12n"] for row in candidate_table])
    axes[0].bar(x - width, gravity, width, color="#0072B2", label="Gravity @ 8 N")
    axes[0].bar(x, lift, width, color="#56B4E9", label="Lift @ 8 N")
    axes[0].bar(x + width, tws, width, color="#009E73", label="Bounded task @ 12 N")
    axes[0].axhline(1.0, color="#D55E00", ls="--", lw=1)
    axes[0].set_ylabel("Safety factor (-)")
    axes[0].set_title("Force-closure task margins")
    axes[0].legend(ncol=3, frameon=False)
    predicted = np.asarray([row["predicted_peak_single_finger_force_n"] for row in candidate_table])
    bar_colors = ["#0072B2" if row["selected_final"] else "#E69F00" if row["candidate_id"] in TOP3 else "#9E9E9E" for row in candidate_table]
    axes[1].bar(x, predicted, color=bar_colors)
    axes[1].axhline(12.0, color="#D55E00", ls="--", lw=1, label="Adaptive target limit")
    axes[1].axhline(15.0, color="black", ls=":", lw=1, label="Per-finger hard cap")
    axes[1].set_ylabel("Predicted peak force (N)")
    axes[1].set_xlabel("Candidate")
    axes[1].set_xticks(x, labels, rotation=35, ha="right")
    axes[1].legend(frameon=False)
    fig.tight_layout()
    figure_rows["FIGURE_06_SOURCE.csv"] = [
        {
            "candidate_id": row["candidate_id"],
            "gravity_safety_factor": row["gravity_safety_factor_at_8n"],
            "lift_safety_factor": row["lift_safety_factor_at_8n"],
            "bounded_task_safety_factor": row["bounded_task_safety_factor_at_12n"],
            "predicted_peak_force_n": row["predicted_peak_single_finger_force_n"],
        }
        for row in candidate_table
    ]
    return _save_figure(fig, output, "FIGURE_06_FORCE_CLOSURE_TWS")


def _figure7(output: Path, trace: Sequence[dict[str, str]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    rows = _trace_slice(trace, "CONTACT_LOCKED_SETTLE", "FORCE_QUIET_HOLD")
    time = (_column(rows, "step") - _number(rows[0]["step"])) / PHYSICS_HZ
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 6.4), sharex=True)
    source = []
    target = _column(rows, "force_target_level_n")
    axes[0].plot(time, target, color="black", lw=1.5, label="Common target")
    for finger, prefix in enumerate(("f1", "f2", "f3")):
        estimated = _column(rows, f"{prefix}_estimated_force_n")
        posthoc = _column(rows, f"{prefix}_normal_force_n")
        axes[0].plot(time, estimated, color=FINGER_COLORS[finger], lw=1.2, label=f"F{finger+1} online estimate")
        axes[0].plot(time, posthoc, color=FINGER_COLORS[finger], lw=0.8, ls=":", alpha=0.8, label=f"F{finger+1} post-hoc normal")
        offset = _column(rows, f"{prefix}_controller_offset_rad")
        axes[1].plot(time, offset, color=FINGER_COLORS[finger], lw=1.2, label=f"F{finger+1}")
        for index, row in enumerate(rows):
            source.append(
                {
                    "time_s": time[index],
                    "phase": row["phase"],
                    "finger": finger + 1,
                    "target_force_n": target[index],
                    "online_estimated_force_n": estimated[index],
                    "posthoc_normal_force_n": posthoc[index],
                    "controller_offset_rad": offset[index],
                    "controller_frozen": row["force_controller_frozen"],
                    "target_change_rad": row["hand_target_change_max_rad"],
                }
            )
    switch_time = (_number(rows[_first_phase_index(rows, "FORCE_TARGET_RAMP")]["step"]) - _number(rows[0]["step"])) / PHYSICS_HZ
    quiet_time = (_number(rows[_first_phase_index(rows, "FORCE_QUIET_HOLD")]["step"]) - _number(rows[0]["step"])) / PHYSICS_HZ
    for ax in axes:
        ax.axvline(switch_time, color="#CC79A7", ls="--", lw=1, label="Bumpless switch")
        ax.axvline(quiet_time, color="#D55E00", ls="--", lw=1, label="Integrator/target frozen")
    axes[0].axhspan(7.25, 8.75, color="#009E73", alpha=0.08)
    axes[0].set_ylabel("Finger force (N)")
    axes[1].set_ylabel("Controller offset (rad)")
    axes[1].set_xlabel("Time from locked settle (s)")
    axes[0].legend(ncol=3, frameon=False)
    axes[1].legend(ncol=3, frameon=False)
    fig.suptitle("Bumpless compliant force control and FORCE_QUIET_HOLD freeze")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    figure_rows["FIGURE_07_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_07_COMPLIANT_FORCE_CONTROL")


def _figure8(output: Path, trace: Sequence[dict[str, str]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    rows = _trace_slice(trace, "FORCE_TARGET_SETTLE", "FINAL_HOLD")
    time = (_column(rows, "step") - _number(rows[0]["step"])) / PHYSICS_HZ
    target = _column(rows, "force_target_level_n")
    confirmation = _column(rows, "slip_confirmation_count")
    tcp = _column(rows, "tcp_z_m")
    object_lift = _column(rows, "object_lift_m")
    start_tcp = tcp[0]
    slip = np.abs((tcp - start_tcp) - np.nan_to_num(object_lift, nan=0.0)) * 1e6
    rotation = np.nan_to_num(_column(rows, "object_rotation_rad"), nan=0.0) * 180.0 / math.pi
    rho = np.nanmax(np.stack([_column(rows, f"f{i}_friction_utilization") for i in (1, 2, 3)]), axis=0)
    rho_plot = np.clip(np.nan_to_num(rho, nan=0.0, posinf=1.2), 0.0, 1.2)
    fig, axes = plt.subplots(4, 1, figsize=(10.6, 8.2), sharex=True)
    axes[0].step(time, target, where="post", color="#0072B2", lw=1.4, label="Force target")
    axes[0].plot(time, confirmation, color="#D55E00", lw=1.0, label="Slip confirmation count")
    axes[0].set_ylabel("N / steps")
    axes[0].legend(frameon=False, ncol=2)
    axes[1].plot(time, slip, color="#009E73", lw=1.2)
    axes[1].axhline(500, color="black", ls=":", lw=1)
    axes[1].set_ylabel("Axial slip (um)")
    axes[2].plot(time, rotation, color="#CC79A7", lw=1.2)
    axes[2].axhline(5, color="black", ls=":", lw=1)
    axes[2].set_ylabel("Relative rotation (deg)")
    axes[3].plot(time, rho_plot, color="#E69F00", lw=1.1)
    axes[3].axhline(0.70, color="#D55E00", ls="--", lw=1, label="0.70 soft metric")
    axes[3].axhline(1.0, color="black", ls=":", lw=1, label="friction boundary")
    axes[3].set_ylabel("rho (clipped at 1.2)")
    axes[3].set_xlabel("Time from force settle (s)")
    axes[3].legend(frameon=False, ncol=2)
    for index, row in enumerate(rows):
        if str(row.get("adaptive_event", "")).strip():
            for ax in axes:
                ax.axvline(time[index], color="#56B4E9", lw=0.9, alpha=0.8)
    fig.suptitle("Proprioceptive slip precursor, bounded adaptive grip, and post-hoc motion audit")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    figure_rows["FIGURE_08_SOURCE.csv"] = [
        {
            "time_s": time[index],
            "phase": row["phase"],
            "force_target_n": target[index],
            "slip_confirmation_count": confirmation[index],
            "adaptive_event": row.get("adaptive_event", ""),
            "axial_slip_um": slip[index],
            "relative_rotation_deg": rotation[index],
            "maximum_posthoc_rho": rho[index],
            "rho_plot_clipped": rho_plot[index],
        }
        for index, row in enumerate(rows)
    ]
    return _save_figure(fig, output, "FIGURE_08_ADAPTIVE_GRIP_SLIP")


def _figure9(output: Path, trace: Sequence[dict[str, str]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    rows = _trace_slice(trace, "LIFT_0.5MM", "FINAL_HOLD")
    time = (_column(rows, "step") - _number(rows[0]["step"])) / PHYSICS_HZ
    command = _column(rows, "arm_target_z_offset_m") * 1e3
    compensation = _column(rows, "arm_tracking_compensation_z_m") * 1e3
    tcp = (_column(rows, "tcp_z_m") - _number(rows[0]["tcp_z_m"])) * 1e3
    obj = _column(rows, "object_lift_m") * 1e3
    fig, ax = plt.subplots(figsize=(10.8, 4.4))
    ax.plot(time, command + compensation, color="black", ls="--", lw=1.4, label="Command TCP Z incl. load compensation")
    ax.plot(time, tcp, color="#0072B2", lw=1.5, label="Actual TCP Z")
    ax.plot(time, obj, color="#009E73", lw=1.4, label="Object Z")
    for phase, label in (("LIFT_0.5MM", "0.5"), ("LIFT_2.0MM", "2"), ("LIFT_10.0MM", "10"), ("LIFT_40.0MM", "40"), ("FINAL_HOLD", "hold")):
        index = _first_phase_index(rows, phase)
        boundary = time[index]
        ax.axvline(boundary, color="#999999", lw=0.75, ls=":")
        ax.text(boundary, 41.0, label, rotation=90, va="top", ha="right", fontsize=7)
    ax.set_xlabel("Time from first lift command (s)")
    ax.set_ylabel("Vertical displacement (mm)")
    ax.set_ylim(-1, 42)
    ax.legend(frameon=False, ncol=3)
    ax.set_title("Minimum-jerk four-stage lift tracking in the full iiwa scene")
    fig.tight_layout()
    figure_rows["FIGURE_09_SOURCE.csv"] = [
        {
            "time_s": time[index],
            "phase": row["phase"],
            "command_tcp_z_mm": command[index],
            "load_compensation_mm": compensation[index],
            "command_plus_compensation_mm": command[index] + compensation[index],
            "actual_tcp_z_mm": tcp[index],
            "object_z_mm": obj[index],
            "table_normal_force_n": row["table_normal_force_n"],
        }
        for index, row in enumerate(rows)
    ]
    return _save_figure(fig, output, "FIGURE_09_FOUR_STAGE_LIFT")


def _figure10(output: Path, trace: Sequence[dict[str, str]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    rows = [row for row in trace if row["phase"] == "FORCE_QUIET_HOLD"]
    if len(rows) != 120:
        raise ValueError(f"expected 120 FORCE_QUIET_HOLD rows, got {len(rows)}")
    time = (_column(rows, "step") - _number(rows[0]["step"])) / PHYSICS_HZ
    fig, axes = plt.subplots(2, 1, figsize=(10.4, 6.2))
    source = []
    p2p = []
    for finger, joint in enumerate(("f1j2", "f2j1", "f3j2")):
        raw = np.abs(_column(rows, f"{joint}_velocity_rad_s"))
        fd = np.abs(_column(rows, f"{joint}_qdot_fd_rad_s"))
        position = _column(rows, f"{joint}_position_rad")
        axes[0].plot(time, raw, color=FINGER_COLORS[finger], lw=1.1, label=f"F{finger+1} raw")
        axes[0].plot(time, fd, color=FINGER_COLORS[finger], lw=1.1, ls="--", label=f"F{finger+1} finite-difference")
        p2p_value = float(np.ptp(position)) * 1e6
        p2p.append(p2p_value)
        for index, row in enumerate(rows):
            source.append(
                {
                    "time_s": time[index],
                    "finger": finger + 1,
                    "raw_generalized_velocity_rad_s": raw[index],
                    "finite_difference_qdot_rad_s": fd[index],
                    "joint_position_rad": position[index],
                    "joint_position_peak_to_peak_urad": p2p_value,
                }
            )
    axes[0].axhline(0.03, color="#D55E00", ls=":", lw=1.2, label="Legacy instantaneous gate")
    axes[0].axhline(0.002, color="black", ls="--", lw=1, label="FD RMS absolute bound")
    axes[0].set_xlabel("Time in FORCE_QUIET_HOLD (s)")
    axes[0].set_ylabel("Absolute joint speed (rad/s)")
    axes[0].set_yscale("log")
    axes[0].legend(ncol=4, frameon=False)
    axes[0].set_title("Raw generalized velocity is diagnostic, not the settle gate")
    axes[1].bar(np.arange(3), p2p, color=FINGER_COLORS)
    axes[1].axhline(20.0, color="black", ls="--", lw=1, label="Frozen pre-run bound")
    axes[1].set_xticks(np.arange(3), ("F1", "F2", "F3"))
    axes[1].set_ylabel("Joint position peak-to-peak (urad)")
    axes[1].legend(frameon=False)
    fig.tight_layout()
    figure_rows["FIGURE_10_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_10_VELOCITY_GATE_EVIDENCE")


def _figure11(output: Path, baseline: Mapping[str, Any], selected_candidate: Mapping[str, Any], validation: Mapping[str, Any], trace: Sequence[Mapping[str, str]], figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    final_hold_rho = []
    for row in trace:
        if row.get("phase") != "FINAL_HOLD":
            continue
        normal_forces = [_number(row.get(f"f{finger}_normal_force_n")) for finger in (1, 2, 3)]
        rho_values = [_number(row.get(f"f{finger}_friction_utilization")) for finger in (1, 2, 3)]
        if all(math.isfinite(value) and value >= 1.0 for value in normal_forces) and all(math.isfinite(value) for value in rho_values):
            final_hold_rho.append(max(rho_values))
    if not final_hold_rho:
        raise RuntimeError("no valid FINAL_HOLD friction-utilization samples with all normal forces >= 1 N")
    stabilized_final_hold_max_rho = max(final_hold_rho)

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.4))
    axes[0].set_title("Legacy H25: contact role unresolved")
    _draw_cylinder_top(axes[0])
    axes[0].text(0, 3, "3 authorized link contacts\nPAD/TIP/SIDE partition: UNAVAILABLE\nload split / slip / rho: UNAVAILABLE", ha="center", va="center", fontsize=8.2)
    axes[0].text(0, -12, "2 mm stage not started", ha="center", color="#D55E00", fontweight="bold")
    axes[0].set_xlim(-32, 32)
    axes[0].set_ylim(-32, 32)
    axes[0].set_aspect("equal")
    axes[0].set_xlabel("X (mm)")
    axes[0].set_ylabel("Y (mm)")
    axes[1].set_title("Selected BG_P120_Z15")
    _plot_candidate_top(axes[1], selected_candidate)
    lift = validation["lift"]
    peak_normals = validation["maximum_posthoc_normal_force_n"]
    axes[1].text(
        0,
        -27.1,
        f"PAD share=100% each; lift={1e3*lift['object_lift_m']:.3f} mm; slip={1e6*lift['relative_axial_slip_m']:.1f} um\n"
        f"peak normal={peak_normals[0]:.2f}/{peak_normals[1]:.2f}/{peak_normals[2]:.2f} N; final-hold max rho={stabilized_final_hold_max_rho:.3f}",
        ha="center",
        va="top",
        fontsize=6.8,
        color="#0072B2",
    )
    axes[1].set_xlabel("X (mm)")
    axes[1].set_ylabel("Y (mm)")
    for ax in axes:
        ax.set_xlim(-32, 32)
        ax.set_ylim(-34, 32)
    fig.suptitle("Legacy fixed pose versus selected multi-grasp PAD solution")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    source = [
        {"metric": "contact_role_partition", "legacy_h25": "UNAVAILABLE", "selected": "PAD_SHARE_1.0_EACH"},
        {"metric": "authorized_contacts", "legacy_h25": baseline["three_authorized_finger_contacts_at_failure"], "selected": 3},
        {"metric": "object_z_change_mm", "legacy_h25": baseline["plug_truth_z_change_um"] / 1000.0, "selected": 1e3 * lift["object_lift_m"]},
        {"metric": "two_mm_stage_completed", "legacy_h25": False, "selected": True},
        {"metric": "relative_slip_um", "legacy_h25": "UNAVAILABLE", "selected": 1e6 * lift["relative_axial_slip_m"]},
        {"metric": "final_hold_max_rho_all_fingers_normal_ge_1n", "legacy_h25": "UNAVAILABLE", "selected": stabilized_final_hold_max_rho},
        {"metric": "rho_sampling_condition", "legacy_h25": "UNAVAILABLE", "selected": "FINAL_HOLD_AND_ALL_FINGER_NORMAL_FORCE_GE_1N"},
        {"metric": "wrist_moment_nm", "legacy_h25": baseline["sensor_origin_moment_gate_score_nm"], "selected": validation["wrist"]["tare_compensated_moment_peak_nm"]},
        {"metric": "forty_mm_lift_completed", "legacy_h25": False, "selected": True},
    ]
    figure_rows["FIGURE_11_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_11_LEGACY_VS_SELECTED")


def _figure12(output: Path, figure_rows: dict[str, list[dict[str, Any]]]) -> dict[str, str]:
    fig, ax = plt.subplots(figsize=(11.2, 5.7))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 6)
    ax.axis("off")
    states = [
        ("HOME / approach", 0.7, 4.6, "#56B4E9"),
        ("Per-finger\ncontact-stop", 3.0, 4.6, "#0072B2"),
        ("Force closure\nverify", 5.3, 4.6, "#009E73"),
        ("Bumpless\ncompliance", 7.6, 4.6, "#009E73"),
        ("FORCE_QUIET_HOLD\nfreeze targets", 9.9, 4.6, "#E69F00"),
        ("Unsupported\nhold", 9.9, 2.4, "#E69F00"),
        ("Adaptive grip\n8 -> 10 -> 12 N", 7.6, 2.4, "#CC79A7"),
        ("Minimum-jerk lift\n0.5 / 2 / 10 / 40 mm", 5.3, 2.4, "#0072B2"),
        ("Final 2 s\nhold", 3.0, 2.4, "#009E73"),
        ("3 independent\nfull-iiwa validations", 0.7, 2.4, "#D55E00"),
    ]
    source = []
    for order, (label, x, y, color) in enumerate(states):
        box = patches.FancyBboxPatch((x, y), 1.6, 0.75, boxstyle="round,pad=0.06", facecolor=color, edgecolor="white", linewidth=1.2, alpha=0.90)
        ax.add_patch(box)
        ax.text(x + 0.8, y + 0.375, label, ha="center", va="center", color="white", fontsize=8, fontweight="bold")
        source.append({"order": order + 1, "state": label.replace("\n", " "), "x": x, "y": y})
    centers = [(x + 0.8, y + 0.375) for _, x, y, _ in states]
    for first, second in zip(centers, centers[1:]):
        ax.annotate("", xy=second, xytext=first, arrowprops={"arrowstyle": "->", "lw": 1.4, "color": "#4D4D4D", "connectionstyle": "arc3,rad=0"})
    ax.text(6, 0.9, "Hard safety gates: finite states, joint limits/speed, <=15 N/finger, no TIP/SIDE/old hull bearing,\nno unauthorized contact or pose writes, no severe solver error, 1.00 N m simulation emergency stop", ha="center", va="center", fontsize=8, bbox={"boxstyle": "round", "facecolor": "#F0F0F0", "edgecolor": "#888888"})
    ax.set_title("B-stage closed-loop state machine and evidence hierarchy", fontsize=11)
    figure_rows["FIGURE_12_SOURCE.csv"] = source
    return _save_figure(fig, output, "FIGURE_12_STATE_MACHINE")


def _captions() -> dict[str, tuple[str, str]]:
    return {
        "Figure 1": ("经用户确认的蓝色指腹、红色指尖、任务相关解析指腹胶囊及连接器圆柱的四视图。高摩擦只属于蓝色PAD承载面。", "Four-view audit of the user-confirmed blue PAD, red TIP, task-specific analytic PAD capsule, and connector cylinder. High friction is assigned only to the blue PAD bearing surface."),
        "Figure 2": ("冻结的12个候选的统一比例离线总览。全部候选仅完成几何、303点扫掠、力封闭和任务扳手筛选；只有Top 3进入动态比较。", "Equal-scale overview of the 12 frozen offline candidates. All underwent geometry, 303-sample sweep, force-closure, and task-wrench screening; only the Top 3 entered dynamic comparison."),
        "Figure 3": ("候选排名、任务扳手裕量和Top 3动态滑移/摩擦利用率的Pareto关系。蓝色表示最终选择BG_P120_Z15。", "Candidate ranking and Pareto relations for task-wrench margin and Top-3 dynamic slip/friction utilization. Blue marks the selected BG_P120_Z15."),
        "Figure 4": ("Top 3候选的正视、俯视、侧视和斜视投影，显示三接触点、径向法向、连接器轴线和任务模型质心。", "Front, top, side, and oblique projections of the Top 3 candidates showing contact points, radial normals, connector axis, and task-model center of mass."),
        "Figure 5": ("三指独立位置接近和接触即停时序。竖线为每根手指首次锁定时刻。", "Independent position approach and contact-triggered stop timing. Vertical lines mark the first lock event of each finger."),
        "Figure 6": ("12候选的重力、抬升和有界任务扳手安全因子及预测峰值单指力。5 N、2 N、0.05 N m和0.18 N m仅是实验包络。", "Gravity, lift, and bounded task-wrench safety factors and predicted peak finger force for all 12 candidates. The 5 N, 2 N, 0.05 N m, and 0.18 N m loads are experimental envelopes only."),
        "Figure 7": ("无扰切换后的逐指柔顺力控制；虚线后积分器和目标冻结进入FORCE_QUIET_HOLD。实线估计力供在线控制，点线PhysX法向力仅供后验审计。", "Per-finger compliant force control after bumpless transfer; the integrator and targets are frozen for FORCE_QUIET_HOLD. Solid estimated forces drive control, whereas dotted PhysX normal forces are post-hoc audit only."),
        "Figure 8": ("本体感觉滑移前兆、8/9/10 N有界增力和后验滑移/转角/rho。rho=0.70是软质量指标；任务失败要求rho>1连续至少12步或真实滑移证据。", "Proprioceptive slip precursor, bounded 8/9/10 N adaptation, and post-hoc slip/rotation/rho. rho=0.70 is a soft quality metric; task failure requires rho>1 for at least 12 consecutive steps or physical slip evidence."),
        "Figure 9": ("完整iiwa场景中的minimum-jerk四级抬升。TCP实际位移跟踪0.5/2/10/40 mm，活动端从真实桌面卸载并最终抬升39.907 mm。", "Minimum-jerk four-stage lift in the full-iiwa scene. Actual TCP motion tracks 0.5/2/10/40 mm while the object unloads from the real table and reaches 39.907 mm."),
        "Figure 10": ("FORCE_QUIET_HOLD中Isaac原始广义速度与位置差分速度的数量级差异；实际位置峰峰值支持删除0.03 rad/s瞬时稳定硬门。", "Order-of-magnitude discrepancy between Isaac raw generalized velocity and finite-difference velocity during FORCE_QUIET_HOLD; actual position peak-to-peak supports removal of the instantaneous 0.03 rad/s settle gate."),
        "Figure 11": ("H25旧固定姿态与最终BG_P120_Z15比较。旧证据没有PAD/TIP/SIDE分区，不能被补推；最终姿态记录三指PAD占比100%并完成40 mm抬升。", "Comparison of legacy fixed H25 and final BG_P120_Z15. The legacy evidence lacks PAD/TIP/SIDE partition and is not back-inferred; the final pose records 100% PAD share for all fingers and completes the 40 mm lift."),
        "Figure 12": ("B阶段闭环状态机与证据流，包含逐指接触即停、力封闭、无扰柔顺、安静保持、自适应抓力、四级抬升和三进程验证。", "B-stage closed-loop state machine and evidence flow, including per-finger contact stop, force closure, bumpless compliance, quiet hold, adaptive grip, four-stage lift, and three-process validation."),
    }


def _write_reports(output: Path, candidate_table: Sequence[Mapping[str, Any]], top3_table: Sequence[Mapping[str, Any]], validation_table: Sequence[Mapping[str, Any]]) -> None:
    selected_dynamic = next(row for row in top3_table if row["candidate_id"] == SELECTED)
    validation = validation_table[0]
    method_cn = f"""# D38999 B阶段方法

## 问题与语义边界

目标系统包含完整KUKA iiwa、空间三指手、真实桌面和质量0.31 kg的D38999活动端。用户确认蓝色宽大内侧面为PAD承载面，红色component 4为TIP。正式接触链仅使用每指一个经审计的中央解析PAD胶囊；红TIP、SIDE和旧整节凸包均不得成为主承载面。仿真接触点、法向和对象位姿只用于物理步后的审计，从不改变在线命令。

## 候选生成与力封闭

冻结搜索包含12个候选（6个preshape乘2个抓取z），每个候选执行303点离线扫掠、三指可达/间隙检查、摩擦锥抓持矩阵、带法向力上限的力封闭和任务扳手评价。12个候选全部只是离线验证；Top 3（BG_P120_Z15、BG_P124_Z15、BG_P128_Z15）各执行一次相同动态比较；最终仅BG_P120_Z15进入完整iiwa三进程验证。

## 逐指接触即停与无扰柔顺

三根手指独立位置接近。每根手指的指根力矩增量达到稳定接触判据后单独锁定，其余手指继续搜索。三指锁定后，将各自当前接触位置作为平衡点，无扰切换到逐指柔顺力控制。共同抓紧分量维持摩擦裕量，零和差分分量降低载荷不均；积分器具有限幅和anti-windup。

## 安静保持和自适应抓力

连续48个物理步位于8±0.75 N估计带后，冻结积分器和手指目标120步。稳定性由实际关节位置峰峰值和位置差分qdot RMS相对同运行基线判断；Isaac原始广义速度仅保留8 rad/s异常安全守卫和诊断。初始目标8 N/指，本体感觉力偏置/速度残差连续确认后依次增至9、10或12 N，15 N为硬上限。rho=0.70为软指标；rho>1连续12步才是任务门。

## 抬升与安全门

Z方向使用minimum-jerk位置轨迹依次执行0.5、2、10、40 mm。首次卸载后仅依据机器人关节位置FK计算一次72.916 um负载转移补偿，不读取对象或接触真值。0.30 N m是质量软目标，0.60 N m连续5步进入恢复，1.00 N m为仿真专用紧急门。硬门还包括非有限状态、关节超限/异常高速、单指超过15 N、对象位姿写入、在线真值、TIP/SIDE/旧凸包承载、未授权碰撞及严重求解器错误。
"""
    method_en = f"""# D38999 B-stage method

## Problem and semantic boundary

The system comprises the complete KUKA iiwa, spatial three-finger hand, physical table, and a 0.31 kg D38999 movable end. The user-confirmed broad blue inner surface is the PAD, whereas red component 4 is the TIP. The formal contact chain uses one audited central analytic PAD capsule per finger; the red TIP, SIDE surfaces, and legacy whole-link hull cannot be load bearing. PhysX contact points/normals and object pose are consumed only after each step for audit and never alter online commands.

## Candidate generation and force closure

The frozen set contains 12 candidates (six preshapes by two grasp heights). Each candidate undergoes a 303-sample offline sweep, reachability/clearance checks, friction-cone grasp-matrix analysis, bounded-normal-force closure, and task-wrench evaluation. All 12 are offline-only; the Top 3 (BG_P120_Z15, BG_P124_Z15, BG_P128_Z15) receive one matched dynamic comparison each; only BG_P120_Z15 proceeds to three full-iiwa validation processes.

## Per-finger contact stop and bumpless compliance

The fingers approach independently under position control. A stable root-torque increment locks only the contacting finger while the others continue searching. Once all three are locked, their measured contact positions define equilibrium points for a bumpless transfer to per-finger compliant force control. A common grip component maintains friction margin, while a zero-sum differential component reduces load imbalance; bounded integrators include anti-windup.

## Quiet hold and adaptive grip

After 48 consecutive physics steps inside the estimated 8±0.75 N band, the integrators and finger targets are frozen for 120 steps. Stability is judged from actual joint-position peak-to-peak and finite-difference qdot RMS relative to a same-run baseline. Isaac raw generalized velocity remains only for diagnostics and an 8 rad/s abnormal-speed guard. The grip starts at 8 N/finger and increases to 9, 10, or 12 N after confirmed proprioceptive force-bias/velocity residuals; 15 N is the hard cap. rho=0.70 is soft, whereas rho>1 for 12 consecutive steps is a task gate.

## Lift and safety

Minimum-jerk Z trajectories command 0.5, 2, 10, and 40 mm. After first table unloading, a single 72.916 um load-transfer correction is computed only from robot joint-position FK; no object/contact truth is read. A 0.30 N m wrist moment is a quality target, 0.60 N m for five consecutive steps invokes recovery, and 1.00 N m is a simulation-only emergency gate. Other hard gates cover nonfinite states, joint limits/abnormal speed, >15 N per finger, object-pose writes, online truth, TIP/SIDE/legacy-hull bearing, unauthorized collision, and severe solver errors.
"""
    experiment_cn = f"""# D38999 B阶段实验与结果

## 实验层级

- 12个候选：全部完成离线几何、303点扫掠、力封闭和任务扳手评价；没有宣称12个全部动态验证。
- Top 3：每个候选在相同最小三指动态条件下运行一次，执行逐指接触、8 N起步柔顺抓力、2秒无支撑保持及四级抬升记录。
- 最终候选：BG_P120_Z15在完整iiwa、桌面和0.31 kg活动端中运行三个全新独立Isaac进程。

## Top 3结果

BG_P120_Z15、BG_P124_Z15和BG_P128_Z15均通过单次动态比较。完整序列最大轴向滑移分别为{top3_table[0]['full_sequence_max_slip_um']:.3f}、{top3_table[1]['full_sequence_max_slip_um']:.3f}和{top3_table[2]['full_sequence_max_slip_um']:.3f} um；最大相对转角分别为{top3_table[0]['full_sequence_max_rotation_deg']:.4f}、{top3_table[1]['full_sequence_max_rotation_deg']:.4f}和{top3_table[2]['full_sequence_max_rotation_deg']:.4f} deg。BG_P120_Z15同时具有最高离线TWS安全因子和关节余量，因此被选择。

## 完整iiwa三进程验证

三个进程均执行10665个物理步并输出`FULL_IIWA_TABLE_PICK_VALIDATION_PASS`。TCP四阶段位移为{validation['tcp_lift_0p5_mm']:.6f}、{validation['tcp_lift_2_mm']:.6f}、{validation['tcp_lift_10_mm']:.6f}和{validation['tcp_lift_40_mm']:.6f} mm；活动端最终抬升{validation['final_object_lift_mm']:.6f} mm，轴向相对滑移{validation['relative_axial_slip_um']:.3f} um，横向漂移{validation['lateral_drift_um']:.3f} um，倾角{validation['tilt_deg']:.6f} deg。三指PAD冲量占比均为100%，TIP未主承载，峰值后验单指法向力{validation['peak_posthoc_force_n']:.3f} N。

腕部原始峰值为{validation['wrist_raw_force_peak_n']:.3f} N和{validation['wrist_raw_moment_peak_nm']:.3f} N m；同运行tare补偿后的增量峰值为{validation['wrist_tare_force_peak_n']:.3f} N和{validation['wrist_tare_moment_peak_nm']:.3f} N m。0.30 N m软目标超限{validation['wrist_soft_0p30_exceed_s']:.3f} s，0.60 N m恢复门持续超限为0，1.00 N m紧急门未触发。

## 结论与限制

三进程均满足完整iiwa B阶段仿真门，因此聚合状态为`B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS`。该结论是仿真专用B阶段结果，不代表实体硬件安全认证或完整装配链通过。实体迁移前仍需标定指根力矩到法向力映射、真实PAD/螺母摩擦区间、六维力传感器量程和腕部/法兰硬件门限。
"""
    experiment_en = f"""# D38999 B-stage experiments and results

## Evidence hierarchy

- Twelve candidates underwent offline geometry, a 303-sample sweep, force-closure, and task-wrench evaluation. We do not claim that all 12 were dynamically tested.
- The Top 3 received one matched minimal-hand dynamic comparison each, including independent contact acquisition, compliant grip starting at 8 N, a 2 s unsupported hold, and recorded multistage lifting.
- The selected BG_P120_Z15 was evaluated in three new independent Isaac processes with the complete iiwa, table, and 0.31 kg movable end.

## Top-3 results

BG_P120_Z15, BG_P124_Z15, and BG_P128_Z15 all passed their single dynamic comparison. Maximum full-sequence axial slip was {top3_table[0]['full_sequence_max_slip_um']:.3f}, {top3_table[1]['full_sequence_max_slip_um']:.3f}, and {top3_table[2]['full_sequence_max_slip_um']:.3f} um; maximum relative rotation was {top3_table[0]['full_sequence_max_rotation_deg']:.4f}, {top3_table[1]['full_sequence_max_rotation_deg']:.4f}, and {top3_table[2]['full_sequence_max_rotation_deg']:.4f} deg. BG_P120_Z15 also had the highest offline TWS safety factor and joint margin and was therefore selected.

## Three-process full-iiwa validation

Each process executed 10,665 physics steps and reported `FULL_IIWA_TABLE_PICK_VALIDATION_PASS`. TCP displacements were {validation['tcp_lift_0p5_mm']:.6f}, {validation['tcp_lift_2_mm']:.6f}, {validation['tcp_lift_10_mm']:.6f}, and {validation['tcp_lift_40_mm']:.6f} mm. Final object lift was {validation['final_object_lift_mm']:.6f} mm, relative axial slip {validation['relative_axial_slip_um']:.3f} um, lateral drift {validation['lateral_drift_um']:.3f} um, and tilt {validation['tilt_deg']:.6f} deg. All three PAD impulse shares were 100%, the TIP was not load bearing, and peak post-hoc per-finger normal force was {validation['peak_posthoc_force_n']:.3f} N.

Raw wrist peaks were {validation['wrist_raw_force_peak_n']:.3f} N and {validation['wrist_raw_moment_peak_nm']:.3f} N m; same-run tare-compensated incremental peaks were {validation['wrist_tare_force_peak_n']:.3f} N and {validation['wrist_tare_moment_peak_nm']:.3f} N m. The 0.30 N m soft target was exceeded for {validation['wrist_soft_0p30_exceed_s']:.3f} s, the 0.60 N m recovery gate had zero sustained exceedance, and the 1.00 N m emergency gate did not trigger.

## Conclusion and limitations

All three processes satisfy the full-iiwa B-stage simulation gates, yielding `B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS`. This is a simulation-only B-stage result, not hardware safety certification or full assembly-chain completion. Hardware transfer still requires calibration of root-torque-to-normal-force mapping, real PAD/nut friction, six-axis sensor ranges, and wrist/flange hardware limits.
"""
    (output / "B_METHOD_SECTION_CN.md").write_text(method_cn, encoding="utf-8")
    (output / "B_METHOD_SECTION_EN.md").write_text(method_en, encoding="utf-8")
    (output / "B_EXPERIMENT_SECTION_CN.md").write_text(experiment_cn, encoding="utf-8")
    (output / "B_EXPERIMENT_SECTION_EN.md").write_text(experiment_en, encoding="utf-8")


def _arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=Path(__file__).resolve().parents[6])
    parser.add_argument("--output-dir")
    parser.add_argument("--closeout-dir", default="artifacts/b_goal_mode/B_FULL_IIWA_SCI_CLOSEOUT_20260820T081608Z")
    parser.add_argument("--candidate-dir", default="artifacts/b_goal_mode/B_GOAL_MODE_SESSION_20260819T213558Z/experiments/G7_BOUNDED_CANDIDATE_SEARCH_01")
    parser.add_argument("--dynamic-session", default="artifacts/b_goal_mode/B_GOAL_MODE_SESSION_20260820T082003Z")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = _arguments(argv)
    repo = Path(args.repo_root).expanduser().resolve()
    output = Path(args.output_dir).expanduser().resolve() if args.output_dir else repo / "artifacts/b_goal_mode/publication_figures"
    closeout = repo / args.closeout_dir
    candidate_dir = repo / args.candidate_dir
    session = repo / args.dynamic_session
    output.mkdir(parents=True, exist_ok=True)
    data_dir = output / "source_data"
    data_dir.mkdir(parents=True, exist_ok=True)
    _configure_plotting()

    candidate_path = candidate_dir / "B_GOAL_MODE_CANDIDATES.json"
    candidate_bundle = _json(candidate_path)
    candidates = _candidate_sources(candidate_bundle)
    by_id = {candidate["candidate_id"]: candidate for candidate in candidates}
    top3_results = {
        candidate_id: _json(session / "experiments" / f"TOP3_DYNAMIC_COMPARISON_{candidate_id}" / "G4567_RESULT.json")
        for candidate_id in TOP3
    }
    validation_paths = [
        session / "experiments" / f"FULL_IIWA_TABLE_PICK_VALIDATION_{index:02d}" / "FULL_IIWA_RESULT.json"
        for index in (1, 2, 3)
    ]
    trace_paths = [path.with_name("FULL_IIWA_TRACE.csv") for path in validation_paths]
    validation_results = [_json(path) for path in validation_paths]
    trace = _rows(trace_paths[0])
    baseline_path = repo / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2/DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP/LEGACY_H25_BASELINE.json"
    baseline = _json(baseline_path)

    candidate_table = _candidate_table(candidates)
    top3_table = _top3_table(top3_results, by_id)
    validation_table, validation_checks = _validation_table(validation_results)
    if not all(all(checks.values()) for checks in validation_checks):
        _write_json(output / "B_FULL_IIWA_VALIDATION_GATE_FAILURE.json", {"schema": SCHEMA, "checks": validation_checks})
        raise RuntimeError("three-process full-iiwa validation aggregate gate failed")

    _write_csv(output / "B_CANDIDATE_COMPARISON_TABLE.csv", list(candidate_table[0]), candidate_table)
    _write_csv(output / "B_TOP3_DYNAMIC_COMPARISON_TABLE.csv", list(top3_table[0]), top3_table)
    _write_csv(output / "B_FULL_IIWA_THREE_PROCESS_RESULTS.csv", list(validation_table[0]), validation_table)
    threshold_source = closeout / "analysis/B_THRESHOLD_AUDIT.csv"
    shutil.copy2(threshold_source, output / "B_THRESHOLD_AUDIT.csv")

    ablation_rows = [
        {"comparison": "Legacy fixed pose", "variant": "H25 fixed authorized-link pose", "evidence": "DYNAMIC_LEGACY", "pad_semantics": "UNDETERMINED", "adaptive_grip": "NO", "differential_centering": "NO", "outcome": "FAIL_BEFORE_2MM", "metric": "object_z_change_um", "value": baseline["plug_truth_z_change_um"], "limitation": "PAD/TIP/SIDE partition unavailable"},
        {"comparison": "Single PAD pose", "variant": "PAD_CORE_Z12", "evidence": "DYNAMIC_DIAGNOSTIC_BASELINE", "pad_semantics": "PAD_CORE_PROXY", "adaptive_grip": "NO", "differential_centering": "NO", "outcome": "FAIL", "metric": "classification", "value": "B_MINIMAL_V2_THREE_PAD_CONTACT_LOSS", "limitation": "minimal rig; not matched full-iiwa control"},
        {"comparison": "Multi-pose PAD search", "variant": "12 offline -> Top3 dynamic -> P120 final", "evidence": "OFFLINE_PLUS_DYNAMIC", "pad_semantics": "PAD_ONLY", "adaptive_grip": "YES", "differential_centering": "YES", "outcome": "PASS", "metric": "final_object_lift_mm", "value": validation_table[0]["final_object_lift_mm"], "limitation": "simulation-only"},
        {"comparison": "Fixed vs adaptive grip", "variant": "8 N initial -> bounded 9/10/12 N", "evidence": "WITHIN_RUN_EVENT_EVIDENCE", "pad_semantics": "PAD_ONLY", "adaptive_grip": "YES", "differential_centering": "YES", "outcome": "PASS", "metric": "adaptive_events", "value": len(validation_results[0]["adaptive_events"]), "limitation": "no matched full-iiwa fixed-force counterfactual"},
        {"comparison": "Load balance vs common+differential", "variant": "orthogonal common grip + zero-sum centering", "evidence": "CONTROLLER_AND_TRACE", "pad_semantics": "PAD_ONLY", "adaptive_grip": "YES", "differential_centering": "YES", "outcome": "PASS", "metric": "peak_estimated_force_imbalance_n", "value": max(validation_results[0]["maximum_estimated_force_n"]) - min(validation_results[0]["maximum_estimated_force_n"]), "limitation": "no matched load-equality-only full-iiwa run"},
    ]
    _write_csv(output / "B_ABLATION_TABLE.csv", list(ablation_rows[0]), ablation_rows)

    figure_rows: dict[str, list[dict[str, Any]]] = {}
    figure_files = {
        "Figure 1": _figure1(output, repo, figure_rows),
        "Figure 2": _figure2(output, candidates, figure_rows),
        "Figure 3": _figure3(output, candidate_table, top3_table, figure_rows),
        "Figure 4": _figure4(output, by_id, figure_rows),
        "Figure 5": _figure5(output, trace, figure_rows),
        "Figure 6": _figure6(output, candidate_table, figure_rows),
        "Figure 7": _figure7(output, trace, figure_rows),
        "Figure 8": _figure8(output, trace, figure_rows),
        "Figure 9": _figure9(output, trace, figure_rows),
        "Figure 10": _figure10(output, trace, figure_rows),
        "Figure 11": _figure11(output, baseline, by_id[SELECTED], validation_results[0], trace, figure_rows),
        "Figure 12": _figure12(output, figure_rows),
    }
    for name, rows in figure_rows.items():
        if not rows:
            raise RuntimeError(f"empty source data: {name}")
        _write_csv(data_dir / name, list(rows[0]), rows)

    captions = _captions()
    caption_lines = ["# Figure captions / 图片说明", ""]
    manifest_rows = []
    for figure_id in (f"Figure {index}" for index in range(1, 13)):
        cn, en = captions[figure_id]
        caption_lines.extend((f"## {figure_id}", "", f"中文：{cn}", "", f"English: {en}", ""))
        files = figure_files[figure_id]
        source_name = f"FIGURE_{int(figure_id.split()[1]):02d}_SOURCE.csv"
        manifest_rows.append(
            {
                "figure_id": figure_id,
                "png": files["png"],
                "vector_pdf": files["pdf"],
                "vector_svg": files["svg"],
                "source_csv": f"source_data/{source_name}",
                "png_dpi": 360,
                "caption_language": "CN_EN",
                "evidence_role": "OFFLINE_GEOMETRY" if int(figure_id.split()[1]) <= 4 or int(figure_id.split()[1]) in (6, 12) else "POSTHOC_DYNAMIC_AUDIT",
            }
        )
    (output / "FIGURE_CAPTIONS_CN_EN.md").write_text("\n".join(caption_lines), encoding="utf-8")
    _write_csv(output / "FIGURE_MANIFEST.csv", list(manifest_rows[0]), manifest_rows)

    _write_reports(output, candidate_table, top3_table, validation_table)
    shutil.copy2(Path(__file__), output / "generate_b_sci_figures.py")

    pass_record = {
        "schema": "D38999_B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS_V1",
        "status": "B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS",
        "passed": True,
        "candidate_id": SELECTED,
        "scope": "SIMULATION_ONLY_B_STAGE_FULL_IIWA_TABLE_PICK",
        "not_claimed": ["HARDWARE_SAFETY_CERTIFICATION", "FULL_CHAIN_DYNAMIC_PASS", "C_STAGE", "D_STAGE", "E_STAGE"],
        "evidence_hierarchy": {
            "offline_candidate_count": 12,
            "offline_candidates_all_dynamic": False,
            "top3_single_dynamic_comparison": list(TOP3),
            "formal_full_iiwa_validation_process_count": 3,
        },
        "validation_processes": [
            {
                "validation_index": index,
                "result": str(path.relative_to(repo)),
                "trace": str(trace_path.relative_to(repo)),
                "result_sha256": _sha256(path),
                "trace_sha256": _sha256(trace_path),
                "checks": validation_checks[index - 1],
            }
            for index, (path, trace_path) in enumerate(zip(validation_paths, trace_paths), start=1)
        ],
        "aggregate_metrics": {
            "physics_steps_each": [row["physics_steps"] for row in validation_table],
            "final_object_lift_mm": [row["final_object_lift_mm"] for row in validation_table],
            "relative_axial_slip_um": [row["relative_axial_slip_um"] for row in validation_table],
            "lateral_drift_um": [row["lateral_drift_um"] for row in validation_table],
            "tilt_deg": [row["tilt_deg"] for row in validation_table],
            "minimum_pad_normal_impulse_share": min(row["pad_share_min"] for row in validation_table),
            "red_tip_main_bearing_any": any(row["tip_main_bearing"] for row in validation_table),
            "peak_estimated_force_n": max(row["peak_estimated_force_n"] for row in validation_table),
            "peak_posthoc_normal_force_n": max(row["peak_posthoc_force_n"] for row in validation_table),
            "peak_raw_wrist_force_n": max(row["wrist_raw_force_peak_n"] for row in validation_table),
            "peak_raw_wrist_moment_nm": max(row["wrist_raw_moment_peak_nm"] for row in validation_table),
            "peak_tare_compensated_wrist_force_n": max(row["wrist_tare_force_peak_n"] for row in validation_table),
            "peak_tare_compensated_wrist_moment_nm": max(row["wrist_tare_moment_peak_nm"] for row in validation_table),
            "object_pose_writes_total": sum(int(row["object_pose_writes"]) for row in validation_table),
        },
        "truth_boundary": {
            "online_object_truth_used": False,
            "online_contact_truth_used": False,
            "posthoc_physx_contact_used_for_audit": True,
            "object_pose_writes_after_physics": 0,
        },
        "hardware_calibration_remaining": [
            "root_torque_to_pad_normal_force",
            "real_pad_to_nut_friction_and_uncertainty",
            "six_axis_force_torque_sensor_range_and_overload",
            "wrist_flange_and_fastener_limits",
            "iiwa_end_effector_hardware_force_moment_limits",
        ],
    }
    _write_json(closeout / "B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS.json", pass_record)
    _write_json(output / "B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS.json", pass_record)
    _write_json(
        output / "PUBLICATION_DATA_LINEAGE.json",
        {
            "schema": SCHEMA,
            "candidate_source": str(candidate_path.relative_to(repo)),
            "top3_results": {candidate_id: str((session / "experiments" / f"TOP3_DYNAMIC_COMPARISON_{candidate_id}" / "G4567_RESULT.json").relative_to(repo)) for candidate_id in TOP3},
            "validation_results": [str(path.relative_to(repo)) for path in validation_paths],
            "validation_traces": [str(path.relative_to(repo)) for path in trace_paths],
            "legacy_baseline": str(baseline_path.relative_to(repo)),
            "online_truth_used_by_controller": False,
        },
    )

    print(json.dumps({"status": "PASS", "output_dir": str(output), "figures": 12, "formal_pass_json": str(closeout / "B_FULL_IIWA_TABLE_PICK_DYNAMIC_PASS.json")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
