#!/usr/bin/env python3
"""Own B_GOAL_MODE child processes and preserve uploadable checkpoints.

The supervisor deliberately uses only the Python standard library so it can
still stop and package a run when the Isaac environment itself is unhealthy.
Every Isaac command is launched in its own process group, allowing a bounded
TERM-to-KILL shutdown without matching unrelated workstation processes.
"""

from __future__ import annotations

import argparse
import atexit
import csv
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence


MODE_NAME = "B_GOAL_MODE_AUTONOMOUS"
CHECKPOINT_NAME = "B_GOAL_MODE_LATEST_CHECKPOINT.tar.gz"
ACTIVE_SESSION_POINTER = "ACTIVE_SESSION_PATH.txt"
STATE_NAME = "CURRENT_GOAL_STATE.json"
LEDGER_NAME = "EXPERIMENT_LEDGER.csv"
SUMMARY_NAME = "SESSION_SUMMARY_CN.md"
STOP_SUMMARY_NAME = "STOP_SESSION_SUMMARY_CN.md"
STOP_PATH_NAME = "STOP_PACKAGE_PATH.txt"
PACKAGE_INTERVAL_SECONDS = 15 * 60
CHILD_TERM_GRACE_SECONDS = 10.0

LEDGER_FIELDS = (
    "utc_start",
    "utc_end",
    "goal_id",
    "unique_change",
    "expected_result",
    "failure_criterion",
    "failure_branch",
    "command",
    "log_path",
    "child_pid",
    "exit_code",
    "outcome",
)

SOURCE_ROOTS = (
    "run_b_goal_mode_supervisor.sh",
    "src/kcg_connector/kcg_connector/grasp/b_goal_mode",
    "src/kcg_connector/isaac/b_goal_mode",
    "src/kcg_connector/config/b_goal_mode",
)

REGENERABLE_DIRECTORY_NAMES = {
    "rig_usd",
    "render_cache",
    "__pycache__",
}
EXCLUDED_SUFFIXES = {".tar", ".gz", ".tgz", ".usd", ".usda", ".usdc"}


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    atomic_write_text(
        path,
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
    )


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def quote_command(command: Sequence[str]) -> str:
    import shlex

    return shlex.join(command)


def is_excluded(path: Path) -> bool:
    if any(part.startswith(".portable_") for part in path.parts):
        return True
    if any(part in REGENERABLE_DIRECTORY_NAMES for part in path.parts):
        return True
    if path.name.endswith("_STAGE.usd") or path.name.endswith("_STAGE.usda"):
        return True
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    return False


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def tail_text_file(source: Path, destination: Path, lines: int = 3000) -> None:
    # Logs are textual Isaac output. Decoding errors must never prevent a stop
    # package, so replacement is intentional here.
    content = source.read_text(encoding="utf-8", errors="replace").splitlines()
    atomic_write_text(destination, "\n".join(content[-lines:]) + "\n")


def run_git(repo_root: Path, *arguments: str) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=repo_root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    return completed.stdout


def append_ledger(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=LEDGER_FIELDS)
        if not exists:
            writer.writeheader()
        writer.writerow({field: row.get(field, "") for field in LEDGER_FIELDS})
        stream.flush()
        os.fsync(stream.fileno())


def ensure_ledger(path: Path) -> None:
    if not path.exists():
        append_ledger(path, {})
        rows = path.read_text(encoding="utf-8").splitlines()
        atomic_write_text(path, rows[0] + "\n")


def render_summary(state: dict[str, Any], *, stopped: bool = False) -> str:
    title = "B_GOAL_MODE 停止摘要" if stopped else "B_GOAL_MODE 会话摘要"
    return "\n".join(
        (
            f"# {title}",
            "",
            f"- 会话：`{state.get('session_id', 'UNKNOWN')}`",
            f"- 模式：`{state.get('mode', MODE_NAME)}`",
            f"- 当前目标门：`{state.get('current_goal_gate', 'UNKNOWN')}`",
            f"- 状态：`{state.get('status', 'UNKNOWN')}`",
            f"- 最佳结果：`{state.get('best_result', 'NONE')}`",
            f"- 停止原因：`{state.get('stop_reason') or 'NONE'}`",
            f"- 下一步建议：{state.get('next_recommended_action', '继续当前目标门。')}",
            f"- 最近更新：`{state.get('updated_utc', 'UNKNOWN')}`",
            "",
        )
    )


def refresh_session_metadata(repo_root: Path, session_dir: Path) -> dict[str, Any]:
    state_path = session_dir / STATE_NAME
    state = read_json(state_path)
    state["updated_utc"] = utc_iso()
    atomic_write_json(state_path, state)
    atomic_write_text(session_dir / SUMMARY_NAME, render_summary(state))
    atomic_write_text(session_dir / "GIT_STATUS.txt", run_git(repo_root, "status", "--short", "--untracked-files=all"))
    atomic_write_text(session_dir / "GIT_DIFF.patch", run_git(repo_root, "diff", "--no-ext-diff", "--binary"))
    return state


def copy_session_evidence(session_dir: Path, stage_root: Path) -> None:
    destination_root = stage_root / session_dir.name
    for source in sorted(session_dir.rglob("*")):
        if not source.is_file() or is_excluded(source.relative_to(session_dir)):
            continue
        relative = source.relative_to(session_dir)
        if source.suffix.lower() == ".log":
            tail_text_file(source, destination_root / "LOG_TAILS" / relative)
        else:
            copy_file(source, destination_root / relative)


def copy_source_snapshot(repo_root: Path, session_dir: Path, stage_root: Path) -> None:
    destination_root = stage_root / session_dir.name / "SOURCE_SNAPSHOT"
    for relative_text in SOURCE_ROOTS:
        source = repo_root / relative_text
        if not source.exists():
            continue
        if source.is_file():
            copy_file(source, destination_root / relative_text)
            continue
        for child in sorted(source.rglob("*")):
            if child.is_file() and not is_excluded(child.relative_to(repo_root)):
                copy_file(child, destination_root / child.relative_to(repo_root))

    # Candidate/config evidence can predate goal mode but must be present in a
    # stop package when a run used it.
    config_root = repo_root / "src/kcg_connector/config"
    if config_root.exists():
        for child in sorted(config_root.rglob("*")):
            upper_name = child.name.upper()
            relevant = (
                "B_GOAL_MODE" in upper_name
                or "B_MINIMAL_V2_CANDIDATES" in upper_name
                or "B_MINIMAL_V2_PAD_CORE" in upper_name
            )
            if child.is_file() and relevant and not is_excluded(child.relative_to(repo_root)):
                copy_file(child, destination_root / child.relative_to(repo_root))


def write_manifest(stage_root: Path, session_name: str) -> None:
    entries: list[str] = []
    package_root = stage_root / session_name
    for path in sorted(package_root.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.txt":
            entries.append(f"{sha256(path)}  {path.relative_to(package_root)}")
    atomic_write_text(package_root / "SHA256SUMS.txt", "\n".join(entries) + "\n")


def create_package(
    *,
    repo_root: Path,
    session_dir: Path,
    target: Path,
    stopped: bool,
) -> tuple[int, str]:
    state = refresh_session_metadata(repo_root, session_dir)
    if stopped:
        atomic_write_text(session_dir / STOP_SUMMARY_NAME, render_summary(state, stopped=True))
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="b_goal_mode_package_") as temporary_text:
        stage_root = Path(temporary_text)
        copy_session_evidence(session_dir, stage_root)
        copy_source_snapshot(repo_root, session_dir, stage_root)
        write_manifest(stage_root, session_dir.name)
        temporary_archive = target.with_name(f".{target.name}.tmp.{os.getpid()}")
        try:
            with tarfile.open(temporary_archive, "w:gz") as archive:
                archive.add(stage_root / session_dir.name, arcname=session_dir.name)
            os.replace(temporary_archive, target)
        finally:
            temporary_archive.unlink(missing_ok=True)
    return target.stat().st_size, sha256(target)


def create_session(repo_root: Path) -> Path:
    artifacts_root = repo_root / "artifacts/b_goal_mode"
    artifacts_root.mkdir(parents=True, exist_ok=True)
    session_id = f"B_GOAL_MODE_SESSION_{utc_stamp()}"
    session_dir = artifacts_root / session_id
    suffix = 1
    while session_dir.exists():
        session_dir = artifacts_root / f"{session_id}_{suffix:02d}"
        suffix += 1
    session_dir.mkdir()
    state = {
        "schema": "D38999_B_GOAL_MODE_STATE_V1",
        "mode": MODE_NAME,
        "session_id": session_dir.name,
        "session_dir": str(session_dir),
        "created_utc": utc_iso(),
        "updated_utc": utc_iso(),
        "current_goal_gate": "G0_LIFT_AXIS_TRACKING",
        "status": "INITIALIZED",
        "best_result": "NONE",
        "stop_reason": None,
        "active_child": None,
        "next_recommended_action": "独立验证 lift_z 的 0.5/2/10/40 mm 真实跟踪。",
    }
    atomic_write_json(session_dir / STATE_NAME, state)
    ensure_ledger(session_dir / LEDGER_NAME)
    atomic_write_text(session_dir / SUMMARY_NAME, render_summary(state))
    atomic_write_text(artifacts_root / ACTIVE_SESSION_POINTER, str(session_dir) + "\n")
    return session_dir


def resolve_session(repo_root: Path, requested: str | None) -> Path:
    if requested:
        session_dir = Path(requested).expanduser().resolve()
    else:
        pointer = repo_root / "artifacts/b_goal_mode" / ACTIVE_SESSION_POINTER
        if not pointer.is_file():
            raise FileNotFoundError("no active B_GOAL_MODE session; run --initialize first")
        session_dir = Path(pointer.read_text(encoding="utf-8").strip()).resolve()
    state_path = session_dir / STATE_NAME
    if not state_path.is_file():
        raise FileNotFoundError(f"invalid B_GOAL_MODE session: {session_dir}")
    return session_dir


@dataclass
class ExperimentSpec:
    goal_id: str
    unique_change: str
    expected_result: str
    failure_criterion: str
    failure_branch: str

    def validate(self) -> None:
        missing = [name for name, value in self.__dict__.items() if not value.strip()]
        if missing:
            raise ValueError(f"experiment specification fields are required: {missing}")


class Supervisor:
    def __init__(self, repo_root: Path, session_dir: Path, downloads: Path) -> None:
        self.repo_root = repo_root
        self.session_dir = session_dir
        self.downloads = downloads
        self.child: subprocess.Popen[str] | None = None
        self.stop_event = threading.Event()
        self.package_lock = threading.Lock()
        self.stop_reason: str | None = None
        self.final_package_created = False
        self.normal_exit = False
        self.heartbeat = threading.Thread(target=self._heartbeat_loop, daemon=True)

    @property
    def checkpoint_path(self) -> Path:
        return self.downloads / CHECKPOINT_NAME

    def install_signal_handlers(self) -> None:
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            signal.signal(signum, self._handle_signal)
        atexit.register(self._handle_exit)

    def _handle_signal(self, signum: int, _frame: Any) -> None:
        self.stop_reason = f"SIGNAL_{signal.Signals(signum).name}"
        self.stop_event.set()
        self.terminate_child()

    def _handle_exit(self) -> None:
        # EXIT always refreshes recoverable state. Signals additionally create
        # the timestamped final stop package in the main control flow.
        if self.final_package_created:
            return
        try:
            self.checkpoint()
        except Exception as exc:  # pragma: no cover - last-resort path
            print(f"[B_GOAL_MODE] EXIT checkpoint failed: {exc!r}", file=sys.stderr)

    def _heartbeat_loop(self) -> None:
        while not self.stop_event.wait(PACKAGE_INTERVAL_SECONDS):
            try:
                self.checkpoint()
                print(f"[B_GOAL_MODE] rolling checkpoint refreshed: {self.checkpoint_path}")
            except Exception as exc:
                print(f"[B_GOAL_MODE] rolling checkpoint failed: {exc!r}", file=sys.stderr)

    def checkpoint(self) -> tuple[int, str]:
        with self.package_lock:
            return create_package(
                repo_root=self.repo_root,
                session_dir=self.session_dir,
                target=self.checkpoint_path,
                stopped=False,
            )

    def final_stop_package(self, reason: str) -> tuple[Path, int, str]:
        self.stop_event.set()
        self.terminate_child()
        state_path = self.session_dir / STATE_NAME
        state = read_json(state_path)
        state.update(
            {
                "status": "STOPPED",
                "stop_reason": reason,
                "active_child": None,
                "updated_utc": utc_iso(),
            }
        )
        atomic_write_json(state_path, state)
        target = self.downloads / f"B_GOAL_MODE_STOP_PACKAGE_{utc_stamp()}.tar.gz"
        # Record the future absolute path inside the package before creating it.
        atomic_write_text(self.session_dir / STOP_PATH_NAME, str(target) + "\n")
        with self.package_lock:
            size, digest = create_package(
                repo_root=self.repo_root,
                session_dir=self.session_dir,
                target=target,
                stopped=True,
            )
        atomic_write_text(self.downloads / STOP_PATH_NAME, str(target) + "\n")
        self.final_package_created = True
        return target, size, digest

    def terminate_child(self) -> None:
        child = self.child
        if child is None or child.poll() is not None:
            return
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        deadline = time.monotonic() + CHILD_TERM_GRACE_SECONDS
        while child.poll() is None and time.monotonic() < deadline:
            time.sleep(0.1)
        if child.poll() is None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                pass

    def run_child(self, command: Sequence[str], spec: ExperimentSpec) -> int:
        spec.validate()
        if not command:
            raise ValueError("child command is empty")
        log_dir = self.session_dir / "logs"
        log_dir.mkdir(exist_ok=True)
        log_path = log_dir / f"{utc_stamp()}_{spec.goal_id}.log"
        state_path = self.session_dir / STATE_NAME
        state = read_json(state_path)
        started_utc = utc_iso()
        state.update(
            {
                "current_goal_gate": spec.goal_id,
                "status": "RUNNING",
                "active_child": {"command": list(command), "pid": None},
                "updated_utc": started_utc,
            }
        )
        atomic_write_json(state_path, state)
        self.checkpoint()
        self.heartbeat.start()

        with log_path.open("w", encoding="utf-8", errors="replace") as log:
            self.child = subprocess.Popen(
                list(command),
                cwd=self.repo_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
            state = read_json(state_path)
            state["active_child"] = {"command": list(command), "pid": self.child.pid}
            state["updated_utc"] = utc_iso()
            atomic_write_json(state_path, state)
            assert self.child.stdout is not None
            for line in self.child.stdout:
                log.write(line)
                log.flush()
                print(line, end="", flush=True)
                if self.stop_event.is_set():
                    self.terminate_child()
                    break
            exit_code = self.child.wait()

        ended_utc = utc_iso()
        interrupted = self.stop_event.is_set()
        outcome = "INTERRUPTED" if interrupted else ("PASS" if exit_code == 0 else "FAIL")
        append_ledger(
            self.session_dir / LEDGER_NAME,
            {
                "utc_start": started_utc,
                "utc_end": ended_utc,
                "goal_id": spec.goal_id,
                "unique_change": spec.unique_change,
                "expected_result": spec.expected_result,
                "failure_criterion": spec.failure_criterion,
                "failure_branch": spec.failure_branch,
                "command": quote_command(command),
                "log_path": str(log_path),
                "child_pid": self.child.pid,
                "exit_code": exit_code,
                "outcome": outcome,
            },
        )
        state = read_json(state_path)
        state.update(
            {
                "status": outcome,
                "active_child": None,
                "updated_utc": ended_utc,
            }
        )
        atomic_write_json(state_path, state)
        self.checkpoint()
        if interrupted:
            target, size, digest = self.final_stop_package(self.stop_reason or "EXTERNAL_STOP")
            print_stop_package(target, size, digest, state)
        else:
            self.normal_exit = True
        return exit_code


def print_stop_package(path: Path, size: int, digest: str, state: dict[str, Any]) -> None:
    print(f"PACKAGE_PATH={path}")
    print(f"SIZE_BYTES={size}")
    print(f"SHA256={digest}")
    print(f"CURRENT_GOAL_GATE={state.get('current_goal_gate', 'UNKNOWN')}")
    print(f"BEST_RESULT={state.get('best_result', 'NONE')}")
    print(f"NEXT_RECOMMENDED_ACTION={state.get('next_recommended_action', 'UNKNOWN')}")


def parse_arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True)
    parser.add_argument("--session-dir")
    parser.add_argument("--initialize", action="store_true")
    parser.add_argument("--checkpoint", action="store_true")
    parser.add_argument("--stop-and-package", action="store_true")
    parser.add_argument("--stop-reason", default="USER_STOP_AND_PACKAGE")
    parser.add_argument("--goal-id")
    parser.add_argument("--unique-change")
    parser.add_argument("--expected-result")
    parser.add_argument("--failure-criterion")
    parser.add_argument("--failure-branch")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = parse_arguments(argv)
    repo_root = Path(arguments.repo_root).expanduser().resolve()
    if not (repo_root / "src/kcg_connector").is_dir():
        raise FileNotFoundError(f"repository not found: {repo_root}")
    downloads = Path.home() / "Downloads"
    downloads.mkdir(parents=True, exist_ok=True)

    if arguments.initialize:
        session_dir = create_session(repo_root)
    else:
        session_dir = resolve_session(repo_root, arguments.session_dir)
    supervisor = Supervisor(repo_root, session_dir, downloads)
    supervisor.install_signal_handlers()

    if arguments.stop_and_package:
        target, size, digest = supervisor.final_stop_package(arguments.stop_reason)
        print_stop_package(target, size, digest, read_json(session_dir / STATE_NAME))
        return 0
    if arguments.initialize or arguments.checkpoint:
        size, digest = supervisor.checkpoint()
        print(f"SESSION_DIR={session_dir}")
        print(f"CHECKPOINT_PATH={supervisor.checkpoint_path}")
        print(f"SIZE_BYTES={size}")
        print(f"SHA256={digest}")
        supervisor.normal_exit = True
        return 0

    command = list(arguments.command)
    if command and command[0] == "--":
        command = command[1:]
    spec = ExperimentSpec(
        goal_id=arguments.goal_id or "",
        unique_change=arguments.unique_change or "",
        expected_result=arguments.expected_result or "",
        failure_criterion=arguments.failure_criterion or "",
        failure_branch=arguments.failure_branch or "",
    )
    return supervisor.run_child(command, spec)


if __name__ == "__main__":
    raise SystemExit(main())
