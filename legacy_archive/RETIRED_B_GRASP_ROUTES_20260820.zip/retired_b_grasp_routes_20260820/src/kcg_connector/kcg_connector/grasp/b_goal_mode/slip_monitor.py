"""Truth-free slip precursors for B_GOAL_MODE adaptive grip force.

The monitor deliberately consumes only proprioceptive signals available on a
real hand: the normal-force proxy derived from root-joint effort and joint
velocity. Object pose and PhysX contact reports remain post-hoc diagnostics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class ProprioceptiveSlipObservation:
    risk_detected: bool
    confirmed_event: bool
    reasons: tuple[str, ...]
    force_bias_shift_n: float
    maximum_velocity_excess_rad_s: float
    confirmation_count: int
    stabilization_count: int
    armed: bool

    def as_dict(self) -> dict[str, object]:
        return {
            "risk_detected": self.risk_detected,
            "confirmed_event": self.confirmed_event,
            "reasons": list(self.reasons),
            "force_bias_shift_n": self.force_bias_shift_n,
            "maximum_velocity_excess_rad_s": self.maximum_velocity_excess_rad_s,
            "confirmation_count": self.confirmation_count,
            "stabilization_count": self.stabilization_count,
            "armed": self.armed,
        }


class ProprioceptiveSlipMonitor:
    """Confirm load redistribution or abnormal joint motion before adding grip."""

    def __init__(
        self,
        *,
        baseline_estimated_force_n: Sequence[float],
        baseline_maximum_abs_velocity_rad_s: Sequence[float],
        initial_force_target_n: float,
        force_bias_shift_trigger_n: float,
        velocity_excess_trigger_rad_s: float,
        force_drop_trigger_n: float,
        confirmation_steps: int,
        stabilization_steps: int,
        stabilization_force_tolerance_n: float,
    ) -> None:
        baseline_force = np.asarray(baseline_estimated_force_n, dtype=np.float64)
        baseline_velocity = np.asarray(
            baseline_maximum_abs_velocity_rad_s, dtype=np.float64
        )
        if baseline_force.shape != (3,) or baseline_velocity.shape != (3,):
            raise ValueError("slip monitor requires exactly three finger channels")
        if not np.all(np.isfinite(baseline_force)) or not np.all(
            np.isfinite(baseline_velocity)
        ):
            raise ValueError("slip monitor baselines must be finite")
        if confirmation_steps <= 0 or stabilization_steps <= 0:
            raise ValueError("slip monitor windows must be positive")
        self._baseline_force_error_n = float(
            np.mean(baseline_force - float(initial_force_target_n))
        )
        self._baseline_velocity = baseline_velocity
        self._force_bias_shift_trigger_n = float(force_bias_shift_trigger_n)
        self._velocity_excess_trigger_rad_s = float(
            velocity_excess_trigger_rad_s
        )
        self._force_drop_trigger_n = float(force_drop_trigger_n)
        self._confirmation_steps = int(confirmation_steps)
        self._stabilization_steps = int(stabilization_steps)
        self._stabilization_force_tolerance_n = float(
            stabilization_force_tolerance_n
        )
        self._confirmation_count = 0
        self._stabilization_count = self._stabilization_steps
        self._armed = True
        self._event_count = 0

    @property
    def armed(self) -> bool:
        return self._armed

    @property
    def event_count(self) -> int:
        return self._event_count

    def acknowledge_force_increment(self) -> None:
        self._armed = False
        self._confirmation_count = 0
        self._stabilization_count = 0
        self._event_count += 1

    def update(
        self,
        *,
        estimated_force_n: Sequence[float],
        joint_velocity_rad_s: Sequence[float],
        force_target_n: float,
    ) -> ProprioceptiveSlipObservation:
        estimated = np.asarray(estimated_force_n, dtype=np.float64)
        velocity = np.asarray(joint_velocity_rad_s, dtype=np.float64)
        if estimated.shape != (3,) or velocity.shape != (3,):
            raise ValueError("slip monitor inputs must have three channels")
        if not np.all(np.isfinite(estimated)) or not np.all(np.isfinite(velocity)):
            raise ValueError("slip monitor inputs must be finite")

        force_error_bias = float(np.mean(estimated - float(force_target_n)))
        force_bias_shift = abs(force_error_bias - self._baseline_force_error_n)
        velocity_excess = float(
            np.max(np.abs(velocity) - self._baseline_velocity)
        )
        reasons: list[str] = []
        if force_bias_shift > self._force_bias_shift_trigger_n:
            reasons.append("ROOT_LOAD_BIAS_SHIFT")
        if velocity_excess > self._velocity_excess_trigger_rad_s:
            reasons.append("ABNORMAL_JOINT_MOTION")
        if np.any(estimated < float(force_target_n) - self._force_drop_trigger_n):
            reasons.append("ROOT_LOAD_DROP")

        if not self._armed:
            stable = bool(
                np.all(
                    np.abs(estimated - float(force_target_n))
                    <= self._stabilization_force_tolerance_n
                )
            )
            self._stabilization_count = (
                self._stabilization_count + 1 if stable else 0
            )
            if self._stabilization_count >= self._stabilization_steps:
                self._armed = True
                self._confirmation_count = 0
            return ProprioceptiveSlipObservation(
                risk_detected=False,
                confirmed_event=False,
                reasons=(),
                force_bias_shift_n=force_bias_shift,
                maximum_velocity_excess_rad_s=velocity_excess,
                confirmation_count=self._confirmation_count,
                stabilization_count=self._stabilization_count,
                armed=self._armed,
            )

        risk = bool(reasons)
        self._confirmation_count = self._confirmation_count + 1 if risk else 0
        confirmed = self._confirmation_count >= self._confirmation_steps
        return ProprioceptiveSlipObservation(
            risk_detected=risk,
            confirmed_event=confirmed,
            reasons=tuple(reasons),
            force_bias_shift_n=force_bias_shift,
            maximum_velocity_excess_rad_s=velocity_excess,
            confirmation_count=self._confirmation_count,
            stabilization_count=self._stabilization_count,
            armed=self._armed,
        )

    def state(self) -> dict[str, object]:
        return {
            "input_role": "PROPRIOCEPTIVE_ONLY_NO_OBJECT_OR_CONTACT_TRUTH",
            "baseline_force_error_n": self._baseline_force_error_n,
            "baseline_maximum_abs_velocity_rad_s": self._baseline_velocity.tolist(),
            "force_bias_shift_trigger_n": self._force_bias_shift_trigger_n,
            "velocity_excess_trigger_rad_s": self._velocity_excess_trigger_rad_s,
            "force_drop_trigger_n": self._force_drop_trigger_n,
            "confirmation_steps": self._confirmation_steps,
            "stabilization_steps": self._stabilization_steps,
            "stabilization_force_tolerance_n": self._stabilization_force_tolerance_n,
            "confirmation_count": self._confirmation_count,
            "stabilization_count": self._stabilization_count,
            "armed": self._armed,
            "event_count": self._event_count,
        }
