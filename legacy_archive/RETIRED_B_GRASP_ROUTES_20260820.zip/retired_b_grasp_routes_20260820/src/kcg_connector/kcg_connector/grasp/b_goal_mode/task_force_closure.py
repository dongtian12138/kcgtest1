"""Conservative polyhedral friction-cone task-wrench analysis for G3."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Mapping, Sequence

import numpy as np
from scipy.optimize import linprog


@dataclass(frozen=True)
class FrictionPyramid:
    grasp_matrix: np.ndarray
    ray_owner: tuple[int, ...]
    contact_points_m: np.ndarray
    contact_normals: np.ndarray
    friction_coefficient: float
    edges_per_contact: int


def _unit(vector: Sequence[float], *, name: str) -> np.ndarray:
    value = np.asarray(vector, dtype=np.float64)
    if value.shape != (3,) or not np.all(np.isfinite(value)):
        raise ValueError(f"{name} must be one finite 3-vector")
    norm = float(np.linalg.norm(value))
    if norm <= 1.0e-12:
        raise ValueError(f"{name} cannot be zero")
    return value / norm


def build_friction_pyramid(
    *,
    contact_points_m: Sequence[Sequence[float]],
    contact_normals: Sequence[Sequence[float]],
    center_of_mass_m: Sequence[float],
    friction_coefficient: float,
    edges_per_contact: int,
) -> FrictionPyramid:
    points = np.asarray(contact_points_m, dtype=np.float64)
    normals = np.asarray(contact_normals, dtype=np.float64)
    center = np.asarray(center_of_mass_m, dtype=np.float64)
    if points.shape != (3, 3) or normals.shape != (3, 3) or center.shape != (3,):
        raise ValueError("G3 requires exactly three contact points, normals and one COM")
    if not np.all(np.isfinite(points)) or not np.all(np.isfinite(normals)):
        raise ValueError("G3 contact geometry must be finite")
    if friction_coefficient <= 0.0 or edges_per_contact < 8:
        raise ValueError("friction coefficient must be positive and cone needs at least 8 edges")
    columns: list[np.ndarray] = []
    owners: list[int] = []
    unit_normals: list[np.ndarray] = []
    for contact_index, (point, normal_raw) in enumerate(zip(points, normals)):
        normal = _unit(normal_raw, name=f"contact_normal_{contact_index}")
        unit_normals.append(normal)
        reference = np.asarray((1.0, 0.0, 0.0), dtype=np.float64)
        if abs(float(reference @ normal)) > 0.9:
            reference = np.asarray((0.0, 1.0, 0.0), dtype=np.float64)
        tangent_1 = reference - float(reference @ normal) * normal
        tangent_1 /= np.linalg.norm(tangent_1)
        tangent_2 = np.cross(normal, tangent_1)
        radius = point - center
        for edge in range(edges_per_contact):
            angle = 2.0 * math.pi * edge / float(edges_per_contact)
            force = normal + float(friction_coefficient) * (
                math.cos(angle) * tangent_1 + math.sin(angle) * tangent_2
            )
            columns.append(np.concatenate((force, np.cross(radius, force))))
            owners.append(contact_index)
    return FrictionPyramid(
        grasp_matrix=np.asarray(columns, dtype=np.float64).T,
        ray_owner=tuple(owners),
        contact_points_m=points,
        contact_normals=np.asarray(unit_normals, dtype=np.float64),
        friction_coefficient=float(friction_coefficient),
        edges_per_contact=int(edges_per_contact),
    )


def _normal_constraints(
    pyramid: FrictionPyramid, *, include_scale_column: bool
) -> np.ndarray:
    extra = 1 if include_scale_column else 0
    rows = np.zeros((3, len(pyramid.ray_owner) + extra), dtype=np.float64)
    for ray, owner in enumerate(pyramid.ray_owner):
        rows[owner, ray] = 1.0
    return rows


def maximum_wrench_scale(
    pyramid: FrictionPyramid,
    *,
    external_wrench: Sequence[float],
    normal_force_cap_n_per_finger: float,
) -> dict[str, Any]:
    wrench = np.asarray(external_wrench, dtype=np.float64)
    if wrench.shape != (6,) or not np.all(np.isfinite(wrench)):
        raise ValueError("external_wrench must contain six finite values")
    if float(np.linalg.norm(wrench)) <= 1.0e-15:
        raise ValueError("external_wrench cannot be zero")
    if normal_force_cap_n_per_finger <= 0.0:
        raise ValueError("normal force cap must be positive")
    ray_count = pyramid.grasp_matrix.shape[1]
    objective = np.concatenate((np.zeros(ray_count), (-1.0,)))
    equality = np.column_stack((pyramid.grasp_matrix, wrench))
    inequality = _normal_constraints(pyramid, include_scale_column=True)
    result = linprog(
        objective,
        A_ub=inequality,
        b_ub=np.full(3, float(normal_force_cap_n_per_finger)),
        A_eq=equality,
        b_eq=np.zeros(6),
        bounds=[(0.0, None)] * ray_count + [(0.0, None)],
        method="highs",
    )
    scale = float(result.x[-1]) if result.success else 0.0
    allocation = [0.0, 0.0, 0.0]
    if result.success:
        for ray, owner in enumerate(pyramid.ray_owner):
            allocation[owner] += float(result.x[ray])
    return {
        "solver_success": bool(result.success),
        "solver_status": int(result.status),
        "solver_message": str(result.message),
        "maximum_scale": scale,
        "normal_force_at_max_scale_n": allocation,
        "normal_force_cap_n_per_finger": float(normal_force_cap_n_per_finger),
        "equilibrium_residual_norm": (
            float(np.linalg.norm(equality @ result.x)) if result.success else None
        ),
    }


def minimum_peak_normal_force(
    pyramid: FrictionPyramid,
    *,
    external_wrench: Sequence[float],
    maximum_allowed_normal_force_n: float,
) -> dict[str, Any]:
    wrench = np.asarray(external_wrench, dtype=np.float64)
    ray_count = pyramid.grasp_matrix.shape[1]
    objective = np.concatenate((np.zeros(ray_count), (1.0,)))
    equality = np.column_stack((pyramid.grasp_matrix, np.zeros(6)))
    inequality = _normal_constraints(pyramid, include_scale_column=True)
    inequality[:, -1] = -1.0
    result = linprog(
        objective,
        A_ub=inequality,
        b_ub=np.zeros(3),
        A_eq=equality,
        b_eq=-wrench,
        bounds=[(0.0, None)] * ray_count
        + [(0.0, float(maximum_allowed_normal_force_n))],
        method="highs",
    )
    allocation = [0.0, 0.0, 0.0]
    if result.success:
        for ray, owner in enumerate(pyramid.ray_owner):
            allocation[owner] += float(result.x[ray])
    return {
        "solver_success": bool(result.success),
        "solver_status": int(result.status),
        "solver_message": str(result.message),
        "minimum_peak_normal_force_n": (
            float(result.x[-1]) if result.success else None
        ),
        "normal_force_allocation_n": allocation,
        "maximum_allowed_normal_force_n": float(maximum_allowed_normal_force_n),
        "equilibrium_residual_norm": (
            float(np.linalg.norm(equality @ result.x + wrench))
            if result.success
            else None
        ),
    }


def circular_contact_metrics(
    contact_points_m: Sequence[Sequence[float]], center_of_mass_m: Sequence[float]
) -> dict[str, Any]:
    points = np.asarray(contact_points_m, dtype=np.float64)
    center = np.asarray(center_of_mass_m, dtype=np.float64)
    angles = np.mod(np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0]), 2 * math.pi)
    ordered = np.sort(angles)
    gaps = np.diff(np.concatenate((ordered, ordered[:1] + 2 * math.pi)))
    return {
        "angles_deg": np.degrees(angles).tolist(),
        "sorted_gaps_deg": np.degrees(gaps).tolist(),
        "minimum_gap_deg": float(np.degrees(np.min(gaps))),
        "maximum_gap_deg": float(np.degrees(np.max(gaps))),
    }


def radial_alignment_metrics(
    *,
    contact_points_m: Sequence[Sequence[float]],
    contact_normals: Sequence[Sequence[float]],
    connector_axis_center_xy_m: Sequence[float],
) -> dict[str, Any]:
    center_xy = np.asarray(connector_axis_center_xy_m, dtype=np.float64)
    values: list[float] = []
    axis_angles: list[float] = []
    for point_raw, normal_raw in zip(contact_points_m, contact_normals):
        point = np.asarray(point_raw, dtype=np.float64)
        normal = _unit(normal_raw, name="contact_normal")
        toward_axis = center_xy - point[:2]
        toward_axis /= np.linalg.norm(toward_axis)
        values.append(float(np.clip(normal[:2] @ toward_axis, -1.0, 1.0)))
        axis_angles.append(
            math.degrees(math.acos(float(np.clip(abs(normal[2]), 0.0, 1.0))))
        )
    return {
        "radial_alignment": values,
        "minimum_radial_alignment": min(values),
        "normal_to_connector_axis_angle_deg": axis_angles,
    }


def signed_basis_force_closure(
    pyramid: FrictionPyramid,
    *,
    characteristic_length_m: float,
    normal_force_cap_n_per_finger: float,
) -> dict[str, Any]:
    directions: dict[str, list[float]] = {}
    labels = ("fx", "fy", "fz", "mx", "my", "mz")
    for index, label in enumerate(labels):
        magnitude = 1.0 if index < 3 else float(characteristic_length_m)
        for sign, suffix in ((-1.0, "negative"), (1.0, "positive")):
            wrench = np.zeros(6, dtype=np.float64)
            wrench[index] = sign * magnitude
            directions[f"{label}_{suffix}"] = wrench.tolist()
    results = {
        name: maximum_wrench_scale(
            pyramid,
            external_wrench=wrench,
            normal_force_cap_n_per_finger=normal_force_cap_n_per_finger,
        )
        for name, wrench in directions.items()
    }
    minimum = min(result["maximum_scale"] for result in results.values())
    return {
        "characteristic_length_m": float(characteristic_length_m),
        "directions": results,
        "minimum_normalized_signed_basis_scale": minimum,
        "force_closure": bool(
            np.linalg.matrix_rank(pyramid.grasp_matrix, tol=1.0e-9) == 6
            and minimum > 1.0e-6
        ),
    }


def evaluate_task_suite(
    pyramid: FrictionPyramid,
    *,
    task_wrenches: Mapping[str, Sequence[float]],
    normal_force_caps_n: Sequence[float],
) -> dict[str, Any]:
    caps = [float(value) for value in normal_force_caps_n]
    maximum_cap = max(caps)
    results: dict[str, Any] = {}
    for name, wrench in task_wrenches.items():
        results[name] = {
            "external_wrench": [float(value) for value in wrench],
            "safety_factor_by_normal_cap": {
                f"{cap:g}N": maximum_wrench_scale(
                    pyramid,
                    external_wrench=wrench,
                    normal_force_cap_n_per_finger=cap,
                )
                for cap in caps
            },
            "minimum_peak_normal_force": minimum_peak_normal_force(
                pyramid,
                external_wrench=wrench,
                maximum_allowed_normal_force_n=maximum_cap,
            ),
        }
    return results
