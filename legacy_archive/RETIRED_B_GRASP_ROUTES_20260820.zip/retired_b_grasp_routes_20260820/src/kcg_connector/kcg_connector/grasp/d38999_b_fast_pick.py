"""Fast, task-focused three-finger grasp geometry for D38999 B-stage recovery.

The module bypasses the historical H1--H25 controller stack. It uses the
user-confirmed blue PAD analytic capsule manifest plus the real hand URDF to
produce deterministic grasp candidates. Candidate generation is offline; the
Isaac runner consumes a frozen manifest and never reads object/contact truth
for online control.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np

from kcg_connector.hand_occluder_cad import HAND_JOINT_ORDER, _joint_transform


SCHEMA = "D38999_B_FAST_PICK_CANDIDATES_V1"
DEFAULT_GRASP_Z_MM = (14.0, 19.0, 24.0)
ACTIVE_TERMINAL_LINKS = ("f1Link3", "f2Link2", "f3Link3")
DEFAULT_OBJECT_MASS_KG = 0.310
DEFAULT_OBJECT_RADIUS_M = 0.024
DEFAULT_OBJECT_HEIGHT_M = 0.020
DEFAULT_PAD_CAPSULE_RADIUS_M = 0.004
DEFAULT_PRELOAD_M = 0.00025
DEFAULT_CONSERVATIVE_FRICTION = 0.30
DEFAULT_GRIP_SAFETY_FACTOR = 2.0


@dataclass(frozen=True)
class GraspCandidate:
    candidate_id: str
    rank: int
    grasp_local_z_mm: float
    preshape_rad: float
    finger_flexion_targets_rad: tuple[float, float, float]
    object_axis_center_xy_hand_m: tuple[float, float]
    object_center_z_hand_m: float
    predicted_contact_center_z_hand_m: float
    predicted_radial_gaps_m: tuple[float, float, float]
    predicted_radial_alignment: tuple[float, float, float]
    predicted_contact_z_spread_m: float
    optimization_residual_norm: float
    minimum_joint_margin_rad: float
    geometry_score: float


@dataclass(frozen=True)
class ForceBudget:
    object_mass_kg: float
    gravity_m_s2: float
    conservative_friction: float
    safety_factor: float
    required_normal_force_per_finger_n: float
    nominal_normal_force_per_finger_n: float
    adaptive_limit_per_finger_n: float
    user_reported_hardware_limit_per_finger_n: float


def sha256(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def repository_relative_path(path: Path | str) -> str:
    resolved = Path(path).resolve()
    for ancestor in (resolved.parent, *resolved.parents):
        if (ancestor / "src/kcg_connector").is_dir() and (ancestor / "artifacts").is_dir():
            try:
                return resolved.relative_to(ancestor).as_posix()
            except ValueError:
                break
    return resolved.as_posix()


def minimum_jerk(fraction: float) -> float:
    value = min(1.0, max(0.0, float(fraction)))
    return 10.0 * value**3 - 15.0 * value**4 + 6.0 * value**5


def required_normal_force_per_finger(
    *,
    object_mass_kg: float = DEFAULT_OBJECT_MASS_KG,
    friction_coefficient: float = DEFAULT_CONSERVATIVE_FRICTION,
    safety_factor: float = DEFAULT_GRIP_SAFETY_FACTOR,
    gravity_m_s2: float = 9.81,
    finger_count: int = 3,
) -> float:
    if object_mass_kg <= 0.0:
        raise ValueError("object_mass_kg must be positive")
    if friction_coefficient <= 0.0:
        raise ValueError("friction_coefficient must be positive")
    if safety_factor < 1.0:
        raise ValueError("safety_factor must be at least 1")
    if finger_count < 2:
        raise ValueError("finger_count must be at least 2")
    return (
        float(safety_factor)
        * float(object_mass_kg)
        * float(gravity_m_s2)
        / (float(finger_count) * float(friction_coefficient))
    )


def default_force_budget() -> ForceBudget:
    required = required_normal_force_per_finger()
    return ForceBudget(
        object_mass_kg=DEFAULT_OBJECT_MASS_KG,
        gravity_m_s2=9.81,
        conservative_friction=DEFAULT_CONSERVATIVE_FRICTION,
        safety_factor=DEFAULT_GRIP_SAFETY_FACTOR,
        required_normal_force_per_finger_n=required,
        nominal_normal_force_per_finger_n=max(7.0, required),
        adaptive_limit_per_finger_n=12.0,
        user_reported_hardware_limit_per_finger_n=15.0,
    )


def _load_proxy_manifest(path: Path | str) -> dict[str, Any]:
    manifest = json.loads(Path(path).read_text(encoding="utf-8"))
    if manifest.get("collision_route") != "CONSERVATIVE_CONVEX_PAD_PROXY":
        raise ValueError("expected audited conservative PAD proxy manifest")
    if manifest.get("whole_terminal_convex_hull_count") != 0:
        raise ValueError("whole terminal convex hull must be disabled")
    links = manifest.get("links")
    if not isinstance(links, list) or len(links) != 3:
        raise ValueError("expected three audited PAD links")
    return manifest


def _load_hand_kinematics(
    urdf_path: Path | str,
) -> tuple[dict[str, ET.Element], dict[str, str], dict[str, str]]:
    root = ET.parse(Path(urdf_path)).getroot()
    joints = {joint.get("name"): joint for joint in root.findall("joint")}
    missing = [name for name in HAND_JOINT_ORDER if name not in joints]
    if missing:
        raise ValueError(f"hand URDF missing joints: {missing}")
    parent = {
        name: joints[name].find("parent").get("link") for name in HAND_JOINT_ORDER
    }
    child = {
        name: joints[name].find("child").get("link") for name in HAND_JOINT_ORDER
    }
    return joints, parent, child


def hand_link_transforms(
    urdf_path: Path | str,
    *,
    preshape_rad: float,
    finger_flexion_rad: Sequence[float],
) -> dict[str, np.ndarray]:
    flexion = np.asarray(finger_flexion_rad, dtype=np.float64)
    if flexion.shape != (3,) or not np.all(np.isfinite(flexion)):
        raise ValueError("finger_flexion_rad must contain three finite values")
    joints, parent, child = _load_hand_kinematics(urdf_path)
    values = {
        "f1j1": float(preshape_rad),
        "f1j2": float(flexion[0]),
        "f1j3": float(flexion[0]),
        "f2j1": float(flexion[1]),
        "f2j2": float(flexion[1]),
        "f3j1": float(preshape_rad),
        "f3j2": float(flexion[2]),
        "f3j3": float(flexion[2]),
    }
    transforms: dict[str, np.ndarray] = {"handbase_link": np.eye(4)}
    for name in HAND_JOINT_ORDER:
        joint = joints[name]
        transforms[child[name]] = transforms[parent[name]] @ _joint_transform(
            joint.find("origin"), joint.find("axis").get("xyz"), values[name]
        )
    return transforms


def _representative_pad_geometry(
    *,
    urdf_path: Path | str,
    proxy_manifest: Mapping[str, Any],
    preshape_rad: float,
    finger_flexion_rad: Sequence[float],
) -> tuple[np.ndarray, np.ndarray]:
    transforms = hand_link_transforms(
        urdf_path,
        preshape_rad=preshape_rad,
        finger_flexion_rad=finger_flexion_rad,
    )
    entries = {str(entry["link_name"]): entry for entry in proxy_manifest["links"]}
    centers: list[np.ndarray] = []
    normals: list[np.ndarray] = []
    for link_name in ACTIVE_TERMINAL_LINKS:
        entry = entries[link_name]
        capsules = entry["capsules"]
        capsule = capsules[len(capsules) // 2]
        transform = transforms[link_name]
        local_center = np.asarray(capsule["center_local_m"], dtype=np.float64)
        local_normal = np.asarray(
            entry["contact_frame_local"]["outward_normal_unit"], dtype=np.float64
        )
        center = transform[:3, :3] @ local_center + transform[:3, 3]
        normal = transform[:3, :3] @ local_normal
        normal /= np.linalg.norm(normal)
        centers.append(center)
        normals.append(normal)
    return np.asarray(centers), np.asarray(normals)


def _candidate_residual(
    x: np.ndarray,
    *,
    urdf_path: Path,
    proxy_manifest: Mapping[str, Any],
    target_radius_m: float,
) -> np.ndarray:
    finger_flexion = x[:3]
    preshape = float(x[3])
    axis_xy = x[4:6]
    centers, normals = _representative_pad_geometry(
        urdf_path=urdf_path,
        proxy_manifest=proxy_manifest,
        preshape_rad=preshape,
        finger_flexion_rad=finger_flexion,
    )
    residual: list[float] = []
    for center, normal in zip(centers, normals):
        vector_xy = axis_xy - center[:2]
        distance = float(np.linalg.norm(vector_xy))
        direction = vector_xy / max(distance, 1.0e-12)
        normal_xy = normal[:2] / max(float(np.linalg.norm(normal[:2])), 1.0e-12)
        residual.append((distance - target_radius_m) / 0.001)
        residual.extend(((direction - normal_xy) / 0.02).tolist())
    residual.extend(((centers[:, 2] - np.mean(centers[:, 2])) / 0.001).tolist())
    residual.append((preshape - 1.30) / 0.40)
    return np.asarray(residual, dtype=np.float64)


def optimize_base_grasp(
    *, urdf_path: Path | str, proxy_manifest_path: Path | str
) -> dict[str, Any]:
    try:
        from scipy.optimize import least_squares
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("SciPy is required for offline candidate generation") from exc

    urdf = Path(urdf_path).resolve()
    manifest = _load_proxy_manifest(proxy_manifest_path)
    target_radius = (
        DEFAULT_OBJECT_RADIUS_M + DEFAULT_PAD_CAPSULE_RADIUS_M - DEFAULT_PRELOAD_M
    )
    solution = least_squares(
        _candidate_residual,
        np.array([0.75, 0.65, 0.75, 1.30, -0.009, 0.005]),
        bounds=(
            np.array([0.30, 0.30, 0.30, 0.70, -0.03, -0.03]),
            np.array([1.10, 1.10, 1.10, 1.50, 0.03, 0.03]),
        ),
        kwargs={
            "urdf_path": urdf,
            "proxy_manifest": manifest,
            "target_radius_m": target_radius,
        },
        max_nfev=6000,
        xtol=1.0e-12,
        ftol=1.0e-12,
        gtol=1.0e-12,
    )
    centers, normals = _representative_pad_geometry(
        urdf_path=urdf,
        proxy_manifest=manifest,
        preshape_rad=float(solution.x[3]),
        finger_flexion_rad=solution.x[:3],
    )
    axis_xy = solution.x[4:6]
    distances = np.linalg.norm(centers[:, :2] - axis_xy[None, :], axis=1)
    alignments: list[float] = []
    for center, normal in zip(centers, normals):
        direction = axis_xy - center[:2]
        direction /= np.linalg.norm(direction)
        normal_xy = normal[:2] / np.linalg.norm(normal[:2])
        alignments.append(float(direction @ normal_xy))
    joint_upper = np.array([1.3963, 1.3963, 1.3963])
    flexion_margin = np.minimum(solution.x[:3], joint_upper - solution.x[:3])
    preshape_margin = min(float(solution.x[3]), 1.57 - float(solution.x[3]))
    return {
        "preshape_rad": float(solution.x[3]),
        "finger_flexion_targets_rad": [float(value) for value in solution.x[:3]],
        "object_axis_center_xy_hand_m": [float(value) for value in axis_xy],
        "predicted_contact_center_z_hand_m": float(np.mean(centers[:, 2])),
        "predicted_contact_centers_hand_m": centers.tolist(),
        "predicted_contact_normals_hand": normals.tolist(),
        "predicted_radial_gaps_m": (distances - target_radius).tolist(),
        "predicted_radial_alignment": alignments,
        "predicted_contact_z_spread_m": float(np.ptp(centers[:, 2])),
        "optimization_residual_norm": float(np.linalg.norm(solution.fun)),
        "minimum_joint_margin_rad": float(
            min(float(np.min(flexion_margin)), preshape_margin)
        ),
        "solver_success": bool(solution.success),
        "solver_message": str(solution.message),
    }


def build_candidates(
    *,
    urdf_path: Path | str,
    proxy_manifest_path: Path | str,
    grasp_z_mm: Iterable[float] = DEFAULT_GRASP_Z_MM,
) -> dict[str, Any]:
    base = optimize_base_grasp(
        urdf_path=urdf_path, proxy_manifest_path=proxy_manifest_path
    )
    z_values = [float(value) for value in grasp_z_mm]
    if len(z_values) < 3 or len(set(z_values)) != len(z_values):
        raise ValueError("at least three unique grasp z candidates are required")
    if any(value < 9.0 or value > 29.0 for value in z_values):
        raise ValueError("grasp z candidates must stay inside the 9..29 mm band")

    raw: list[GraspCandidate] = []
    for value in z_values:
        object_center_z = base["predicted_contact_center_z_hand_m"] - (
            value - 19.0
        ) / 1000.0
        edge_margin_mm = min(value - 9.0, 29.0 - value)
        score = (
            100.0 * min(base["predicted_radial_alignment"])
            - 5000.0 * max(abs(v) for v in base["predicted_radial_gaps_m"])
            - 1000.0 * base["predicted_contact_z_spread_m"]
            + 0.1 * edge_margin_mm
        )
        raw.append(
            GraspCandidate(
                candidate_id=f"PAD_Z{int(round(value)):02d}",
                rank=0,
                grasp_local_z_mm=value,
                preshape_rad=base["preshape_rad"],
                finger_flexion_targets_rad=tuple(
                    base["finger_flexion_targets_rad"]
                ),
                object_axis_center_xy_hand_m=tuple(
                    base["object_axis_center_xy_hand_m"]
                ),
                object_center_z_hand_m=float(object_center_z),
                predicted_contact_center_z_hand_m=base[
                    "predicted_contact_center_z_hand_m"
                ],
                predicted_radial_gaps_m=tuple(base["predicted_radial_gaps_m"]),
                predicted_radial_alignment=tuple(
                    base["predicted_radial_alignment"]
                ),
                predicted_contact_z_spread_m=base[
                    "predicted_contact_z_spread_m"
                ],
                optimization_residual_norm=base["optimization_residual_norm"],
                minimum_joint_margin_rad=base["minimum_joint_margin_rad"],
                geometry_score=float(score),
            )
        )
    ranked = sorted(raw, key=lambda candidate: candidate.geometry_score, reverse=True)
    ranked = [
        GraspCandidate(**{**asdict(candidate), "rank": index + 1})
        for index, candidate in enumerate(ranked)
    ]
    return {
        "schema": SCHEMA,
        "status": "OFFLINE_CANDIDATES_READY_FOR_FAST_ISAAC_RIG",
        "source_urdf": repository_relative_path(urdf_path),
        "source_urdf_sha256": sha256(urdf_path),
        "proxy_manifest": repository_relative_path(proxy_manifest_path),
        "proxy_manifest_sha256": sha256(proxy_manifest_path),
        "object": {
            "mass_kg": DEFAULT_OBJECT_MASS_KG,
            "radius_m": DEFAULT_OBJECT_RADIUS_M,
            "height_m": DEFAULT_OBJECT_HEIGHT_M,
            "authorized_grasp_band_local_z_mm": [9.0, 29.0],
        },
        "force_budget": asdict(default_force_budget()),
        "base_optimization": base,
        "candidate_count": len(ranked),
        "candidates": [
            json.loads(json.dumps(asdict(candidate), allow_nan=False))
            for candidate in ranked
        ],
        "online_truth_use_allowed": False,
        "posthoc_contact_audit_required": True,
        "formal_b_pass_claimed": False,
    }


def write_candidates(
    *,
    urdf_path: Path | str,
    proxy_manifest_path: Path | str,
    output_path: Path | str,
    grasp_z_mm: Iterable[float] = DEFAULT_GRASP_Z_MM,
) -> dict[str, Any]:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = build_candidates(
        urdf_path=urdf_path,
        proxy_manifest_path=proxy_manifest_path,
        grasp_z_mm=grasp_z_mm,
    )
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )
    return manifest


__all__ = [
    "ForceBudget",
    "GraspCandidate",
    "SCHEMA",
    "build_candidates",
    "default_force_budget",
    "hand_link_transforms",
    "minimum_jerk",
    "optimize_base_grasp",
    "repository_relative_path",
    "required_normal_force_per_finger",
    "write_candidates",
]
