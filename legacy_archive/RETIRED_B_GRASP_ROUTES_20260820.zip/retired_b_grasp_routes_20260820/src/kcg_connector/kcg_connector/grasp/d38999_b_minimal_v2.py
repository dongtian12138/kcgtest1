"""Deterministic geometry and trajectory preflight for D38999 B_MINIMAL_V2.

This module is intentionally independent from the historical H1--H25 stack.
It uses exactly one conservative analytic capsule at the centre of each
user-confirmed blue finger pad.  Every candidate is rejected offline unless
all three capsules are clear of the table and each other over the complete
open -> preclose -> descend -> close sweep, while the final contact preload
remains small.

The resulting candidates are diagnostic B-stage baselines, not a formal claim
that the complete iiwa + full finger collision model has passed.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np


SCHEMA = "D38999_B_MINIMAL_V2_CANDIDATES"
PAD_CORE_SCHEMA = "D38999_B_MINIMAL_V2_PAD_CORE_V1"
ACTIVE_TERMINAL_LINKS = ("f1Link3", "f2Link2", "f3Link3")
HAND_JOINT_ORDER = (
    "f1j1",
    "f1j2",
    "f1j3",
    "f2j1",
    "f2j2",
    "f3j1",
    "f3j2",
    "f3j3",
)
ACTIVE_CONTROL_JOINTS = ("f1j1", "f1j2", "f2j1", "f3j2")
FOLLOWER_JOINTS = ("f1j3", "f2j2", "f3j1", "f3j3")
ROOT_TORQUE_JOINTS = ("f1j2", "f2j1", "f3j2")

DEFAULT_HAND_MOUNT_RPY_RAD = (-3.14140498, -0.00258625116, 2.75771363)
DEFAULT_OBJECT_MASS_KG = 0.310
DEFAULT_OBJECT_RADIUS_M = 0.024
DEFAULT_OBJECT_HEIGHT_M = 0.020
DEFAULT_TABLE_TOP_Z_M = 0.020
DEFAULT_OBJECT_WORLD_CENTER_M = (0.0, 0.0, 0.030)
DEFAULT_OPEN_PRESHAPE_RAD = 1.0
DEFAULT_OPEN_FLEXION_RAD = 0.35
DEFAULT_TARGET_PRELOAD_M = 0.00010
DEFAULT_PRECONTACT_OBJECT_CLEARANCE_M = 0.003
DEFAULT_TABLE_CLEARANCE_M = 0.003
DEFAULT_MAXIMUM_FINAL_PENETRATION_M = 0.00020
DEFAULT_MINIMUM_INTERFINGER_CLEARANCE_M = 0.010
DEFAULT_PRECLOSE_FRACTION = 0.915
DEFAULT_GRASP_Z_MM = (12.0, 14.0, 18.0)


@dataclass(frozen=True)
class CandidateSweepMetrics:
    minimum_table_clearance_m: float
    minimum_precontact_object_clearance_m: float
    maximum_final_object_penetration_m: float
    minimum_interfinger_clearance_m: float
    open_table_clearance_m: float
    closed_table_clearance_m: float
    closed_object_gaps_m: tuple[float, float, float]
    approach_lift_m: float
    preclose_fraction: float
    sample_count: int


@dataclass(frozen=True)
class MinimalCandidate:
    candidate_id: str
    rank: int
    grasp_local_z_mm: float
    preshape_rad: float
    finger_flexion_targets_rad: tuple[float, float, float]
    object_axis_center_xy_hand_m: tuple[float, float]
    object_center_z_hand_m: float
    open_preshape_rad: float
    open_flexion_rad: float
    preclose_preshape_rad: float
    preclose_flexion_rad: tuple[float, float, float]
    approach_lift_m: float
    central_capsule_index_per_finger: tuple[int, int, int]
    predicted_contact_centers_hand_m: tuple[tuple[float, float, float], ...]
    predicted_contact_normals_hand: tuple[tuple[float, float, float], ...]
    predicted_closed_object_gaps_m: tuple[float, float, float]
    predicted_contact_z_spread_m: float
    minimum_joint_margin_rad: float
    optimization_residual_norm: float
    sweep_metrics: CandidateSweepMetrics
    geometry_score: float


@dataclass(frozen=True)
class CapsuleWorld:
    finger: str
    capsule_index: int
    center_m: np.ndarray
    axis_unit: np.ndarray
    endpoint_a_m: np.ndarray
    endpoint_b_m: np.ndarray
    radius_m: float


def sha256(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _parse_vector(text: str | None, default: Sequence[float]) -> np.ndarray:
    if not text:
        return np.asarray(default, dtype=np.float64)
    values = np.asarray([float(value) for value in text.split()], dtype=np.float64)
    if values.shape != (3,) or not np.all(np.isfinite(values)):
        raise ValueError(f"invalid three-vector: {text!r}")
    return values


def _rpy_matrix(rpy: Sequence[float]) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    rx = np.array(((1.0, 0.0, 0.0), (0.0, cr, -sr), (0.0, sr, cr)))
    ry = np.array(((cp, 0.0, sp), (0.0, 1.0, 0.0), (-sp, 0.0, cp)))
    rz = np.array(((cy, -sy, 0.0), (sy, cy, 0.0), (0.0, 0.0, 1.0)))
    return rz @ ry @ rx


def _axis_angle_matrix(axis: np.ndarray, angle: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=np.float64)
    axis /= max(float(np.linalg.norm(axis)), 1.0e-15)
    x, y, z = axis
    c, s = math.cos(angle), math.sin(angle)
    one = 1.0 - c
    return np.array(
        (
            (c + x * x * one, x * y * one - z * s, x * z * one + y * s),
            (y * x * one + z * s, c + y * y * one, y * z * one - x * s),
            (z * x * one - y * s, z * y * one + x * s, c + z * z * one),
        ),
        dtype=np.float64,
    )


def _joint_transform(joint: ET.Element, position_rad: float) -> np.ndarray:
    origin = joint.find("origin")
    xyz = _parse_vector(origin.get("xyz") if origin is not None else None, (0, 0, 0))
    rpy = _parse_vector(origin.get("rpy") if origin is not None else None, (0, 0, 0))
    axis_node = joint.find("axis")
    axis = _parse_vector(axis_node.get("xyz") if axis_node is not None else None, (0, 0, 1))
    transform = np.eye(4, dtype=np.float64)
    transform[:3, :3] = _rpy_matrix(rpy)
    transform[:3, 3] = xyz
    rotation = np.eye(4, dtype=np.float64)
    rotation[:3, :3] = _axis_angle_matrix(axis, float(position_rad))
    return transform @ rotation


def _load_urdf(urdf_path: Path | str) -> tuple[
    dict[str, ET.Element], dict[str, str], dict[str, str], dict[str, tuple[float, float]]
]:
    root = ET.parse(Path(urdf_path)).getroot()
    joints = {str(joint.get("name")): joint for joint in root.findall("joint")}
    missing = [name for name in HAND_JOINT_ORDER if name not in joints]
    if missing:
        raise ValueError(f"hand URDF missing joints: {missing}")
    parents = {name: joints[name].find("parent").get("link") for name in HAND_JOINT_ORDER}
    children = {name: joints[name].find("child").get("link") for name in HAND_JOINT_ORDER}
    limits: dict[str, tuple[float, float]] = {}
    for name in HAND_JOINT_ORDER:
        node = joints[name].find("limit")
        if node is None:
            raise ValueError(f"joint has no limit: {name}")
        limits[name] = (float(node.get("lower")), float(node.get("upper")))
    return joints, parents, children, limits


def hand_link_transforms(
    urdf_path: Path | str,
    *,
    preshape_rad: float,
    finger_flexion_rad: Sequence[float],
) -> dict[str, np.ndarray]:
    flexion = np.asarray(finger_flexion_rad, dtype=np.float64)
    if flexion.shape != (3,) or not np.all(np.isfinite(flexion)):
        raise ValueError("finger_flexion_rad must contain three finite values")
    joints, parents, children, _limits = _load_urdf(urdf_path)
    values = {
        "f1j1": float(preshape_rad),
        "f1j2": float(flexion[0]),
        "f1j3": float(flexion[0]),
        "f2j1": float(flexion[1]),
        "f2j2": float(flexion[1]),
        "f3j1": float(preshape_rad),
        "f3j2": float(flexion[2]),
        "f3j3": float(flexion[2]),
    }
    transforms: dict[str, np.ndarray] = {"handbase_link": np.eye(4, dtype=np.float64)}
    for name in HAND_JOINT_ORDER:
        transforms[children[name]] = transforms[parents[name]] @ _joint_transform(
            joints[name], values[name]
        )
    return transforms


def _load_proxy_manifest(path: Path | str) -> dict[str, Any]:
    """Load the isolated three-capsule PAD-core geometry snapshot.

    The source V5 manifest intentionally remained ``dynamic_use_allowed=false``
    because its full fifteen-capsule representation had never passed PhysX.
    B_MINIMAL_V2 therefore carries a separately reviewed, diagnostic-only
    snapshot containing exactly one central analytic capsule per blue PAD.
    It must never be confused with a formal full-hand collision model.
    """
    manifest = json.loads(Path(path).read_text(encoding="utf-8"))
    if manifest.get("schema") != PAD_CORE_SCHEMA:
        raise ValueError("unexpected B_MINIMAL_V2 PAD-core schema")
    if manifest.get("collision_route") != "B_MINIMAL_V2_PAD_CORE_ANALYTIC_CAPSULES":
        raise ValueError("unexpected PAD-core collision route")
    if manifest.get("whole_terminal_convex_hull_count") != 0:
        raise ValueError("whole terminal convex hull must be absent")
    if manifest.get("diagnostic_dynamic_use_allowed") is not True:
        raise ValueError("PAD-core diagnostic dynamic use is not authorized")
    if manifest.get("formal_b_use_allowed") is not False:
        raise ValueError("PAD-core snapshot must remain non-formal")
    links = manifest.get("links")
    if not isinstance(links, list) or len(links) != 3:
        raise ValueError("expected exactly three PAD-core links")
    if manifest.get("pad_primitive_count_total") != 3:
        raise ValueError("PAD-core snapshot must contain exactly three primitives")
    return manifest


def selected_central_capsules(proxy_manifest: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    links = {str(entry["link_name"]): entry for entry in proxy_manifest["links"]}
    selected: dict[str, dict[str, Any]] = {}
    for link_name in ACTIVE_TERMINAL_LINKS:
        entry = links.get(link_name)
        if entry is None:
            raise ValueError(f"proxy missing {link_name}")
        capsules = entry.get("capsules")
        if not isinstance(capsules, list) or len(capsules) != 1:
            raise ValueError(f"PAD-core snapshot must contain one capsule for {link_name}")
        index = 0
        selected[link_name] = {
            "capsule": capsules[index],
            "capsule_index": int(capsules[index].get("index", index)),
            "contact_frame_local": entry["contact_frame_local"],
        }
    return selected


def _representative_geometry(
    *,
    urdf_path: Path | str,
    selected: Mapping[str, Mapping[str, Any]],
    preshape_rad: float,
    flexion_rad: Sequence[float],
) -> tuple[np.ndarray, np.ndarray]:
    transforms = hand_link_transforms(
        urdf_path,
        preshape_rad=preshape_rad,
        finger_flexion_rad=flexion_rad,
    )
    centers: list[np.ndarray] = []
    normals: list[np.ndarray] = []
    for link_name in ACTIVE_TERMINAL_LINKS:
        entry = selected[link_name]
        transform = transforms[link_name]
        capsule = entry["capsule"]
        center_local = np.asarray(capsule["center_local_m"], dtype=np.float64)
        normal_local = np.asarray(
            entry["contact_frame_local"]["outward_normal_unit"], dtype=np.float64
        )
        center = transform[:3, :3] @ center_local + transform[:3, 3]
        normal = transform[:3, :3] @ normal_local
        normal /= max(float(np.linalg.norm(normal)), 1.0e-15)
        centers.append(center)
        normals.append(normal)
    return np.asarray(centers), np.asarray(normals)


def _closed_pose_residual(
    vector: np.ndarray,
    *,
    urdf_path: Path,
    selected: Mapping[str, Mapping[str, Any]],
    target_radius_m: float,
) -> np.ndarray:
    flexion = vector[:3]
    preshape = float(vector[3])
    axis_xy = vector[4:6]
    centers, normals = _representative_geometry(
        urdf_path=urdf_path,
        selected=selected,
        preshape_rad=preshape,
        flexion_rad=flexion,
    )
    residual: list[float] = []
    for center, normal in zip(centers, normals):
        radial_vector = axis_xy - center[:2]
        distance = float(np.linalg.norm(radial_vector))
        radial_direction = radial_vector / max(distance, 1.0e-15)
        normal_xy = normal[:2] / max(float(np.linalg.norm(normal[:2])), 1.0e-15)
        residual.append((distance - target_radius_m) / 0.001)
        residual.extend(((radial_direction - normal_xy) / 0.02).tolist())
    residual.extend(((centers[:, 2] - float(np.mean(centers[:, 2]))) / 0.001).tolist())
    residual.append((preshape - 1.30) / 0.40)
    return np.asarray(residual, dtype=np.float64)


def optimize_closed_pose(
    *,
    urdf_path: Path | str,
    proxy_manifest_path: Path | str,
    target_preload_m: float = DEFAULT_TARGET_PRELOAD_M,
) -> dict[str, Any]:
    try:
        from scipy.optimize import least_squares
    except Exception as exc:  # pragma: no cover - environment dependent
        raise RuntimeError("SciPy is required for candidate generation") from exc
    manifest = _load_proxy_manifest(proxy_manifest_path)
    selected = selected_central_capsules(manifest)
    radius = float(next(iter(selected.values()))["capsule"]["radius_m"])
    target_radius = DEFAULT_OBJECT_RADIUS_M + radius - float(target_preload_m)
    solution = least_squares(
        _closed_pose_residual,
        np.array((0.75, 0.65, 0.75, 1.30, -0.009, 0.005), dtype=np.float64),
        bounds=(
            np.array((0.30, 0.30, 0.30, 0.70, -0.03, -0.03), dtype=np.float64),
            np.array((1.10, 1.10, 1.10, 1.50, 0.03, 0.03), dtype=np.float64),
        ),
        kwargs={
            "urdf_path": Path(urdf_path),
            "selected": selected,
            "target_radius_m": target_radius,
        },
        max_nfev=6000,
        xtol=1.0e-13,
        ftol=1.0e-13,
        gtol=1.0e-13,
    )
    centers, normals = _representative_geometry(
        urdf_path=urdf_path,
        selected=selected,
        preshape_rad=float(solution.x[3]),
        flexion_rad=solution.x[:3],
    )
    axis_xy = solution.x[4:6]
    distances = np.linalg.norm(centers[:, :2] - axis_xy[None, :], axis=1)
    _joints, _parents, _children, limits = _load_urdf(urdf_path)
    flexion_margins: list[float] = []
    for name, value in zip(ROOT_TORQUE_JOINTS, solution.x[:3]):
        lower, upper = limits[name]
        flexion_margins.append(min(float(value) - lower, upper - float(value)))
    p_lower, p_upper = limits["f1j1"]
    preshape_margin = min(float(solution.x[3]) - p_lower, p_upper - float(solution.x[3]))
    return {
        "solver_success": bool(solution.success),
        "solver_message": str(solution.message),
        "optimization_residual_norm": float(np.linalg.norm(solution.fun)),
        "preshape_rad": float(solution.x[3]),
        "finger_flexion_targets_rad": [float(value) for value in solution.x[:3]],
        "object_axis_center_xy_hand_m": [float(value) for value in axis_xy],
        "predicted_contact_center_z_hand_m": float(np.mean(centers[:, 2])),
        "predicted_contact_centers_hand_m": centers.tolist(),
        "predicted_contact_normals_hand": normals.tolist(),
        "predicted_radial_gaps_m": (distances - target_radius).tolist(),
        "predicted_contact_z_spread_m": float(np.ptp(centers[:, 2])),
        "minimum_joint_margin_rad": float(min(flexion_margins + [preshape_margin])),
        "target_preload_m": float(target_preload_m),
        "selected_capsule_index_per_finger": [
            int(selected[link]["capsule_index"]) for link in ACTIVE_TERMINAL_LINKS
        ],
    }


def _capsule_world(
    *,
    link_transform_hand: np.ndarray,
    capsule: Mapping[str, Any],
    handbase_world_m: np.ndarray,
    rotation_world_from_hand: np.ndarray,
    finger: str,
) -> CapsuleWorld:
    center_local = np.asarray(capsule["center_local_m"], dtype=np.float64)
    axis_local = np.asarray(capsule["axis_unit_local"], dtype=np.float64)
    axis_local /= max(float(np.linalg.norm(axis_local)), 1.0e-15)
    center_hand = link_transform_hand[:3, :3] @ center_local + link_transform_hand[:3, 3]
    axis_hand = link_transform_hand[:3, :3] @ axis_local
    center_world = handbase_world_m + rotation_world_from_hand @ center_hand
    axis_world = rotation_world_from_hand @ axis_hand
    axis_world /= max(float(np.linalg.norm(axis_world)), 1.0e-15)
    half_cylinder = 0.5 * float(capsule["cylinder_height_m"])
    endpoint_a = center_world - half_cylinder * axis_world
    endpoint_b = center_world + half_cylinder * axis_world
    return CapsuleWorld(
        finger=finger,
        capsule_index=int(capsule.get("index", 0)),
        center_m=center_world,
        axis_unit=axis_world,
        endpoint_a_m=endpoint_a,
        endpoint_b_m=endpoint_b,
        radius_m=float(capsule["radius_m"]),
    )


def _finite_cylinder_sdf(
    points_m: np.ndarray,
    *,
    center_m: np.ndarray,
    radius_m: float,
    height_m: float,
) -> np.ndarray:
    relative = np.asarray(points_m, dtype=np.float64) - center_m
    radial = np.linalg.norm(relative[:, :2], axis=1) - float(radius_m)
    axial = np.abs(relative[:, 2]) - 0.5 * float(height_m)
    outside = np.linalg.norm(np.maximum(np.column_stack((radial, axial)), 0.0), axis=1)
    inside = np.minimum(np.maximum(radial, axial), 0.0)
    return outside + inside


def capsule_cylinder_gap_m(
    capsule: CapsuleWorld,
    *,
    object_center_m: Sequence[float] = DEFAULT_OBJECT_WORLD_CENTER_M,
    object_radius_m: float = DEFAULT_OBJECT_RADIUS_M,
    object_height_m: float = DEFAULT_OBJECT_HEIGHT_M,
    samples: int = 81,
) -> float:
    fractions = np.linspace(0.0, 1.0, int(samples), dtype=np.float64)
    points = (
        capsule.endpoint_a_m[None, :]
        + fractions[:, None] * (capsule.endpoint_b_m - capsule.endpoint_a_m)[None, :]
    )
    return float(
        np.min(
            _finite_cylinder_sdf(
                points,
                center_m=np.asarray(object_center_m, dtype=np.float64),
                radius_m=object_radius_m,
                height_m=object_height_m,
            )
        )
        - capsule.radius_m
    )


def capsule_table_gap_m(capsule: CapsuleWorld, table_top_z_m: float = DEFAULT_TABLE_TOP_Z_M) -> float:
    return float(
        min(capsule.endpoint_a_m[2], capsule.endpoint_b_m[2])
        - capsule.radius_m
        - float(table_top_z_m)
    )


def _segment_distance_m(
    p1: np.ndarray, q1: np.ndarray, p2: np.ndarray, q2: np.ndarray
) -> float:
    u = q1 - p1
    v = q2 - p2
    w = p1 - p2
    a, b, c = float(u @ u), float(u @ v), float(v @ v)
    d, e = float(u @ w), float(v @ w)
    determinant = a * c - b * b
    epsilon = 1.0e-15
    if determinant < epsilon:
        s = 0.0
        t = min(1.0, max(0.0, e / max(c, epsilon)))
    else:
        s = min(1.0, max(0.0, (b * e - c * d) / determinant))
        t = min(1.0, max(0.0, (a * e - b * d) / determinant))
        # Reproject once after clamping to handle endpoint cases.
        if a > epsilon:
            s = min(1.0, max(0.0, (b * t - d) / a))
        if c > epsilon:
            t = min(1.0, max(0.0, (b * s + e) / c))
    return float(np.linalg.norm((p1 + s * u) - (p2 + t * v)))


def capsule_capsule_gap_m(first: CapsuleWorld, second: CapsuleWorld) -> float:
    return _segment_distance_m(
        first.endpoint_a_m,
        first.endpoint_b_m,
        second.endpoint_a_m,
        second.endpoint_b_m,
    ) - first.radius_m - second.radius_m


def _pose_capsules(
    *,
    urdf_path: Path | str,
    selected: Mapping[str, Mapping[str, Any]],
    preshape_rad: float,
    flexion_rad: Sequence[float],
    axis_xy_hand_m: Sequence[float],
    object_center_z_hand_m: float,
    lift_m: float,
    hand_mount_rpy_rad: Sequence[float] = DEFAULT_HAND_MOUNT_RPY_RAD,
    object_world_center_m: Sequence[float] = DEFAULT_OBJECT_WORLD_CENTER_M,
) -> list[CapsuleWorld]:
    rotation = _rpy_matrix(hand_mount_rpy_rad)
    object_world = np.asarray(object_world_center_m, dtype=np.float64)
    object_hand = np.array(
        (float(axis_xy_hand_m[0]), float(axis_xy_hand_m[1]), float(object_center_z_hand_m)),
        dtype=np.float64,
    )
    handbase_world = object_world - rotation @ object_hand + np.array((0.0, 0.0, lift_m))
    transforms = hand_link_transforms(
        urdf_path,
        preshape_rad=preshape_rad,
        finger_flexion_rad=flexion_rad,
    )
    return [
        _capsule_world(
            link_transform_hand=transforms[link],
            capsule=selected[link]["capsule"],
            handbase_world_m=handbase_world,
            rotation_world_from_hand=rotation,
            finger=link,
        )
        for link in ACTIVE_TERMINAL_LINKS
    ]


def _evaluate_capsules(capsules: Sequence[CapsuleWorld]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    object_gaps = np.asarray([capsule_cylinder_gap_m(capsule) for capsule in capsules])
    table_gaps = np.asarray([capsule_table_gap_m(capsule) for capsule in capsules])
    pair_gaps: list[float] = []
    for first_index in range(len(capsules)):
        for second_index in range(first_index + 1, len(capsules)):
            pair_gaps.append(capsule_capsule_gap_m(capsules[first_index], capsules[second_index]))
    return object_gaps, table_gaps, np.asarray(pair_gaps, dtype=np.float64)


def _interpolate(start: float, stop: float, fraction: float) -> float:
    return float(start + float(fraction) * (stop - start))


def evaluate_candidate_sweep(
    *,
    urdf_path: Path | str,
    proxy_manifest_path: Path | str,
    closed_pose: Mapping[str, Any],
    grasp_local_z_mm: float,
    preclose_fraction: float = DEFAULT_PRECLOSE_FRACTION,
    minimum_table_clearance_m: float = DEFAULT_TABLE_CLEARANCE_M,
    samples_per_phase: int = 101,
) -> tuple[CandidateSweepMetrics, dict[str, Any]]:
    manifest = _load_proxy_manifest(proxy_manifest_path)
    selected = selected_central_capsules(manifest)
    closed_preshape = float(closed_pose["preshape_rad"])
    closed_flexion = np.asarray(closed_pose["finger_flexion_targets_rad"], dtype=np.float64)
    axis_xy = np.asarray(closed_pose["object_axis_center_xy_hand_m"], dtype=np.float64)
    contact_center_z = float(closed_pose["predicted_contact_center_z_hand_m"])
    object_center_z_hand = contact_center_z - (float(grasp_local_z_mm) - 19.0) / 1000.0
    preclose_preshape = _interpolate(
        DEFAULT_OPEN_PRESHAPE_RAD, closed_preshape, preclose_fraction
    )
    preclose_flexion = np.asarray(
        [
            _interpolate(DEFAULT_OPEN_FLEXION_RAD, target, preclose_fraction)
            for target in closed_flexion
        ],
        dtype=np.float64,
    )

    # Derive the smallest vertical approach offset that gives a full 3 mm table
    # margin throughout the open -> preclose sweep.
    zero_lift_table_minimum = float("inf")
    for fraction in np.linspace(0.0, preclose_fraction, samples_per_phase):
        capsules = _pose_capsules(
            urdf_path=urdf_path,
            selected=selected,
            preshape_rad=_interpolate(
                DEFAULT_OPEN_PRESHAPE_RAD, closed_preshape, fraction
            ),
            flexion_rad=[
                _interpolate(DEFAULT_OPEN_FLEXION_RAD, target, fraction)
                for target in closed_flexion
            ],
            axis_xy_hand_m=axis_xy,
            object_center_z_hand_m=object_center_z_hand,
            lift_m=0.0,
        )
        _object, table, _pairs = _evaluate_capsules(capsules)
        zero_lift_table_minimum = min(zero_lift_table_minimum, float(np.min(table)))
    approach_lift = max(0.0, float(minimum_table_clearance_m) - zero_lift_table_minimum)

    minimum_table = float("inf")
    minimum_precontact_object = float("inf")
    minimum_pair = float("inf")
    maximum_final_penetration = 0.0
    sample_rows: list[dict[str, Any]] = []

    def evaluate_sample(
        *, phase: str, phase_fraction: float, pose_fraction: float, lift_m: float
    ) -> None:
        nonlocal minimum_table, minimum_precontact_object, minimum_pair
        nonlocal maximum_final_penetration
        capsules = _pose_capsules(
            urdf_path=urdf_path,
            selected=selected,
            preshape_rad=_interpolate(
                DEFAULT_OPEN_PRESHAPE_RAD, closed_preshape, pose_fraction
            ),
            flexion_rad=[
                _interpolate(DEFAULT_OPEN_FLEXION_RAD, target, pose_fraction)
                for target in closed_flexion
            ],
            axis_xy_hand_m=axis_xy,
            object_center_z_hand_m=object_center_z_hand,
            lift_m=lift_m,
        )
        object_gaps, table_gaps, pair_gaps = _evaluate_capsules(capsules)
        minimum_table = min(minimum_table, float(np.min(table_gaps)))
        minimum_pair = min(minimum_pair, float(np.min(pair_gaps)))
        if phase != "FINAL_CLOSE":
            minimum_precontact_object = min(
                minimum_precontact_object, float(np.min(object_gaps))
            )
        else:
            maximum_final_penetration = max(
                maximum_final_penetration, max(0.0, -float(np.min(object_gaps)))
            )
        sample_rows.append(
            {
                "phase": phase,
                "phase_fraction": float(phase_fraction),
                "pose_fraction": float(pose_fraction),
                "lift_m": float(lift_m),
                "minimum_object_gap_m": float(np.min(object_gaps)),
                "minimum_table_gap_m": float(np.min(table_gaps)),
                "minimum_interfinger_gap_m": float(np.min(pair_gaps)),
            }
        )

    for phase_fraction in np.linspace(0.0, 1.0, samples_per_phase):
        evaluate_sample(
            phase="RAISED_PRECLOSE",
            phase_fraction=float(phase_fraction),
            pose_fraction=float(preclose_fraction * phase_fraction),
            lift_m=approach_lift,
        )
    for phase_fraction in np.linspace(0.0, 1.0, samples_per_phase):
        evaluate_sample(
            phase="DESCEND",
            phase_fraction=float(phase_fraction),
            pose_fraction=preclose_fraction,
            lift_m=approach_lift * (1.0 - float(phase_fraction)),
        )
    for phase_fraction in np.linspace(0.0, 1.0, samples_per_phase):
        evaluate_sample(
            phase="FINAL_CLOSE",
            phase_fraction=float(phase_fraction),
            pose_fraction=_interpolate(preclose_fraction, 1.0, phase_fraction),
            lift_m=0.0,
        )

    open_capsules = _pose_capsules(
        urdf_path=urdf_path,
        selected=selected,
        preshape_rad=DEFAULT_OPEN_PRESHAPE_RAD,
        flexion_rad=(DEFAULT_OPEN_FLEXION_RAD,) * 3,
        axis_xy_hand_m=axis_xy,
        object_center_z_hand_m=object_center_z_hand,
        lift_m=approach_lift,
    )
    closed_capsules = _pose_capsules(
        urdf_path=urdf_path,
        selected=selected,
        preshape_rad=closed_preshape,
        flexion_rad=closed_flexion,
        axis_xy_hand_m=axis_xy,
        object_center_z_hand_m=object_center_z_hand,
        lift_m=0.0,
    )
    closed_object_gaps, closed_table_gaps, _closed_pairs = _evaluate_capsules(
        closed_capsules
    )
    _open_object_gaps, open_table_gaps, _open_pairs = _evaluate_capsules(open_capsules)
    metrics = CandidateSweepMetrics(
        minimum_table_clearance_m=minimum_table,
        minimum_precontact_object_clearance_m=minimum_precontact_object,
        maximum_final_object_penetration_m=maximum_final_penetration,
        minimum_interfinger_clearance_m=minimum_pair,
        open_table_clearance_m=float(np.min(open_table_gaps)),
        closed_table_clearance_m=float(np.min(closed_table_gaps)),
        closed_object_gaps_m=tuple(float(value) for value in closed_object_gaps),
        approach_lift_m=float(approach_lift),
        preclose_fraction=float(preclose_fraction),
        sample_count=len(sample_rows),
    )
    checks = {
        "table_sweep_clearance_pass": metrics.minimum_table_clearance_m
        >= minimum_table_clearance_m - 1.0e-12,
        "precontact_object_clearance_pass": metrics.minimum_precontact_object_clearance_m
        >= DEFAULT_PRECONTACT_OBJECT_CLEARANCE_M - 1.0e-12,
        "final_preload_pass": metrics.maximum_final_object_penetration_m
        <= DEFAULT_MAXIMUM_FINAL_PENETRATION_M + 1.0e-12,
        "all_three_final_contacts_present": all(
            -DEFAULT_MAXIMUM_FINAL_PENETRATION_M <= gap <= 0.00020
            for gap in metrics.closed_object_gaps_m
        ),
        "interfinger_clearance_pass": metrics.minimum_interfinger_clearance_m
        >= DEFAULT_MINIMUM_INTERFINGER_CLEARANCE_M,
        "approach_lift_within_joint_range": metrics.approach_lift_m <= 0.020,
    }
    if not all(checks.values()):
        raise ValueError(
            f"candidate {grasp_local_z_mm:.1f} mm failed static sweep: {checks}, {metrics}"
        )
    return metrics, {"checks": checks, "samples": sample_rows}


def build_candidates(
    *,
    urdf_path: Path | str,
    proxy_manifest_path: Path | str,
    grasp_z_mm: Iterable[float] = DEFAULT_GRASP_Z_MM,
) -> dict[str, Any]:
    closed = optimize_closed_pose(
        urdf_path=urdf_path,
        proxy_manifest_path=proxy_manifest_path,
    )
    if not closed["solver_success"]:
        raise RuntimeError(f"closed grasp optimization failed: {closed['solver_message']}")
    selected = selected_central_capsules(_load_proxy_manifest(proxy_manifest_path))
    candidates: list[MinimalCandidate] = []
    sweep_evidence: dict[str, Any] = {}
    for grasp_z in (float(value) for value in grasp_z_mm):
        if not 9.0 <= grasp_z <= 29.0:
            raise ValueError(f"grasp z outside authorized 9..29 mm band: {grasp_z}")
        metrics, evidence = evaluate_candidate_sweep(
            urdf_path=urdf_path,
            proxy_manifest_path=proxy_manifest_path,
            closed_pose=closed,
            grasp_local_z_mm=grasp_z,
        )
        object_center_z = float(closed["predicted_contact_center_z_hand_m"]) - (
            grasp_z - 19.0
        ) / 1000.0
        preclose_flexion = tuple(
            _interpolate(DEFAULT_OPEN_FLEXION_RAD, value, DEFAULT_PRECLOSE_FRACTION)
            for value in closed["finger_flexion_targets_rad"]
        )
        score = (
            1000.0 * metrics.minimum_table_clearance_m
            + 500.0 * metrics.minimum_precontact_object_clearance_m
            + 100.0 * closed["minimum_joint_margin_rad"]
            - 1000.0 * metrics.maximum_final_object_penetration_m
            - 5.0 * metrics.approach_lift_m
        )
        candidate_id = f"PAD_CORE_Z{int(round(grasp_z)):02d}"
        candidates.append(
            MinimalCandidate(
                candidate_id=candidate_id,
                rank=0,
                grasp_local_z_mm=grasp_z,
                preshape_rad=float(closed["preshape_rad"]),
                finger_flexion_targets_rad=tuple(
                    float(value) for value in closed["finger_flexion_targets_rad"]
                ),
                object_axis_center_xy_hand_m=tuple(
                    float(value) for value in closed["object_axis_center_xy_hand_m"]
                ),
                object_center_z_hand_m=object_center_z,
                open_preshape_rad=DEFAULT_OPEN_PRESHAPE_RAD,
                open_flexion_rad=DEFAULT_OPEN_FLEXION_RAD,
                preclose_preshape_rad=_interpolate(
                    DEFAULT_OPEN_PRESHAPE_RAD,
                    float(closed["preshape_rad"]),
                    DEFAULT_PRECLOSE_FRACTION,
                ),
                preclose_flexion_rad=preclose_flexion,
                approach_lift_m=metrics.approach_lift_m,
                central_capsule_index_per_finger=tuple(
                    int(selected[link]["capsule_index"])
                    for link in ACTIVE_TERMINAL_LINKS
                ),
                predicted_contact_centers_hand_m=tuple(
                    tuple(float(component) for component in row)
                    for row in closed["predicted_contact_centers_hand_m"]
                ),
                predicted_contact_normals_hand=tuple(
                    tuple(float(component) for component in row)
                    for row in closed["predicted_contact_normals_hand"]
                ),
                predicted_closed_object_gaps_m=metrics.closed_object_gaps_m,
                predicted_contact_z_spread_m=float(
                    closed["predicted_contact_z_spread_m"]
                ),
                minimum_joint_margin_rad=float(closed["minimum_joint_margin_rad"]),
                optimization_residual_norm=float(
                    closed["optimization_residual_norm"]
                ),
                sweep_metrics=metrics,
                geometry_score=float(score),
            )
        )
        sweep_evidence[candidate_id] = evidence
    ranked = sorted(candidates, key=lambda item: item.geometry_score, reverse=True)
    ranked = [
        MinimalCandidate(**{**asdict(candidate), "rank": index + 1})
        for index, candidate in enumerate(ranked)
    ]
    return {
        "schema": SCHEMA,
        "status": "STATIC_SWEEP_PASS_AWAITING_ISAAC",
        "source_urdf_name": Path(urdf_path).name,
        "source_urdf_sha256": sha256(urdf_path),
        "source_proxy_manifest_name": Path(proxy_manifest_path).name,
        "source_proxy_manifest_sha256": sha256(proxy_manifest_path),
        "source_proxy_dynamic_use_allowed": bool(
            _load_proxy_manifest(proxy_manifest_path).get(
                "source_proxy_dynamic_use_allowed", False
            )
        ),
        "diagnostic_pad_core_dynamic_use_allowed": bool(
            _load_proxy_manifest(proxy_manifest_path).get(
                "diagnostic_dynamic_use_allowed", False
            )
        ),
        "minimal_v2_collision_subset": {
            "kind": "ONE_CENTRAL_ANALYTIC_PAD_CAPSULE_PER_FINGER",
            "pad_primitive_count_total": 3,
            "whole_terminal_convex_hull_count": 0,
            "tip_collision_count": 0,
            "formal_b_pass_claimed": False,
        },
        "closed_pose_optimization": closed,
        "candidate_count": len(ranked),
        "candidates": [
            json.loads(json.dumps(asdict(candidate), allow_nan=False))
            for candidate in ranked
        ],
        "sweep_evidence": sweep_evidence,
        "online_truth_use_allowed": False,
        "formal_b_pass_claimed": False,
    }



def compare_candidate_manifests(
    actual: Any,
    expected: Any,
    *,
    absolute_tolerance: float = 1.0e-8,
    relative_tolerance: float = 1.0e-9,
) -> dict[str, Any]:
    """Compare regenerated candidate evidence across numerical environments.

    SciPy/BLAS versions can legitimately perturb least-squares outputs by a few
    nanometres or nanoradians while preserving every geometric safety gate.
    Structural fields remain exact; only finite floating-point leaves use the
    explicit tolerances above.  The report keeps the comparison auditable and
    fail-closed for any material change.
    """

    import numbers

    exact_numeric_difference_count = 0
    numeric_leaf_count = 0
    maximum_absolute_difference = 0.0
    maximum_relative_difference = 0.0
    maximum_absolute_difference_path: str | None = None
    maximum_relative_difference_path: str | None = None
    out_of_tolerance: list[dict[str, Any]] = []
    structural_differences: list[dict[str, Any]] = []
    out_of_tolerance_count = 0
    structural_difference_count = 0

    def _path(parent: str, child: str) -> str:
        if child.startswith("["):
            return f"{parent}{child}"
        return f"{parent}.{child}" if parent else child

    def _record_structure(path: str, left: Any, right: Any, reason: str) -> None:
        nonlocal structural_difference_count
        structural_difference_count += 1
        if len(structural_differences) < 20:
            structural_differences.append(
                {
                    "path": path,
                    "reason": reason,
                    "actual_type": type(left).__name__,
                    "expected_type": type(right).__name__,
                    "actual": left,
                    "expected": right,
                }
            )

    def _walk(left: Any, right: Any, path: str) -> None:
        nonlocal exact_numeric_difference_count
        nonlocal numeric_leaf_count
        nonlocal maximum_absolute_difference
        nonlocal maximum_relative_difference
        nonlocal maximum_absolute_difference_path
        nonlocal maximum_relative_difference_path
        nonlocal out_of_tolerance_count

        if isinstance(left, Mapping) or isinstance(right, Mapping):
            if not isinstance(left, Mapping) or not isinstance(right, Mapping):
                _record_structure(path, left, right, "mapping_type_mismatch")
                return
            left_keys = set(left)
            right_keys = set(right)
            if left_keys != right_keys:
                _record_structure(
                    path,
                    sorted(left_keys - right_keys),
                    sorted(right_keys - left_keys),
                    "mapping_keys_mismatch",
                )
                return
            for key in sorted(left_keys, key=str):
                _walk(left[key], right[key], _path(path, str(key)))
            return

        sequence_types = (list, tuple)
        if isinstance(left, sequence_types) or isinstance(right, sequence_types):
            if not isinstance(left, sequence_types) or not isinstance(right, sequence_types):
                _record_structure(path, left, right, "sequence_type_mismatch")
                return
            if len(left) != len(right):
                _record_structure(path, len(left), len(right), "sequence_length_mismatch")
                return
            for index, (left_item, right_item) in enumerate(zip(left, right)):
                _walk(left_item, right_item, _path(path, f"[{index}]"))
            return

        # bool is a subclass of int and therefore must be handled first.
        if isinstance(left, bool) or isinstance(right, bool):
            if type(left) is not type(right) or left != right:
                _record_structure(path, left, right, "boolean_mismatch")
            return

        if isinstance(left, numbers.Integral) or isinstance(right, numbers.Integral):
            if not isinstance(left, numbers.Integral) or not isinstance(right, numbers.Integral):
                _record_structure(path, left, right, "integer_type_mismatch")
            elif int(left) != int(right):
                _record_structure(path, left, right, "integer_value_mismatch")
            return

        if isinstance(left, numbers.Real) and isinstance(right, numbers.Real):
            numeric_leaf_count += 1
            left_value = float(left)
            right_value = float(right)
            if not math.isfinite(left_value) or not math.isfinite(right_value):
                if left_value != right_value:
                    _record_structure(path, left, right, "nonfinite_numeric_mismatch")
                return
            difference = abs(left_value - right_value)
            scale = max(abs(left_value), abs(right_value), 1.0e-300)
            relative_difference = difference / scale
            if difference != 0.0:
                exact_numeric_difference_count += 1
            if difference > maximum_absolute_difference:
                maximum_absolute_difference = difference
                maximum_absolute_difference_path = path
            if relative_difference > maximum_relative_difference:
                maximum_relative_difference = relative_difference
                maximum_relative_difference_path = path
            tolerance = max(absolute_tolerance, relative_tolerance * scale)
            if difference > tolerance:
                out_of_tolerance_count += 1
                if len(out_of_tolerance) < 20:
                    out_of_tolerance.append(
                        {
                            "path": path,
                            "actual": left_value,
                            "expected": right_value,
                            "absolute_difference": difference,
                            "relative_difference": relative_difference,
                            "allowed_tolerance": tolerance,
                        }
                    )
            return

        if type(left) is not type(right) or left != right:
            _record_structure(path, left, right, "exact_value_mismatch")

    _walk(actual, expected, "$")
    return {
        "equivalent": structural_difference_count == 0 and out_of_tolerance_count == 0,
        "absolute_tolerance": absolute_tolerance,
        "relative_tolerance": relative_tolerance,
        "numeric_leaf_count": numeric_leaf_count,
        "exact_numeric_difference_count": exact_numeric_difference_count,
        "maximum_numeric_absolute_difference": maximum_absolute_difference,
        "maximum_numeric_absolute_difference_path": maximum_absolute_difference_path,
        "maximum_numeric_relative_difference": maximum_relative_difference,
        "maximum_numeric_relative_difference_path": maximum_relative_difference_path,
        "structural_difference_count": structural_difference_count,
        "out_of_tolerance_count": out_of_tolerance_count,
        "structural_differences": structural_differences,
        "out_of_tolerance": out_of_tolerance,
    }

def write_candidates(
    *,
    urdf_path: Path | str,
    proxy_manifest_path: Path | str,
    output_path: Path | str,
    grasp_z_mm: Iterable[float] = DEFAULT_GRASP_Z_MM,
) -> dict[str, Any]:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = build_candidates(
        urdf_path=urdf_path,
        proxy_manifest_path=proxy_manifest_path,
        grasp_z_mm=grasp_z_mm,
    )
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )
    return manifest


__all__ = [
    "ACTIVE_CONTROL_JOINTS",
    "ACTIVE_TERMINAL_LINKS",
    "CandidateSweepMetrics",
    "FOLLOWER_JOINTS",
    "HAND_JOINT_ORDER",
    "MinimalCandidate",
    "PAD_CORE_SCHEMA",
    "ROOT_TORQUE_JOINTS",
    "SCHEMA",
    "build_candidates",
    "compare_candidate_manifests",
    "capsule_capsule_gap_m",
    "capsule_cylinder_gap_m",
    "capsule_table_gap_m",
    "evaluate_candidate_sweep",
    "hand_link_transforms",
    "optimize_closed_pose",
    "selected_central_capsules",
    "sha256",
    "write_candidates",
]
