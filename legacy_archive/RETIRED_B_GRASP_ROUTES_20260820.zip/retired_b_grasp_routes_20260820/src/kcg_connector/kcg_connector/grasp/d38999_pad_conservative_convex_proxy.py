"""Deterministic conservative convex PAD proxy derivation for D38999 B V5.

The source is the user-confirmed blue PAD_BODY and its motion-derived
PAD_CONTACT_SURFACE.  This module deliberately does not decompose the author
mesh, select tread ridges, or tune parameters.  It derives a small uniform set
of analytic capsule strips whose connector-facing envelope is everywhere
behind the deepest authored contact-surface vertex.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping

import numpy as np


SCHEMA = "D38999_BLUE_PAD_CONSERVATIVE_CONVEX_PROXY_V1"
SOURCE_SCHEMA = "D38999_BLUE_PAD_SDF_SOURCE_ASSET_V1"
COLLISION_ROUTE = "CONSERVATIVE_CONVEX_PAD_PROXY"
PRIMITIVE_TYPE = "USDGEOM_CAPSULE"

CAPSULE_RADIUS_M = 0.004
CAPSULE_CYLINDER_HEIGHT_M = 0.008
CONTACT_MIDDLE_COVERAGE_FRACTION = 0.65
MAXIMUM_INTERSTRIP_RECESSION_M = 0.001
OUTWARD_INSET_M = 0.0001
MINIMUM_LONGITUDINAL_EDGE_MARGIN_M = 0.001
MINIMUM_WIDTH_EDGE_MARGIN_M = 0.001
MINIMUM_PAD_BACK_MARGIN_M = 0.002


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _unit(vector: np.ndarray, description: str) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if not math.isfinite(norm) or norm <= 1.0e-12:
        raise ValueError(f"degenerate {description}")
    return np.asarray(vector, dtype=np.float64) / norm


def _load_arrays(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _contact_frame(
    points: np.ndarray, faces: np.ndarray, contact_face_ids: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    triangles = points[faces[contact_face_ids]]
    cross = np.cross(
        triangles[:, 1] - triangles[:, 0],
        triangles[:, 2] - triangles[:, 0],
    )
    double_area = np.linalg.norm(cross, axis=1)
    if np.any(double_area <= 1.0e-15):
        raise ValueError("PAD_CONTACT_SURFACE contains a degenerate triangle")
    areas = 0.5 * double_area
    normals = cross / double_area[:, None]
    centers = np.mean(triangles, axis=1)
    origin = np.average(centers, axis=0, weights=areas)
    centered = centers - origin
    covariance = (
        (centered * areas[:, None]).T @ centered / float(np.sum(areas))
    )
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    order = np.argsort(eigenvalues)[::-1]
    longitudinal = _unit(eigenvectors[:, order[0]], "longitudinal axis")
    outward = _unit(eigenvectors[:, order[-1]], "outward normal")
    authored_normal = _unit(
        np.average(normals, axis=0, weights=areas), "authored mean normal"
    )
    if float(outward @ authored_normal) < 0.0:
        outward = -outward
    dominant = int(np.argmax(np.abs(longitudinal)))
    if longitudinal[dominant] < 0.0:
        longitudinal = -longitudinal
    width = _unit(np.cross(outward, longitudinal), "width axis")
    basis = np.column_stack((longitudinal, width, outward))
    return origin, basis, triangles, areas, eigenvalues[order]


def _capsule_count(target_footprint_m: float) -> tuple[int, float]:
    radius = CAPSULE_RADIUS_M
    recession = MAXIMUM_INTERSTRIP_RECESSION_M
    maximum_spacing = 2.0 * math.sqrt(
        radius * radius - (radius - recession) ** 2
    )
    remaining = max(0.0, target_footprint_m - 2.0 * radius)
    count = max(1, int(math.ceil(remaining / maximum_spacing)) + 1)
    return count, maximum_spacing


def _link_proxy(source_dir: Path, entry: Mapping[str, Any]) -> dict[str, Any]:
    pad_path = source_dir / str(entry["pad_sdf_source_arrays"])
    tip_path = source_dir / str(entry["tip_base_collision_source_arrays"])
    if file_sha256(pad_path) != entry["pad_sdf_source_arrays_sha256"]:
        raise ValueError(f"PAD source hash mismatch: {pad_path}")
    if file_sha256(tip_path) != entry["tip_base_collision_source_arrays_sha256"]:
        raise ValueError(f"TIP source hash mismatch: {tip_path}")
    arrays = _load_arrays(pad_path)
    required = {"points_local_m", "faces", "pad_contact_face_ids"}
    if not required.issubset(arrays):
        raise ValueError(f"missing PAD source arrays: {sorted(required - arrays.keys())}")
    points = np.asarray(arrays["points_local_m"], dtype=np.float64)
    faces = np.asarray(arrays["faces"], dtype=np.int64)
    contact_ids = np.asarray(arrays["pad_contact_face_ids"], dtype=np.int64)
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("PAD points must be Nx3")
    if faces.ndim != 2 or faces.shape[1] != 3:
        raise ValueError("PAD faces must be Mx3")
    if len(contact_ids) == 0 or np.any(contact_ids < 0) or np.any(contact_ids >= len(faces)):
        raise ValueError("PAD contact face ids are invalid")

    origin, basis, triangles, areas, eigenvalues = _contact_frame(
        points, faces, contact_ids
    )
    contact_coordinates = (triangles.reshape(-1, 3) - origin) @ basis
    pad_coordinates = (points - origin) @ basis
    contact_min = np.min(contact_coordinates, axis=0)
    contact_max = np.max(contact_coordinates, axis=0)
    pad_min = np.min(pad_coordinates, axis=0)
    pad_max = np.max(pad_coordinates, axis=0)
    contact_span = contact_max - contact_min
    radius = CAPSULE_RADIUS_M
    total_axis_span = CAPSULE_CYLINDER_HEIGHT_M + 2.0 * radius
    if total_axis_span >= float(contact_span[1]):
        raise ValueError("capsule total width does not fit PAD contact width")

    target_footprint = CONTACT_MIDDLE_COVERAGE_FRACTION * float(contact_span[0])
    count, maximum_spacing = _capsule_count(target_footprint)
    center_span = max(0.0, target_footprint - 2.0 * radius)
    spacing = 0.0 if count == 1 else center_span / float(count - 1)
    if spacing > maximum_spacing + 1.0e-12:
        raise AssertionError("derived capsule spacing exceeds recession contract")
    middle_u = 0.5 * float(contact_min[0] + contact_max[0])
    middle_v = 0.5 * float(contact_min[1] + contact_max[1])
    first_u = middle_u - 0.5 * center_span
    outer_cap_w = float(contact_min[2]) - OUTWARD_INSET_M
    center_w = outer_cap_w - radius

    capsules: list[dict[str, Any]] = []
    for index in range(count):
        coordinate = np.array(
            [first_u + float(index) * spacing, middle_v, center_w],
            dtype=np.float64,
        )
        center_local = origin + basis @ coordinate
        capsules.append(
            {
                "index": index,
                "prim_name": f"PAD_CONTACT_CAPSULE_{index + 1:02d}",
                "center_local_m": center_local.tolist(),
                "axis_unit_local": basis[:, 1].tolist(),
                "radius_m": radius,
                "cylinder_height_m": CAPSULE_CYLINDER_HEIGHT_M,
                "total_axis_span_m": total_axis_span,
                "collision_role": "PAD_CONTACT_SURFACE_PROXY",
                "physics_material_role": "PAD_FRICTION",
                "formal_contact_use": "POSTHOC_ROLE_GATE_ONLY",
            }
        )

    last_u = first_u + float(count - 1) * spacing
    longitudinal_edge_margin = min(
        first_u - radius - float(contact_min[0]),
        float(contact_max[0]) - (last_u + radius),
    )
    width_edge_margin = min(
        middle_v - 0.5 * total_axis_span - float(contact_min[1]),
        float(contact_max[1]) - (middle_v + 0.5 * total_axis_span),
    )
    back_margin = center_w - radius - float(pad_min[2])
    actual_recession = (
        0.0
        if count == 1
        else radius - math.sqrt(radius * radius - (0.5 * spacing) ** 2)
    )
    outward_clearance = float(contact_min[2]) - outer_cap_w
    checks = {
        "connector_facing_proxy_never_ahead_of_any_contact_vertex": bool(
            outer_cap_w <= float(contact_min[2]) - OUTWARD_INSET_M + 1.0e-12
        ),
        "longitudinal_edge_margin_pass": bool(
            longitudinal_edge_margin >= MINIMUM_LONGITUDINAL_EDGE_MARGIN_M
        ),
        "width_edge_margin_pass": bool(
            width_edge_margin >= MINIMUM_WIDTH_EDGE_MARGIN_M
        ),
        "pad_back_margin_pass": bool(
            back_margin >= MINIMUM_PAD_BACK_MARGIN_M
        ),
        "interstrip_recession_pass": bool(
            actual_recession <= MAXIMUM_INTERSTRIP_RECESSION_M + 1.0e-12
        ),
    }
    if not all(checks.values()):
        raise ValueError(f"conservative PAD proxy geometry gate failed: {checks}")

    return {
        "finger_number": int(entry["finger_number"]),
        "link_name": str(entry["link_name"]),
        "source_pad_arrays": pad_path.name,
        "source_pad_arrays_sha256": entry["pad_sdf_source_arrays_sha256"],
        "source_tip_arrays": tip_path.name,
        "source_tip_arrays_sha256": entry[
            "tip_base_collision_source_arrays_sha256"
        ],
        "source_contact_face_count": int(len(contact_ids)),
        "contact_frame_local": {
            "origin_m": origin.tolist(),
            "longitudinal_axis_unit": basis[:, 0].tolist(),
            "width_axis_unit": basis[:, 1].tolist(),
            "outward_normal_unit": basis[:, 2].tolist(),
            "weighted_covariance_eigenvalues_m2": eigenvalues.tolist(),
        },
        "source_contact_bounds_in_frame_m": {
            "minimum": contact_min.tolist(),
            "maximum": contact_max.tolist(),
            "span": contact_span.tolist(),
        },
        "source_pad_bounds_in_frame_m": {
            "minimum": pad_min.tolist(),
            "maximum": pad_max.tolist(),
        },
        "capsule_count": count,
        "capsules": capsules,
        "tip_collision": {
            "source_arrays": tip_path.name,
            "shape": "AUTHOR_TIP_MESH_CONVEX_HULL",
            "collision_role": "TIP_END_SURFACE",
            "physics_material_role": "BASE_FRICTION",
            "formal_pad_contact_allowed": False,
        },
        "task_geometry_metrics": {
            "contact_surface_area_m2": float(np.sum(areas)),
            "contact_relief_m": float(contact_span[2]),
            "target_middle_footprint_m": target_footprint,
            "actual_middle_coverage_fraction": (
                (last_u + radius - (first_u - radius)) / float(contact_span[0])
            ),
            "capsule_center_spacing_m": spacing,
            "maximum_spacing_from_recession_contract_m": maximum_spacing,
            "actual_interstrip_recession_m": actual_recession,
            "outward_cap_coordinate_m": outer_cap_w,
            "minimum_authored_contact_coordinate_m": float(contact_min[2]),
            "minimum_outward_inset_m": outward_clearance,
            "longitudinal_edge_margin_m": longitudinal_edge_margin,
            "width_edge_margin_m": width_edge_margin,
            "pad_back_margin_m": back_margin,
        },
        "static_checks": checks,
    }


def build_proxy_manifest(source_dir: Path) -> dict[str, Any]:
    source_dir = Path(source_dir).resolve()
    source_manifest_path = source_dir / "PAD_SDF_SOURCE_ASSET_MANIFEST.json"
    source = json.loads(source_manifest_path.read_text(encoding="utf-8"))
    if source.get("schema") != SOURCE_SCHEMA:
        raise ValueError(f"unexpected PAD source schema: {source.get('schema')}")
    if source.get("collision_route") != "PHYSX_SDF":
        raise ValueError("source asset is not the audited exact blue PAD source")
    if source.get("semantic_authority") != "USER_CONFIRMED_HAND_GEOMETRY_SEMANTICS":
        raise ValueError("blue PAD semantic authority is missing")
    links = source.get("links")
    if not isinstance(links, list) or len(links) != 3:
        raise ValueError("expected exactly three audited finger links")
    link_results = [_link_proxy(source_dir, entry) for entry in links]
    counts = {int(link["capsule_count"]) for link in link_results}
    if len(counts) != 1:
        raise ValueError(f"homologous PAD proxy counts disagree: {sorted(counts)}")
    return {
        "schema": SCHEMA,
        "status": "STATIC_PROXY_DERIVED_AWAITING_ISAAC_COMPATIBILITY",
        "collision_route": COLLISION_ROUTE,
        "primitive_type": PRIMITIVE_TYPE,
        "source_manifest": source_manifest_path.name,
        "source_manifest_sha256": file_sha256(source_manifest_path),
        "source_semantic_authority": source["semantic_authority"],
        "derivation": {
            "kind": "UNIFORM_ANALYTIC_CAPSULE_STRIPS_FROM_CONTACT_FRAME",
            "parameter_grid_used": False,
            "per_tread_selection_used": False,
            "coacd_used": False,
            "sdf_used": False,
            "capsule_radius_m": CAPSULE_RADIUS_M,
            "capsule_cylinder_height_m": CAPSULE_CYLINDER_HEIGHT_M,
            "contact_middle_coverage_fraction": CONTACT_MIDDLE_COVERAGE_FRACTION,
            "maximum_interstrip_recession_m": MAXIMUM_INTERSTRIP_RECESSION_M,
            "outward_inset_m": OUTWARD_INSET_M,
        },
        "pad_collision_primitive_count_per_finger": next(iter(counts)),
        "pad_collision_primitive_count_total": sum(
            int(link["capsule_count"]) for link in link_results
        ),
        "tip_collision_primitive_count_per_finger": 1,
        "whole_terminal_convex_hull_allowed": False,
        "whole_terminal_convex_hull_count": 0,
        "visual_geometry_changed": False,
        "robot_mass_changed": False,
        "robot_inertia_changed": False,
        "finger_dimensions_expanded": False,
        "pad_material_scope": "PAD_CONTACT_CAPSULES_ONLY",
        "tip_material_scope": "BASE_FRICTION",
        "formal_valid_contact_role": "PAD_CONTACT_SURFACE_ONLY",
        "online_contact_truth_use_allowed": False,
        "posthoc_contact_role_audit_required": True,
        "dynamic_use_allowed": False,
        "links": link_results,
    }


def write_proxy_asset(source_dir: Path, output_dir: Path) -> dict[str, Any]:
    output_dir = Path(output_dir).resolve()
    if output_dir.exists():
        raise FileExistsError(f"refusing to overwrite PAD proxy output: {output_dir}")
    manifest = build_proxy_manifest(source_dir)
    output_dir.mkdir(parents=True, exist_ok=False)
    path = output_dir / "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json"
    path.write_text(
        json.dumps(manifest, allow_nan=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest

