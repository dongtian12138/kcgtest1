"""Offline blue-PAD/red-TIP semantics for D38999 V5.

The user-confirmed blue PAD_BODY is selected by authored geometry and checked
against the f1 reference shape.  The red drawing component 4 is TIP.  The broad
inner PAD surface is identified by the real URDF joint chain's closing motion.

This module deliberately does not build convex proxies, impose a convex-piece
count, or reuse the connector's 50 um event-position tolerance.  Its geometry
and role labels are asset-authoring/post-hoc audit data and are forbidden as
online controller observations.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
from pathlib import Path
from typing import Any, Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np


USER_SEMANTIC_AUTHORITY = "USER_CONFIRMED_HAND_GEOMETRY_SEMANTICS"
REJECTED_WRONG_BRANCH_STATUS = "REJECTED_WRONG_SEMANTIC_COMPONENT"
REJECTED_WRONG_BRANCH_REASON = "component_4_is_tip_not_pad"
SDF_ROUTE_STATUS = "SDF_PRIORITY_COMPATIBILITY_SMOKE_PENDING"


class ContactRole(str, Enum):
    PAD_CONTACT_SURFACE = "PAD_CONTACT_SURFACE"
    PAD_SIDE_SURFACE = "PAD_SIDE_SURFACE"
    TIP_END_SURFACE = "TIP_END_SURFACE"
    OTHER_STRUCTURE = "OTHER_STRUCTURE"


@dataclass(frozen=True)
class FingerPadRoleSpec:
    finger_number: int
    link_name: str
    authored_mesh_sha256: str
    chain_joint_names: tuple[str, ...]
    fixed_joint_positions_rad: Mapping[str, float]
    closing_joint_names: tuple[str, ...]
    blue_face_count: int = 2479
    blue_vertex_count: int = 1250
    blue_area_m2: float = 0.0025598507
    tip_face_count: int = 1076
    tip_area_m2: float = 0.000403693989


@dataclass(frozen=True)
class FingerPadRoleBuild:
    spec: FingerPadRoleSpec
    source_path: Path
    source_sha256: str
    urdf_path: Path
    authored_mesh: Any
    components_by_area: tuple[Any, ...]
    pad_component: Any
    tip_component: Any
    pad_component_rank_by_area: int
    tip_component_rank_by_area: int
    pad_component_registration: Mapping[str, float]
    pad_face_roles: np.ndarray
    pad_contact_face_ids: np.ndarray
    pad_side_face_ids: np.ndarray
    minimum_closure_alignment: np.ndarray
    diagnostics: Mapping[str, Any]


FINGER_PAD_ROLE_SPECS: tuple[FingerPadRoleSpec, ...] = (
    FingerPadRoleSpec(
        finger_number=1,
        link_name="f1Link3",
        authored_mesh_sha256=(
            "7a33a6ab46729a2237dd13d99be3bcefb92bb3d4b77bbf9e69d884509cffcdb0"
        ),
        chain_joint_names=("f1j1", "f1j2", "f1j3"),
        fixed_joint_positions_rad={"f1j1": 1.0},
        closing_joint_names=("f1j2", "f1j3"),
        blue_area_m2=0.0025598508051483595,
    ),
    FingerPadRoleSpec(
        finger_number=2,
        link_name="f2Link2",
        authored_mesh_sha256=(
            "1758619f7ef1369fc3342c7032edee07222f9bdccc187c33830f9fa59bd508b3"
        ),
        chain_joint_names=("f2j1", "f2j2"),
        fixed_joint_positions_rad={},
        closing_joint_names=("f2j1", "f2j2"),
        blue_area_m2=0.0025598504960375435,
    ),
    FingerPadRoleSpec(
        finger_number=3,
        link_name="f3Link3",
        authored_mesh_sha256=(
            "93645443cff113b8c6e5a0280e3270192831d04246233cc45d9745c6e3c7d16e"
        ),
        chain_joint_names=("f3j1", "f3j2", "f3j3"),
        fixed_joint_positions_rad={"f3j1": 1.0},
        closing_joint_names=("f3j2", "f3j3"),
        blue_area_m2=0.0025598508051483595,
    ),
)

CLOSURE_Q_SAMPLES_RAD = (0.35, 0.45, 0.55, 0.65, 0.75)
CLOSURE_ALIGNMENT_MINIMUM = 0.90
CLOSURE_FINITE_DIFFERENCE_RAD = 1.0e-5


def repository_root() -> Path:
    return Path(__file__).resolve().parents[4]


def authored_mesh_path(
    spec: FingerPadRoleSpec, root: Path | None = None
) -> Path:
    base = repository_root() if root is None else Path(root)
    return base / "src/iiwa_description/meshes/hand" / f"{spec.link_name}.STL"


def default_urdf_path(root: Path | None = None) -> Path:
    base = repository_root() if root is None else Path(root)
    return base / "artifacts/kcg_connector/urdf/handarm.urdf"


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _trimesh_module() -> Any:
    try:
        import trimesh
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("blue PAD semantic audit requires trimesh 5.0.0") from exc
    return trimesh


def _triangle_key(triangle: np.ndarray) -> str:
    quantized = np.rint(np.asarray(triangle) / 1.0e-9).astype("<i8")
    order = np.lexsort((quantized[:, 2], quantized[:, 1], quantized[:, 0]))
    return hashlib.sha256(quantized[order].tobytes()).hexdigest()


def _load_components(
    spec: FingerPadRoleSpec, source_path: Path
) -> tuple[Any, tuple[Any, ...], str]:
    trimesh = _trimesh_module()
    path = Path(source_path).resolve()
    source_hash = file_sha256(path)
    if source_hash != spec.authored_mesh_sha256:
        raise ValueError(
            f"{spec.link_name} authored STL changed: {source_hash} != "
            f"{spec.authored_mesh_sha256}"
        )
    mesh = trimesh.load_mesh(path, process=True)
    if not isinstance(mesh, trimesh.Trimesh):
        raise TypeError(f"{path} did not load as one Trimesh")
    components = tuple(
        sorted(
            mesh.split(only_watertight=False),
            key=lambda component: float(component.area),
            reverse=True,
        )
    )
    return mesh, components, source_hash


def _unique_component_by_geometry(
    components: Sequence[Any],
    *,
    face_count: int,
    vertex_count: int | None,
    area_m2: float,
    role: str,
) -> tuple[Any, int]:
    candidates: list[tuple[Any, int]] = []
    for rank, component in enumerate(components):
        if len(component.faces) != face_count:
            continue
        if vertex_count is not None and len(component.vertices) != vertex_count:
            continue
        if abs(float(component.area) - area_m2) > 5.0e-10:
            continue
        candidates.append((component, rank))
    if len(candidates) != 1:
        raise ValueError(f"expected one {role}; found {len(candidates)}")
    return candidates[0]


def _pca_coordinates(points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    centered = np.asarray(points, dtype=np.float64) - np.mean(points, axis=0)
    _u, singular_values, axes = np.linalg.svd(centered, full_matrices=False)
    return centered @ axes.T, singular_values


def _directed_nearest_distances(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    result = np.empty(len(a), dtype=np.float64)
    for start in range(0, len(a), 128):
        chunk = a[start : start + 128]
        squared = np.sum((chunk[:, None, :] - b[None, :, :]) ** 2, axis=2)
        result[start : start + len(chunk)] = np.sqrt(np.min(squared, axis=1))
    return result


def _registration_diagnostics(candidate: Any, reference: Any) -> dict[str, float]:
    candidate_coordinates, candidate_singular = _pca_coordinates(candidate.vertices)
    reference_coordinates, reference_singular = _pca_coordinates(reference.vertices)
    best: tuple[float, float] | None = None
    for sx in (-1.0, 1.0):
        for sy in (-1.0, 1.0):
            for sz in (-1.0, 1.0):
                aligned = candidate_coordinates * np.array([sx, sy, sz])
                forward = _directed_nearest_distances(aligned, reference_coordinates)
                reverse = _directed_nearest_distances(reference_coordinates, aligned)
                rms = float(np.sqrt(np.mean(np.r_[forward**2, reverse**2])))
                maximum = float(max(np.max(forward), np.max(reverse)))
                if best is None or (rms, maximum) < best:
                    best = (rms, maximum)
    assert best is not None
    return {
        "symmetric_chamfer_rms_m": best[0],
        "symmetric_chamfer_max_m": best[1],
        "pca_singular_value_max_relative_error": float(
            np.max(
                np.abs(candidate_singular - reference_singular)
                / np.maximum(reference_singular, 1.0e-15)
            )
        ),
    }


def _rpy_rotation(rpy: Sequence[float]) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = np.cos(roll), np.sin(roll)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cy, sy = np.cos(yaw), np.sin(yaw)
    return np.array(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ],
        dtype=np.float64,
    )


def _axis_rotation(axis: np.ndarray, angle: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=np.float64)
    axis = axis / np.linalg.norm(axis)
    x, y, z = axis
    skew = np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])
    return (
        np.eye(3)
        + np.sin(angle) * skew
        + (1.0 - np.cos(angle)) * (skew @ skew)
    )


def _joint_records(urdf_path: Path) -> dict[str, dict[str, np.ndarray]]:
    root = ET.parse(urdf_path).getroot()
    records: dict[str, dict[str, np.ndarray]] = {}
    for joint in root.findall("joint"):
        name = joint.attrib["name"]
        origin = joint.find("origin")
        axis = joint.find("axis")
        xyz = np.fromstring(
            "0 0 0" if origin is None else origin.attrib.get("xyz", "0 0 0"),
            sep=" ",
        )
        rpy = np.fromstring(
            "0 0 0" if origin is None else origin.attrib.get("rpy", "0 0 0"),
            sep=" ",
        )
        axis_xyz = np.fromstring(
            "0 0 1" if axis is None else axis.attrib.get("xyz", "0 0 1"),
            sep=" ",
        )
        records[name] = {"xyz": xyz, "rpy": rpy, "axis": axis_xyz}
    return records


def _link_transform(
    spec: FingerPadRoleSpec,
    joint_records: Mapping[str, Mapping[str, np.ndarray]],
    closing_q: float,
) -> np.ndarray:
    transform = np.eye(4, dtype=np.float64)
    for joint_name in spec.chain_joint_names:
        record = joint_records[joint_name]
        origin = np.eye(4, dtype=np.float64)
        origin[:3, :3] = _rpy_rotation(record["rpy"])
        origin[:3, 3] = record["xyz"]
        position = float(spec.fixed_joint_positions_rad.get(joint_name, closing_q))
        rotation = np.eye(4, dtype=np.float64)
        rotation[:3, :3] = _axis_rotation(record["axis"], position)
        transform = transform @ origin @ rotation
    return transform


def _minimum_closure_alignment(
    pad: Any, spec: FingerPadRoleSpec, urdf_path: Path
) -> np.ndarray:
    records = _joint_records(urdf_path)
    centers_h = np.c_[pad.triangles_center, np.ones(len(pad.faces))]
    minimum = np.full(len(pad.faces), np.inf, dtype=np.float64)
    for closing_q in CLOSURE_Q_SAMPLES_RAD:
        before = _link_transform(
            spec, records, closing_q - CLOSURE_FINITE_DIFFERENCE_RAD
        )
        after = _link_transform(
            spec, records, closing_q + CLOSURE_FINITE_DIFFERENCE_RAD
        )
        middle = _link_transform(spec, records, closing_q)
        world_before = (before @ centers_h.T).T[:, :3]
        world_after = (after @ centers_h.T).T[:, :3]
        velocity = world_after - world_before
        speed = np.linalg.norm(velocity, axis=1)
        valid = speed > 1.0e-12
        unit_velocity = np.zeros_like(velocity)
        unit_velocity[valid] = velocity[valid] / speed[valid, None]
        world_normals = pad.face_normals @ middle[:3, :3].T
        alignment = np.einsum("ij,ij->i", world_normals, unit_velocity)
        # If the whole candidate side is reversed by a joint convention, fail
        # closed only after choosing the physical closing direction globally.
        if float(np.median(alignment)) < 0.0:
            alignment = -alignment
        minimum = np.minimum(minimum, alignment)
    return minimum


def build_finger_pad_role(
    spec: FingerPadRoleSpec,
    source_path: Path | None = None,
    urdf_path: Path | None = None,
    reference_path: Path | None = None,
) -> FingerPadRoleBuild:
    path = authored_mesh_path(spec) if source_path is None else Path(source_path)
    hand_urdf = default_urdf_path() if urdf_path is None else Path(urdf_path)
    mesh, components, source_hash = _load_components(spec, path)
    pad, pad_rank = _unique_component_by_geometry(
        components,
        face_count=spec.blue_face_count,
        vertex_count=spec.blue_vertex_count,
        area_m2=spec.blue_area_m2,
        role="blue PAD_BODY",
    )
    tip, tip_rank = _unique_component_by_geometry(
        components,
        face_count=spec.tip_face_count,
        vertex_count=None,
        area_m2=spec.tip_area_m2,
        role="red TIP",
    )
    if pad_rank != 1 or tip_rank != 4:
        raise ValueError(
            f"{spec.link_name} drawing audit changed: blue={pad_rank}, tip={tip_rank}"
        )

    reference_spec = FINGER_PAD_ROLE_SPECS[0]
    reference_source = (
        authored_mesh_path(reference_spec)
        if reference_path is None
        else Path(reference_path)
    )
    _reference_mesh, reference_components, _reference_hash = _load_components(
        reference_spec, reference_source
    )
    reference_pad, _reference_rank = _unique_component_by_geometry(
        reference_components,
        face_count=reference_spec.blue_face_count,
        vertex_count=reference_spec.blue_vertex_count,
        area_m2=reference_spec.blue_area_m2,
        role="f1 blue PAD_BODY reference",
    )
    registration = _registration_diagnostics(pad, reference_pad)
    if registration["symmetric_chamfer_max_m"] > 1.0e-8:
        raise ValueError(f"{spec.link_name} PAD registration failed: {registration}")

    closure_alignment = _minimum_closure_alignment(pad, spec, hand_urdf)
    contact_ids = np.flatnonzero(
        closure_alignment >= CLOSURE_ALIGNMENT_MINIMUM
    ).astype(np.int64)
    roles = np.full(
        len(pad.faces), ContactRole.PAD_SIDE_SURFACE.value, dtype=object
    )
    roles[contact_ids] = ContactRole.PAD_CONTACT_SURFACE.value
    side_ids = np.flatnonzero(roles == ContactRole.PAD_SIDE_SURFACE.value).astype(
        np.int64
    )
    diagnostics = {
        "semantic_authority": USER_SEMANTIC_AUTHORITY,
        "red_component_4_role": "TIP",
        "red_component_4_pad_use_allowed": False,
        "rejected_wrong_branch_status": REJECTED_WRONG_BRANCH_STATUS,
        "rejected_wrong_branch_reason": REJECTED_WRONG_BRANCH_REASON,
        "pad_body_identification_basis": (
            "USER_CONFIRMED_BLUE_BODY_PLUS_GEOMETRY_SIGNATURE_AND_F1_REGISTRATION"
        ),
        "pad_component_rank_by_area_diagnostic_only": int(pad_rank),
        "tip_component_rank_by_area_diagnostic_only": int(tip_rank),
        "pad_component_faces": int(len(pad.faces)),
        "pad_component_vertices": int(len(pad.vertices)),
        "pad_component_area_m2": float(pad.area),
        "pad_component_is_watertight": bool(pad.is_watertight),
        "pad_component_is_winding_consistent": bool(pad.is_winding_consistent),
        "tip_component_faces": int(len(tip.faces)),
        "tip_component_is_watertight": bool(tip.is_watertight),
        "pad_component_registration_to_f1": dict(registration),
        "contact_surface_method": "REAL_URDF_CLOSING_MOTION_MINIMUM_ALIGNMENT",
        "closure_q_samples_rad": list(CLOSURE_Q_SAMPLES_RAD),
        "closure_alignment_minimum": CLOSURE_ALIGNMENT_MINIMUM,
        "pad_contact_source_face_count": int(len(contact_ids)),
        "pad_contact_source_area_m2": float(np.sum(pad.area_faces[contact_ids])),
        "pad_side_source_face_count": int(len(side_ids)),
        "sdf_route_status": SDF_ROUTE_STATUS,
        "convex_piece_limit_enforced": False,
        "connector_event_50um_reused_as_pad_mesh_gate": False,
        "visual_geometry_changed": False,
        "mass_or_inertia_changed": False,
        "isaac_sdf_cooked_verified": False,
        "dynamic_use_allowed": False,
        "online_control_role_truth_allowed": False,
        "posthoc_role_evaluation_allowed": True,
    }
    return FingerPadRoleBuild(
        spec=spec,
        source_path=Path(path).resolve(),
        source_sha256=source_hash,
        urdf_path=hand_urdf.resolve(),
        authored_mesh=mesh,
        components_by_area=components,
        pad_component=pad,
        tip_component=tip,
        pad_component_rank_by_area=pad_rank,
        tip_component_rank_by_area=tip_rank,
        pad_component_registration=registration,
        pad_face_roles=roles,
        pad_contact_face_ids=contact_ids,
        pad_side_face_ids=side_ids,
        minimum_closure_alignment=closure_alignment,
        diagnostics=diagnostics,
    )


def face_role_records(build: FingerPadRoleBuild) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for rank, component in enumerate(build.components_by_area):
        if rank == build.pad_component_rank_by_area:
            roles = build.pad_face_roles
            component_role = "PAD_BODY"
        elif rank == build.tip_component_rank_by_area:
            roles = np.full(
                len(component.faces), ContactRole.TIP_END_SURFACE.value, dtype=object
            )
            component_role = "TIP"
        else:
            roles = np.full(
                len(component.faces), ContactRole.OTHER_STRUCTURE.value, dtype=object
            )
            component_role = "OTHER_STRUCTURE"
        for face_id, triangle in enumerate(component.triangles):
            rows.append(
                {
                    "source_face_key": _triangle_key(triangle),
                    "source_component_rank_by_area_diagnostic_only": int(rank),
                    "source_component_role": component_role,
                    "source_component_face_id_diagnostic_only": int(face_id),
                    "contact_role": str(roles[face_id]),
                    "area_m2": float(component.area_faces[face_id]),
                    "center_local_m": np.mean(triangle, axis=0).tolist(),
                    "normal_local": component.face_normals[face_id].tolist(),
                }
            )
    rows.sort(key=lambda row: row["source_face_key"])
    return rows


__all__ = [
    "CLOSURE_ALIGNMENT_MINIMUM",
    "CLOSURE_Q_SAMPLES_RAD",
    "ContactRole",
    "FINGER_PAD_ROLE_SPECS",
    "FingerPadRoleBuild",
    "FingerPadRoleSpec",
    "REJECTED_WRONG_BRANCH_REASON",
    "REJECTED_WRONG_BRANCH_STATUS",
    "SDF_ROUTE_STATUS",
    "USER_SEMANTIC_AUTHORITY",
    "authored_mesh_path",
    "build_finger_pad_role",
    "default_urdf_path",
    "face_role_records",
    "file_sha256",
    "repository_root",
]
