import json
from pathlib import Path

import numpy as np

from kcg_connector.grasp.b_goal_mode.grasp_candidate_search import (
    BOUNDED_CANDIDATE_SCHEMA,
    build_bounded_candidate_bundle,
    candidate_world_geometry,
    load_seed_geometry,
    select_candidate,
    selected_pad_capsules,
)

import yaml


REPOSITORY = Path(__file__).resolve().parents[3]


def test_seed_geometry_is_hash_bound_and_has_only_three_pad_capsules() -> None:
    candidates, pad_core = load_seed_geometry(
        candidates_path=REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json",
        pad_core_path=REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json",
        source_urdf=REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf",
    )
    assert len(selected_pad_capsules(pad_core)) == 3
    assert pad_core["whole_terminal_convex_hull_count"] == 0
    assert select_candidate(candidates, "PAD_CORE_Z12")["grasp_local_z_mm"] == 12.0


def test_candidate_world_transform_reproduces_object_center() -> None:
    candidates = json.loads(
        (REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json").read_text()
    )
    candidate = select_candidate(candidates, "PAD_CORE_Z12")
    geometry = candidate_world_geometry(
        hand_mount_rpy_rad=[-3.14140498, -0.00258625116, 2.75771363],
        object_world_center_m=[0.0, 0.0, 0.100],
        candidate=candidate,
    )
    rotation = np.asarray(geometry["rotation_world_from_hand"])
    reproduced = np.asarray(geometry["handbase_world_m"]) + rotation @ np.asarray(
        geometry["object_center_hand_m"]
    )
    assert np.allclose(reproduced, [0.0, 0.0, 0.100], atol=1.0e-12)
    axis_world = rotation @ np.asarray(geometry["lift_axis_in_joint_frame"])
    assert np.allclose(axis_world, [0.0, 0.0, 1.0], atol=1.0e-12)


def test_bounded_search_has_twelve_candidates_and_three_distinct_hand_shapes() -> None:
    config = yaml.safe_load(
        (REPOSITORY / "src/kcg_connector/config/b_goal_mode/b_goal_mode.yaml").read_text()
    )
    bundle = build_bounded_candidate_bundle(
        config=config,
        source_urdf=REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf",
        seed_candidates_path=REPOSITORY
        / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json",
        pad_core_path=REPOSITORY
        / "src/kcg_connector/config/d38999_b_minimal_v2_pad_core.json",
    )
    assert bundle["schema"] == BOUNDED_CANDIDATE_SCHEMA
    assert bundle["candidate_count"] == 12
    assert bundle["dynamic_candidate_count"] == 3
    selected = [
        row for row in bundle["candidates"] if row["dynamic_rank"] is not None
    ]
    assert [row["dynamic_rank"] for row in selected] == [1, 2, 3]
    assert len({row["preshape_rad"] for row in selected}) == 3
    assert all(row["static_pass"] for row in bundle["candidates"])
    assert all(row["sweep_metrics"]["sample_count"] == 303 for row in bundle["candidates"])
    assert all(
        row["task_metrics"]["maximum_required_peak_normal_force_n"] <= 12.0
        for row in bundle["candidates"]
    )
    assert all(
        0.15 <= fraction <= 0.85
        for row in bundle["candidates"]
        for fraction in row["predicted_contact_axis_fraction"]
    )
    assert bundle["minimal_v2_collision_subset"] == {
        "kind": "ONE_CENTRAL_ANALYTIC_PAD_CAPSULE_PER_FINGER",
        "pad_primitive_count_total": 3,
        "whole_terminal_convex_hull_count": 0,
        "tip_collision_count": 0,
        "formal_b_pass_claimed": False,
    }


def test_candidate_world_transform_applies_bounded_wrist_offsets() -> None:
    candidates = json.loads(
        (REPOSITORY / "src/kcg_connector/config/d38999_b_minimal_v2_candidates.json").read_text()
    )
    candidate = select_candidate(candidates, "PAD_CORE_Z12")
    candidate["wrist_rpy_offset_rad"] = [0.01, -0.02, 0.0]
    geometry = candidate_world_geometry(
        hand_mount_rpy_rad=[-3.14140498, -0.00258625116, 2.75771363],
        object_world_center_m=[0.0, 0.0, 0.100],
        candidate=candidate,
    )
    assert np.allclose(
        geometry["candidate_wrist_rpy_offset_rad"], [0.01, -0.02, 0.0]
    )
    assert np.allclose(
        geometry["hand_mount_rpy_rad"],
        [-3.13140498, -0.02258625116, 2.75771363],
    )
