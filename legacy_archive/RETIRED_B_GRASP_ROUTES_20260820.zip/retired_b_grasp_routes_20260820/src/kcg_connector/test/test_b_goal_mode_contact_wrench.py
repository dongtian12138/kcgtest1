import math

import pytest

from kcg_connector.grasp.b_goal_mode.contact_wrench_audit import (
    aggregate_contact_wrench,
    decompose_contact_impulse,
    normal_axis_angle_deg,
)


def test_contact_impulse_is_split_into_normal_and_tangential_force() -> None:
    sample = decompose_contact_impulse(
        contact_impulse_ns=[0.03, 0.04, 0.12],
        contact_normal=[0.0, 0.0, 1.0],
        contact_point_m=[1.0, 2.0, 3.0],
        dt_s=0.01,
        friction_coefficient=0.5,
    )
    assert sample.normal_force_n == pytest.approx(12.0)
    assert sample.tangential_force_n == pytest.approx(5.0)
    assert sample.friction_utilization == pytest.approx(5.0 / 6.0)
    assert sample.contact_point_m == (1.0, 2.0, 3.0)


def test_contact_normal_is_normalized_and_sign_independent() -> None:
    sample = decompose_contact_impulse(
        contact_impulse_ns=[0.0, 0.0, -0.1],
        contact_normal=[0.0, 0.0, 2.0],
        contact_point_m=[0.0, 0.0, 0.0],
        dt_s=0.02,
        friction_coefficient=0.5,
    )
    assert sample.normal_force_n == pytest.approx(5.0)
    assert sample.tangential_force_n == pytest.approx(0.0)
    assert normal_axis_angle_deg([0.0, 0.0, -1.0], [0.0, 0.0, 1.0]) == pytest.approx(0.0)


def test_zero_normal_is_rejected() -> None:
    with pytest.raises(ValueError, match="zero length"):
        decompose_contact_impulse(
            contact_impulse_ns=[1.0, 0.0, 0.0],
            contact_normal=[0.0, 0.0, 0.0],
            contact_point_m=[0.0, 0.0, 0.0],
            dt_s=1.0,
            friction_coefficient=0.5,
        )


def test_pair_aggregation_uses_projection_and_friction_anchors() -> None:
    aggregate = aggregate_contact_wrench(
        contact_impulses_ns=[[0.03, 0.0, 0.04], [0.0, 0.0, 0.06]],
        contact_normals=[[0.0, 0.0, 1.0], [0.0, 0.0, -1.0]],
        contact_points_m=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.1]],
        friction_anchor_impulses_ns=[[0.02, 0.0, 0.0]],
        dt_s=0.01,
        friction_coefficient=0.5,
        orient_normals_toward_point_m=[0.0, 0.0, 0.05],
    )
    assert aggregate.normal_force_n == pytest.approx(10.0)
    assert aggregate.tangential_force_n == pytest.approx(2.0)
    assert aggregate.friction_utilization == pytest.approx(0.4)
    assert aggregate.contact_total_impulse_norm_ns == pytest.approx(0.11)
    assert aggregate.tangential_source == "PHYSX_FRICTION_ANCHOR_IMPULSE"
    assert aggregate.contact_count == 2
    assert aggregate.friction_anchor_count == 1
    assert aggregate.maximum_impulse_reconstruction_error_ns < 1.0e-15


def test_pair_aggregation_falls_back_to_contact_tangent() -> None:
    aggregate = aggregate_contact_wrench(
        contact_impulses_ns=[[0.03, 0.04, 0.12]],
        contact_normals=[[0.0, 0.0, 1.0]],
        contact_points_m=[[0.0, 0.0, 0.0]],
        friction_anchor_impulses_ns=[],
        dt_s=0.01,
        friction_coefficient=0.5,
    )
    assert aggregate.normal_force_n == pytest.approx(12.0)
    assert aggregate.tangential_force_n == pytest.approx(5.0)
    assert aggregate.tangential_source == "CONTACT_VECTOR_TANGENTIAL_RESIDUAL"
