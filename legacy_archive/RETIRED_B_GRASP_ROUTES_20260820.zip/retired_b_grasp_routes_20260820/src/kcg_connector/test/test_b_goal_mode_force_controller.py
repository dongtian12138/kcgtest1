from pathlib import Path

import pytest

from kcg_connector.grasp.b_goal_mode.bumpless_force_controller import (
    BumplessThreeFingerForceController,
)
from kcg_connector.grasp.b_goal_mode.root_torque_force_calibration import (
    fit_g1_trace,
)


REPOSITORY = Path(__file__).resolve().parents[3]


def test_force_controller_switch_is_bumpless_and_first_integrator_step_is_frozen() -> None:
    controller = BumplessThreeFingerForceController(
        equilibrium_target_positions_rad=[0.70, 0.60, 0.70],
        common_rate_gain_rad_s_per_n=0.004,
        differential_rate_gain_rad_s_per_n=0.002,
        maximum_offset_rate_rad_s=0.04,
        maximum_target_step_rad=0.0002,
        minimum_cumulative_offset_rad=-0.01,
        maximum_cumulative_offset_rad=0.12,
    )
    first = controller.update(
        desired_force_n=[8.0, 8.0, 8.0],
        estimated_force_n=[0.2, 0.2, 0.2],
        dt_s=1.0 / 240.0,
    )
    assert first.first_step_integrator_frozen is True
    assert first.target_positions_rad == pytest.approx((0.70, 0.60, 0.70))
    second = controller.update(
        desired_force_n=[8.0, 8.0, 8.0],
        estimated_force_n=[0.2, 0.2, 0.2],
        dt_s=1.0 / 240.0,
    )
    assert max(abs(a - b) for a, b in zip(second.target_positions_rad, first.target_positions_rad)) <= 0.0002


def test_common_and_differential_modes_do_not_overwrite_each_other() -> None:
    controller = BumplessThreeFingerForceController(
        equilibrium_target_positions_rad=[0.0, 0.0, 0.0],
        common_rate_gain_rad_s_per_n=0.004,
        differential_rate_gain_rad_s_per_n=0.002,
        maximum_offset_rate_rad_s=1.0,
        maximum_target_step_rad=1.0,
        minimum_cumulative_offset_rad=-1.0,
        maximum_cumulative_offset_rad=1.0,
    )
    controller.update(desired_force_n=[0, 0, 0], estimated_force_n=[0, 0, 0], dt_s=0.1)
    output = controller.update(
        desired_force_n=[8, 8, 8], estimated_force_n=[2, 4, 6], dt_s=0.1
    )
    assert sum(output.differential_error_n) == pytest.approx(0.0)
    assert output.common_error_n == pytest.approx(4.0)
    assert controller.state()["common_and_differential_are_orthogonal"] is True


def test_g1_trace_produces_three_simulation_only_force_proxy_fits() -> None:
    sessions = sorted((REPOSITORY / "artifacts/b_goal_mode").glob("B_GOAL_MODE_SESSION_*"))
    if not sessions:
        pytest.skip("no G1 runtime evidence in this checkout")
    traces = list(sessions[-1].glob("experiments/G1_CONTACT_WRENCH_MEASUREMENT_01/G1_CONTACT_WRENCH_TRACE.csv"))
    if not traces:
        pytest.skip("no G1 trace in latest goal-mode session")
    fits = fit_g1_trace(traces[0])
    assert set(fits) == {"f1Link3", "f2Link2", "f3Link3"}
    assert all(5.0 < fit.normal_force_per_root_torque_n_per_nm < 20.0 for fit in fits.values())
    assert all(fit.sample_count >= 120 for fit in fits.values())
    assert all("NOT_HARDWARE" in fit.role for fit in fits.values())
