from pathlib import Path

import numpy as np
import pytest

from kcg_connector.d38999_tabletop_pick import iiwa14_grasp_tcp_transform
from kcg_connector.grasp.b_goal_mode.full_iiwa_integration import (
    CLAIM_SCOPE,
    advance_closure_target,
    build_full_iiwa_plan,
    compute_proprioceptive_load_transfer_compensation,
    load_full_iiwa_config,
    map_force_controller_targets,
)


REPOSITORY = Path(__file__).resolve().parents[3]
CONFIG = (
    REPOSITORY
    / "src/kcg_connector/config/b_goal_mode/full_iiwa_b_goal_mode.yaml"
)
RUNNER = (
    REPOSITORY
    / "src/kcg_connector/isaac/b_goal_mode/full_iiwa_table_pick.py"
)


def test_full_iiwa_plan_locks_selected_diagnostic_candidate() -> None:
    plan = build_full_iiwa_plan(CONFIG, repository_root=REPOSITORY)
    assert plan["status"] == "STATIC_PASS"
    assert plan["claim_scope"] == CLAIM_SCOPE
    assert plan["candidate_id"] == "BG_P120_Z15"
    assert plan["scene"]["moved_mass_kg"] == 0.310
    assert np.allclose(
        plan["scene"]["nominal_authorized_grip_center_world_m"],
        [0.520, -0.210, 0.2115],
        rtol=0.0,
        atol=1.0e-12,
    )
    assert plan["pad_contract"] == {
        "legacy_candidate_seed_primitive_count": 3,
        "runtime_pad_collision_count": 3,
        "runtime_tip_collision_count": 3,
        "runtime_side_collision_count": 3,
        "maximum_convex_hulls_per_terminal": 8,
        "runtime_collision_route": (
            "AUTHORED_VISUAL_CAD_BOUNDED_CONVEX_DECOMPOSITION"
        ),
        "whole_terminal_convex_hull_count": 0,
        "formal_b_passed": False,
    }


def test_full_iiwa_plan_override_is_bounded_to_existing_candidate_bundle() -> None:
    plan = build_full_iiwa_plan(
        CONFIG,
        repository_root=REPOSITORY,
        candidate_id="BG_P120_Z12",
    )
    assert plan["candidate_id"] == "BG_P120_Z12"
    assert plan["candidate_selection"] == "EXISTING_BOUNDED_12_POSE_OVERRIDE"
    with pytest.raises(ValueError, match="seed candidate missing or duplicated"):
        build_full_iiwa_plan(
            CONFIG,
            repository_root=REPOSITORY,
            candidate_id="NOT_A_FROZEN_CANDIDATE",
        )
    assert plan["formal_b_passed"] is False


def test_real_cad_top_candidate_uses_complete_collision_rescreen() -> None:
    baseline = build_full_iiwa_plan(
        CONFIG,
        repository_root=REPOSITORY,
        candidate_id="BG_P120_Z12",
    )
    plan = build_full_iiwa_plan(
        CONFIG,
        repository_root=REPOSITORY,
        candidate_id="CAD_P118_Q658_Q539",
    )
    candidate = plan["candidate"]
    assert (
        plan["candidate_selection"]
        == "REAL_CAD_COMPLETE_COLLISION_RESCREEN_TOP3"
    )
    assert candidate["seed_candidate_id"] == "BG_P120_Z12"
    assert candidate["candidate_generation"] == (
        "REAL_CAD_COMPLETE_COLLISION_RESCREEN"
    )
    assert candidate["closure_direction"] == [1.0, 1.0, 1.0]
    assert candidate["approach_flexion_rad"] == [0.638, 0.51875, 0.638]
    assert candidate["finger_flexion_targets_rad"] == [0.658, 0.53875, 0.658]
    assert candidate["closure_start_offset_m"] == 0.002
    assert candidate["minimum_table_clearance_m"] == 0.0012
    sweep = candidate["complete_cad_sweep"]
    assert sweep["sample_count"] == 101
    assert sweep["minimum_non_pad_clearance_m"] > 0.002
    assert sweep["minimum_tip_clearance_m"] > 0.004
    assert sweep["minimum_terminal_self_aabb_clearance_m"] > 0.025
    assert sweep["first_full_pad_contact_fraction"] > 0.97
    assert candidate["force_closure"] is True
    assert candidate["minimum_8n_lift_safety_factor"] > 4.3
    assert candidate["minimum_12n_other_task_safety_factor"] > 2.5
    assert np.allclose(
        plan["geometry"]["handbase_world_m"],
        candidate["target_handbase_world_m"],
        rtol=0.0,
        atol=2.0e-12,
    )
    assert np.allclose(
        plan["ik"]["grasp_tcp_position_world_m"],
        candidate["target_tcp_world_m"],
        rtol=0.0,
        atol=2.0e-9,
    )
    assert not np.allclose(
        plan["ik"]["grasp_tcp_position_world_m"],
        baseline["ik"]["grasp_tcp_position_world_m"],
        rtol=0.0,
        atol=1.0e-5,
    )
    assert plan["ik"]["minimum_hard_joint_margin_rad"] >= 0.02
    assert "z_offset_0.0020_m" in plan["ik"]["solutions"]


def test_signed_closure_mapping_preserves_controller_law() -> None:
    assert advance_closure_target(1.07, 0.95, -1.0, 0.01) == pytest.approx(1.06)
    assert advance_closure_target(0.951, 0.95, -1.0, 0.01) == pytest.approx(0.95)
    assert advance_closure_target(0.638, 0.658, 1.0, 0.01) == pytest.approx(0.648)
    assert advance_closure_target(0.657, 0.658, 1.0, 0.01) == pytest.approx(0.658)
    negative = map_force_controller_targets(
        [1.03, 0.90, 1.03],
        [1.04, 0.92, 1.06],
        [-1.0, -1.0, -1.0],
    )
    assert np.allclose(negative, [1.02, 0.88, 1.00])
    positive = map_force_controller_targets(
        [0.658, 0.53875, 0.658],
        [0.668, 0.55875, 0.688],
        [1.0, 1.0, 1.0],
    )
    assert np.allclose(positive, [0.668, 0.55875, 0.688])


def test_all_real_cad_candidates_keep_positive_unauthorized_clearance() -> None:
    config, _paths = load_full_iiwa_config(CONFIG, repository_root=REPOSITORY)
    records = config["motion"]["real_cad_grasp_candidates"]
    assert [row["candidate_id"] for row in records] == [
        "CAD_P118_Q658_Q539",
        "CAD_P100_Q662_Q522",
        "CAD_P136_Q659_Q538",
    ]
    assert [row["collision_truth_score"] for row in records] == [100.0, 90.0, 80.0]
    for row in records:
        assert row["closure_direction"] == [1.0, 1.0, 1.0]
        assert row["closure_start_offset_m"] == 0.002
        assert row["minimum_table_clearance_m"] >= 0.001
        sweep = row["complete_cad_sweep"]
        assert sweep["sample_count"] == 101
        assert sweep["minimum_non_pad_clearance_m"] > 0.0
        assert sweep["minimum_tip_clearance_m"] > 0.0
        assert sweep["minimum_terminal_self_aabb_clearance_m"] > 0.0


def test_full_iiwa_fixed_q7_lift_family_reproduces_tcp_targets() -> None:
    plan = build_full_iiwa_plan(CONFIG, repository_root=REPOSITORY)
    grasp_tcp = np.asarray(plan["ik"]["grasp_tcp_position_world_m"], dtype=float)
    fixed_q7 = float(plan["ik"]["fixed_q7_rad"])
    expected_offsets = (0.0, 0.0005, 0.002, 0.010, 0.040)
    assert plan["ik"]["minimum_hard_joint_margin_rad"] >= 0.18
    for offset in expected_offsets:
        record = plan["ik"]["solutions"][f"z_offset_{offset:.4f}_m"]
        joints = np.asarray(record["arm_rad"], dtype=float)
        transform = np.asarray(
            iiwa14_grasp_tcp_transform(tuple(joints)), dtype=float
        )
        assert abs(float(joints[6]) - fixed_q7) <= 1.0e-12
        assert np.allclose(
            transform[:3, 3],
            grasp_tcp + np.asarray((0.0, 0.0, offset)),
            rtol=0.0,
            atol=2.0e-9,
        )
        assert float(record["position_error_m"]) <= 2.0e-9
        assert float(record["rotation_error_rad"]) <= 1.0e-9


def test_load_transfer_compensation_uses_only_frozen_ik_tangent() -> None:
    plan = build_full_iiwa_plan(CONFIG, repository_root=REPOSITORY)
    original = np.asarray(
        plan["ik"]["solutions"]["z_offset_0.0005_m"]["arm_rad"], dtype=float
    ).copy()
    corrected, report = compute_proprioceptive_load_transfer_compensation(
        plan,
        target_offset_m=0.0005,
        achieved_tcp_offset_m=0.000427083,
    )
    original_after = np.asarray(
        plan["ik"]["solutions"]["z_offset_0.0005_m"]["arm_rad"], dtype=float
    )
    assert np.array_equal(original, original_after)
    assert report["source"] == "ROBOT_JOINT_POSITION_FK_ONLY"
    assert report["online_object_truth_used"] is False
    assert report["online_contact_truth_used"] is False
    assert report["stored_ik_waypoints_modified"] is False
    assert report["secant_offsets_m"] == [0.0, 0.002]
    assert report["maximum_joint_target_delta_rad"] < 2.0e-4
    assert report["predicted_tcp_lateral_correction_m"] < 2.0e-7
    assert report["predicted_tcp_rotation_delta_rad"] < 1.0e-6
    assert abs(report["predicted_tcp_z_correction_m"] - 0.000072917) < 5.0e-9
    assert corrected[6] == original[6]


def test_full_iiwa_config_preserves_frozen_force_and_truth_boundaries() -> None:
    config, paths = load_full_iiwa_config(CONFIG, repository_root=REPOSITORY)
    frozen = config["frozen_boundaries"]
    assert frozen["candidate_id"] == "BG_P120_Z15"
    assert frozen["object_mass_kg"] == 0.310
    assert frozen["pad_object_friction"] == 0.50
    assert frozen["first_grip_force_n_per_finger"] == 8.0
    assert frozen["nominal_assembly_force_n_per_finger"] == 10.0
    assert frozen["adaptive_force_ceiling_n_per_finger"] == 12.0
    assert frozen["absolute_force_ceiling_n_per_finger"] == 15.0
    assert config["force_quiet_hold"] == {
        "entry_consecutive_force_steps": 48,
        "hold_steps": 120,
        "tare_baseline_steps": 120,
        "locked_baseline_steps": 48,
        "position_baseline_multiplier": 5.0,
        "qdot_fd_baseline_multiplier": 12.0,
        "maximum_position_peak_to_peak_rad": 2.0e-5,
        "maximum_qdot_fd_rms_rad_s": 2.0e-3,
        "raw_to_fd_diagnostic_ratio": 10.0,
    }
    assert config["threshold_roles"][
        "raw_generalized_velocity_0p03_rad_s"
    ] == "SLIP_MONITOR_ONLY"
    assert config["threshold_roles"]["rho_0p70"] == "DEMOTE_SOFT"
    assert config["threshold_roles"]["wrist_moment_0p30_nm"] == "DEMOTE_SOFT"
    for key in (
        "sdf_allowed",
        "coacd_allowed",
        "whole_terminal_convex_hull_allowed",
        "object_pose_write_after_physics_allowed",
        "online_object_pose_control_allowed",
        "online_contact_truth_control_allowed",
    ):
        assert frozen[key] is False
    assert set(paths) == {
        "robot_asset",
        "tabletop_config",
        "connector_asset",
        "selected_goal_config",
        "candidate_bundle",
        "pad_core",
        "source_hand_urdf",
        "g1_trace",
    }


def test_full_iiwa_runner_uses_complete_cad_collision_and_has_no_pose_write() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    assert 'old_collision.CreateCollisionEnabledAttr().Set(False)' in source
    assert "PAD_CORE_CAPSULE" not in source
    assert '"BLUE_PAD_CONTACT"' in source
    assert '"RED_TIP_BLOCKER"' in source
    assert '"FINGERTIP_BODY_BLOCKER"' in source
    assert '"ALL_REMAINING_AUTHORED_VISUAL_CAD_COMPONENTS"' in source
    assert '"complete_terminal_source_component_count"' in source
    assert 'physics_step("COLLISION_SAFE_HAND_AT_HIGH_APPROACH", index)' in source
    assert 'physics_step("PAD_PRECLOSE_AT_40MM", index)' not in source
    assert '"DESCEND_TO_CLOSURE_START"' in source
    assert '"DESCEND_TO_NOMINAL_GRASP"' not in source
    assert '"D0_CLOSURE_START_HOLD"' in source
    assert '"FULL_IIWA_D0_ZERO_PRECONTACT"' in source
    assert "closure_start_offset" in source
    assert "closure_descent_steps" in source
    assert "index + 1 >= closure_descent_steps" in source
    precheck = source[
        source.index('        if run_arguments.scenario == "precheck":') :
        source.index("        tare_effort_samples =")
    ]
    assert "lift_targets_m" not in precheck
    assert "NO_CONTACT_LIFT" not in precheck
    assert '"closure_executed": False' in precheck
    assert '"lift_executed": False' in precheck
    assert "map_force_controller_targets(" in source
    assert '"precheck_requires_zero_contact": True' in source
    assert "FULL_IIWA_STANDARD_COLLIDER_FIRST_AUTHORIZED_PAD_CONTACT_PASS" not in source
    assert "PhysxConvexDecompositionCollisionAPI" in source
    assert 'filter_groups(finger_group, ())' in source
    assert '"robot_environment_filters": []' in source
    assert '"PRECONTACT_TARE_CONTAMINATED"' not in source
    assert "set_world_pose" not in source
    assert "set_local_pose" not in source
    assert "MeshCollisionAPI" in source
    assert "convexDecomposition" in source
    assert "CoACD" not in source
    assert '"physx_contact_changes_commands": False' in source
    assert '"object_pose_changes_commands": False' in source
    assert '"formal_b_passed": False' in source
    assert '"FORCE_QUIET_HOLD"' in source
    assert '"posthoc_diagnostic_force_stable_role": "DIAGNOSTIC_ONLY"' in source
    assert '"LIFT_LOAD_TRANSFER_COMPENSATION"' in source
    assert '"arm_tracking_compensation_z_m"' in source


def test_force_controller_receives_only_proprioceptive_estimate() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    force_block = source[source.index("    def force_step(") : source.index(
        "    def maybe_recover_wrist("
    )]
    assert "estimated_input = estimate_forces(previous_efforts)" in force_block
    assert "estimated_force_n=estimated_input" in force_block
    assert "contacts" not in force_block
    assert "object_diagnostics" not in force_block
    stability_block = source[
        source.index("            proprio_stable = bool(") : source.index(
            "            force_stable_steps =", source.index(
                "            proprio_stable = bool("
            )
        )
    ]
    assert "diagnostic" not in stability_block
    assert "contact" not in stability_block
    assert "values[1]" not in stability_block
    assert "proprioceptive_velocity_excess_trigger_rad_s" not in stability_block


def test_wrist_soft_target_does_not_trigger_recovery() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    recovery = source[source.index("    def maybe_recover_wrist(") : source.index(
        "    def update_adaptive_force("
    )]
    assert 'safety["wrist_quality_soft_target_nm"]' not in recovery
    assert recovery.count('safety["wrist_recovery_gate_nm"]') == 1
    assert 'safety["wrist_recovery_confirmation_steps"]' in recovery


def test_single_sample_rho_is_not_a_final_failure() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    assert 'safety["sustained_rho_failure_steps"]' in source
    assert "maximum_rho_above_one_consecutive" in source
    assert "maximum_friction_utilization <=" not in source


def test_each_lift_stage_requires_object_following_and_table_clearance() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    assert '"achieved_object_lift_m": object_lift' in source
    assert '"relative_axial_slip_m": relative_axial_slip' in source
    assert '"table_clearance_passed": table_clearance_passed' in source
    assert 'g6["maximum_relative_axial_slip_m"]' in source
