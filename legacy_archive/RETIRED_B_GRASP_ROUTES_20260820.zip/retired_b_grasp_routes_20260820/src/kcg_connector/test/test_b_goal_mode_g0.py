from pathlib import Path
import xml.etree.ElementTree as ET

import pytest

from kcg_connector.grasp.b_goal_mode.lift_axis_controller import (
    design_lift_axis,
    minimum_jerk,
)
from kcg_connector.grasp.b_goal_mode.minimal_hand_rig import (
    HAND_LINKS,
    build_collision_free_hand_urdf,
)


REPOSITORY = Path(__file__).resolve().parents[3]
SOURCE_URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"


def test_mass_derived_lift_design_meets_contract() -> None:
    design = design_lift_axis(
        moved_mass_kg=2.091942,
        targets_m=[0.0005, 0.002, 0.010, 0.040],
        gravity_m_s2=9.81,
        minimum_tracking_ratio=0.98,
        maximum_absolute_error_m=0.00005,
        stiffness_margin=1.25,
        damping_ratio=1.0,
        drive_force_multiplier=3.0,
    )
    assert design.drive_force_to_weight_ratio == pytest.approx(3.0)
    assert design.design_error_budget_m == pytest.approx(0.00001)
    assert design.predicted_static_error_m < 0.00001
    assert design.kp_n_per_m > 2_000_000
    assert design.kd_n_s_per_m > 0.0


def test_minimum_jerk_endpoints_and_monotonicity() -> None:
    values = [minimum_jerk(0.002, 0.010, index, 100) for index in range(100)]
    assert values[-1] == pytest.approx(0.010)
    assert all(left <= right for left, right in zip(values, values[1:]))


def test_g0_rig_preserves_inertials_and_removes_geometry(tmp_path: Path) -> None:
    destination = tmp_path / "g0.urdf"
    evidence = build_collision_free_hand_urdf(
        source_urdf=SOURCE_URDF,
        destination=destination,
        lift_effort_limit_n=61.56585306,
    )
    assert evidence["moved_mass_kg"] == pytest.approx(2.091942)
    assert evidence["collision_count"] == 0
    assert evidence["real_hand_inertials_preserved"] is True
    root = ET.parse(destination).getroot()
    for name in HAND_LINKS:
        link = root.find(f"link[@name='{name}']")
        assert link is not None
        assert not link.findall("collision")
        assert not link.findall("visual")
    lift = root.find("joint[@name='lift_z']")
    assert lift is not None
    assert lift.find("axis").get("xyz") == "0 0 1"
