from pathlib import Path

import yaml


REPOSITORY = Path(__file__).resolve().parents[3]
RUNNER = REPOSITORY / "src/kcg_connector/isaac/b_goal_mode/g1_contact_wrench_measurement.py"
CONFIG = REPOSITORY / "src/kcg_connector/config/b_goal_mode/b_goal_mode.yaml"


def test_g1_runner_has_truth_read_only_contact_channels() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    assert "get_full_contact_report" in source
    assert "aggregate_contact_wrench" in source
    assert "normal_force_n" in source
    assert "tangential_force_n" in source
    assert "friction_utilization" in source
    assert "contact_normal" in source
    assert "contact_point_m" in source
    assert "friction_anchors_offset" in source
    assert "np.linalg.norm(np.asarray(contact.impulse" not in source
    assert "set_world_pose" not in source
    assert "set_local_pose" not in source
    assert "object_view" not in source
    assert "SDF" not in source
    assert "CoACD" not in source


def test_g1_config_preserves_frozen_values() -> None:
    config = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    frozen = config["frozen_boundaries"]
    assert frozen["object_mass_kg"] == 0.310
    assert frozen["pad_object_friction"] == 0.50
    assert frozen["first_grip_force_n_per_finger"] == 8.0
    assert frozen["nominal_assembly_force_n_per_finger"] == 10.0
    assert frozen["adaptive_force_ceiling_n_per_finger"] == 12.0
    assert frozen["absolute_force_ceiling_n_per_finger"] == 15.0
    assert frozen["sdf_allowed"] is False
    assert frozen["coacd_allowed"] is False
    assert frozen["whole_terminal_convex_hull_allowed"] is False
    assert frozen["object_pose_write_after_physics_allowed"] is False
