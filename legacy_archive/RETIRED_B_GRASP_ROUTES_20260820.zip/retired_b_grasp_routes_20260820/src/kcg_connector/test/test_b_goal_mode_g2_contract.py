from pathlib import Path


REPOSITORY = Path(__file__).resolve().parents[3]
RUNNER = REPOSITORY / "src/kcg_connector/isaac/b_goal_mode/g2_independent_contact_acquisition.py"
LATCH = REPOSITORY / "src/kcg_connector/kcg_connector/grasp/b_goal_mode/independent_contact_latch.py"


def test_g2_runner_uses_proprioceptive_independent_contact_latches() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    latch_source = LATCH.read_text(encoding="utf-8")
    assert "IndependentContactLatch" in source
    assert "compute_tare_statistics" in source
    assert '"CONTACT_LOCKED"' in source
    assert '"CONTACT_LOST_RESUME_SEARCH"' in latch_source
    assert "search_velocity_rad_s" in source
    assert "contact_truth_changes_motion_commands" in source
    assert '"root_joint_effort", "joint_position"' in source
    assert "get_full_contact_report" in source
    assert "set_world_pose" not in source
    assert "set_local_pose" not in source
    assert "np.linalg.norm(np.asarray(contact.impulse" not in source
    assert "SDF" not in source
    assert "CoACD" not in source


def test_g2_locked_finger_target_is_not_incremented() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    locked_branch = source.index("if latch.locked:")
    search_branch = source.index("else:", locked_branch)
    locked_text = source[locked_branch:search_branch]
    assert "lock_target_rad" in locked_text
    assert "search_increment" not in locked_text
