from pathlib import Path


REPOSITORY = Path(__file__).resolve().parents[3]
RUNNER = REPOSITORY / "src/kcg_connector/isaac/b_goal_mode/g3_task_force_closure.py"


def test_g3_is_offline_actual_contact_geometry_analysis() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    assert "build_friction_pyramid" in source
    assert "signed_basis_force_closure" in source
    assert "minimum_other_task_safety_factor_at_12n" in source
    assert "reference_abort_envelope_is_gate" in source
    assert "get_full_contact_report" not in source
    assert "SimulationApp" not in source
    assert "3 * mu" not in source
    assert "formal_b_passed" in source
