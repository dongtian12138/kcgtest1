from pathlib import Path


REPOSITORY = Path(__file__).resolve().parents[3]
RUNNER = REPOSITORY / "src/kcg_connector/isaac/b_goal_mode/g456_compliant_grasp_lift.py"


def test_g456_controller_truth_boundary_and_required_phases() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    assert "IndependentContactLatch" in source
    assert "BumplessThreeFingerForceController" in source
    assert "fit_g1_trace" in source
    assert '"INDEPENDENT_CONTACT_SEARCH"' in source
    assert '"FORCE_TARGET_RAMP"' in source
    assert '"UNSUPPORTED_HOLD"' in source
    assert '"FINAL_HOLD"' in source
    assert '"top3_comparison": "TOP3_DYNAMIC_COMPARISON"' in source
    assert "TOP3_CANDIDATES" in source
    assert "REEXECUTED_IN_CURRENT_PROCESS" in source
    assert "object_pose_write_after_first_physics_step_count" in source
    assert "physx_contact_changes_nominal_force_command" in source
    assert "set_world_pose" not in source
    assert "set_local_pose" not in source
    assert "np.linalg.norm(np.asarray(contact.impulse" not in source
    assert "SDF" not in source
    assert "CoACD" not in source
    assert "maximum_rho_above_one_consecutive" in source
    assert '"rho_0p70_role": "DEMOTE_SOFT_POSTHOC_QUALITY_METRIC"' in source
    assert "and first_target_jump <=" not in source


def test_force_controller_update_receives_estimate_not_contact_measurement() -> None:
    source = RUNNER.read_text(encoding="utf-8")
    block = source[source.index("def force_step"):source.index("def base_result")]
    assert "estimated_input = estimate_forces(previous_efforts)" in block
    assert "estimated_force_n=estimated_input" in block
    assert "measurements" not in block
