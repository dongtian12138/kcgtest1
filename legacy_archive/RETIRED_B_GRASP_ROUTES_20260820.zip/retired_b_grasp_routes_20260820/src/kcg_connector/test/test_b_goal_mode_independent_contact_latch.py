import pytest

from kcg_connector.grasp.b_goal_mode.independent_contact_latch import (
    IndependentContactLatch,
    compute_tare_statistics,
)


def test_tare_threshold_has_absolute_floor_and_noise_gate() -> None:
    quiet = compute_tare_statistics(
        [0.10 + 0.0001 * ((index % 3) - 1) for index in range(48)],
        minimum_threshold_nm=0.03,
        sigma_multiplier=5.0,
    )
    assert quiet.mean_effort_nm == pytest.approx(0.10, abs=1.0e-5)
    assert quiet.contact_threshold_nm == pytest.approx(0.03)
    noisy = compute_tare_statistics(
        [0.10 + 0.02 * ((index % 2) * 2 - 1) for index in range(48)],
        minimum_threshold_nm=0.03,
        sigma_multiplier=5.0,
    )
    assert noisy.contact_threshold_nm >= 0.03


def test_each_latch_freezes_only_after_twelve_consecutive_samples() -> None:
    tare = compute_tare_statistics(
        [0.0] * 48, minimum_threshold_nm=0.03, sigma_multiplier=5.0
    )
    latch = IndependentContactLatch(
        tare=tare,
        confirmation_steps=12,
        loss_threshold_fraction=0.5,
        loss_confirmation_steps=12,
    )
    for step in range(1, 12):
        assert latch.update(
            effort_nm=0.04,
            current_target_rad=0.70 + step * 0.001,
            actual_position_rad=0.69,
            physics_step=step,
        ) is None
        assert not latch.locked
    assert latch.update(
        effort_nm=0.04,
        current_target_rad=0.712,
        actual_position_rad=0.70,
        physics_step=12,
    ) == "CONTACT_LOCKED"
    assert latch.locked
    assert latch.lock_target_rad == pytest.approx(0.712)
    assert latch.first_contact_step == 12


def test_only_lost_finger_resumes_search() -> None:
    tare = compute_tare_statistics(
        [0.0] * 48, minimum_threshold_nm=0.03, sigma_multiplier=5.0
    )
    latches = [
        IndependentContactLatch(
            tare=tare,
            confirmation_steps=2,
            loss_threshold_fraction=0.5,
            loss_confirmation_steps=2,
        )
        for _ in range(3)
    ]
    for step in (1, 2):
        for latch in latches:
            latch.update(
                effort_nm=0.04,
                current_target_rad=0.7,
                actual_position_rad=0.69,
                physics_step=step,
            )
    assert all(latch.locked for latch in latches)
    for step in (3, 4):
        latches[0].update(
            effort_nm=0.0,
            current_target_rad=0.7,
            actual_position_rad=0.69,
            physics_step=step,
        )
        for latch in latches[1:]:
            latch.update(
                effort_nm=0.04,
                current_target_rad=0.7,
                actual_position_rad=0.69,
                physics_step=step,
            )
    assert not latches[0].locked
    assert latches[1].locked and latches[2].locked
    assert latches[0].recovery_count == 1
