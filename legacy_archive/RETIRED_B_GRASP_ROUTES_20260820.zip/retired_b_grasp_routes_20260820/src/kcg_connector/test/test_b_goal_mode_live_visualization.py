from pathlib import Path

import numpy as np

from kcg_connector.grasp.b_goal_mode.live_visualization import (
    FULL_ASSEMBLY_OVERVIEW_EYE_M,
    FULL_ASSEMBLY_OVERVIEW_TARGET_M,
    LIVE_RESOLUTION,
    OVERLAY_ROOT,
    generate_camera_candidates,
    score_camera_observation,
)


REPOSITORY = Path(__file__).resolve().parents[3]
RUNNER = (
    REPOSITORY
    / "src/kcg_connector/isaac/b_goal_mode/full_iiwa_table_pick.py"
)
VISUALIZER = (
    REPOSITORY
    / "src/kcg_connector/kcg_connector/grasp/b_goal_mode/live_visualization.py"
)
GUI_LAUNCHER = REPOSITORY / "run_full_iiwa_b_gui.sh"


def test_camera_candidates_cover_required_view_diversity() -> None:
    candidates = generate_camera_candidates(
        (0.520, -0.210, 0.220), (0.0, -1.0, 0.0)
    )
    assert len(candidates) == 8
    assert {candidate.elevation_deg for candidate in candidates} == {18.0, 32.0}
    assert {candidate.distance_m for candidate in candidates} == {0.36, 0.48}
    assert len({round(candidate.azimuth_deg, 6) for candidate in candidates}) == 8


def test_full_assembly_overview_is_a_distinct_wide_view() -> None:
    eye = np.asarray(FULL_ASSEMBLY_OVERVIEW_EYE_M, dtype=np.float64)
    target = np.asarray(FULL_ASSEMBLY_OVERVIEW_TARGET_M, dtype=np.float64)
    assert np.linalg.norm(eye - target) > 5.0
    runner = RUNNER.read_text(encoding="utf-8")
    assert '"eye_m": FULL_ASSEMBLY_OVERVIEW_EYE_M' in runner
    assert '"target_m": FULL_ASSEMBLY_OVERVIEW_TARGET_M' in runner
    assert "CreateFocalLengthAttr(32.0)" in runner


def test_camera_gate_rejects_black_frame() -> None:
    candidate = generate_camera_candidates(
        (0.520, -0.210, 0.220), (0.0, -1.0, 0.0)
    )[0]
    width, height = LIVE_RESOLUTION
    report = score_camera_observation(
        rgb=np.zeros((height, width, 3), dtype=np.uint8),
        depth_m=np.full((height, width), candidate.distance_m, dtype=float),
        candidate=candidate,
        object_aabb_min_m=(0.510, -0.220, 0.210),
        object_aabb_max_m=(0.530, -0.200, 0.230),
        pad_centers_world_m=(
            (0.515, -0.210, 0.220),
            (0.520, -0.205, 0.220),
            (0.525, -0.210, 0.220),
        ),
        contact_center_world_m=(0.520, -0.210, 0.220),
    )
    assert report["near_black_fraction"] == 1.0
    assert report["passed"] is False


def test_live_visualization_is_overlay_only_and_runner_has_no_pose_replay() -> None:
    runner = RUNNER.read_text(encoding="utf-8")
    visualizer = VISUALIZER.read_text(encoding="utf-8")
    assert "--visual-overlay-complete" in runner
    assert "--record-live-video" in runner
    assert 'world.step(render=False, update_fabric=True)' in runner
    assert "capture_visual_milestone" in runner
    assert "set_world_pose" not in runner
    assert "set_local_pose" not in runner
    assert "set_world_pose" not in visualizer
    assert "set_local_pose" not in visualizer
    assert OVERLAY_ROOT in visualizer
    assert "VISUAL_OVERLAY_WRITE_ONLY" in visualizer
    assert "physical_dynamics_unchanged" in visualizer


def test_gui_launcher_uses_live_overlay_and_supervisor() -> None:
    launcher = GUI_LAUNCHER.read_text(encoding="utf-8")
    assert "run_b_goal_mode_supervisor.sh" in launcher
    assert "--visual-overlay-complete" in launcher
    assert "--gui-camera-preset" in launcher
    assert "overview|grasp|side" in launcher
    assert "--gui-hold-seconds" in launcher
    assert "publication_render_replay.py" not in launcher.split("COMMAND=(", 1)[-1]
