from __future__ import annotations

import numpy as np

from kcg_connector.grasp.b_goal_mode.quiet_hold import assess_force_quiet_hold


def assessment(*, drifting: bool = False):
    dt = 1.0 / 240.0
    phase = np.linspace(0.0, 2.0 * np.pi, 120)
    tare = np.zeros((120, 3), dtype=np.float64)
    locked = np.column_stack(
        [
            1.0e-6 * np.sin(phase),
            1.2e-6 * np.cos(phase),
            0.8e-6 * np.sin(phase + 0.3),
        ]
    )
    hold = np.column_stack(
        [
            1.5e-6 * np.sin(phase),
            1.4e-6 * np.cos(phase),
            1.0e-6 * np.sin(phase + 0.5),
        ]
    )
    if drifting:
        hold[:, 0] += np.linspace(0.0, 3.0e-5, len(hold))
    return assess_force_quiet_hold(
        tare_positions_rad=tare,
        locked_positions_rad=locked,
        hold_positions_rad=hold,
        hold_raw_generalized_velocity_rad_s=np.full((120, 3), 0.04),
        hold_target_positions_rad=np.tile((0.7, 0.6, 0.7), (120, 1)),
        hold_estimated_force_n=np.tile((7.7, 7.8, 7.9), (120, 1)),
        dt_s=dt,
        target_force_n=8.0,
        force_tolerance_n=0.75,
        position_baseline_multiplier=5.0,
        qdot_fd_baseline_multiplier=5.0,
        maximum_position_peak_to_peak_rad=2.0e-5,
        maximum_qdot_fd_rms_rad_s=0.002,
        raw_to_fd_diagnostic_ratio=10.0,
    )


def test_raw_generalized_velocity_cannot_fail_a_quiet_position_hold() -> None:
    report = assessment()
    assert report.passed
    payload = report.as_dict()
    assert payload["target_positions_exactly_frozen"]
    assert payload["qdot_fd_rms_within_bound"]
    assert payload["diagnostic_flags"] == [
        "RAW_GENERALIZED_VELOCITY_NOT_USED_FOR_SETTLE"
    ]
    assert all(value > 10.0 for value in payload["raw_to_fd_rms_ratio"])


def test_actual_monotonic_position_drift_fails_quiet_hold() -> None:
    report = assessment(drifting=True)
    assert not report.passed
    assert not report.as_dict()["position_peak_to_peak_within_bound"]
