from __future__ import annotations

from kcg_connector.grasp.b_goal_mode.slip_monitor import ProprioceptiveSlipMonitor


def monitor() -> ProprioceptiveSlipMonitor:
    return ProprioceptiveSlipMonitor(
        baseline_estimated_force_n=(7.5, 7.6, 7.5),
        baseline_maximum_abs_velocity_rad_s=(0.032, 0.031, 0.033),
        initial_force_target_n=8.0,
        force_bias_shift_trigger_n=0.50,
        velocity_excess_trigger_rad_s=0.030,
        force_drop_trigger_n=1.0,
        confirmation_steps=12,
        stabilization_steps=24,
        stabilization_force_tolerance_n=0.75,
    )


def test_transient_does_not_confirm_but_twelve_steps_do() -> None:
    detector = monitor()
    for _ in range(11):
        observation = detector.update(
            estimated_force_n=(8.3, 8.3, 8.3),
            joint_velocity_rad_s=(0.02, 0.02, 0.02),
            force_target_n=8.0,
        )
        assert not observation.confirmed_event
    observation = detector.update(
        estimated_force_n=(8.3, 8.3, 8.3),
        joint_velocity_rad_s=(0.02, 0.02, 0.02),
        force_target_n=8.0,
    )
    assert observation.confirmed_event
    assert "ROOT_LOAD_BIAS_SHIFT" in observation.reasons


def test_force_increment_requires_24_stable_steps_before_rearming() -> None:
    detector = monitor()
    for _ in range(12):
        event = detector.update(
            estimated_force_n=(8.3, 8.3, 8.3),
            joint_velocity_rad_s=(0.02, 0.02, 0.02),
            force_target_n=8.0,
        )
    assert event.confirmed_event
    detector.acknowledge_force_increment()
    for _ in range(23):
        observation = detector.update(
            estimated_force_n=(9.0, 9.0, 9.0),
            joint_velocity_rad_s=(0.10, 0.10, 0.10),
            force_target_n=9.0,
        )
        assert not observation.armed
        assert not observation.confirmed_event
    observation = detector.update(
        estimated_force_n=(9.0, 9.0, 9.0),
        joint_velocity_rad_s=(0.10, 0.10, 0.10),
        force_target_n=9.0,
    )
    assert observation.armed
    assert not observation.confirmed_event
    for _ in range(12):
        observation = detector.update(
            estimated_force_n=(9.0, 9.0, 9.0),
            joint_velocity_rad_s=(0.02, 0.08, 0.02),
            force_target_n=9.0,
        )
    assert observation.confirmed_event
    assert "ABNORMAL_JOINT_MOTION" in observation.reasons


def test_quiet_proprioception_remains_armed_without_event() -> None:
    detector = monitor()
    for _ in range(100):
        observation = detector.update(
            estimated_force_n=(7.6, 7.7, 7.6),
            joint_velocity_rad_s=(0.02, 0.02, 0.02),
            force_target_n=8.0,
        )
    assert observation.armed
    assert not observation.risk_detected
    assert detector.event_count == 0
