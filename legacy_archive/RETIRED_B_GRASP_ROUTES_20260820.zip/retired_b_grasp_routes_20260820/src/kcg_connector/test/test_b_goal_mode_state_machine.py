import json
from pathlib import Path

import pytest

from kcg_connector.grasp.b_goal_mode.goal_state_machine import advance_gate


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_gate_advances_only_on_matching_pass(tmp_path: Path) -> None:
    state = tmp_path / "state.json"
    result = tmp_path / "result.json"
    write_json(state, {"current_goal_gate": "G0_LIFT_AXIS_TRACKING"})
    write_json(result, {"status": "PASS", "goal_id": "G0_LIFT_AXIS_TRACKING"})
    updated = advance_gate(
        state_path=state,
        completed_gate="G0_LIFT_AXIS_TRACKING",
        result_path=result,
    )
    assert updated["completed_gates"] == ["G0_LIFT_AXIS_TRACKING"]
    assert updated["current_goal_gate"] == "G1_CONTACT_WRENCH_MEASUREMENT"
    assert updated["status"] == "READY"


def test_gate_rejects_failed_result(tmp_path: Path) -> None:
    state = tmp_path / "state.json"
    result = tmp_path / "result.json"
    write_json(state, {"current_goal_gate": "G0_LIFT_AXIS_TRACKING"})
    write_json(result, {"status": "FAIL", "goal_id": "G0_LIFT_AXIS_TRACKING"})
    with pytest.raises(ValueError, match="does not pass"):
        advance_gate(
            state_path=state,
            completed_gate="G0_LIFT_AXIS_TRACKING",
            result_path=result,
        )
