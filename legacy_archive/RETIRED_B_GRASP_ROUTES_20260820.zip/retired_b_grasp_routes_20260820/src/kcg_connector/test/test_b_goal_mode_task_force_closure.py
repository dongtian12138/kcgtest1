import numpy as np
import pytest

from kcg_connector.grasp.b_goal_mode.task_force_closure import (
    build_friction_pyramid,
    circular_contact_metrics,
    maximum_wrench_scale,
    minimum_peak_normal_force,
    signed_basis_force_closure,
)


def radial_three_contact_pyramid():
    radius = 0.024
    points = []
    normals = []
    for angle in (0.0, 2.0 * np.pi / 3.0, 4.0 * np.pi / 3.0):
        radial = np.asarray((np.cos(angle), np.sin(angle), 0.0))
        points.append((radius * radial).tolist())
        normals.append((-radial).tolist())
    return build_friction_pyramid(
        contact_points_m=points,
        contact_normals=normals,
        center_of_mass_m=[0.0, 0.0, 0.0],
        friction_coefficient=0.5,
        edges_per_contact=16,
    )


def test_three_radial_friction_contacts_have_full_wrench_rank() -> None:
    pyramid = radial_three_contact_pyramid()
    assert pyramid.grasp_matrix.shape == (6, 48)
    assert np.linalg.matrix_rank(pyramid.grasp_matrix, tol=1.0e-9) == 6
    closure = signed_basis_force_closure(
        pyramid,
        characteristic_length_m=0.024,
        normal_force_cap_n_per_finger=12.0,
    )
    assert closure["force_closure"] is True
    assert closure["minimum_normalized_signed_basis_scale"] > 0.0


def test_wrench_scale_and_minimum_peak_force_are_consistent() -> None:
    pyramid = radial_three_contact_pyramid()
    wrench = [0.0, 0.0, -3.0411, 0.0, 0.0, 0.0]
    scale = maximum_wrench_scale(
        pyramid, external_wrench=wrench, normal_force_cap_n_per_finger=8.0
    )
    required = minimum_peak_normal_force(
        pyramid, external_wrench=wrench, maximum_allowed_normal_force_n=12.0
    )
    assert scale["solver_success"] is True
    assert scale["maximum_scale"] > 2.0
    assert required["solver_success"] is True
    assert required["minimum_peak_normal_force_n"] < 8.0
    assert required["equilibrium_residual_norm"] < 1.0e-8


def test_circular_distribution_reports_three_equal_gaps() -> None:
    radius = 0.024
    points = [
        [radius * np.cos(angle), radius * np.sin(angle), 0.0]
        for angle in (0.0, 2.0 * np.pi / 3.0, 4.0 * np.pi / 3.0)
    ]
    metrics = circular_contact_metrics(points, [0.0, 0.0, 0.0])
    assert metrics["minimum_gap_deg"] == pytest.approx(120.0)
    assert metrics["maximum_gap_deg"] == pytest.approx(120.0)
