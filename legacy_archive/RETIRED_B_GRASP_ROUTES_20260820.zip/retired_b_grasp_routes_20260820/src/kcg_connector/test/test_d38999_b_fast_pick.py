import json
from pathlib import Path

import numpy as np

from kcg_connector.grasp.d38999_b_fast_pick import (
    build_candidates,
    minimum_jerk,
    required_normal_force_per_finger,
)


REPOSITORY = Path(__file__).resolve().parents[3]
URDF = REPOSITORY / "artifacts/kcg_connector/urdf/handarm.urdf"
PROXY = (
    REPOSITORY
    / "artifacts/agent_control/tasks/D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2"
    / "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
    / "BLUE_PAD_CONSERVATIVE_CONVEX_PROXY_V1"
    / "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json"
)
FROZEN = REPOSITORY / "src/kcg_connector/config/d38999_b_fast_pick_candidates_v1.json"


def test_force_budget_matches_conservative_three_finger_grasp() -> None:
    force = required_normal_force_per_finger(
        object_mass_kg=0.310,
        friction_coefficient=0.30,
        safety_factor=2.0,
    )
    assert np.isclose(force, 6.758, atol=1.0e-9)
    assert force < 15.0


def test_minimum_jerk_is_bounded_and_monotonic() -> None:
    values = np.asarray([minimum_jerk(x) for x in np.linspace(0.0, 1.0, 101)])
    assert values[0] == 0.0 and values[-1] == 1.0
    assert np.all(np.diff(values) >= -1.0e-12)


def test_candidate_generation_is_deterministic_and_well_conditioned() -> None:
    first = build_candidates(
        urdf_path=URDF,
        proxy_manifest_path=PROXY,
        grasp_z_mm=(14.0, 19.0, 24.0),
    )
    second = build_candidates(
        urdf_path=URDF,
        proxy_manifest_path=PROXY,
        grasp_z_mm=(14.0, 19.0, 24.0),
    )
    assert first == second
    assert first["candidate_count"] == 3
    assert first["candidates"][0]["candidate_id"] == "PAD_Z19"
    for candidate in first["candidates"]:
        assert min(candidate["predicted_radial_alignment"]) > 0.999
        assert max(abs(x) for x in candidate["predicted_radial_gaps_m"]) < 10.0e-6
        assert candidate["predicted_contact_z_spread_m"] < 0.00005
        assert candidate["minimum_joint_margin_rad"] > 0.20


def test_frozen_candidate_manifest_matches_generator() -> None:
    frozen = json.loads(FROZEN.read_text())
    regenerated = build_candidates(
        urdf_path=URDF,
        proxy_manifest_path=PROXY,
        grasp_z_mm=(14.0, 19.0, 24.0),
    )
    assert frozen == regenerated
