import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


REPOSITORY = Path(__file__).resolve().parents[3]
ISAAC_DIR = REPOSITORY / "src/kcg_connector/isaac"
RUNNER_PATH = ISAAC_DIR / "d38999_b_fast_pick_rig.py"
if str(ISAAC_DIR) not in sys.path:
    sys.path.insert(0, str(ISAAC_DIR))
SPEC = importlib.util.spec_from_file_location("d38999_b_fast_pick_rig", RUNNER_PATH)
assert SPEC is not None and SPEC.loader is not None
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)


def test_fast_rig_urdf_is_mesh_free_and_preserves_hand_topology(tmp_path: Path) -> None:
    destination = tmp_path / "fast_rig.urdf"
    evidence = RUNNER._build_fast_rig_urdf(
        source_urdf=RUNNER.DEFAULT_URDF,
        destination=destination,
        handbase_world_xyz=(0.0, 0.0, 0.42),
        hand_mount_rpy=(-3.1414, -0.0026, 2.7577),
    )
    root = ET.parse(destination).getroot()
    assert evidence["all_mesh_collisions_removed"]
    assert evidence["real_hand_inertials_preserved"]
    assert root.find("joint[@name='lift_z']") is not None
    assert root.find("joint[@name='hand_mount']") is not None
    for name in RUNNER.HAND_LINKS:
        link = root.find(f"link[@name='{name}']")
        assert link is not None
        assert not link.findall("visual")
        assert not link.findall("collision")


def test_dry_run_builds_candidate_specific_rig(tmp_path: Path) -> None:
    arguments = RUNNER._arguments(
        [
            "--output-dir",
            str(tmp_path / "output"),
            "--kit-portable-root",
            str(tmp_path / "portable"),
            "--candidate-id",
            "PAD_Z19",
            "--dry-run",
        ]
    )
    report = RUNNER._dry_run(arguments)
    assert report["status"] == "DRY_RUN_PASS"
    assert report["candidate"]["candidate_id"] == "PAD_Z19"
    assert report["pad_primitive_count"] == 15
    assert report["old_whole_terminal_hull_count"] == 0
    assert Path(report["rig_urdf"]["temporary_urdf"]).exists()


def test_runner_is_primitive_only_and_does_not_restore_h_stack() -> None:
    source = RUNNER_PATH.read_text(encoding="utf-8")
    assert "UsdGeom.Capsule.Define" in source
    assert "UsdGeom.Cylinder.Define" in source
    assert "UsdGeom.Cube.Define" in source
    assert "UsdGeom.Mesh.Define" not in source
    assert "MeshCollisionAPI" not in source
    assert "SDF" not in source
    assert "H26" not in source and "H27" not in source
    assert '"formal_b_passed": False' in source
    assert '"online_object_pose_used": False' in source
    assert '"online_contact_truth_used": False' in source


def test_tilt_angle_ignores_cylinder_yaw_but_detects_tilt() -> None:
    identity = (1.0, 0.0, 0.0, 0.0)
    yaw_90 = (2**-0.5, 0.0, 0.0, 2**-0.5)
    pitch_10 = (0.996194698, 0.0, 0.087155743, 0.0)
    assert RUNNER._tilt_angle_rad(identity, yaw_90) < 1.0e-9
    assert abs(RUNNER._tilt_angle_rad(identity, pitch_10) - 0.174532925) < 1.0e-6
