import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest

from kcg_connector.grasp.d38999_pad_contact_roles import repository_root


ISAAC_DIR = repository_root() / "src/kcg_connector/isaac"
RUNNER_PATH = ISAAC_DIR / "d38999_pad_conservative_convex_compatibility_smoke.py"
if str(ISAAC_DIR) not in sys.path:
    sys.path.insert(0, str(ISAAC_DIR))
SPEC = importlib.util.spec_from_file_location("pad_convex_smoke", RUNNER_PATH)
assert SPEC is not None and SPEC.loader is not None
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)


def test_authorization_accepts_only_planned_non_h_run(tmp_path: Path) -> None:
    arguments = RUNNER._arguments(
        [
            "--output-dir",
            str(tmp_path / "output"),
            "--kit-portable-root",
            str(tmp_path / "portable"),
            "--run-id",
            RUNNER.RUN_ID,
            "--steps",
            "1500",
        ]
    )
    assert arguments.run_id == "B-V5-PAD-CONSERVATIVE-CONVEX-COMPATIBILITY-SMOKE-01"
    assert "H26" not in arguments.run_id and "H27" not in arguments.run_id
    with pytest.raises(ValueError):
        RUNNER._arguments(
            [
                "--output-dir",
                str(tmp_path / "bad"),
                "--kit-portable-root",
                str(tmp_path / "bad-portable"),
                "--run-id",
                "H26",
            ]
        )


def test_verified_inputs_preserve_blue_pad_lineage() -> None:
    source_entry, proxy_entry, paths = RUNNER._verified_inputs(
        RUNNER.DEFAULT_SOURCE_ASSET_DIR, RUNNER.DEFAULT_PROXY_ASSET_DIR
    )
    assert source_entry["link_name"] == "f2Link2"
    assert proxy_entry["link_name"] == "f2Link2"
    assert proxy_entry["capsule_count"] == 5
    assert len(proxy_entry["capsules"]) == 5
    assert paths["proxy_manifest"].is_file()


def test_fk_fixture_starts_clear_and_preloads_only_center_capsule() -> None:
    _source, proxy, paths = RUNNER._verified_inputs(
        RUNNER.DEFAULT_SOURCE_ASSET_DIR, RUNNER.DEFAULT_PROXY_ASSET_DIR
    )
    tip = RUNNER.legacy._load_arrays(paths["tip"])
    fixture = RUNNER._derive_proxy_fixture(proxy, tip)
    assert fixture["initial_separation_pass"]
    assert fixture["center_capsule_preload_pass"]
    assert fixture["adjacent_capsules_not_preloaded"]
    assert fixture["tip_radially_clear_pass"]
    assert min(fixture["initial_capsule_surface_gaps_m"]) > 0.047
    assert np.isclose(
        fixture["final_capsule_surface_gaps_m"][2],
        -RUNNER.FIXTURE_PRELOAD_M,
        atol=1.0e-9,
    )


def test_runner_authors_analytic_capsules_without_sdf_or_old_hull() -> None:
    source = RUNNER_PATH.read_text(encoding="utf-8")
    assert "UsdGeom.Capsule.Define" in source
    assert 'Set("PAD_CONTACT_SURFACE_PROXY")' in source
    assert 'len(pad_colliders) == 5' in source
    assert '"f2Link2_convex" in row["path"]' in source
    assert "PhysxSDFMeshCollisionAPI" not in source
    assert "CreateSdfResolutionAttr" not in source


def test_controller_truth_boundary_is_fixed_time_and_posthoc_only() -> None:
    source = RUNNER_PATH.read_text(encoding="utf-8")
    assert "FIXED_TIME_MINIMUM_JERK_JOINT_POSITION" in source
    assert "get_world_pose" not in source
    assert "set_world_pose" not in source
    assert "set_local_pose" not in source
    assert source.index("robot.apply_action") < source.index("get_full_contact_report")
    assert '"control_reads_contact_names": False' in source
    assert '"control_reads_contact_normals": False' in source
    assert '"object_pose_write_after_physics_start_count": 0' in source
