from pathlib import Path

import numpy as np
import pytest

from kcg_connector.grasp.d38999_pad_conservative_convex_proxy import (
    CAPSULE_CYLINDER_HEIGHT_M,
    CAPSULE_RADIUS_M,
    COLLISION_ROUTE,
    OUTWARD_INSET_M,
    build_proxy_manifest,
    write_proxy_asset,
)
from kcg_connector.grasp.d38999_pad_contact_roles import repository_root


SOURCE_ASSET = (
    repository_root()
    / "artifacts"
    / "agent_control"
    / "tasks"
    / "D38999-AUTONOMOUS-DYNAMIC-CLOSEOUT-V2"
    / "DYN-B-V5-PAD-FORCE-CLOSURE-MULTI-GRASP"
    / "BLUE_PAD_SDF_SOURCE_ASSET_V2"
)


@pytest.fixture(scope="module")
def manifest() -> dict:
    return build_proxy_manifest(SOURCE_ASSET)


def test_proxy_route_and_frozen_boundaries(manifest: dict) -> None:
    assert manifest["collision_route"] == COLLISION_ROUTE
    assert manifest["whole_terminal_convex_hull_allowed"] is False
    assert manifest["whole_terminal_convex_hull_count"] == 0
    assert manifest["visual_geometry_changed"] is False
    assert manifest["robot_mass_changed"] is False
    assert manifest["robot_inertia_changed"] is False
    assert manifest["finger_dimensions_expanded"] is False
    assert manifest["online_contact_truth_use_allowed"] is False
    assert manifest["derivation"]["parameter_grid_used"] is False
    assert manifest["derivation"]["per_tread_selection_used"] is False


def test_three_homologous_pad_sets_have_five_capsules(manifest: dict) -> None:
    assert [link["link_name"] for link in manifest["links"]] == [
        "f1Link3",
        "f2Link2",
        "f3Link3",
    ]
    assert manifest["pad_collision_primitive_count_per_finger"] == 5
    assert manifest["pad_collision_primitive_count_total"] == 15
    assert {link["capsule_count"] for link in manifest["links"]} == {5}
    for link in manifest["links"]:
        assert len(link["capsules"]) == 5
        assert all(
            capsule["radius_m"] == CAPSULE_RADIUS_M
            and capsule["cylinder_height_m"] == CAPSULE_CYLINDER_HEIGHT_M
            for capsule in link["capsules"]
        )


def test_connector_facing_envelope_is_strictly_inward(manifest: dict) -> None:
    for link in manifest["links"]:
        metrics = link["task_geometry_metrics"]
        assert metrics["minimum_outward_inset_m"] >= OUTWARD_INSET_M - 1.0e-12
        assert (
            metrics["outward_cap_coordinate_m"]
            < metrics["minimum_authored_contact_coordinate_m"]
        )
        assert link["static_checks"][
            "connector_facing_proxy_never_ahead_of_any_contact_vertex"
        ]


def test_task_relevant_boundary_and_depth_margins_pass(manifest: dict) -> None:
    for link in manifest["links"]:
        checks = link["static_checks"]
        assert all(checks.values())
        metrics = link["task_geometry_metrics"]
        assert metrics["longitudinal_edge_margin_m"] > 0.007
        assert metrics["width_edge_margin_m"] > 0.001
        assert metrics["pad_back_margin_m"] > 0.004
        assert metrics["actual_interstrip_recession_m"] < 0.001


def test_tip_is_independent_and_never_formal_pad(manifest: dict) -> None:
    for link in manifest["links"]:
        tip = link["tip_collision"]
        assert tip["collision_role"] == "TIP_END_SURFACE"
        assert tip["physics_material_role"] == "BASE_FRICTION"
        assert tip["formal_pad_contact_allowed"] is False
        assert all(
            capsule["physics_material_role"] == "PAD_FRICTION"
            for capsule in link["capsules"]
        )


def test_f1_f3_geometry_is_identical_and_f2_is_registered(manifest: dict) -> None:
    links = {link["link_name"]: link for link in manifest["links"]}
    for key in ("source_contact_bounds_in_frame_m", "task_geometry_metrics"):
        if key == "task_geometry_metrics":
            names = (
                "contact_relief_m",
                "longitudinal_edge_margin_m",
                "width_edge_margin_m",
                "pad_back_margin_m",
            )
            for name in names:
                assert np.isclose(
                    links["f1Link3"][key][name], links["f3Link3"][key][name]
                )
        else:
            assert links["f1Link3"][key] == links["f3Link3"][key]
    assert links["f2Link2"]["capsule_count"] == links["f1Link3"]["capsule_count"]


def test_output_is_immutable_and_reproducible(tmp_path: Path, manifest: dict) -> None:
    output = tmp_path / "proxy"
    generated = write_proxy_asset(SOURCE_ASSET, output)
    assert generated == manifest
    assert (output / "PAD_CONSERVATIVE_CONVEX_PROXY_MANIFEST.json").is_file()
    with pytest.raises(FileExistsError):
        write_proxy_asset(SOURCE_ASSET, output)
