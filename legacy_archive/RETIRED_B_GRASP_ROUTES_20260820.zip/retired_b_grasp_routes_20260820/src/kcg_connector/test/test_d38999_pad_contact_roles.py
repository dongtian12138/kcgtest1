"""Static acceptance for user-confirmed blue PAD / red TIP semantics."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pytest

from kcg_connector.grasp.d38999_pad_contact_roles import (
    ContactRole,
    FINGER_PAD_ROLE_SPECS,
    USER_SEMANTIC_AUTHORITY,
    build_finger_pad_role,
    face_role_records,
)


REPOSITORY = Path(__file__).resolve().parents[3]
EXPECTED_CONTACT_FACE_COUNTS = {
    "f1Link3": 492,
    "f2Link2": 490,
    "f3Link3": 492,
}
EXPECTED_CONTACT_AREAS_M2 = {
    "f1Link3": 0.000420170726,
    "f2Link2": 0.000420131867,
    "f3Link3": 0.000420170726,
}


@pytest.mark.parametrize("spec", FINGER_PAD_ROLE_SPECS)
def test_user_confirmed_blue_pad_and_red_tip_are_not_reversed(spec):
    build = build_finger_pad_role(spec)
    assert build.source_sha256 == spec.authored_mesh_sha256
    assert build.pad_component_rank_by_area == 1
    assert build.tip_component_rank_by_area == 4
    assert len(build.pad_component.faces) == 2479
    assert len(build.pad_component.vertices) == 1250
    assert len(build.tip_component.faces) == 1076
    assert build.diagnostics["semantic_authority"] == USER_SEMANTIC_AUTHORITY
    assert build.diagnostics["red_component_4_role"] == "TIP"
    assert build.diagnostics["red_component_4_pad_use_allowed"] is False
    assert build.diagnostics["rejected_wrong_branch_reason"] == (
        "component_4_is_tip_not_pad"
    )


@pytest.mark.parametrize("spec", FINGER_PAD_ROLE_SPECS)
def test_real_closure_identifies_the_broad_blue_inner_contact_surface(spec):
    build = build_finger_pad_role(spec)
    assert len(build.pad_contact_face_ids) == EXPECTED_CONTACT_FACE_COUNTS[
        spec.link_name
    ]
    assert len(build.pad_contact_face_ids) + len(build.pad_side_face_ids) == len(
        build.pad_component.faces
    )
    assert set(build.pad_face_roles) == {
        ContactRole.PAD_CONTACT_SURFACE.value,
        ContactRole.PAD_SIDE_SURFACE.value,
    }
    contact_area = float(
        np.sum(build.pad_component.area_faces[build.pad_contact_face_ids])
    )
    assert contact_area == pytest.approx(
        EXPECTED_CONTACT_AREAS_M2[spec.link_name], abs=2.0e-12
    )
    assert np.all(
        build.minimum_closure_alignment[build.pad_contact_face_ids] >= 0.90
    )
    assert build.diagnostics["connector_event_50um_reused_as_pad_mesh_gate"] is False
    assert build.diagnostics["convex_piece_limit_enforced"] is False
    assert build.diagnostics["isaac_sdf_cooked_verified"] is False
    assert build.diagnostics["dynamic_use_allowed"] is False


def test_three_blue_pad_bodies_are_same_source_geometry_with_measured_registration():
    builds = [build_finger_pad_role(spec) for spec in FINGER_PAD_ROLE_SPECS]
    assert builds[0].pad_component_registration["symmetric_chamfer_max_m"] <= 1e-12
    assert builds[2].pad_component_registration["symmetric_chamfer_max_m"] <= 1e-12
    assert builds[1].pad_component_registration["symmetric_chamfer_max_m"] == (
        pytest.approx(4.075715e-9, abs=1.0e-12)
    )


@pytest.mark.parametrize("spec", FINGER_PAD_ROLE_SPECS)
def test_role_face_map_is_deterministic_and_keeps_tip_independent(spec):
    first = build_finger_pad_role(spec)
    second = build_finger_pad_role(spec)
    assert np.array_equal(first.pad_contact_face_ids, second.pad_contact_face_ids)
    assert np.array_equal(first.pad_side_face_ids, second.pad_side_face_ids)
    assert face_role_records(first) == face_role_records(second)
    records = face_role_records(first)
    assert [row["source_face_key"] for row in records] == sorted(
        row["source_face_key"] for row in records
    )
    assert sum(
        row["contact_role"] == ContactRole.TIP_END_SURFACE.value for row in records
    ) == len(first.tip_component.faces)


def test_generator_emits_one_exact_sdf_source_mesh_per_finger(tmp_path):
    script = REPOSITORY / "src/kcg_connector/isaac/build_d38999_pad_role_meshes.py"
    module_spec = importlib.util.spec_from_file_location("pad_sdf_source_builder", script)
    assert module_spec is not None and module_spec.loader is not None
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)

    output = tmp_path / "pad_sdf_sources"
    manifest = module.generate_pad_role_assets(output, REPOSITORY)
    assert manifest["status"] == (
        "STATIC_EXACT_BLUE_PAD_SOURCE_EXTRACTED_SDF_COOKING_PENDING"
    )
    assert manifest["collision_route"] == "PHYSX_SDF"
    assert manifest["pad_collision_source_mesh_count_per_finger"] == 1
    assert manifest["whole_distal_link_convex_hull_allowed"] is False
    assert manifest["whole_distal_link_convex_hull_runtime_removal_verified"] is False
    assert manifest["fixed_convex_piece_limit"] is None
    assert manifest["pad_all_surface_reconstruction_tolerance_m"] is None
    assert manifest["connector_event_50um_reused_as_pad_mesh_gate"] is False
    assert manifest["coacd_used"] is False
    assert manifest["isaac_sdf_cooked_verified"] is False
    assert manifest["dynamic_use_allowed"] is False
    assert manifest["online_control_role_truth_allowed"] is False
    assert len(manifest["links"]) == 3

    for spec, link in zip(FINGER_PAD_ROLE_SPECS, manifest["links"], strict=True):
        build = build_finger_pad_role(spec)
        with np.load(output / link["pad_sdf_source_arrays"]) as arrays:
            assert np.array_equal(
                arrays["points_local_m"], build.pad_component.vertices
            )
            assert np.array_equal(arrays["faces"], build.pad_component.faces)
            assert np.array_equal(
                arrays["pad_contact_face_ids"], build.pad_contact_face_ids
            )
            assert np.array_equal(arrays["pad_side_face_ids"], build.pad_side_face_ids)
        with np.load(output / link["tip_base_collision_source_arrays"]) as arrays:
            assert np.array_equal(
                arrays["points_local_m"], build.tip_component.vertices
            )
            assert np.array_equal(arrays["faces"], build.tip_component.faces)
        assert link["diagnostics"]["pad_collision_source_mesh_count"] == 1
        assert link["diagnostics"]["analytic_convex_proxy_used"] is False
        assert link["diagnostics"]["per_tread_collision_reconstruction_used"] is False

    with pytest.raises(FileExistsError):
        module.generate_pad_role_assets(output, REPOSITORY)
