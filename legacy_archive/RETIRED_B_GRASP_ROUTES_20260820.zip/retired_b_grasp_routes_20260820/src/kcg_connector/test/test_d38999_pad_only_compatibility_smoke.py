import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import numpy as np
import pytest

from kcg_connector.grasp.d38999_pad_contact_roles import repository_root


ISAAC_DIR = repository_root() / "src/kcg_connector/isaac"
RUNNER_PATH = ISAAC_DIR / "d38999_pad_only_compatibility_smoke.py"
if str(ISAAC_DIR) not in sys.path:
    sys.path.insert(0, str(ISAAC_DIR))
SPEC = importlib.util.spec_from_file_location("pad_only_smoke", RUNNER_PATH)
assert SPEC is not None and SPEC.loader is not None
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)


def test_authorization_accepts_only_pad_only_non_h_run(tmp_path: Path) -> None:
    arguments = RUNNER._arguments(
        [
            "--output-dir",
            str(tmp_path / "output"),
            "--kit-portable-root",
            str(tmp_path / "portable"),
            "--run-id",
            RUNNER.RUN_ID,
            "--steps",
            "1500",
        ]
    )
    assert arguments.run_id == "B-V5-PAD-ONLY-SMOKE-01"
    assert "H26" not in arguments.run_id and "H27" not in arguments.run_id
    with pytest.raises(ValueError):
        RUNNER._arguments(
            [
                "--output-dir",
                str(tmp_path / "bad"),
                "--kit-portable-root",
                str(tmp_path / "bad-portable"),
                "--run-id",
                "H26",
            ]
        )


def test_pad_only_urdf_preserves_topology_and_inertials_but_removes_geometry(
    tmp_path: Path,
) -> None:
    destination = tmp_path / "pad_only.urdf"
    evidence = RUNNER._build_pad_only_f2_urdf(
        RUNNER.legacy.SOURCE_URDF, destination
    )
    root = ET.parse(destination).getroot()
    assert evidence["selected_links"] == ["handbase_link", "f2Link1", "f2Link2"]
    assert evidence["selected_joints"] == ["f2j1", "f2j2"]
    assert evidence["removed_original_collision_element_count"] == 3
    assert evidence["output_visual_element_count"] == 0
    assert evidence["output_collision_element_count"] == 0
    assert evidence["real_joint_topology_mass_inertia_preserved"]
    for name in evidence["selected_links"]:
        link = root.find(f"link[@name='{name}']")
        assert link is not None
        assert len(link.findall("inertial")) == 1
        assert not link.findall("visual")
        assert not link.findall("collision")
    f2j2 = root.find("joint[@name='f2j2']")
    assert f2j2 is not None
    assert f2j2.find("mimic").attrib == {
        "joint": "f2j1",
        "multiplier": "1",
        "offset": "0",
    }


def test_verified_inputs_keep_five_pad_capsules_and_unconfirmed_old_blocker() -> None:
    source, proxy, paths = RUNNER._verified_inputs(
        RUNNER.DEFAULT_SOURCE_ASSET_DIR, RUNNER.DEFAULT_PROXY_ASSET_DIR
    )
    timeout = json.loads(paths["full_chain_timeout_result"].read_text())
    assert source["link_name"] == "f2Link2"
    assert proxy["capsule_count"] == 5
    assert len(proxy["capsules"]) == 5
    assert timeout["true_blocking_collision_prim"] is None
    assert timeout["tip_rootcause_confirmed"] is False
    assert timeout["pad_capsule_incompatibility_claimed"] is False


def test_pad_only_fixture_keeps_exact_proxy_and_removes_tip_dependency() -> None:
    _source, proxy, _paths = RUNNER._verified_inputs(
        RUNNER.DEFAULT_SOURCE_ASSET_DIR, RUNNER.DEFAULT_PROXY_ASSET_DIR
    )
    fixture = RUNNER._derive_pad_only_fixture(proxy)
    assert fixture["tip_collision_enabled"] is False
    assert fixture["initial_separation_pass"]
    assert fixture["center_capsule_preload_pass"]
    assert fixture["adjacent_capsules_not_preloaded"]
    assert min(fixture["initial_capsule_surface_gaps_m"]) > 0.047
    assert np.isclose(
        fixture["final_capsule_surface_gaps_m"][2],
        -RUNNER.full_chain.FIXTURE_PRELOAD_M,
        atol=1.0e-9,
    )


def test_runner_is_analytic_pad_only_without_cooking_or_mesh() -> None:
    source = RUNNER_PATH.read_text(encoding="utf-8")
    assert "UsdGeom.Capsule.Define" in source
    assert 'Set("PAD_CONTACT_SURFACE_PROXY")' in source
    assert "UsdGeom.Mesh.Define" not in source
    assert "MeshCollisionAPI" not in source
    assert "get_physx_cooking" not in source
    assert "TIP_BASE_COLLISION" not in source
    assert '"tip_collision_body_count": 0' in source
    assert '"other_chain_collision_body_count"' in source


def test_first_step_precedes_stage_export_and_truth_is_posthoc_only() -> None:
    source = RUNNER_PATH.read_text(encoding="utf-8")
    assert source.index("world.step(render=False)") < source.index("stage.Export")
    assert source.index("robot.apply_action") < source.index(
        "get_full_contact_report"
    )
    assert "FIRST_STEP_DEADLINE_S = 60.0" in source
    assert "get_world_pose" not in source
    assert "set_world_pose" not in source
    assert "set_local_pose" not in source
    assert '"control_reads_contact_names": False' in source
    assert '"control_reads_contact_normals": False' in source
    assert '"object_pose_write_after_physics_start_count": 0' in source
